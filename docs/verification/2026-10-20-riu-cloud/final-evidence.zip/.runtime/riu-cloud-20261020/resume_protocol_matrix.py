"""Continue unchanged frozen-build matrix after managed-environment restart."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
ROOT=Path('/workspace/Reverie-Cli')
BASE=ROOT/'.runtime/riu-cloud-20261020'
original=BASE/'anonymous-matrix-protocol-fixed'
output=BASE/'anonymous-matrix-protocol-resumed'
output.mkdir(exist_ok=False)
verifier=ROOT/'scripts/verification/riu_quality_benchmark.py'
report=json.loads((original/'matrix.json').read_text())
report.update(continuation_of=str(original),environment_restart=str(original/'environment-interruption-2.json'),excluded_interrupted_sample=str(original/'calculator-2'),verifier_sha256=hashlib.sha256(verifier.read_bytes()).hexdigest())
for sample in report['samples']:
 sample['origin']='before-environment-restart; completed with cleanup'
for attempt in (2,3):
 for task in ('calculator','table','chart','form','comparison','text'):
  name=f'{task}-{attempt}'
  child=output/name
  command=[sys.executable,str(verifier),'--exe',str(ROOT/'ReverieCli-ui/release/linux-unpacked/ReverieUI'),'--output',str(child),'--source','standard','--api-url','https://text.pollinations.ai/v1','--model','openai-fast','--attempts','1','--tasks',task,'--timeout','900','--shared-profile']
  with (output/f'{name}.txt').open('w')as log:
   done=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
  entry={'task':task,'attempt':attempt,'exit_code':done.returncode,'report':str(child/'report.json'),'origin':'fresh profile after environment restart'}
  if (child/'report.json').exists():
   entry['cases']=json.loads((child/'report.json').read_text()).get('cases',[])
  report['samples'].append(entry)
  (output/'matrix.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
  print(json.dumps({'sample':name,'exit_code':done.returncode}),flush=True)
