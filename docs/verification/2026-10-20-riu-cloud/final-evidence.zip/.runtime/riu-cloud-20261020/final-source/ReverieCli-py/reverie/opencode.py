"""OpenCode Zen free-model source helpers."""

from __future__ import annotations

import os
import re
import time
from hashlib import sha256
from typing import Any, Dict, List, Optional
from urllib.parse import urlsplit, urlunsplit
from uuid import uuid4

import requests

from .proxy import normalize_proxy_url, requests_proxy_dict
from .version import __version__


OPENCODE_DEFAULT_API_URL = "https://opencode.ai/zen/v1"
OPENCODE_DEFAULT_ENDPOINT = "/chat/completions"
OPENCODE_DEFAULT_MODELS_URL = "https://opencode.ai/zen/v1/models"
OPENCODE_DEFAULT_MODEL_ID = "deepseek-v4-flash-free"
OPENCODE_DEFAULT_MODEL_DISPLAY_NAME = "DeepSeek V4 Flash Free"
OPENCODE_API_KEY_HINT_URL = "https://opencode.ai/zen"
OPENCODE_DEFAULT_CONTEXT_TOKENS = 200_000
OPENCODE_DEFAULT_MAX_TOKENS = 16_384
OPENCODE_MUSE_SPARK_CONTEXT_TOKENS = 1_000_000
OPENCODE_MUSE_SPARK_MAX_OUTPUT_TOKENS = 65_536
OPENCODE_DEFAULT_TEMPERATURE = 0.7
OPENCODE_DEFAULT_TOP_P = 1.0
OPENCODE_MODEL_CACHE_TTL_SECONDS = 300
OPENCODE_LIVE_MODEL_DESCRIPTION = "OpenCode Zen model returned by the live API catalog."
OPENCODE_CLIENT_NAME = "reverie-cli"
OPENCODE_USER_AGENT = f"Reverie-Cli/{__version__}"
_OPENCODE_RESPONSES_MODEL_PREFIXES = ("gpt-", "grok-", "muse-spark-")
_OPENCODE_ANTHROPIC_MODEL_PREFIXES = ("claude-", "qwen")

_REASONING_LABELS = {
    "none": ("Non-think", "Disable reasoning for a faster direct response."),
    "low": ("Low", "Use a low reasoning effort."),
    "medium": ("Medium", "Use the provider-recommended balanced reasoning effort."),
    "high": ("High", "Use a high reasoning effort for complex work."),
    "max": ("Max", "Use the model's maximum reasoning effort."),
}


def _reasoning_options(*values: str) -> List[Dict[str, str]]:
    return [
        {
            "id": value,
            "label": _REASONING_LABELS[value][0],
            "description": _REASONING_LABELS[value][1],
        }
        for value in values
    ]


def _opencode_model(
    model_id: str,
    display_name: str,
    description: str,
    *,
    context_length: int = OPENCODE_DEFAULT_CONTEXT_TOKENS,
    max_output_tokens: int = OPENCODE_DEFAULT_MAX_TOKENS,
    vision: bool = False,
    vision_modalities: Optional[List[str]] = None,
    thinking: bool = True,
    thinking_control: str = "fixed",
    thinking_options: Optional[List[Dict[str, str]]] = None,
    default_thinking_choice: str = "",
    free: bool = True,
    transport: str = "openai-chat",
    endpoint: str = "/chat/completions",
) -> Dict[str, Any]:
    return {
        "id": str(model_id or "").strip(),
        "display_name": str(display_name or model_id or "").strip(),
        "description": str(description or "").strip(),
        "transport": str(transport or "openai-chat"),
        "endpoint": str(endpoint or "/chat/completions"),
        "context_length": int(context_length or OPENCODE_DEFAULT_CONTEXT_TOKENS),
        "max_output_tokens": int(max_output_tokens or OPENCODE_DEFAULT_MAX_TOKENS),
        "vision": bool(vision),
        "vision_modalities": list(vision_modalities or (["image"] if vision else [])),
        "thinking": bool(thinking),
        "thinking_control": str(thinking_control or ("fixed" if thinking else "none")),
        "thinking_options": list(thinking_options or []),
        "default_thinking_choice": str(default_thinking_choice or ""),
        "tool_calling": True,
        "free": bool(free),
    }


_OPENCODE_MODEL_CATALOG: List[Dict[str, Any]] = [
    _opencode_model(
        "big-pickle",
        "Big Pickle",
        "OpenCode Zen stealth free model exposed through chat.completions.",
        context_length=200_000,
        max_output_tokens=32_000,
    ),
    _opencode_model(
        "deepseek-v4-flash-free",
        "DeepSeek V4 Flash Free",
        "OpenCode Zen free DeepSeek V4 Flash model with selectable reasoning effort.",
        context_length=200_000,
        max_output_tokens=128_000,
        thinking_control="effort",
        thinking_options=_reasoning_options("low", "high", "max"),
        default_thinking_choice="high",
    ),
    _opencode_model(
        "mimo-v2.5-free",
        "MiMo-V2.5 Free",
        "OpenCode Zen free native multimodal MiMo-V2.5 model.",
        context_length=200_000,
        max_output_tokens=32_000,
        vision=True,
        vision_modalities=["image", "audio", "video"],
    ),
    _opencode_model(
        "muse-spark-1.3",
        "Muse Spark 1.3",
        "OpenCode Zen Muse Spark 1.3 model served through the Responses API.",
        context_length=OPENCODE_MUSE_SPARK_CONTEXT_TOKENS,
        max_output_tokens=OPENCODE_MUSE_SPARK_MAX_OUTPUT_TOKENS,
        free=False,
        transport="openai-responses",
        endpoint="/responses",
    ),
    _opencode_model(
        "muse-spark-1.3-contributor-free",
        "Muse Spark 1.3 Contributor Free",
        "OpenCode Zen contributor-free Muse Spark 1.3 model served through the Responses API.",
        context_length=OPENCODE_MUSE_SPARK_CONTEXT_TOKENS,
        max_output_tokens=OPENCODE_MUSE_SPARK_MAX_OUTPUT_TOKENS,
        transport="openai-responses",
        endpoint="/responses",
    ),
    _opencode_model(
        "muse-spark-1.2",
        "Muse Spark 1.2",
        "OpenCode Zen Muse Spark 1.2 model served through the Responses API.",
        context_length=OPENCODE_MUSE_SPARK_CONTEXT_TOKENS,
        max_output_tokens=OPENCODE_MUSE_SPARK_MAX_OUTPUT_TOKENS,
        free=False,
        transport="openai-responses",
        endpoint="/responses",
    ),
    _opencode_model(
        "muse-spark-1.2-contributor-free",
        "Muse Spark 1.2 Contributor Free",
        "OpenCode Zen contributor-free Muse Spark 1.2 model served through the Responses API.",
        context_length=OPENCODE_MUSE_SPARK_CONTEXT_TOKENS,
        max_output_tokens=OPENCODE_MUSE_SPARK_MAX_OUTPUT_TOKENS,
        transport="openai-responses",
        endpoint="/responses",
    ),
    _opencode_model(
        "hy3-free",
        "Hy3 Free",
        "OpenCode Zen free Hy3 reasoning model.",
        context_length=190_000,
        max_output_tokens=64_000,
        thinking_control="effort",
        thinking_options=_reasoning_options("low", "medium", "high"),
        default_thinking_choice="high",
    ),
    _opencode_model(
        "nemotron-3-ultra-free",
        "Nemotron 3 Ultra Free",
        "OpenCode Zen free Nemotron 3 Ultra chat.completions model.",
        context_length=1_000_000,
        max_output_tokens=128_000,
    ),
    _opencode_model(
        "ling-3.0-flash-fin-free",
        "Ling 3.0 Flash Fin Free",
        "OpenCode Zen free Ling 3.0 Flash Fin reasoning model.",
        context_length=262_144,
        max_output_tokens=32_768,
    ),
    _opencode_model(
        "nemotron-3.5-lightning-free",
        "Nemotron 3.5 Lightning Free",
        "OpenCode Zen free Nemotron 3.5 Lightning reasoning model.",
    ),
    _opencode_model(
        "laguna-s-2.1-free",
        "Laguna S 2.1 Free",
        "OpenCode Zen free Laguna S 2.1 coding model with selectable reasoning effort.",
        context_length=256_000,
        max_output_tokens=32_000,
        thinking_control="effort",
        thinking_options=_reasoning_options("low", "medium", "high"),
        default_thinking_choice="medium",
    ),
    _opencode_model(
        "deepseek-v4-pro",
        "DeepSeek V4 Pro",
        "OpenCode Zen paid DeepSeek V4 Pro model available with an API key.",
        context_length=1_000_000,
        max_output_tokens=384_000,
        free=False,
        thinking_control="effort",
        thinking_options=_reasoning_options("high", "max"),
        default_thinking_choice="high",
    ),
    _opencode_model(
        "deepseek-v4-flash",
        "DeepSeek V4 Flash",
        "OpenCode Zen paid DeepSeek V4 Flash model available with an API key.",
        context_length=1_000_000,
        max_output_tokens=384_000,
        free=False,
        thinking_control="effort",
        thinking_options=_reasoning_options("low", "high", "max"),
        default_thinking_choice="high",
    ),
    _opencode_model(
        "minimax-m3",
        "MiniMax M3",
        "OpenCode Zen paid MiniMax M3 model available with an API key.",
        context_length=512_000,
        max_output_tokens=128_000,
        free=False,
    ),
    _opencode_model(
        "minimax-m2.7",
        "MiniMax M2.7",
        "OpenCode Zen paid MiniMax M2.7 model available with an API key.",
        context_length=204_800,
        max_output_tokens=131_072,
        free=False,
    ),
    _opencode_model(
        "minimax-m2.5",
        "MiniMax M2.5",
        "OpenCode Zen paid MiniMax M2.5 model available with an API key.",
        context_length=204_800,
        max_output_tokens=131_072,
        free=False,
    ),
    _opencode_model(
        "glm-5.2",
        "GLM 5.2",
        "OpenCode Zen paid GLM 5.2 model available with an API key.",
        context_length=204_800,
        max_output_tokens=131_072,
        free=False,
        thinking_control="effort",
        thinking_options=_reasoning_options("high", "max"),
        default_thinking_choice="high",
    ),
    _opencode_model(
        "glm-5.1",
        "GLM 5.1",
        "OpenCode Zen paid GLM 5.1 reasoning model available with an API key.",
        context_length=204_800,
        max_output_tokens=131_072,
        free=False,
    ),
    _opencode_model(
        "glm-5",
        "GLM 5",
        "OpenCode Zen paid GLM 5 reasoning model available with an API key.",
        context_length=204_800,
        max_output_tokens=131_072,
        free=False,
    ),
    _opencode_model(
        "kimi-k2.5",
        "Kimi K2.5",
        "OpenCode Zen paid multimodal Kimi K2.5 model available with an API key.",
        context_length=262_144,
        max_output_tokens=65_536,
        vision=True,
        vision_modalities=["image", "video"],
        free=False,
    ),
    _opencode_model(
        "kimi-k2.6",
        "Kimi K2.6",
        "OpenCode Zen paid multimodal Kimi K2.6 model available with an API key.",
        context_length=262_144,
        max_output_tokens=65_536,
        vision=True,
        vision_modalities=["image", "video"],
        free=False,
    ),
    _opencode_model(
        "kimi-k2.7-code",
        "Kimi K2.7 Code",
        "OpenCode Zen paid Kimi K2.7 coding model available with an API key.",
        free=False,
    ),
    _opencode_model(
        "kimi-k3",
        "Kimi K3",
        "OpenCode Zen paid Kimi K3 model available with an API key.",
        free=False,
        thinking_control="effort",
        thinking_options=_reasoning_options("max"),
        default_thinking_choice="max",
    ),
]

_OPENCODE_MODEL_METADATA = {
    str(item["id"]).strip().lower(): dict(item) for item in _OPENCODE_MODEL_CATALOG
}
_OPENCODE_MODEL_CACHE: Dict[str, Any] = {"key": "", "expires_at": 0.0, "models": []}


def default_opencode_config() -> Dict[str, Any]:
    """Default OpenCode source config stored in config.json."""
    return {
        "enabled": True,
        "api_key": "",
        "selected_model_id": OPENCODE_DEFAULT_MODEL_ID,
        "selected_model_display_name": OPENCODE_DEFAULT_MODEL_DISPLAY_NAME,
        "api_url": OPENCODE_DEFAULT_API_URL,
        "endpoint": OPENCODE_DEFAULT_ENDPOINT,
        # Empty values send Reverie's own identity. Gateway-specific overrides
        # identify the actual caller; they do not grant free-tier access.
        "client_name": "",
        "user_agent": "",
        "use_builtin_model_catalog": False,
        "max_context_tokens": OPENCODE_DEFAULT_CONTEXT_TOKENS,
        "timeout": 60,
        "max_tokens": OPENCODE_DEFAULT_MAX_TOKENS,
        "temperature": OPENCODE_DEFAULT_TEMPERATURE,
        "top_p": OPENCODE_DEFAULT_TOP_P,
        "reasoning_effort": "high",
    }


def _opencode_models_url(api_url: Any) -> str:
    base = resolve_opencode_sdk_base_url(api_url)
    parts = urlsplit(base)
    # The official inference router separates its aggregate catalog from the
    # OpenAI transport route. Custom proxies keep their configured path.
    if parts.hostname == "opencode.ai" and parts.path.rstrip("/") == "/inference/openai/v1":
        base = urlunsplit((parts.scheme, parts.netloc, "/inference/v1", parts.query, ""))
    return _append_opencode_path(base, "models")


def fetch_opencode_model_catalog(
    opencode_config: Any = None,
    *,
    timeout: int = 5,
    force_refresh: bool = False,
    proxy: Any = "",
) -> List[Dict[str, Any]]:
    """Fetch every model id exposed by the live OpenCode catalog."""
    cfg = default_opencode_config()
    if isinstance(opencode_config, dict):
        cfg.update(opencode_config)
    api_key = resolve_opencode_api_key(cfg)
    models_url = _opencode_models_url(cfg.get("api_url"))
    auth_hash = sha256(api_key.encode("utf-8")).hexdigest() if api_key else "anonymous"
    configured_proxy = normalize_proxy_url(proxy)
    cache_key = f"{models_url}:{auth_hash}:{configured_proxy}"
    now = time.monotonic()
    if (
        not force_refresh
        and _OPENCODE_MODEL_CACHE.get("key") == cache_key
        and float(_OPENCODE_MODEL_CACHE.get("expires_at") or 0.0) > now
    ):
        return [dict(item) for item in _OPENCODE_MODEL_CACHE.get("models", [])]

    headers = {"Accept": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    request_kwargs: Dict[str, Any] = {
        "headers": headers,
        "timeout": max(1, int(timeout or 5)),
    }
    if configured_proxy:
        request_kwargs["proxies"] = requests_proxy_dict(configured_proxy)
    response = requests.get(models_url, **request_kwargs)
    response.raise_for_status()
    payload = response.json()
    raw_models = payload.get("data", payload.get("models", [])) if isinstance(payload, dict) else []
    models: List[Dict[str, Any]] = []
    seen_ids = set()
    for raw_model in raw_models if isinstance(raw_models, list) else []:
        if isinstance(raw_model, dict):
            model_id = str(raw_model.get("id") or raw_model.get("model") or "").strip()
        else:
            model_id = str(raw_model or "").strip()
        normalized_id = model_id.lower()
        if not normalized_id or normalized_id in seen_ids:
            continue
        seen_ids.add(normalized_id)
        models.append(_live_opencode_model(model_id, raw_model if isinstance(raw_model, dict) else None))
    _OPENCODE_MODEL_CACHE.update(
        key=cache_key,
        expires_at=now + OPENCODE_MODEL_CACHE_TTL_SECONDS,
        models=models,
    )
    return [dict(item) for item in models]


def get_opencode_model_catalog(
    opencode_config: Any = None,
    *,
    fetch_live: bool = False,
    force_refresh: bool = False,
    proxy: Any = "",
) -> List[Dict[str, Any]]:
    """Return the live catalog or the dedicated built-in catalog when selected."""
    cfg = default_opencode_config()
    if isinstance(opencode_config, dict):
        cfg.update(opencode_config)
    if fetch_live and not bool(cfg.get("use_builtin_model_catalog", False)):
        try:
            live_models = fetch_opencode_model_catalog(cfg, force_refresh=force_refresh, proxy=proxy)
            if live_models:
                return live_models
        except (requests.RequestException, ValueError, TypeError):
            pass
    has_api_key = bool(resolve_opencode_api_key(cfg))
    return [dict(item) for item in _OPENCODE_MODEL_CATALOG if has_api_key or bool(item.get("free"))]


def get_opencode_model_metadata(model_id: Any) -> Optional[Dict[str, Any]]:
    """Return metadata for one OpenCode model id."""
    wanted = str(model_id or "").strip().lower()
    if not wanted:
        return None
    found = _OPENCODE_MODEL_METADATA.get(wanted)
    return dict(found) if found else None


def _infer_live_opencode_transport(model_id: str) -> tuple[str, str]:
    """Infer the documented Zen endpoint for models absent from the snapshot."""
    normalized_id = str(model_id or "").strip().lower()
    if normalized_id.startswith(_OPENCODE_RESPONSES_MODEL_PREFIXES):
        return "openai-responses", "/responses"
    if normalized_id.startswith(_OPENCODE_ANTHROPIC_MODEL_PREFIXES):
        return "anthropic", "/messages"
    return "openai-chat", OPENCODE_DEFAULT_ENDPOINT


def _live_opencode_model(model_id: Any, raw_model: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Decorate one live id without dropping models absent from the built-in metadata."""
    normalized_id = str(model_id or "").strip()
    known = get_opencode_model_metadata(normalized_id)
    if known:
        model = dict(known)
        model.update(dict(raw_model or {}))
        # The live endpoint does not publish transport details. Keep the
        # source-of-truth mapping for known special endpoints such as Muse.
        model["id"] = normalized_id
        model["display_name"] = str(known.get("display_name") or normalized_id)
        model["transport"] = str(known.get("transport") or "openai-chat")
        model["endpoint"] = str(known.get("endpoint") or OPENCODE_DEFAULT_ENDPOINT)
    else:
        raw = dict(raw_model or {})
        inferred_transport, inferred_endpoint = _infer_live_opencode_transport(normalized_id)
        transport = str(raw.get("transport") or inferred_transport).strip()
        if transport not in {"openai-chat", "openai-responses", "anthropic"}:
            transport = inferred_transport
        endpoint = str(raw.get("endpoint") or "").strip()
        if not endpoint:
            endpoint = inferred_endpoint
        model = _opencode_model(
            normalized_id,
            str(raw.get("display_name") or raw.get("name") or normalized_id).strip(),
            OPENCODE_LIVE_MODEL_DESCRIPTION,
            thinking=False,
            thinking_control="none",
            free=bool(raw.get("free", False)),
            transport=transport,
            endpoint=endpoint,
        )
        model.update(raw)
        model["id"] = normalized_id
        model["display_name"] = str(model.get("display_name") or normalized_id).strip()
        model["description"] = str(model.get("description") or OPENCODE_LIVE_MODEL_DESCRIPTION).strip()
        model["transport"] = transport
        model["endpoint"] = endpoint
    model["catalog_source"] = "api"
    return model


def resolve_opencode_selected_model(opencode_config: Any, model_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Resolve selected OpenCode model metadata from config or override."""
    cfg = default_opencode_config()
    if isinstance(opencode_config, dict):
        cfg.update(opencode_config)

    wanted = str(model_id or cfg.get("selected_model_id", OPENCODE_DEFAULT_MODEL_ID) or "").strip().lower()
    catalog = get_opencode_model_catalog(cfg)
    matched = next((dict(item) for item in catalog if str(item.get("id") or "").lower() == wanted), None)
    if matched:
        return matched
    if wanted and not bool(cfg.get("use_builtin_model_catalog", False)) and wanted not in _OPENCODE_MODEL_METADATA:
        return _live_opencode_model(wanted)
    default_model = next(
        (dict(item) for item in catalog if str(item.get("id") or "").lower() == OPENCODE_DEFAULT_MODEL_ID),
        None,
    )
    return default_model or (dict(catalog[0]) if catalog else None)


def _append_opencode_path(base_url: str, extra: str) -> str:
    """Append a path segment to a base URL, keeping any query string at the end.

    A reverse proxy often carries auth in the query (`?key=...`), so the extra
    path must land on the URL's path component -- naive string concatenation
    produces `...?key=abc/chat/completions`, which no gateway can route.
    """
    parts = urlsplit(base_url)
    path = parts.path.rstrip("/")
    tail = str(extra or "").strip().strip("/")
    if tail:
        path = f"{path}/{tail}" if path else f"/{tail}"
    return urlunsplit((parts.scheme, parts.netloc, path, parts.query, ""))


def resolve_opencode_sdk_base_url(api_url: Any) -> str:
    """Resolve an OpenAI-compatible `/v1` base URL for OpenCode Zen.

    Only the path is normalized; the scheme, host, and any query string (proxy
    auth) are preserved, so a reverse-proxy URL survives the round trip.
    """
    base = str(api_url or "").strip()
    if not base:
        return OPENCODE_DEFAULT_API_URL
    if not base.startswith(("http://", "https://")):
        base = f"https://{base}"
    parts = urlsplit(base)
    path = parts.path.rstrip("/")
    lower_path = path.lower()
    for suffix in (
        "/chat/completions",
        "/v1/chat/completions",
        "/models",
        "/v1/models",
    ):
        if lower_path.endswith(suffix):
            path = path[: -len(suffix)]
            lower_path = path.lower()
            break
    if not lower_path.endswith("/v1"):
        path = f"{path}/v1"
    return urlunsplit((parts.scheme, parts.netloc, path, parts.query, ""))


def resolve_opencode_request_url(api_url: Any, endpoint: Any = "") -> str:
    """Resolve the concrete chat-completions request URL."""
    candidate_endpoint = str(endpoint or "").strip() or OPENCODE_DEFAULT_ENDPOINT
    if candidate_endpoint.startswith(("http://", "https://")):
        return candidate_endpoint
    return _append_opencode_path(resolve_opencode_sdk_base_url(api_url), candidate_endpoint)


def resolve_opencode_session_id(session_id: Any = "") -> str:
    """Return the provider-shaped session id required by OpenCode Zen."""
    candidate = str(session_id or "").strip()
    if re.fullmatch(r"ses_[0-9a-f]{64}", candidate, flags=re.IGNORECASE):
        return candidate
    return f"ses_{sha256((candidate or 'default').encode('utf-8')).hexdigest()}"


def resolve_opencode_client_identity(opencode_config: Any) -> Dict[str, str]:
    """Resolve the client name and User-Agent to present to the gateway.

    Empty config values fall back to Reverie's own identity. Overrides describe
    the actual caller for a configured gateway; they do not authorize a client
    to use models that the service restricts to another application.
    """
    client_name = OPENCODE_CLIENT_NAME
    user_agent = OPENCODE_USER_AGENT
    if isinstance(opencode_config, dict):
        configured_client = str(opencode_config.get("client_name", "") or "").strip()
        configured_agent = str(opencode_config.get("user_agent", "") or "").strip()
        if configured_client:
            client_name = configured_client
        if configured_agent:
            user_agent = configured_agent
    return {"client_name": client_name, "user_agent": user_agent}


def build_opencode_request_headers(
    session_id: Any = "",
    *,
    request_id: Any = "",
    project_id: Any = "",
    client: str = OPENCODE_CLIENT_NAME,
    user_agent: str = "",
) -> Dict[str, str]:
    """Build transparent request metadata expected by OpenCode Zen."""
    normalized_request_id = str(request_id or "").strip()
    if not re.fullmatch(r"msg_[0-9a-f]{32,64}", normalized_request_id, flags=re.IGNORECASE):
        normalized_request_id = f"msg_{uuid4().hex}"
    headers = {
        "x-opencode-session": resolve_opencode_session_id(session_id),
        "x-opencode-request": normalized_request_id,
        "x-opencode-client": str(client or OPENCODE_CLIENT_NAME).strip() or OPENCODE_CLIENT_NAME,
        "User-Agent": str(user_agent or "").strip() or OPENCODE_USER_AGENT,
    }
    normalized_project_id = str(project_id or "").strip()
    if normalized_project_id:
        headers["x-opencode-project"] = normalized_project_id
    return headers


def build_opencode_request_headers_from_config(
    opencode_config: Any,
    session_id: Any = "",
    *,
    request_id: Any = "",
    project_id: Any = "",
) -> Dict[str, str]:
    """Build request headers honouring the configured client identity overrides."""
    identity = resolve_opencode_client_identity(opencode_config)
    return build_opencode_request_headers(
        session_id,
        request_id=request_id,
        project_id=project_id,
        client=identity["client_name"],
        user_agent=identity["user_agent"],
    )


def resolve_opencode_api_key(opencode_config: Any) -> str:
    """Resolve the effective OpenCode API key from config or environment."""
    cfg = default_opencode_config()
    if isinstance(opencode_config, dict):
        cfg.update(opencode_config)

    key = str(cfg.get("api_key", "") or "").strip()
    if key:
        return key
    for env_name in ("OPENCODE_API_KEY", "OPENCODE_TOKEN"):
        value = str(os.getenv(env_name, "") or "").strip()
        if value:
            return value
    return ""


def normalize_opencode_config(raw_opencode: Any) -> Dict[str, Any]:
    """Normalize OpenCode config for persistence and runtime usage."""
    cfg = default_opencode_config()
    raw_has_reasoning_effort = False
    if isinstance(raw_opencode, dict):
        raw_has_reasoning_effort = "reasoning_effort" in raw_opencode
        cfg.update(raw_opencode)

    cfg["enabled"] = bool(cfg.get("enabled", True))
    cfg["api_key"] = str(cfg.get("api_key", "") or "").strip()
    cfg["client_name"] = str(cfg.get("client_name", "") or "").strip()
    cfg["user_agent"] = str(cfg.get("user_agent", "") or "").strip()
    cfg["use_builtin_model_catalog"] = bool(cfg.get("use_builtin_model_catalog", False))
    cfg["api_url"] = resolve_opencode_sdk_base_url(cfg.get("api_url", OPENCODE_DEFAULT_API_URL))
    cfg["endpoint"] = str(cfg.get("endpoint") or OPENCODE_DEFAULT_ENDPOINT).strip() or OPENCODE_DEFAULT_ENDPOINT
    cfg["selected_model_id"] = (
        str(cfg.get("selected_model_id", OPENCODE_DEFAULT_MODEL_ID) or "").strip()
        or OPENCODE_DEFAULT_MODEL_ID
    )
    cfg["selected_model_display_name"] = (
        str(cfg.get("selected_model_display_name", OPENCODE_DEFAULT_MODEL_DISPLAY_NAME) or "").strip()
        or OPENCODE_DEFAULT_MODEL_DISPLAY_NAME
    )

    for key, default_value in (
        ("max_context_tokens", OPENCODE_DEFAULT_CONTEXT_TOKENS),
        ("timeout", 60),
        ("max_tokens", OPENCODE_DEFAULT_MAX_TOKENS),
    ):
        try:
            value = int(cfg.get(key, default_value))
        except (TypeError, ValueError):
            value = default_value
        if value <= 0:
            value = default_value
        cfg[key] = value

    for key, default_value in (
        ("temperature", OPENCODE_DEFAULT_TEMPERATURE),
        ("top_p", OPENCODE_DEFAULT_TOP_P),
    ):
        try:
            cfg[key] = float(cfg.get(key, default_value))
        except (TypeError, ValueError):
            cfg[key] = default_value

    matched = resolve_opencode_selected_model(cfg)
    if matched:
        cfg["selected_model_id"] = str(matched["id"])
        cfg["selected_model_display_name"] = str(matched["display_name"])
        cfg["endpoint"] = str(matched.get("endpoint") or OPENCODE_DEFAULT_ENDPOINT)
        context_length = matched.get("context_length")
        if context_length:
            cfg["max_context_tokens"] = int(context_length)
        output_limit = int(matched.get("max_output_tokens") or OPENCODE_DEFAULT_MAX_TOKENS)
        cfg["max_tokens"] = min(int(cfg.get("max_tokens") or output_limit), output_limit)
        raw_choice = cfg.get("reasoning_effort") if raw_has_reasoning_effort else ""
        cfg["reasoning_effort"] = normalize_opencode_reasoning_choice(matched["id"], raw_choice)

    return cfg


def normalize_opencode_reasoning_choice(model_id: Any, value: Any) -> str:
    """Normalize one model-specific OpenCode reasoning selection."""
    selected = get_opencode_model_metadata(model_id) or {}
    options = [str(item.get("id") or "") for item in selected.get("thinking_options", [])]
    default = str(selected.get("default_thinking_choice") or "")
    candidate = str(value or "").strip().lower().replace("_", "-")
    candidate = {
        "off": "none",
        "false": "none",
        "no-think": "none",
        "non-think": "none",
        "med": "medium",
        "extra-high": "max",
        "xhigh": "max",
    }.get(candidate, candidate)
    if options:
        return candidate if candidate in options else (default if default in options else options[0])
    return "fixed" if bool(selected.get("thinking")) else ""


def resolve_opencode_thinking_choice(opencode_config: Any, model_id: Optional[str] = None) -> str:
    cfg = default_opencode_config()
    if isinstance(opencode_config, dict):
        cfg.update(opencode_config)
    selected = resolve_opencode_selected_model(cfg, model_id=model_id)
    if not selected:
        return ""
    return normalize_opencode_reasoning_choice(selected["id"], cfg.get("reasoning_effort"))


def apply_opencode_thinking_choice(opencode_config: Any, model_id: Any, choice: Any) -> Dict[str, Any]:
    cfg = default_opencode_config()
    if isinstance(opencode_config, dict):
        cfg.update(opencode_config)
    selected = resolve_opencode_selected_model(cfg, model_id=str(model_id or ""))
    if not selected:
        return normalize_opencode_config(cfg)
    normalized = normalize_opencode_reasoning_choice(selected["id"], choice)
    valid = {str(item.get("id") or "") for item in selected.get("thinking_options", [])}
    if valid and normalized not in valid:
        raise ValueError(f"Reasoning level {choice!r} is not supported by {selected['id']}")
    cfg["selected_model_id"] = str(selected["id"])
    cfg["selected_model_display_name"] = str(selected["display_name"])
    if valid:
        cfg["reasoning_effort"] = normalized
    return normalize_opencode_config(cfg)


def build_opencode_runtime_model_data(opencode_config: Any, model_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Build runtime model config dict for agent initialization."""
    cfg = normalize_opencode_config(opencode_config)
    if not cfg.get("enabled", True):
        return None

    selected = resolve_opencode_selected_model(cfg, model_id=model_id)
    if not selected:
        return None

    return {
        "model": selected["id"],
        "model_display_name": selected["display_name"],
        "base_url": resolve_opencode_sdk_base_url(cfg.get("api_url", OPENCODE_DEFAULT_API_URL)),
        "api_key": resolve_opencode_api_key(cfg),
        "max_context_tokens": int(selected.get("context_length") or cfg.get("max_context_tokens", OPENCODE_DEFAULT_CONTEXT_TOKENS)),
        "provider": str(selected.get("transport") or "openai-chat"),
        "supports_vision": bool(selected.get("vision", False)),
        "thinking_mode": resolve_opencode_thinking_choice(cfg, selected["id"]),
        "endpoint": str(selected.get("endpoint") or cfg.get("endpoint", OPENCODE_DEFAULT_ENDPOINT) or OPENCODE_DEFAULT_ENDPOINT),
        "custom_headers": {},
        "vision": bool(selected.get("vision", False)),
        "vision_modalities": list(selected.get("vision_modalities") or (["image"] if selected.get("vision") else [])),
    }


def build_opencode_openai_options(opencode_config: Any, model_id: Optional[str] = None) -> Dict[str, Any]:
    """Return OpenAI-compatible request options for OpenCode chat completions."""
    cfg = normalize_opencode_config(opencode_config)
    selected = resolve_opencode_selected_model(cfg, model_id=model_id)
    output_limit = int((selected or {}).get("max_output_tokens") or OPENCODE_DEFAULT_MAX_TOKENS)
    try:
        max_tokens = int(cfg.get("max_tokens", OPENCODE_DEFAULT_MAX_TOKENS))
    except (TypeError, ValueError):
        max_tokens = OPENCODE_DEFAULT_MAX_TOKENS
    if max_tokens <= 0:
        max_tokens = OPENCODE_DEFAULT_MAX_TOKENS
    options: Dict[str, Any] = {
        "temperature": float(cfg.get("temperature", OPENCODE_DEFAULT_TEMPERATURE)),
        "top_p": float(cfg.get("top_p", OPENCODE_DEFAULT_TOP_P)),
        "max_tokens": min(max_tokens, output_limit),
    }
    if selected and str(selected.get("thinking_control") or "") == "effort":
        options["extra_body"] = {
            "reasoning_effort": resolve_opencode_thinking_choice(cfg, str(selected["id"])),
        }
    return options


def mask_secret(secret: str) -> str:
    """Mask secrets for safe terminal display."""
    value = str(secret or "").strip()
    if not value:
        return "(not set)"
    if len(value) <= 8:
        return "*" * len(value)
    return f"{value[:4]}...{value[-4:]}"
