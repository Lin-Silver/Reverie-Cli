"""Actual native conversation rendering + one real anonymous model turn.

Fixed rendering fixtures are explicitly separate from model-generated evidence.
No edits to prior model samples, HTML or private view state.
"""
from pathlib import Path
from datetime import datetime, timezone
import base64, copy, hashlib, json, os, socket, subprocess, sys, time

ROOT = Path('/workspace/Reverie-Cli')
BASE = ROOT/'.runtime/riu-completion-20261021'
OUT = BASE/'rich-answer-native'
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT/'scripts/verification'))
import riu_quality_benchmark as q
from playwright.sync_api import sync_playwright
from reverie.config import ConfigManager
from reverie.session.manager import SessionManager

report = {'scope': 'Native rich answer rendering fixtures and one actual model response; not the old formal matrix or a claim of general model quality.',
          'started_at_utc': datetime.now(timezone.utc).isoformat(), 'checks': [], 'captures': [], 'page_errors': [],
          'fixture_model_quality_samples': 0, 'actual_model_turns': 0}


def save():
    (OUT/'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))


def check(name, passed, detail=None):
    report['checks'].append({'name': name, 'passed': bool(passed), 'detail': detail})
    save()


def fence(value):
    return '```reverie-ui\n' + json.dumps(value, ensure_ascii=False) + '\n```'


def image_data(name, mime):
    return 'data:' + mime + ';base64,' + base64.b64encode((BASE/'rich-answer-source-assets'/name).read_bytes()).decode()


metrics = {'type': 'metrics', 'items': [{'label': label, 'value': number} for label, number in [('计划中', 7), ('开发中', 5), ('已有成果', 4), ('半归档', 1)]]}
table = {'type': 'table', 'title': '项目总览表', 'columns': ['序号', '项目名称', '当前状态', '说明'], 'rows': [
    [1, 'Reverie CLI', {'text': '开发中', 'tone': 'info'}, '核心 AI 编程助手，包含 Gamer、Context Engine、UI 等模块'],
    [2, 'Reverie-1', {'text': '研发中', 'tone': 'info'}, '模型能力验证阶段'],
    [3, 'Reverie Engine', {'text': '开发中', 'tone': 'info'}, '游戏引擎与编辑器'],
    [4, 'Cliach Nexus', {'text': '半归档', 'tone': 'neutral'}, '保留维护'],
], 'caption': '参考图排版示例数据，不是当前项目现状统计。'}
cards = {'type': 'cards', 'numbered': True, 'items': [
    {'title': 'Plane', 'description': '现代项目管理界面，适合同时整理多个软件项目的工作项、模块与项目视图。',
     'badge': {'text': '综合首选', 'tone': 'success'},
     'image': {'url': image_data('plane-board-art.webp', 'image/webp'), 'alt': 'Plane 项目自带看板示意素材'},
     'details': ['图像来自项目公开仓库；这里验证图文排版，不据此判断产品当前功能或价格。'],
     'sources': [{'label': 'Plane', 'url': 'https://github.com/makeplane/plane'}],
     'links': [{'label': '官方网站', 'url': 'https://plane.so/'}, {'label': 'GitHub 源码', 'url': 'https://github.com/makeplane/plane'}]},
    {'title': 'Vikunja', 'description': '轻量的开源任务管理工具，以项目、任务与看板组织工作。',
     'image': {'url': image_data('vikunja-kanban-actual.png', 'image/png'), 'alt': 'Vikunja 官方网站仓库中的看板截图'},
     'details': ['本图文条目是固定渲染样例，链接指向真实项目。'],
     'sources': [{'label': 'vikunja.io', 'url': 'https://vikunja.io/'}],
     'links': [{'label': '官方网站', 'url': 'https://vikunja.io/'}, {'label': 'GitHub 源码', 'url': 'https://github.com/go-vikunja/vikunja'}]},
]}
app_root, workspace, home = [OUT/name for name in ['app-root', 'workspace', 'desktop-home']]
for folder in [app_root, workspace, home]:
    folder.mkdir()
q.prepare_isolated_workspace(workspace)
original = ConfigManager(ROOT).load()
os.environ['REVERIE_APP_ROOT'] = str(app_root)
os.environ['NO_PROXY'] = '127.0.0.1,localhost'
config = ConfigManager(workspace)
cfg = config.load()
cfg.security = copy.deepcopy(original.security)
cfg.api_proxy = original.api_proxy
cfg.api_max_retries = original.api_max_retries
cfg.api_initial_backoff = original.api_initial_backoff
cfg.stream_responses = True
model = 'Qwen3.5-397B-A17B'
upstream = 'https://oai.endpoints.kepler.ai.cloud.ovh.net/v1/chat/completions'
recorder = q.Recorder(OUT, upstream, '', request_timeout=1800)
q.configure_model_source(cfg, original, 'standard', model, recorder_url=f'http://127.0.0.1:{recorder.server.server_port}/v1')
config.ensure_dirs()
config.save(cfg)
manager = SessionManager(config.project_data_dir, project_root=workspace)
fixtures = {}
for name, body in [('统计与表格', '截至 2026 年 10 月 23 日：\n\n' + fence(metrics) + '\n\n' + fence(table)),
                   ('图文推荐', '## 最值得考虑的开源软件\n\n' + fence(cards))]:
    session = manager.create_session('富格式检查：' + name)
    manager.add_message({'role': 'user', 'content': '固定展示格式检查；不是模型生成结果。'})
    manager.add_message({'role': 'assistant', 'content': body})
    fixtures[name] = session.id
actual = manager.create_session('富格式检查：真实模型回答')
settings = home/'.reverie/desktop/desktop-settings.json'
settings.parent.mkdir(parents=True)
settings.write_text(json.dumps({'coreAppRoot': str(app_root), 'projectRoot': str(workspace),
                               'ui': {'language': 'zh-CN', 'showReasoning': False, 'showToolCalls': False, 'showToolResults': False}}, ensure_ascii=False))
process = None
exe = ROOT/'ReverieCli-ui/release/linux-unpacked/ReverieUI'
log = (OUT/'electron.log').open('x')
try:
    with sync_playwright() as playwright:
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 0)); port = sock.getsockname()[1]
        env = {**os.environ, 'DISPLAY': ':94', 'PORTABLE_EXECUTABLE_DIR': str(home)}
        env.pop('ELECTRON_RUN_AS_NODE', None)
        process = subprocess.Popen([str(exe), '--gui', '--project', str(workspace), f'--remote-debugging-port={port}'],
                                   env=env, stdout=log, stderr=subprocess.STDOUT, **q.launch_options())
        report['owned_pid'] = process.pid
        browser, page = q.wait_for_packaged_page(playwright, process, port)
        page.on('pageerror', lambda error: report['page_errors'].append(str(error)))
        page.set_viewport_size({'width': 1280, 'height': 1200})
        page.wait_for_selector('textarea[aria-autocomplete=list]', timeout=120000)
        report['build'] = page.evaluate('window.reverie.paths()')['desktopBuild']
        built = json.loads((ROOT/'ReverieCli-ui/dist-electron/reverie-build.json').read_text())
        check('actual-native-build-matches-current-build', report['build']['id'] == built['id'], report['build'])

        def select(name):
            page.get_by_role('button', name='展开左侧栏 (Ctrl+B)').click() if page.get_by_role('button', name='展开左侧栏 (Ctrl+B)').count() else None
            page.locator('.session-item').filter(has_text='富格式检查：' + name).click(timeout=30000)
            page.locator('.session-loading').wait_for(state='hidden', timeout=30000)
            page.locator('.message.assistant .answer-markdown').wait_for(timeout=30000)

        def theme(value):
            page.get_by_role('button', name='切换主题', exact=True).click()
            page.locator('.theme-menu').get_by_role('button', name='深色' if value == 'dark' else '浅色', exact=False).click()
            page.wait_for_function('value=>document.documentElement.dataset.theme===value', arg=value)

        for name in ['统计与表格', '图文推荐']:
            select(name)
            for value in ['dark', 'light']:
                theme(value)
                page.set_viewport_size({'width': 1280, 'height': 1400})
                target = page.locator('.message.assistant .answer-markdown').last
                if name == '图文推荐':
                    page.wait_for_function('()=>[...document.querySelectorAll(".answer-card-image")].every(x=>x.tagName==="IMG" && x.complete && x.naturalWidth>0)')
                    check('actual-raster-images-loaded-' + value, target.locator('img').count() == 2)
                else:
                    check('four-reference-metrics-' + value, target.locator('.answer-metric dd').all_text_contents() == ['7', '5', '4', '1'])
                    check('all-reference-table-rows-' + value, target.locator('tbody tr').count() == 4)
                for width in [1280, 460]:
                    page.set_viewport_size({'width': width, 'height': 1400})
                    page.wait_for_timeout(250)
                    path = OUT/(('metrics-table' if name == '统计与表格' else 'image-cards') + f'-{value}-{width}.png')
                    target.screenshot(path=str(path))
                    layout = target.evaluate('el=>({width:el.clientWidth,scrollWidth:el.scrollWidth,tableScroll:[...el.querySelectorAll(".answer-table-scroll")].map(x=>({width:x.clientWidth,scrollWidth:x.scrollWidth})),images:[...el.querySelectorAll("img")].map(x=>({width:x.clientWidth,naturalWidth:x.naturalWidth})),cards:[...el.querySelectorAll(".answer-card")].map(x=>({width:x.clientWidth,scrollWidth:x.scrollWidth}))})')
                    check('answer-container-retains-content-' + name + '-' + value + '-' + str(width), layout['scrollWidth'] <= layout['width'] + 1, layout)
                    report['captures'].append({'fixture': True, 'name': name, 'theme': value, 'viewport': page.viewport_size, 'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'layout': layout})
                if name == '统计与表格':
                    scroll = target.get_by_role('region', name='项目总览表')
                    scroll.focus(); previous_scroll = scroll.evaluate('el=>el.scrollLeft'); page.keyboard.press('ArrowRight'); page.wait_for_timeout(200)
                    if scroll.evaluate('el=>el.scrollWidth>el.clientWidth'):
                        check('table-keyboard-horizontal-scroll-' + value, scroll.evaluate('el=>el.scrollLeft') > previous_scroll)
                    check('table-keyboard-focus-' + value, scroll.evaluate('el=>el===document.activeElement'))
            page.reload(); page.wait_for_selector('textarea[aria-autocomplete=list]')
            select(name)
            check('saved-answer-reloads-' + name, page.locator('.answer-metric' if name == '统计与表格' else '.answer-card').count() == (4 if name == '统计与表格' else 2))

        page.set_viewport_size({'width': 1280, 'height': 1200})
        page.get_by_role('button', name='展开左侧栏 (Ctrl+B)').click() if page.get_by_role('button', name='展开左侧栏 (Ctrl+B)').count() else None
        page.locator('.session-item').filter(has_text='富格式检查：真实模型回答').click()
        recorder.case = 'actual-rich-answer'
        event_start = q.start_event_capture(page)
        prompt = '请直接在对话中展示一份项目概览：统计卡片分别为计划中7、开发中5、已有成果4、半归档1；下方是项目名称、状态、说明三列表格，包含“Reverie CLI / 开发中 / 核心AI编程助手”和“Reverie Engine / 开发中 / 游戏引擎”。这是我提供的展示数据，无需调查仓库。使用卡片和带状态标签的总览表，不要把结果作为代码展示，也不需要可编辑控件。'
        prompt += '\n再用图文推荐卡片展示两项给定演示内容：Plane（现代项目管理工具，标记综合首选，图片 https://raw.githubusercontent.com/makeplane/plane/preview/apps/web/app/assets/empty-state/cycle-issues/kanban-dark.webp ，图片说明为项目自带看板示意素材，官网 https://plane.so/ ，源码 https://github.com/makeplane/plane）；Vikunja（开源任务管理工具，图片 https://media.githubusercontent.com/media/go-vikunja/website/main/src/assets/images/vikunja/features/kanban.png ，图片说明为官方仓库看板截图，官网 https://vikunja.io/ ，源码 https://github.com/go-vikunja/vikunja）。卡片包含来源和可点击官网、源码链接。以上是给定展示内容，不用额外查资料或推断许可价格。'
        (OUT/'actual-prompt.txt').write_text(prompt)
        page.locator('textarea[aria-autocomplete=list]').fill(prompt)
        page.get_by_role('button', name='发送', exact=True).click()
        started = time.monotonic()
        while True:
            events = page.evaluate('n=>window.__qualityEvents.slice(n)', event_start)
            began, active = q.execution_state(events, actual.id)
            if began and not active: break
            if time.monotonic() - started > 1800: raise TimeoutError('Actual native model turn did not close')
            page.wait_for_timeout(500)
        report['actual_model_turns'] = 1
        report['actual_model'] = model
        report['actual_model_seconds'] = time.monotonic() - started
        (OUT/'actual-events.json').write_text(json.dumps(events, ensure_ascii=False, indent=2))
        page.wait_for_timeout(500)
        check('real-model-four-native-metric-cards', page.locator('.answer-metric').count() == 4)
        check('real-model-native-status-table', page.locator('.answer-table tbody tr').count() == 2 and page.locator('.answer-table .answer-badge').count() >= 2)
        check('real-model-native-image-recommendations', page.locator('.answer-card').count() == 2 and page.locator('.answer-source').count() >= 2)
        report['actual_remote_image_elements'] = page.locator('.answer-card-image').evaluate_all('items=>items.map(x=>({tag:x.tagName,src:x.getAttribute("src"),alt:x.getAttribute("alt")||x.getAttribute("aria-label"),naturalWidth:x.naturalWidth||0}))')
        check('real-model-response-not-visible-json-code', page.locator('.message.assistant pre').count() == 0)
        check('real-model-values-preserve-user-data', page.locator('.answer-metric dd').all_text_contents() == ['7', '5', '4', '1'])
        path = OUT/'actual-model-answer.png'; page.screenshot(path=str(path), full_page=True)
        report['captures'].append({'fixture': False, 'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
        page.reload(); page.wait_for_selector('textarea[aria-autocomplete=list]')
        check('real-model-answer-reloads', page.locator('.answer-metric').count() == 4 and page.locator('.answer-table tbody tr').count() == 2)
        records = recorder.records
        forbidden_parameters = {"temperature", "top_p", "max_tokens", "max_completion_tokens", "reasoning_effort"}
        payloads = [json.loads(Path(record["request"]).read_text()) for record in records]
        check('actual-requests-all27-native-defaults', bool(payloads) and all(len(payload.get("tools", [])) == 27 and not forbidden_parameters.intersection(payload) for payload in payloads))
        check('actual-model-identity-observed', sorted({record["response_model"] for record in records if record.get("response_model")}) == [model])
        check('new-native-rich-format-guidance-in-actual-wire', any("## Rich Answer Presentation" in str(message.get("content")) for payload in payloads for message in payload["messages"] if message.get("role") == "system"))
        check('no-native-renderer-page-errors', not report['page_errors'], report['page_errors'])
        browser.close()
except Exception as error:
    report['error'] = type(error).__name__ + ': ' + str(error)
finally:
    q.stop_process(process)
    recorder.close()
    log.close()
    native_sessions = list((app_root/'.reverie/projects').glob('*/sessions/' + actual.id + '.json'))
    if len(native_sessions) == 1:
        content = native_sessions[0].read_bytes()
        (OUT/'actual-model-session.json').write_bytes(content)
        report['actual_model_saved_session'] = {"path": str(OUT/'actual-model-session.json'), "sha256": hashlib.sha256(content).hexdigest()}
    report['requests'] = recorder.records
    report['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    report['passed'] = not report.get('error') and all(item['passed'] for item in report['checks'])
    save()
print(json.dumps({key: report.get(key) for key in ['passed', 'error', 'actual_model_turns', 'actual_model_seconds', 'build']}), flush=True)
raise SystemExit(0 if report['passed'] else 2)
