"""One isolated upstream diagnostic; never a UI quality sample or product default."""
from pathlib import Path
import hashlib,json,time,requests
R=Path('/workspace/Reverie-Cli');B=R/'.runtime/riu-cloud-20261020';O=B/'output-budget-diagnostic';O.mkdir(exist_ok=False)
original=B/'anonymous-matrix-protocol-fixed/chart-1/request-0000.json'
source=json.loads(original.read_text());payload=dict(source);payload['max_tokens']=16384
raw=json.dumps(payload,ensure_ascii=False).encode();(O/'request.json').write_bytes(raw)
report={'scope':'One direct diagnostic using a preserved production request with only max_tokens added; not Desktop, not a quality sample, not a second model, no product default or output limit changed','baseline_request':str(original.relative_to(R)),'baseline_request_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'diagnostic_request_sha256':hashlib.sha256(raw).hexdigest(),'changed_fields':{'max_tokens':16384},'endpoint':'https://text.pollinations.ai/v1/chat/completions','user_agent':'Reverie-Cli/2.5.0','authentication':'none','tool_calls':[]}
start=time.monotonic();response=requests.post(report['endpoint'],data=raw,headers={'User-Agent':report['user_agent'],'Content-Type':'application/json'},stream=True,timeout=(30,300));report['status']=response.status_code;report['headers_ms']=(time.monotonic()-start)*1000;report['headers']=dict(response.headers)
chunks=[]
with (O/'response.sse').open('wb')as f:
 for chunk in response.iter_content(chunk_size=4096):f.write(chunk);f.flush();chunks.append(chunk)
body=b''.join(chunks);report['complete_ms']=(time.monotonic()-start)*1000;report['response_sha256']=hashlib.sha256(body).hexdigest();calls={}
for line in body.decode('utf-8',errors='replace').splitlines():
 if not line.startswith('data: '):continue
 try:item=json.loads(line[6:])
 except ValueError:continue
 if item.get('usage'):report['usage']=item['usage']
 if item.get('model'):report['raw_response_model']=item['model']
 for choice in item.get('choices',[]):
  if choice.get('finish_reason'):report['finish_reason']=choice['finish_reason']
  for call in choice.get('delta',{}).get('tool_calls',[]):
   entry=calls.setdefault(call.get('index',0),{'name':'','arguments':''});function=call.get('function',{});entry['name']+=function.get('name','');entry['arguments']+=function.get('arguments','')
for entry in calls.values():
 try:args=json.loads(entry['arguments']);entry['complete_json']=True;entry['argument_keys']=list(args)
 except ValueError:entry['complete_json']=False
 entry['argument_characters']=len(entry.pop('arguments'));report['tool_calls'].append(entry)
(O/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:report.get(k)for k in ['status','usage','finish_reason','tool_calls','complete_ms']},ensure_ascii=False))
