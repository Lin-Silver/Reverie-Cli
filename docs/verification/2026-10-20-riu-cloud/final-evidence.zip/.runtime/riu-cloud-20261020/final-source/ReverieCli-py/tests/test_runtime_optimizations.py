from __future__ import annotations

import io
import json
import subprocess
import sys
import threading
import time
from pathlib import Path
from types import SimpleNamespace

import requests
from rich.console import Console

from reverie.agent.agent import (
    THINKING_END_MARKER,
    THINKING_START_MARKER,
    _StreamingTurnState,
    _should_recover_partial_stream_error,
    parse_tool_arguments,
)
from reverie.agent.tool_executor import ToolExecutor
from reverie.cli.display import DisplayComponents
from reverie.cli.interface import ReverieInterface, _load_task_drawer_snapshot
from reverie.context_engine.dependency_graph import DependencyGraph
from reverie.context_engine.parsers.python_parser import PythonParser
from reverie.context_engine.symbol_table import Symbol, SymbolKind, SymbolTable
from reverie.gamer import reference_intelligence as gamer_reference_intelligence
from reverie.sse import iter_sse_data_strings
from reverie.tools.codebase_retrieval import CodebaseRetrievalTool
from reverie.tools.command_exec import CommandExecTool
from reverie.tools.task_manager import TaskManagerTool, cleanup_completed_task_artifacts
from reverie.tools.web_search import WebFetchTool, WebSearchTool
from reverie.config import Config, ModelConfig


def test_desktop_interface_import_stays_clear_of_terminal_agent_and_engine_stacks() -> None:
    probe = subprocess.run(
        [
            sys.executable,
            "-c",
            (
                "import sys; import reverie.cli.interface; "
                "blocked=('reverie.cli.commands','reverie.agent.agent','reverie.engine.app'); "
                "print(','.join(name for name in blocked if name in sys.modules))"
            ),
        ],
        capture_output=True,
        text=True,
        check=True,
        cwd=Path(__file__).resolve().parents[1],
    )

    assert probe.stdout.strip() == ""


class _FakeStreamingResponse:
    def __init__(self, lines: list[str]):
        self._lines = list(lines)

    def iter_lines(self, decode_unicode: bool = True, chunk_size: int = 0):
        assert decode_unicode is False
        assert chunk_size >= 512
        for line in self._lines:
            yield line.encode("utf-8")


class _BrokenStreamingResponse:
    def __init__(self, lines: list[str], error: Exception):
        self._lines = list(lines)
        self._error = error

    def iter_lines(self, decode_unicode: bool = True, chunk_size: int = 0):
        assert decode_unicode is False
        assert chunk_size >= 512
        for line in self._lines:
            yield line.encode("utf-8")
        raise self._error


class _FakeHTTPResponse:
    def __init__(self, body: str, *, status_code: int = 200, content_type: str = "text/html; charset=utf-8"):
        self.status_code = status_code
        self.text = body
        self.content = body.encode("utf-8")
        self.headers = {"content-type": content_type}


def _symbol(name: str, qualified_name: str, file_path: str, line: int) -> Symbol:
    return Symbol(
        name=name,
        qualified_name=qualified_name,
        kind=SymbolKind.FUNCTION,
        file_path=file_path,
        start_line=line,
        end_line=line + 1,
        language="python",
    )


def test_python_parser_handles_utf8_bom(tmp_path: Path) -> None:
    target = tmp_path / "bom_module.py"
    target.write_text("\ufeffdef greet(name: str) -> str:\n    return f'hi {name}'\n", encoding="utf-8")

    parser = PythonParser(tmp_path)
    result = parser.parse_file(target)

    assert result.success is True
    assert any(symbol.name == "greet" for symbol in result.symbols)


def test_symbol_table_search_respects_limit(tmp_path: Path) -> None:
    table = SymbolTable()
    table.add_symbol(_symbol("SearchThing", "pkg.SearchThing", str(tmp_path / "a.py"), 1))
    table.add_symbol(_symbol("SearchTools", "pkg.SearchTools", str(tmp_path / "b.py"), 10))
    table.add_symbol(_symbol("SearchState", "pkg.SearchState", str(tmp_path / "c.py"), 20))

    results = table.search("search", limit=2)

    assert len(results) == 2
    assert all("search" in symbol.name.lower() for symbol in results)


def test_iter_sse_data_strings_handles_multiline_events_and_raw_json() -> None:
    response = _FakeStreamingResponse(
        [
            "event: message",
            'data: {"type":"content","text":"hello"}',
            'data: {"type":"content","text":" world"}',
            "",
            '{"choices":[{"delta":{"content":"tail"}}]}',
            "data: [DONE]",
            "",
        ]
    )

    payloads = list(iter_sse_data_strings(response))

    assert payloads == [
        '{"type":"content","text":"hello"}\n{"type":"content","text":" world"}',
        '{"choices":[{"delta":{"content":"tail"}}]}',
    ]


def test_iter_sse_data_strings_decodes_utf8_without_response_charset() -> None:
    response = _FakeStreamingResponse(
        [
            'data: {"choices":[{"delta":{"content":"你好，世界"}}]}',
            "",
            "data: [DONE]",
            "",
        ]
    )

    payloads = list(iter_sse_data_strings(response))

    assert payloads == ['{"choices":[{"delta":{"content":"你好，世界"}}]}']


def test_iter_sse_data_strings_tolerates_premature_close_after_partial_payload() -> None:
    response = _BrokenStreamingResponse(
        [
            'data: {"type":"content","text":"hello"}',
            "",
        ],
        requests.exceptions.ChunkedEncodingError("peer closed connection without sending complete message body"),
    )

    payloads = list(iter_sse_data_strings(response))

    assert payloads == ['{"type":"content","text":"hello"}']


def test_streaming_turn_state_hides_end_token_and_closes_thinking() -> None:
    state = _StreamingTurnState()

    chunks = []
    chunks.extend(state.add_reasoning("Planning"))
    chunks.extend(state.add_content("Hello //EN"))
    chunks.extend(state.add_content("D//world"))
    chunks.extend(state.flush())

    assert chunks == [
        THINKING_START_MARKER,
        "Planning",
        THINKING_END_MARKER,
        "Hello ",
        "world",
    ]
    assert state.cleaned_content() == "Hello world"


def test_streaming_turn_state_routes_inline_think_tags_to_reasoning() -> None:
    state = _StreamingTurnState()

    chunks = []
    chunks.extend(state.add_content("<thi"))
    chunks.extend(state.add_content("nk>Plan first"))
    chunks.extend(state.add_content("</thi"))
    chunks.extend(state.add_content("nk>\nAnswer //END//"))
    chunks.extend(state.flush())

    assert chunks == [
        THINKING_START_MARKER,
        "Plan first",
        THINKING_END_MARKER,
        "\nAnswer ",
    ]
    assert state.collected_thinking == "Plan first"
    assert state.cleaned_content() == "Answer"


def test_streaming_turn_state_accumulates_tool_call_arguments() -> None:
    state = _StreamingTurnState()

    state.update_tool_call(0, tool_call_id="call_1", name="shell")
    state.update_tool_call(0, arguments='{"command":"pw', append_arguments=True)
    state.update_tool_call(0, arguments='sh"}', append_arguments=True, thought_signature="sig-1")

    assert state.tool_calls == [
        {
            "id": "call_1",
            "type": "function",
            "thought_signature": "sig-1",
            "function": {
                "name": "shell",
                "arguments": '{"command":"pwsh"}',
            },
        }
    ]


def test_parse_tool_arguments_preserves_long_malformed_file_content() -> None:
    body = (
        '# 技术方案 "Vulkan"\n'
        "```json\n"
        '{"path":"demo.md","content":"example","pipeline":"deferred","layers":3}\n'
        "```\n"
        + "长文本段落\n" * 200
    )
    raw = '{"path":"task.md","content":"' + body + '","overwrite":true}'

    args = parse_tool_arguments(raw)

    assert args["path"] == "task.md"
    assert args["content"] == body
    assert args["overwrite"] is True


def test_unterminated_tool_content_cannot_write_a_partial_file(tmp_path: Path) -> None:
    body = "# Draft\n" + ("details\n" * 500)
    raw = '{"path":"task.md","content":"' + body

    args = parse_tool_arguments(raw)

    executor = ToolExecutor(project_root=tmp_path)
    result = executor.execute("create_file", args)
    assert result.success is False
    assert "Incomplete tool arguments" in result.error
    assert not (tmp_path / "task.md").exists()


def test_incomplete_arguments_remain_denied_after_history_normalization():
    from reverie.agent.agent import _sanitize_tool_calls

    calls = [{"id": "partial", "function": {"name": "any_tool", "arguments": '{"optional":"cut off'}}]
    _sanitize_tool_calls(calls)
    args = parse_tool_arguments(calls[0]["function"]["arguments"])
    # No tool lookup, discovery, review or no-argument side effect may run.
    executor = ToolExecutor.__new__(ToolExecutor)
    executor._sync_dynamic_tools = lambda: (_ for _ in ()).throw(AssertionError("Tool discovery must not run"))
    result = executor.execute("any_tool", args)
    assert not result.success
    assert "nothing was executed" in result.error


def test_stream_finalization_does_not_execute_nameless_filler_or_emit_empty_ids():
    from reverie.agent.agent import _compact_tool_calls_for_history

    state = _StreamingTurnState()
    state.add_reasoning("  full native trace\n")
    state.update_tool_call(0, name="create_file", arguments='{"path":"x","content":"ok"}')
    state.update_tool_call(1, arguments="")  # Real gateway's extra nameless fragment.
    state.set_finish_reason("tool_calls")
    state.flush()
    assert len(state.tool_calls) == 1
    assert state.tool_calls[0]['id']
    assert _compact_tool_calls_for_history(state.tool_calls)[0]['id'] == state.tool_calls[0]['id']
    assert state.collected_thinking == "  full native trace\n"


def test_outbound_recovery_excludes_empty_id_results_but_preserves_original_history():
    from reverie.agent.agent import _sanitize_messages_for_relay

    messages = [
        {'role': 'assistant', 'content': '', 'reasoning_content': '  full trace\n',
         'tool_calls': [{'id': 'owned', 'function': {'name': 'create_file', 'arguments': '{}'}}]},
        {'role': 'tool', 'tool_call_id': 'owned', 'content': 'Error: incomplete arguments, nothing executed'},
        {'role': 'tool', 'tool_call_id': '', 'content': 'Error: Unknown tool: '},
    ]
    wire = _sanitize_messages_for_relay(messages, preserve_assistant_reasoning=True)
    assert [m.get('tool_call_id') for m in wire if m['role'] == 'tool'] == ['owned']
    assert wire[0]['reasoning_content'] == '  full trace\n'
    assert len(messages) == 3 and messages[-1]['tool_call_id'] == ''


def test_command_exec_builds_powershell_for_pipelines_and_cmdlets(tmp_path: Path) -> None:
    tool = CommandExecTool({"project_root": tmp_path})

    pipeline_invocation = tool._build_invocation(
        "Get-ChildItem . | Select-Object -First 1",
        tmp_path,
    )
    cmdlet_invocation = tool._build_invocation(
        'Select-String -Path *.py -Pattern "TODO"',
        tmp_path,
    )

    assert pipeline_invocation["executor"] == "powershell"
    assert " | " in pipeline_invocation["display"]
    assert "'|'" not in pipeline_invocation["display"]

    assert cmdlet_invocation["executor"] == "powershell"
    assert cmdlet_invocation["argv"][0].lower().endswith(("powershell.exe", "pwsh"))


def test_command_exec_allows_toolchain_registry_and_package_references(tmp_path: Path) -> None:
    tool = CommandExecTool({"project_root": tmp_path})

    npm_invocation = tool._build_invocation("npm install @types/node", tmp_path)
    cargo_invocation = tool._build_invocation("cargo add serde/derive", tmp_path)
    docker_invocation = tool._build_invocation("docker pull ghcr.io/example/app:latest", tmp_path)

    assert npm_invocation["executor"] == "subprocess"
    assert cargo_invocation["executor"] == "subprocess"
    assert docker_invocation["executor"] == "subprocess"


def test_command_exec_keeps_workspace_path_guard_for_toolchain_paths(tmp_path: Path) -> None:
    tool = CommandExecTool({"project_root": tmp_path})

    try:
        tool._build_invocation("docker build -f ../Dockerfile .", tmp_path)
    except ValueError as exc:
        assert "parent-directory traversal" in str(exc)
    else:
        raise AssertionError("docker path traversal should be blocked")


def test_command_exec_prefers_workspace_venv_for_python_package_installs(tmp_path: Path) -> None:
    venv = tmp_path / ".venv"
    bin_dir = venv / ("Scripts" if sys.platform == "win32" else "bin")
    bin_dir.mkdir(parents=True)
    tool = CommandExecTool({"project_root": tmp_path})

    invocation = tool._build_invocation("python -m pip install requests", tmp_path)

    env = invocation["env_overrides"]
    assert env["VIRTUAL_ENV"] == str(venv)
    assert env["PATH"].split(";")[0] == str(bin_dir) if sys.platform == "win32" else env["PATH"].split(":")[0] == str(bin_dir)


def test_task_drawer_snapshot_reads_json_artifact_in_display_order(tmp_path: Path) -> None:
    artifacts_dir = tmp_path / "artifacts"
    artifacts_dir.mkdir(parents=True, exist_ok=True)
    (artifacts_dir / "task_list.json").write_text(
        json.dumps(
            {
                "tasks": [
                    {
                        "id": "root",
                        "name": "Refactor CLI surface",
                        "state": "IN_PROGRESS",
                        "children": ["child"],
                        "parent_id": None,
                    },
                    {
                        "id": "child",
                        "name": "Compact tool logs",
                        "state": "COMPLETED",
                        "children": [],
                        "parent_id": "root",
                    },
                    {
                        "id": "extra",
                        "name": "Add todo drawer",
                        "state": "NOT_STARTED",
                        "children": [],
                        "parent_id": None,
                    },
                ],
                "root_tasks": ["root", "extra"],
            },
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    snapshot = _load_task_drawer_snapshot(tmp_path, max_visible=2)

    assert snapshot["total"] == 3
    assert snapshot["completed"] == 1
    assert snapshot["hidden"] == 0
    assert [item["name"] for item in snapshot["tasks"]] == [
        "Refactor CLI surface",
        "Compact tool logs",
        "Add todo drawer",
    ]
    assert snapshot["tasks"][1]["indent"] == 1


def test_task_drawer_prefers_markdown_over_stale_json(tmp_path: Path) -> None:
    artifacts_dir = tmp_path / "artifacts"
    artifacts_dir.mkdir(parents=True, exist_ok=True)
    json_path = artifacts_dir / "task_list.json"
    markdown_path = artifacts_dir / "task.md"
    json_path.write_text(
        json.dumps(
            {
                "tasks": [
                    {
                        "id": "root",
                        "name": "Wire local repository",
                        "state": "NOT_STARTED",
                        "children": [],
                        "parent_id": None,
                    }
                ],
                "root_tasks": ["root"],
            }
        ),
        encoding="utf-8",
    )
    markdown_path.write_text("[x] Wire local repository\n[ ] Add persistence tests\n", encoding="utf-8")

    snapshot = _load_task_drawer_snapshot(tmp_path)

    assert snapshot["source"] == "markdown"
    assert snapshot["total"] == 2
    assert snapshot["completed"] == 1
    assert [item["state"] for item in snapshot["tasks"]] == ["COMPLETED", "NOT_STARTED"]


def test_task_manager_updates_by_exact_name_and_syncs_checklist(tmp_path: Path) -> None:
    tool = TaskManagerTool({"project_root": tmp_path})

    added = tool.execute(action="add", tasks=["Add DB schema", "Add repository tests"])
    assert added.success is True

    updated = tool.execute(action="update", target="Add DB schema", status="done")

    assert updated.success is True
    checklist = (tmp_path / "artifacts" / "task.md").read_text(encoding="utf-8")
    assert "[x] Add DB schema" in checklist
    assert "[ ] Add repository tests" in checklist
    assert not (tmp_path / "artifacts" / "task_list.json").exists()


def test_task_manager_imports_legacy_json_then_saves_markdown_only(tmp_path: Path) -> None:
    artifacts_dir = tmp_path / "artifacts"
    artifacts_dir.mkdir(parents=True, exist_ok=True)
    legacy_json = artifacts_dir / "task_list.json"
    legacy_json.write_text(
        json.dumps(
            {
                "tasks": [
                    {
                        "id": "root",
                        "name": "Migrate task persistence",
                        "state": "IN_PROGRESS",
                        "children": ["child"],
                        "parent_id": None,
                    },
                    {
                        "id": "child",
                        "name": "Keep checklist editable",
                        "state": "COMPLETED",
                        "children": [],
                        "parent_id": "root",
                    },
                ],
                "root_tasks": ["root"],
            },
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    tool = TaskManagerTool({"project_root": tmp_path})
    result = tool.execute(action="list")

    assert result.success is True
    checklist = (artifacts_dir / "task.md").read_text(encoding="utf-8")
    assert "[/] Migrate task persistence" in checklist
    assert "  [x] Keep checklist editable" in checklist
    assert not legacy_json.exists()


def test_completed_task_artifact_cleanup_removes_finished_checklists(tmp_path: Path) -> None:
    artifacts_dir = tmp_path / "artifacts"
    artifacts_dir.mkdir(parents=True, exist_ok=True)
    canonical = artifacts_dir / "task.md"
    legacy = artifacts_dir / "Tasks.md"
    canonical.write_text("[x] Add task cleanup\n  [X] Verify cleanup\n", encoding="utf-8")
    legacy.write_text("[x]Finish legacy slice\n", encoding="utf-8")

    deleted = cleanup_completed_task_artifacts(tmp_path)

    assert set(path.name for path in deleted) == {"Tasks.md", "task.md"}
    assert not canonical.exists()
    assert not legacy.exists()


def test_completed_task_artifact_cleanup_keeps_incomplete_checklists(tmp_path: Path) -> None:
    artifacts_dir = tmp_path / "artifacts"
    artifacts_dir.mkdir(parents=True, exist_ok=True)
    canonical = artifacts_dir / "task.md"
    atlas = artifacts_dir / "Tasks.md"
    canonical.write_text("[x] Add task cleanup\n[ ] Verify cleanup\n", encoding="utf-8")
    atlas.write_text("Main task\n\nSubgoal 1\n[x]Finish slice\n[/]Run validation\n", encoding="utf-8")

    deleted = cleanup_completed_task_artifacts(tmp_path)

    assert deleted == []
    assert canonical.exists()
    assert atlas.exists()


def test_model_config_omits_null_context_tokens_on_save() -> None:
    payload = ModelConfig(
        model="example-model",
        model_display_name="Example",
        base_url="https://example.invalid/v1",
        max_context_tokens=None,
    ).to_dict()

    assert "max_context_tokens" not in payload


def test_display_compacts_tool_result_into_single_row_with_preview() -> None:
    console = Console(record=True, force_terminal=False, width=120)
    display = DisplayComponents(console)
    display.set_tool_output_style("condensed")

    display.show_tool_invocation(
        tool_name="str_replace_editor",
        message="Viewing file: reverie/cli/interface.py",
        arguments={"command": "view", "path": "reverie/cli/interface.py", "view_range": [50, 60]},
        tool_call_id="call_123",
    )
    assert console.export_text() == ""

    display.show_tool_result_card(
        tool_name="str_replace_editor",
        success=True,
        output=(
            "File: reverie/cli/interface.py\n"
            "Total lines: 2784\n"
            "Showing lines 50-60\n"
            "\n"
            "  50 | class StreamingFooter:\n"
            "  51 |     def __rich__(self):\n"
        ),
        arguments={"command": "view", "path": "reverie/cli/interface.py", "view_range": [50, 60]},
        tool_call_id="call_123",
    )

    rendered = console.export_text()
    assert "ReadFile" in rendered
    assert "Read lines 50-60 of 2784" in rendered
    assert "50 | class StreamingFooter:" in rendered


def test_display_full_tool_output_style_keeps_expanded_result_block() -> None:
    console = Console(record=True, force_terminal=False, width=120)
    display = DisplayComponents(console)
    display.set_tool_output_style("full")

    display.show_tool_result_card(
        tool_name="command_exec",
        success=True,
        output="$ git status\nWorking directory: .\nExecutor: subprocess\nPolicy: workspace_blacklist\nExit code: 0\nDuration: 12ms\n\n--- STDOUT ---\nclean tree",
        arguments={"command": "git status"},
        tool_call_id="call_full",
    )

    rendered = console.export_text()
    assert "command_exec" in rendered.lower()
    assert "clean tree" in rendered
    assert "done" in rendered.lower()


def test_display_condensed_command_result_skips_preview_after_live_progress() -> None:
    console = Console(record=True, force_terminal=False, width=120)
    display = DisplayComponents(console)
    display.set_tool_output_style("condensed")

    display.show_tool_result_card(
        tool_name="command_exec",
        success=True,
        output=(
            "$ git status\n"
            "Working directory: .\n"
            "Executor: subprocess\n"
            "Policy: workspace_blacklist\n"
            "Exit code: 0\n"
            "Duration: 12ms\n\n"
            "--- STDOUT ---\n"
            "clean tree"
        ),
        arguments={"command": "git status"},
        had_live_progress=True,
    )

    rendered = console.export_text()
    assert "Exit 0 in 12ms" in rendered
    assert "clean tree" not in rendered


def test_web_search_defaults_to_link_discovery_without_fetch(monkeypatch) -> None:
    tool = WebSearchTool()
    tool._available = True

    monkeypatch.setattr(
        tool,
        "_search_ddg",
        lambda *args, **kwargs: [
            {
                "title": "Modrinth API",
                "href": "https://docs.modrinth.com/api/",
                "body": "Official API docs",
                "rank": 1,
            }
        ],
    )
    # The parallel pipeline fans out to every engine, so all three must be
    # stubbed or Bing/Brave would make a real network call in the test.
    monkeypatch.setattr(tool, "_search_bing", lambda *args, **kwargs: [])
    monkeypatch.setattr(tool, "_search_brave", lambda *args, **kwargs: [])

    def fail_fetch(*args, **kwargs):
        raise AssertionError("web_search should not fetch page content by default")

    monkeypatch.setattr(tool, "_fetch_page_payload", fail_fetch)

    result = tool.execute(query="Modrinth API", max_results=5)

    assert result.success is True
    assert result.data["settings"]["fetch_content"] is False
    assert "https://docs.modrinth.com/api/" in result.output
    assert "Fetch Status" not in result.output
    # A single-engine hit still carries an evidence score and its engine list.
    top = result.data["results"][0]
    assert top["evidence"]["engines"] == ["ddg"]
    assert 0.0 < top["evidence_score"] <= 1.0


def test_web_fetch_reads_selected_urls(monkeypatch) -> None:
    tool = WebFetchTool()
    tool._available = True

    monkeypatch.setattr(
        tool,
        "_fetch_page_payload",
        lambda url, **kwargs: {
            "fetch_status": "ok",
            "fetched_title": "Modrinth API",
            "fetched_description": "API docs",
            "fetched_content": "Use project versions endpoints for downloads.",
            "outbound_links": ["https://api.modrinth.com/v2/"],
        },
    )

    result = tool.execute(
        urls=["https://docs.modrinth.com/api/", "not-a-url", "https://docs.modrinth.com/api/"],
        max_content_chars=2000,
    )

    assert result.success is True
    assert result.data["count"] == 1
    assert "Use project versions endpoints for downloads." in result.output
    assert result.data["results"][0]["url"] == "https://docs.modrinth.com/api"


def test_web_fetch_extracts_wechat_style_metadata_and_media(monkeypatch) -> None:
    tool = WebFetchTool()
    tool._available = True

    html = """
    <html>
      <head>
        <meta property="og:title" content="AI应用丨周长最短和面积最大问题.html">
        <meta property="og:description" content="应用界面整体显示和动态演示效果">
        <meta property="og:site_name" content="微信公众平台">
        <meta name="author" content="Mr DaBai">
        <meta property="og:image" content="https://mmbiz.qpic.cn/cover/0?wx_fmt=jpeg">
      </head>
      <body>
        <h1 id="activity-name">fallback title</h1>
        <div id="js_content">
          <p>三下人教版教科书题目说明。这里是一段足够长的正文，用来模拟微信公众号文章里的教学应用介绍、界面说明、动态演示和应用获取方式。</p>
          <p>继续补充正文长度，确保主内容节点被选中，并且不会退化成整个 body 的杂乱文本。</p>
          <img data-src="https://mmbiz.qpic.cn/demo/screenshot/640?wx_fmt=png&amp;from=appmsg" data-w="1080" alt="应用完整动态演示效果">
        </div>
      </body>
    </html>
    """

    monkeypatch.setattr(tool, "_request_with_retry", lambda *args, **kwargs: _FakeHTTPResponse(html))

    result = tool.execute(url="https://mp.weixin.qq.com/s/example", max_content_chars=4000)

    assert result.success is True
    fetched = result.data["results"][0]
    assert fetched["fetched_title"] == "AI应用丨周长最短和面积最大问题.html"
    assert fetched["fetched_author"] == "Mr DaBai"
    assert fetched["fetched_site_name"] == "微信公众平台"
    assert len(fetched["media_assets"]) == 2
    assert any(asset["url"].startswith("https://mmbiz.qpic.cn/demo/screenshot/640") for asset in fetched["media_assets"])
    assert "Media Assets" in result.output


def test_web_fetch_marks_verification_pages_as_blocked(monkeypatch) -> None:
    tool = WebFetchTool()
    tool._available = True

    html = """
    <html>
      <head><title>Security Check</title></head>
      <body><main>请完成安全验证后继续访问。This page is checking your browser before access.</main></body>
    </html>
    """
    monkeypatch.setattr(tool, "_request_with_retry", lambda *args, **kwargs: _FakeHTTPResponse(html))

    result = tool.execute(url="https://example.com/protected", max_content_chars=4000)

    assert result.success is True
    fetched = result.data["results"][0]
    assert fetched["fetch_status"] == "blocked"
    assert "verification-gated page" in fetched["fetched_content"]


def test_web_search_treats_direct_url_as_candidate() -> None:
    tool = WebSearchTool()
    tool._available = True

    result = tool.execute(query="https://example.com/docs", max_results=5)

    assert result.success is True
    assert result.data["engine"] == "direct_url"
    assert result.data["results"][0]["href"] == "https://example.com/docs"


def _stub_engine(hits):
    """Return a search-engine stub yielding fixed (title, href, body, rank) rows."""

    def _engine(*args, **kwargs):
        return [dict(hit) for hit in hits]

    return _engine


def test_web_search_fuses_engines_and_rewards_consensus(monkeypatch) -> None:
    tool = WebSearchTool()
    tool._available = True

    # Paris is returned by two engines (consensus); Lyon by one only. Even
    # though DDG ranks Lyon #1, the two-engine agreement on Paris must win.
    ddg_hits = [
        {"title": "Lyon", "href": "https://example.com/lyon", "body": "capital france text", "rank": 1},
        {"title": "Paris capital of France", "href": "https://example.com/paris", "body": "paris is the capital of france", "rank": 2},
    ]
    bing_hits = [
        {"title": "Paris capital of France", "href": "https://example.com/paris", "body": "paris is the capital of france", "rank": 1},
    ]
    monkeypatch.setattr(tool, "_search_ddg", _stub_engine(ddg_hits))
    monkeypatch.setattr(tool, "_search_bing", _stub_engine(bing_hits))
    monkeypatch.setattr(tool, "_search_brave", _stub_engine([]))

    result = tool.execute(query="what is the capital of France", max_results=5)

    assert result.success is True
    top = result.data["results"][0]
    assert top["href"] == "https://example.com/paris"
    assert sorted(top["evidence"]["engines"]) == ["bing", "ddg"]
    assert top["evidence"]["consensus"] == 1.0
    # The one-engine result ranks below and reports lower consensus.
    lyon = next(r for r in result.data["results"] if r["href"] == "https://example.com/lyon")
    assert lyon["evidence"]["consensus"] == 0.5
    assert top["evidence_score"] >= lyon["evidence_score"]
    assert result.data["engine"] == "ddg+bing"


def test_fuse_flags_weak_low_evidence_result() -> None:
    tool = WebSearchTool()

    # Strong hit: agreed on by all three engines at rank 1 (high fusion + full
    # consensus + full lexical overlap). Straggler: one engine, deep rank, no
    # query-term overlap -> low fusion, low consensus, zero lexical -> weak.
    results_by_engine = {
        "ddg": [
            {"title": "Quantum entanglement primer", "href": "https://example.com/qe", "body": "quantum entanglement explained", "rank": 1},
            {"title": "Unrelated cooking blog", "href": "https://example.com/food", "body": "best pasta recipes", "rank": 30},
        ],
        "bing": [{"title": "Quantum entanglement primer", "href": "https://example.com/qe", "body": "quantum entanglement explained", "rank": 1}],
        "brave": [{"title": "Quantum entanglement primer", "href": "https://example.com/qe", "body": "quantum entanglement explained", "rank": 1}],
    }
    fused = tool._fuse_results(results_by_engine, {"quantum", "entanglement"}, 5)

    strong = next(r for r in fused if r["href"] == "https://example.com/qe")
    weak = next(r for r in fused if r["href"] == "https://example.com/food")
    assert strong["weak"] is False
    assert weak["weak"] is True
    assert weak["evidence_score"] < WebSearchTool.WEAK_EVIDENCE_THRESHOLD
    # The confident hit sorts ahead of the weak straggler.
    assert fused.index(strong) < fused.index(weak)


def test_web_search_multi_query_fans_out_and_refuses(monkeypatch) -> None:
    tool = WebSearchTool()
    tool._available = True

    calls = []

    def fake_search_one(query, *args, **kwargs):
        calls.append(query)
        if query == "python asyncio":
            hits = [{"title": "asyncio docs", "href": "https://docs.python.org/3/library/asyncio.html", "body": "asyncio event loop", "rank": 1, "evidence_score": 0.8, "evidence": {"fusion": 1.0, "lexical": 0.5, "consensus": 0.5, "engines": ["ddg"]}, "engines": ["ddg"], "weak": False}]
        else:
            hits = [{"title": "asyncio docs", "href": "https://docs.python.org/3/library/asyncio.html", "body": "asyncio event loop", "rank": 1, "evidence_score": 0.7, "evidence": {"fusion": 1.0, "lexical": 0.4, "consensus": 0.5, "engines": ["bing"]}, "engines": ["bing"], "weak": False}]
        return {"results": hits, "engine": "ddg", "attempts": [{"provider": "ddg", "count": 1, "status": "ok"}], "cached": False}

    monkeypatch.setattr(tool, "_search_one_query", fake_search_one)

    result = tool.execute(query=["python asyncio", "python event loop"], max_results=5)

    assert result.success is True
    assert calls == ["python asyncio", "python event loop"]
    assert result.data["engine"] == "multi-query"
    assert result.data["queries"] == ["python asyncio", "python event loop"]
    # The URL both queries surfaced is fused into a single ranked entry.
    hrefs = [r["href"] for r in result.data["results"]]
    assert hrefs.count("https://docs.python.org/3/library/asyncio.html") == 1


def test_bing_redirect_urls_are_unwrapped() -> None:
    tool = WebSearchTool()
    # bing.com/ck/a wraps the real URL as urlsafe-base64 in the `u=a1...` param.
    import base64

    target = "https://en.wikipedia.org/wiki/Paris"
    token = "a1" + base64.urlsafe_b64encode(target.encode("utf-8")).decode("ascii").rstrip("=")
    wrapped = f"https://www.bing.com/ck/a?!&&p=deadbeef&u={token}"

    assert tool._unwrap_bing_url(wrapped) == target
    # A plain (non-redirect) URL passes through untouched.
    assert tool._unwrap_bing_url("https://example.com/page") == "https://example.com/page"
    # A malformed token falls back to the original href rather than raising.
    assert tool._unwrap_bing_url("https://www.bing.com/ck/a?u=a1@@@notbase64").startswith("https://www.bing.com/ck/a")


def test_content_quality_classification() -> None:
    tool = WebSearchTool()
    assert tool._classify_content_quality("x" * 1500, None) == "ok"
    assert tool._classify_content_quality("short stub", None) == "thin"
    assert tool._classify_content_quality("x" * 600, None) == "ok"

    class _FakeMain:
        def find_all(self, _name):
            return ["<script>" + "y" * 3000 + "</script>"]

    # Tiny visible text but heavy script markup -> unrendered SPA shell.
    assert tool._classify_content_quality("hi", _FakeMain()) == "spa_shell"


def test_excerpt_pins_to_query_match_with_offsets() -> None:
    tool = WebSearchTool()
    content = "Intro sentence. The capital of France is Paris, a major city. More trailing text."
    excerpt = tool._build_excerpt(content, {"paris"}, max_len=40)

    assert "paris" in excerpt["text"].lower()
    assert content[excerpt["start"]:excerpt["end"]] == excerpt["text"]
    # No match falls back to the head of the content.
    head = tool._build_excerpt(content, {"zzznomatch"}, max_len=40)
    assert head["start"] == 0


def test_web_fetch_reports_published_date_and_quality(monkeypatch) -> None:
    tool = WebFetchTool()
    tool._available = True

    html = """
    <html>
      <head>
        <title>Release Notes</title>
        <meta property="article:published_time" content="2026-03-14T09:00:00Z">
      </head>
      <body>
        <main>%s</main>
      </body>
    </html>
    """ % ("Version 2.0 ships today with a rewritten search pipeline. " * 40)

    monkeypatch.setattr(tool, "_request_with_retry", lambda *args, **kwargs: _FakeHTTPResponse(html))

    result = tool.execute(url="https://example.com/notes", query="search pipeline", max_content_chars=6000)

    assert result.success is True
    fetched = result.data["results"][0]
    assert fetched["published_at"] == "2026-03-14T09:00:00Z"
    assert fetched["content_quality"] == "ok"
    assert fetched["excerpt"]["text"]
    assert "Published:" in result.output


def test_vision_upload_is_not_registered_as_builtin_tool(tmp_path: Path) -> None:
    executor = ToolExecutor(project_root=tmp_path)

    schema_names = {
        schema.get("function", {}).get("name")
        for schema in executor.get_tool_schemas(mode="reverie")
    }

    assert "vision_upload" not in schema_names
    assert executor.get_tool("vision_upload") is None


def test_inline_image_vision_gate_accepts_standard_models_marked_vision() -> None:
    interface = ReverieInterface.__new__(ReverieInterface)
    config = Config(
        models=[
            ModelConfig(
                model="vision-model",
                model_display_name="Vision Model",
                base_url="https://example.com/v1",
                supports_vision=True,
            )
        ],
        active_model_index=0,
        active_model_source="standard",
    )

    allowed, detail = interface._can_attach_inline_images(config)

    assert allowed is True
    assert detail == ""


def test_inline_image_vision_gate_rejects_unmarked_standard_models() -> None:
    interface = ReverieInterface.__new__(ReverieInterface)
    config = Config(
        models=[
            ModelConfig(
                model="text-model",
                model_display_name="Text Model",
                base_url="https://example.com/v1",
            )
        ],
        active_model_index=0,
        active_model_source="standard",
    )

    allowed, detail = interface._can_attach_inline_images(config)

    assert allowed is False
    assert "supports_vision=true" in detail


def test_inline_image_vision_gate_accepts_aihubmix_models_marked_vision() -> None:
    interface = ReverieInterface.__new__(ReverieInterface)
    config = Config(
        models=[
            ModelConfig(
                model="aihubmix-vision",
                model_display_name="AIhubMix Vision",
                base_url="https://example.com/v1",
                supports_vision=True,
            )
        ],
        active_model_index=0,
        active_model_source="aihubmix",
    )

    allowed, detail = interface._can_attach_inline_images(config)

    assert allowed is True
    assert detail == ""


def test_command_exec_emits_incremental_ui_progress(tmp_path: Path) -> None:
    events = []
    tool = CommandExecTool(
        {
            "project_root": tmp_path,
            "ui_event_handler": events.append,
            "active_tool_call_id": "call_stream",
            "active_tool_name": "command_exec",
        }
    )

    script = tmp_path / "stream_output.py"
    script.write_text(
        "import sys\nprint('alpha')\nprint('beta', file=sys.stderr)\n",
        encoding="utf-8",
    )
    result = tool.execute(command="python -u stream_output.py")

    assert result.success is True
    assert any(event.get("kind") == "tool_progress" and "alpha" in event.get("text", "") for event in events)
    assert any(event.get("kind") == "tool_progress" and "beta" in event.get("text", "") for event in events)


def test_reference_catalog_scan_uses_cache_on_repeated_workspace_reads(tmp_path: Path) -> None:
    gamer_reference_intelligence._REFERENCE_SCAN_CACHE.clear()
    gamer_reference_intelligence._REFERENCE_MANIFEST_CACHE.clear()
    references_root = tmp_path / "references"
    (references_root / "godot-tps-demo" / "player").mkdir(parents=True, exist_ok=True)
    (references_root / "godot-tps-demo" / "enemies" / "red_robot").mkdir(parents=True, exist_ok=True)
    (references_root / "godot-demo-projects" / "mono" / "squash_the_creeps").mkdir(parents=True, exist_ok=True)

    (references_root / "godot-tps-demo" / "project.godot").write_text("config_version=5\n", encoding="utf-8")
    (references_root / "godot-tps-demo" / "player" / "player.gd").write_text(
        "extends CharacterBody3D\n",
        encoding="utf-8",
    )
    (references_root / "godot-tps-demo" / "player" / "player_input.gd").write_text(
        "extends MultiplayerSynchronizer\n",
        encoding="utf-8",
    )
    (references_root / "godot-tps-demo" / "enemies" / "red_robot" / "red_robot.gd").write_text(
        "extends CharacterBody3D\n",
        encoding="utf-8",
    )
    (references_root / "godot-demo-projects" / "mono" / "squash_the_creeps" / "project.godot").write_text(
        "config_version=5\n",
        encoding="utf-8",
    )
    (references_root / "godot-demo-projects" / "mono" / "squash_the_creeps" / "Main.tscn").write_text(
        "[gd_scene format=3]\n",
        encoding="utf-8",
    )

    first = gamer_reference_intelligence.scan_reference_catalog(project_root=tmp_path)
    second = gamer_reference_intelligence.scan_reference_catalog(project_root=tmp_path)

    assert first["cache_status"] == "miss"
    assert second["cache_status"] == "hit"
    assert second["summary"]["repository_count"] >= 2
    assert second["summary"]["total_files"] >= 4


def test_interface_deduplicates_repeated_live_tool_progress_chunks() -> None:
    interface = ReverieInterface.__new__(ReverieInterface)
    interface._active_tool_details = {}
    interface._active_tool_lock = threading.Lock()

    payload = {
        "tool_call_id": "call_progress",
        "tool_name": "command_exec",
        "stream": "stdout",
        "text": "alpha\n",
    }
    first = interface._append_active_tool_progress(payload)
    second = interface._append_active_tool_progress(payload)
    third = interface._append_active_tool_progress({**payload, "text": "beta\n"})

    current = interface._active_tool_details["call_progress"]
    assert first is True
    assert second is False
    assert third is True
    assert current["stdout"] == "alpha\nbeta\n"
    assert current["progress_event_count"] == 2

    summary = interface._clear_active_tool("call_progress")
    assert summary["had_live_progress"] is True


def test_context_engine_cold_index_runs_in_background() -> None:
    calls: list[str] = []

    class FakeIndexer:
        def full_index(self):
            calls.append("full_index")
            return object()

    interface = ReverieInterface.__new__(ReverieInterface)
    interface.indexer = FakeIndexer()
    interface._indexing_thread = None
    interface._indexing_in_progress = False
    interface._show_activity_event = lambda *args, **kwargs: calls.append("event")
    interface._refresh_command_context = lambda: calls.append("refresh")
    interface._sync_agent_context_engine = lambda: calls.append("sync")

    started = interface._start_context_indexing_background()

    assert started is True
    assert interface._indexing_thread is not None
    interface._indexing_thread.join(timeout=2)
    assert not interface._indexing_thread.is_alive()
    assert interface._indexing_in_progress is False
    assert "full_index" in calls
    assert "refresh" in calls
    assert "sync" in calls


def test_silent_context_engine_init_starts_background_without_activity(monkeypatch) -> None:
    calls: list[str] = []
    index_configs: list[object] = []

    class FakeIndexer:
        def __init__(self, project_root, cache_dir=None, config=None):
            self.project_root = project_root
            self.cache_dir = cache_dir
            index_configs.append(config)
            self.symbol_table = SymbolTable()
            self.dependency_graph = DependencyGraph()
            self._file_info = {}

        def load_cache(self):
            calls.append("load_cache")
            return False

    monkeypatch.setattr("reverie.cli.interface.CodebaseIndexer", FakeIndexer)

    interface = ReverieInterface.__new__(ReverieInterface)
    interface.project_root = Path.cwd()
    interface.project_data_dir = Path.cwd()
    interface.git_integration = None
    interface.memory_indexer = None
    interface.agent = None
    interface.indexer = None
    interface.retriever = None
    interface._context_engine_ready = False
    interface._context_worker_limit = 2
    interface._indexing_thread = None
    interface._indexing_in_progress = False
    interface._context_engine_init_lock = threading.RLock()
    interface._load_active_runtime_config = lambda: type("FakeConfig", (), {"auto_index": True})()
    interface._show_activity_event = lambda *args, **kwargs: calls.append("activity")
    interface._start_context_indexing_background = lambda: calls.append("start_background") or True
    interface._refresh_command_context = lambda: calls.append("refresh")

    interface._init_context_engine_with_options(announce=False)

    assert "load_cache" in calls
    assert "start_background" in calls
    assert "activity" not in calls
    assert interface.retriever is not None
    assert index_configs[0].max_workers == 2
    assert interface.retriever.max_workers == 2


def test_desktop_context_worker_budget_preserves_interactive_capacity() -> None:
    from reverie.sdk_bridge import _interactive_context_worker_limit

    assert _interactive_context_worker_limit(1) == 1
    assert _interactive_context_worker_limit(2) == 1
    assert _interactive_context_worker_limit(3) == 2
    assert _interactive_context_worker_limit(64) == 2


def test_context_retrieval_does_not_block_following_bridge_requests(monkeypatch) -> None:
    from reverie import sdk_bridge

    retrieval_started = threading.Event()
    release_retrieval = threading.Event()
    model_selected = threading.Event()
    retrieval_written = threading.Event()

    class FakeBridge:
        def __init__(self, event_writer=None):
            self.event_writer = event_writer
            self.rats_runtime = type("FakeRatsRuntime", (), {"shutdown": lambda self: None})()

        def dispatch(self, message):
            action = message.get("action")
            if action == "workspaceMentions":
                retrieval_started.set()
                release_retrieval.wait(timeout=2)
                return {"id": message.get("id"), "type": "workspace.mentions"}
            if action == "selectModel":
                model_selected.set()
                return {"id": message.get("id"), "type": "model.selected"}
            return {"id": message.get("id"), "type": "ok"}

    class ThreadSafeOutput(io.StringIO):
        def write(self, value):
            written = super().write(value)
            if '"type": "workspace.mentions"' in value:
                retrieval_written.set()
            return written

    request_stream = io.StringIO(
        '\n'.join(
            [
                json.dumps({"id": "mentions", "action": "workspaceMentions", "payload": {}}),
                json.dumps({"id": "model", "action": "selectModel", "payload": {}}),
            ]
        )
        + '\n'
    )
    output_stream = ThreadSafeOutput()
    monkeypatch.setattr(sdk_bridge, "ReverieSdkBridge", FakeBridge)
    monkeypatch.setattr(sdk_bridge, "_configure_utf8_stdio", lambda: None)
    monkeypatch.setattr(sdk_bridge.sys, "stdin", request_stream)
    monkeypatch.setattr(sdk_bridge.sys, "stdout", output_stream)

    server = threading.Thread(target=sdk_bridge.main)
    server.start()
    assert retrieval_started.wait(timeout=1)
    assert model_selected.wait(timeout=1)
    release_retrieval.set()
    assert retrieval_written.wait(timeout=1)
    server.join(timeout=1)
    assert not server.is_alive()


def test_workspace_mentions_skip_full_index_scan_when_retrieval_is_sufficient(tmp_path: Path) -> None:
    class FailIfScanned(dict):
        def items(self):
            raise AssertionError("indexed files should not be scanned after retrieval fills the request")

    relevant_files = [
        SimpleNamespace(
            file_path=str(tmp_path / "src" / f"module_{index}.py"),
            score=100.0 - index,
            reasons=["task:module"],
            summary="module",
        )
        for index in range(8)
    ]
    retriever = SimpleNamespace(
        retrieve_for_task=lambda *args, **kwargs: SimpleNamespace(
            relevant_files=relevant_files,
            relevant_symbols=[],
        )
    )
    interface = SimpleNamespace(
        project_root=tmp_path,
        session_manager=SimpleNamespace(get_current_session=lambda: None),
        retriever=retriever,
        indexer=SimpleNamespace(_file_info=FailIfScanned({"ready": object()})),
        _indexing_in_progress=False,
        ensure_context_engine=lambda **kwargs: False,
        ensure_git_integration=lambda **kwargs: False,
    )

    candidates = ReverieInterface._collect_workspace_mention_candidates(interface, "module", limit=8)

    assert len(candidates) == 8
    assert all(item["source"] == "context-engine" for item in candidates)


def test_workspace_mentions_avoid_competing_retrieval_during_cold_index(tmp_path: Path) -> None:
    for index in range(100):
        (tmp_path / f"file_{index:03d}.py").write_text("value = 1\n", encoding="utf-8")
    retrieval_calls: list[str] = []
    interface = SimpleNamespace(
        project_root=tmp_path,
        session_manager=SimpleNamespace(get_current_session=lambda: None),
        retriever=SimpleNamespace(
            retrieve_for_task=lambda *args, **kwargs: retrieval_calls.append("retrieve")
        ),
        indexer=SimpleNamespace(_file_info={}),
        _indexing_in_progress=True,
        ensure_context_engine=lambda **kwargs: False,
        ensure_git_integration=lambda **kwargs: False,
    )

    candidates = ReverieInterface._collect_workspace_mention_candidates(interface, "", limit=8)

    assert retrieval_calls == []
    assert len(candidates) == 8


def test_context_engine_warmup_runs_beside_model_turn() -> None:
    calls: list[dict] = []

    interface = ReverieInterface.__new__(ReverieInterface)
    interface.indexer = None
    interface.retriever = None
    interface._context_engine_ready = False
    interface._context_engine_warmup_thread = None
    interface._load_active_runtime_config = lambda: type("FakeConfig", (), {"auto_index": True})()

    def fake_ensure_context_engine(**kwargs):
        calls.append(kwargs)
        return True

    interface.ensure_context_engine = fake_ensure_context_engine
    interface._show_activity_event = lambda *args, **kwargs: calls.append({"activity": True})

    started = interface._prime_context_engine_background()

    assert started is True
    assert interface._context_engine_warmup_thread is not None
    interface._context_engine_warmup_thread.join(timeout=2)
    assert calls == [{"announce": False, "wait_for_index": False}]


def test_codebase_retrieval_waits_for_background_index_when_invoked() -> None:
    calls: list[dict] = []
    retriever = object()

    def fake_ensure_context_engine(**kwargs):
        calls.append(kwargs)
        return True

    tool = CodebaseRetrievalTool(
        {
            "retriever": retriever,
            "ensure_context_engine": fake_ensure_context_engine,
        }
    )

    assert tool._get_retriever() is retriever
    assert calls == [{"wait_for_index": True}]


def test_streaming_footer_ticker_uses_signature_gated_refresh() -> None:
    interface = ReverieInterface.__new__(ReverieInterface)
    interface._status_live = object()
    calls: list[bool] = []
    stop_event = threading.Event()

    def fake_refresh(*, force: bool = False) -> None:
        calls.append(force)
        stop_event.set()

    interface._refresh_streaming_footer = fake_refresh  # type: ignore[method-assign]

    interface._streaming_footer_ticker_loop(stop_event)

    assert calls == [False]


def test_streaming_footer_signature_tracks_elapsed_timer_and_output_tokens() -> None:
    interface = ReverieInterface.__new__(ReverieInterface)
    interface.console = Console(width=120)
    interface._streaming_footer_config = None
    interface._active_tool_lock = threading.Lock()
    interface._active_tool_details = {}
    interface._stream_input_state = None
    interface._current_content_tokens = 100
    interface._task_drawer_visible = True
    interface._task_drawer_cache_key = ("tasks", 1)
    interface.total_active_time = 10.0
    interface.current_task_start = time.time() - 5

    first = interface._build_streaming_footer_signature()
    interface.total_active_time = 11.0
    interface.current_task_start = None

    assert interface._build_streaming_footer_signature() != first

    first = interface._build_streaming_footer_signature()
    interface._current_content_tokens = 999

    assert interface._build_streaming_footer_signature() != first


def test_streaming_footer_requires_real_tty_stdout() -> None:
    class FakeStream:
        def isatty(self) -> bool:
            return False

    class FakeConsole:
        file = FakeStream()

    interface = ReverieInterface.__new__(ReverieInterface)
    interface.headless = False
    interface.console = FakeConsole()

    assert interface._should_use_streaming_footer() is False


def test_streaming_footer_live_options_crop_overflow() -> None:
    interface = ReverieInterface.__new__(ReverieInterface)
    interface.console = Console(width=120)

    options = interface._streaming_footer_live_options()

    assert options["console"] is interface.console
    assert options["auto_refresh"] is False
    assert options["transient"] is True
    assert options["vertical_overflow"] == "crop"


def test_partial_stream_errors_are_recoverable_only_after_visible_output() -> None:
    state = _StreamingTurnState()
    state.add_content("partial answer")

    assert _should_recover_partial_stream_error(
        state,
        RuntimeError("peer closed connection without sending complete message body (incomplete chunked read)"),
    ) is True

    empty_state = _StreamingTurnState()
    assert _should_recover_partial_stream_error(
        empty_state,
        RuntimeError("peer closed connection without sending complete message body (incomplete chunked read)"),
    ) is False

    tool_state = _StreamingTurnState()
    tool_state.add_content("prefix")
    tool_state.update_tool_call(0, tool_call_id="call_1", name="shell", arguments='{"command":"dir"}')
    assert _should_recover_partial_stream_error(
        tool_state,
        RuntimeError("peer closed connection without sending complete message body (incomplete chunked read)"),
    ) is False
