"""Interactive agent inspection of preserved, model-authored native Desktop views.
No HTML is authored or changed by this script. Input actions run in the GUI.
"""
from pathlib import Path
import hashlib,json,os,socket,subprocess,sys,time
ROOT=Path('/workspace/Reverie-Cli');BASE=ROOT/'.runtime/riu-cloud-20261020'
sys.path[:0]=[str(ROOT/'ReverieCli-py'),str(ROOT/'scripts/verification')]
from desktop_process import launch_options,stop_process
from riu_quality_benchmark import Recorder,execution_state,start_event_capture
from reverie.config import ConfigManager
from reverie.session.manager import SessionManager
from reverie.views import ViewStore,visible_view_references
from playwright.sync_api import sync_playwright
kind=sys.argv[1]
profile=BASE/({'form':'anonymous-matrix-final/form-1','chart':'anonymous-matrix/chart-1','table':'anonymous-matrix-contract-final/table-1'}[kind])
if kind=='table' and len(sys.argv)>2 and sys.argv[2]=='second':profile=BASE/'anonymous-matrix-contract-final/table-2'
output=BASE/('agent-inspection-'+kind+('-'+sys.argv[2] if len(sys.argv)>2 else ''))
output.mkdir(exist_ok=False)
workspace=profile/'workspace';home=profile/'desktop-home';app_root=profile/'app-root'
os.environ['REVERIE_APP_ROOT']=str(app_root);os.environ['NO_PROXY']='localhost,127.0.0.1'
config=ConfigManager(workspace);original=config.load();cfg=config.load()
recorder=Recorder(output,'https://text.pollinations.ai/v1/chat/completions','')
cfg.models[0].base_url=f'http://127.0.0.1:{recorder.server.server_port}/v1';config.save(cfg)
manager=SessionManager(config.project_data_dir,project_root=workspace);old_report=json.loads((profile/'report.json').read_text());case=old_report['cases'][0];sid=case['session_id'];recorder.case='agent-inspection-'+kind
session=manager.load_session(sid);store=ViewStore.for_project(workspace)
refs=visible_view_references(session.messages);original_path,manifest=store.resolve_entry(sid,*refs[-1]);html_sha=hashlib.sha256(original_path.read_bytes()).hexdigest()
report={'scope':'Agent-operated actual packaged GUI; preserved earlier model output; separate from final quality matrix','original_generation_report':str(profile/'report.json'),'original_generation_build':old_report.get('build'),'session_id':sid,'original_ref':refs[-1],'model_html_sha256_before':html_sha,'actions':[]}
log=(output/'electron.log').open('w')
with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
env={**os.environ,'PORTABLE_EXECUTABLE_DIR':str(home),'DISPLAY':os.environ.get('DISPLAY',':93')};env.pop('ELECTRON_RUN_AS_NODE',None)
process=subprocess.Popen([str(ROOT/'ReverieCli-ui/release/linux-unpacked/ReverieUI'),'--gui','--project',str(workspace),f'--remote-debugging-port={port}'],env=env,stdout=log,stderr=log,**launch_options())
pw=sync_playwright().start();browser=None
for _ in range(160):
 try:browser=pw.chromium.connect_over_cdp(f'http://127.0.0.1:{port}',timeout=1000);break
 except Exception:
  if process.poll()is not None:raise RuntimeError('Native app exited')
  time.sleep(.25)
if browser is None:raise RuntimeError('No native CDP endpoint')
page=browser.contexts[0].pages[0];page.set_viewport_size({'width':1280,'height':900});page.wait_for_selector('textarea[aria-autocomplete=list]',timeout=120000)
page.locator('.session-item').filter(has_text='RIU quality '+case['id']).click(timeout=120000);page.locator('.session-loading').wait_for(state='hidden',timeout=60000)
report['current_host_build']=page.evaluate('window.reverie.paths()')
def surface():
 anchor=page.locator('.interactive-view-anchor').last;anchor.scroll_into_view_if_needed();expand=anchor.get_by_role('button',name='展开',exact=True)
 if expand.count():expand.click()
 element=page.locator('.interactive-view iframe').last;element.wait_for(timeout=30000)
 return element,element.element_handle().content_frame()
def record(action,detail=None):
 report['actions'].append({'action':action,'detail':detail,'at':time.time()});(output/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str))
def capture(name):
 global iframe,inside
 iframe,inside=surface();page.screenshot(path=str(output/(name+'.png')),full_page=True);iframe.screenshot(path=str(output/(name+'-frame.png')))
 data={'text':inside.locator('body').inner_text(),'controls':inside.locator('input,select,textarea,button').evaluate_all("es=>es.map(e=>({tag:e.tagName,type:e.type,id:e.id,name:e.name,text:e.textContent,value:e.value,checked:e.checked}))"),'viewport':inside.evaluate('({width:innerWidth,height:innerHeight,scroll:document.documentElement.scrollWidth,timeOrigin:performance.timeOrigin})'),'theme':inside.locator('body').evaluate('e=>({bg:getComputedStyle(e).backgroundColor,color:getComputedStyle(e).color})')}
 (output/(name+'-dom.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2));record('capture '+name,data);return data

def send(prompt):
 start_event_capture(page);n=page.evaluate('window.__qualityEvents.length');page.locator('textarea[aria-autocomplete=list]').fill(prompt);page.get_by_role('button',name='发送',exact=True).click();started=time.monotonic()
 while True:
  events=page.evaluate('n=>window.__qualityEvents.slice(n).filter(x=>x.event.type==="executors.changed")',n);began,active=execution_state(events,sid)
  if began and not active:break
  if time.monotonic()-started>900:raise TimeoutError('Inspection model repair deadline')
  page.wait_for_timeout(500)
 page.wait_for_timeout(500);record('normal composer follow-up',{'prompt':prompt,'ms':(time.monotonic()-started)*1000});session=manager.load_session(sid);(output/'after-followup-session.json').write_text(json.dumps(session.to_dict(),ensure_ascii=False,indent=2));print('follow-up complete requests',len(recorder.records))
def finish():
 report['model_html_sha256_after']=hashlib.sha256(original_path.read_bytes()).hexdigest();report['original_model_html_unchanged']=report['model_html_sha256_after']==html_sha;report['requests']=recorder.records;report['finished']=True;record('finish');browser.close();stop_process(process);pw.stop();recorder.close();config.save(original);log.close()
iframe,inside=surface();print('ready',kind,'body',inside.locator('body').inner_text()[:1300])
