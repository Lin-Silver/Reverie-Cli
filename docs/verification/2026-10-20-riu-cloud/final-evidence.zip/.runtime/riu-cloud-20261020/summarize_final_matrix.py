"""Summarize completed evidence without rewriting historical reports."""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import math

ROOT = Path('/workspace/Reverie-Cli')
BASE = ROOT / '.runtime/riu-cloud-20261020'
MATRIX = BASE / 'anonymous-matrix-final-resumed-20261021/matrix.json'
matrix = json.loads(MATRIX.read_text())
assert matrix.get('completed_at') and len(matrix['samples']) == 18

def distribution(values):
    values = sorted(v for v in values if isinstance(v, (int, float)) and math.isfinite(v))
    if not values:
        return None
    return {'n': len(values), 'p50': values[math.ceil(len(values) * .5) - 1],
            'p95': values[math.ceil(len(values) * .95) - 1], 'max': values[-1]}

cases, requests = [], []
duplicates = defaultdict(list)
by_build = defaultdict(list)
options = []
for sample in matrix['samples']:
    report_path = Path(sample['report'])
    report = json.loads(report_path.read_text())
    build = report.get('build')
    build_id = (build.get('desktopBuild') or {}).get('id', 'unknown') if isinstance(build, dict) else str(build)
    for case in sample.get('cases', []):
        reviewed = sample.get('reviewed_outcome', case.get('outcome'))
        item = {'task': sample['task'], 'attempt': sample['attempt'],
                'raw_outcome': case.get('outcome'), 'reviewed_outcome': reviewed,
                'review_reason': sample.get('review_reason'),
                'report': str(report_path.relative_to(ROOT)), 'build': build,
                'verifier_retry_of': sample.get('verifier_retry_of'),
                'checks': len(case.get('checks', [])),
                'checks_passed': sum(c.get('passed', False) for c in case.get('checks', [])),
                'failed_checks': [c['name'] for c in case.get('checks', []) if not c.get('passed')],
                'turns': case.get('turns', []), 'error': case.get('error'),
                'repairs': case.get('repair_count', 0), 'artifacts': case.get('artifacts', []),
                'violations': case.get('violations', []),
                'credential_cleanup': report.get('credential_cleanup')}
        cases.append(item)
        by_build[build_id].append(item)
        for request in case.get('requests', []):
            requests.append(request)
            if request.get('response_sha256'):
                duplicates[(request.get('request_sha256'), request['response_sha256'])].append(
                    {'task': sample['task'], 'attempt': sample['attempt'], 'request': request['request']})
    first = report_path.parent / 'request-0000.json'
    if first.exists():
        data = json.loads(first.read_text())
        options.append({'task': sample['task'], 'attempt': sample['attempt'],
                        'request_options': {k: v for k, v in data.items() if k not in ('messages', 'tools')},
                        'sha256': hashlib.sha256(first.read_bytes()).hexdigest()})

generation = [c for c in cases if c['task'] != 'text']
text = [c for c in cases if c['task'] == 'text']
assert len(generation) == 15 and len(text) == 3
timing_fields = ['model_turn_ms', 'local_before_first_request_ms', 'local_after_last_response_ms',
                 'first-reasoning.delta-renderer-event-ms', 'first-successful-executor-tool-result-ms',
                 'first-view_ready-renderer-event-ms']
summary = {
    'status': 'completed; generation quality gate failed; second compatible free model unavailable',
    'matrix': str(MATRIX.relative_to(ROOT)), 'completed_at': matrix['completed_at'],
    'complete_generation': len(generation), 'complete_text_controls': len(text),
    'raw_generation_outcomes': dict(Counter(c['raw_outcome'] for c in generation)),
    'reviewed_generation_outcomes': dict(Counter(c['reviewed_outcome'] for c in generation)),
    'text_outcomes': dict(Counter(c['reviewed_outcome'] for c in text)),
    'generation_quality_passes': sum(c['reviewed_outcome'] in ('first_pass', 'repaired_success') for c in generation),
    'model_id_requested': matrix['model'],
    'raw_response_models': sorted({r['response_model'] for r in requests if r.get('response_model')}),
    'fixture_version': matrix['task_version'], 'fixture_sha256': matrix['task_sha256'],
    'verifier_sha256': matrix.get('verifier_sha256'),
    'standard_source_equivalence': matrix.get('standard_source_equivalence'),
    'request_count': len(requests), 'http_status_counts': dict(Counter(str(r.get('status')) for r in requests)),
    'usage_reported': {k: sum((r.get('usage') or {}).get(k, 0) for r in requests)
                       for k in ('prompt_tokens', 'completion_tokens', 'total_tokens')},
    'completion_1500_count': sum((r.get('usage') or {}).get('completion_tokens') == 1500 for r in requests),
    'byte_identical_request_and_response_groups': [
        {'request_sha256': key[0], 'response_sha256': key[1], 'members': members}
        for key, members in duplicates.items() if len(members) > 1],
    'independence_limit': 'Fresh process/profile/workspace/memory per sample. Equal request/SSE hashes do not prove independent stochastic draws. Reported usage includes repeated upstream responses, not billing or independently computed token counts.',
    'timing_by_build_ms': {
        key: {field: distribution([turn.get(field) for case in group for turn in case['turns']])
              for field in timing_fields} for key, group in by_build.items()},
    'timing_scope': 'Descriptive per-build measurements only; no controlled before/after speed claim. Cross-day date and derived cache key differ. Failed/no-view/service-error turns retained.',
    'sampling_and_output_options': options, 'cases': cases,
    'excluded_verifier_runs': matrix.get('excluded_verifier_runs'),
    'environment_interruption': matrix.get('environment_interruption'),
    'prior_matrix': matrix.get('prior_matrix'),
}
(BASE / 'quality-summary-final.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: summary[k] for k in ('complete_generation', 'complete_text_controls',
      'raw_generation_outcomes', 'reviewed_generation_outcomes', 'text_outcomes', 'request_count',
      'http_status_counts', 'completion_1500_count')}, ensure_ascii=False))
