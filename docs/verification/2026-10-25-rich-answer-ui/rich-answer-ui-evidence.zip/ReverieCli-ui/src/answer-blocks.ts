/** Declarative answer content only: no HTML, scripts, styles or host actions. */
export type AnswerTone = "neutral" | "info" | "success" | "warning" | "danger";
export type AnswerBadge = { text: string; tone?: AnswerTone };
export type AnswerLink = { label: string; url: string };
export type AnswerCell = string | number | boolean | null | AnswerBadge;
export type AnswerBlock =
  | { type: "metrics"; items: { label: string; value: string | number; detail?: string }[] }
  | { type: "table"; title?: string; columns: string[]; rows: AnswerCell[][]; caption?: string }
  | { type: "cards"; numbered?: boolean; items: {
    title: string; description: string; image?: { url: string; alt: string };
    badge?: AnswerBadge; details?: string[]; links?: AnswerLink[]; sources?: AnswerLink[];
  }[] }
  | { type: "sources"; items: AnswerLink[] };

const record = (value: unknown): value is Record<string, unknown> => Boolean(value) && typeof value === "object" && !Array.isArray(value);
const text = (value: unknown): value is string => typeof value === "string";
const finite = (value: unknown): value is number => typeof value === "number" && Number.isFinite(value);
const optional = (value: unknown, check: (value: unknown) => boolean) => value === undefined || check(value);
const tones = new Set<unknown>(["neutral", "info", "success", "warning", "danger"]);
const badge = (value: unknown): value is AnswerBadge => record(value) && text(value.text) && optional(value.tone, tone => tones.has(tone));
const link = (value: unknown): value is AnswerLink => record(value) && text(value.label) && text(value.url);
const links = (value: unknown): value is AnswerLink[] => Array.isArray(value) && value.every(link);
const cell = (value: unknown): value is AnswerCell => value === null || text(value) || finite(value) || typeof value === "boolean" || badge(value);

/** Invalid or incomplete content stays visible as the original code, never a partial table. */
export function parseAnswerBlock(source: string): AnswerBlock | null {
  let value: unknown;
  try { value = JSON.parse(source); } catch { return null; }
  if (!record(value)) return null;
  if (value.type === "metrics" && Array.isArray(value.items) && value.items.length > 0 && value.items.every(item =>
    record(item) && text(item.label) && (text(item.value) || finite(item.value)) && optional(item.detail, text))) return value as AnswerBlock;
  if (value.type === "table" && optional(value.title, text) && optional(value.caption, text) &&
    Array.isArray(value.columns) && value.columns.length > 0 && value.columns.every(text) &&
    Array.isArray(value.rows) && value.rows.every(row => Array.isArray(row) && row.length === (value.columns as string[]).length && row.every(cell))) return value as AnswerBlock;
  if (value.type === "cards" && optional(value.numbered, item => typeof item === "boolean") &&
    Array.isArray(value.items) && value.items.length > 0 && value.items.every(item => record(item) && text(item.title) && text(item.description) &&
      optional(item.badge, badge) && optional(item.image, image => record(image) && text(image.url) && text(image.alt)) &&
      optional(item.details, details => Array.isArray(details) && details.every(text)) && optional(item.links, links) && optional(item.sources, links))) return value as AnswerBlock;
  if (value.type === "sources" && links(value.items) && value.items.length > 0) return value as AnswerBlock;
  return null;
}

export function answerExternalUrl(value: string): string | null {
  try {
    const url = new URL(value);
    return ["https:", "http:"].includes(url.protocol) && !url.username && !url.password ? url.href : null;
  } catch { return null; }
}

export function answerImageUrl(value: string): string | null {
  // Raster data and HTTPS images only. Never let answer content read local files.
  if (/^data:image\/(?:png|jpeg|gif|webp|avif);base64,[a-z\d+/=\s]+$/i.test(value)) return value;
  const url = answerExternalUrl(value);
  return url?.startsWith("https:") ? url : null;
}
