"""Export immutable real-model view revisions and executor deletion backups verbatim."""
from pathlib import Path
import hashlib,json,shutil
ROOT=Path('/workspace/Reverie-Cli');BASE=ROOT/'.runtime/riu-cloud-20261020';records=[]
for phase in sorted(BASE.glob('anonymous-matrix*')):
 if not phase.is_dir():continue
 for profile in sorted(phase.iterdir()):
  app_root=profile/'app-root'
  if not app_root.is_dir():continue
  for project in sorted((app_root/'.reverie/projects').glob('*')):
   views=project/'views'
   for manifest in sorted(views.glob('*/*/*/manifest.json')):
    for source in sorted(manifest.parent.iterdir()):
     if not source.is_file()or source.name!='manifest.json'and source.suffix.lower()not in {'.html','.htm'}:continue
     destination=profile/'registered-artifacts'/source.relative_to(views);destination.parent.mkdir(parents=True,exist_ok=True);data=source.read_bytes()
     if destination.exists()and destination.read_bytes()!=data:raise RuntimeError('Immutable view export changed: '+str(destination))
     if not destination.exists():destination.write_bytes(data)
     records.append({'path':str(destination.relative_to(ROOT)),'source':str(source.relative_to(ROOT)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'provenance':'immutable registered revision'})
   deleted=project/'deleted-files'
   for source in sorted(deleted.rglob('*'))if deleted.exists()else []:
    if not source.is_file()or source.suffix.lower()not in {'.html','.htm'}:continue
    destination=profile/'executor-deletion-backups'/source.relative_to(deleted);destination.parent.mkdir(parents=True,exist_ok=True);data=source.read_bytes()
    if destination.exists()and destination.read_bytes()!=data:raise RuntimeError('Deletion backup export changed')
    if not destination.exists():destination.write_bytes(data)
    records.append({'path':str(destination.relative_to(ROOT)),'source':str(source.relative_to(ROOT)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'provenance':'executor-managed reversible deletion backup'})
(BASE/'registered-artifacts-manifest.json').write_text(json.dumps({'scope':'Real-model HTML and manifests copied byte-for-byte; no authored or edited HTML','files':records},ensure_ascii=False,indent=2)+'\n');print('exports',len(records))
