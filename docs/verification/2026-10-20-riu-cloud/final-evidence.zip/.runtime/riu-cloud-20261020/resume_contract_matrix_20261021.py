"""Continue fixed-prompt real-model coverage; retain every prior raw failure."""
from pathlib import Path
import copy,datetime,hashlib,json,os,subprocess,sys
ROOT=Path('/workspace/Reverie-Cli');BASE=ROOT/'.runtime/riu-cloud-20261020';old=BASE/'anonymous-matrix-contract-final';out=BASE/'anonymous-matrix-final-resumed-20261021';out.mkdir(exist_ok=False)
verifier=ROOT/'scripts/verification/riu_quality_benchmark.py';prior=json.loads((old/'matrix.json').read_text());report={k:v for k,v in prior.items()if k!='samples'};report.update(samples=[],prior_matrix=str(old/'matrix.json'),prior_runs=copy.deepcopy(prior['samples']),excluded_verifier_runs=[],environment_interruption=str(old/'environment-interruption-3.json'),standard_source_equivalence=str(BASE/'standard-source-equivalence.json'),verifier_sha256=hashlib.sha256(verifier.read_bytes()).hexdigest(),prompt_source_sha256=hashlib.sha256((ROOT/'ReverieCli-py/reverie/agent/system_prompt.py').read_bytes()).hexdigest(),sampling='Provider defaults; no max_tokens/temperature/top_p/seed added',started_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
reviews={('table',1):'Original report already has failed theme/state/version checks. No modified view was registered; the subsequent missing-new-control timeout is not a new product exception.',('chart',1):'Rendered input magnitude has adjacent text but no label/aria-label. Original HTML and generated DOM prove required accessible-control failure; the locator timeout obscured this model defect.'}
for entry in prior['samples']:
 key=(entry['task'],entry['attempt'])
 if key==('table',2):
  report['excluded_verifier_runs'].append({**entry,'reason':'Reproduced OOPIF pointer hit-region race after relocation:4/5 immediate actions failed;0/5 failed after host/component two-frame settlement. Repeat this sample in a fresh profile; original failure remains here.'});continue
 preserved=copy.deepcopy(entry);preserved['origin']='completed before environment reset; raw report unchanged'
 if key in reviews:preserved.update(reviewed_outcome='semantic_failure',review_reason=reviews[key])
 report['samples'].append(preserved)
completed={(s['task'],s['attempt'])for s in report['samples']}
for attempt in range(1,4):
 for task in ['calculator','table','chart','form','comparison','text']:
  if(task,attempt)in completed:continue
  name=f'{task}-{attempt}';child=out/name;command=[sys.executable,str(verifier),'--exe',str(ROOT/'ReverieCli-ui/release/linux-unpacked/ReverieUI'),'--output',str(child),'--source','standard','--api-url','https://text.pollinations.ai/v1','--model','openai-fast','--attempts','1','--tasks',task,'--timeout','900','--shared-profile']
  with(out/f'{name}.txt').open('w')as log:result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
  entry={'task':task,'attempt':attempt,'exit_code':result.returncode,'report':str(child/'report.json'),'origin':'fresh process/profile/workspace/memory after reset'}
  if(task,attempt)==('table',2):entry['verifier_retry_of']=str(old/'table-2/report.json')
  if(child/'report.json').exists():
   detail=json.loads((child/'report.json').read_text());entry.update(cases=detail.get('cases',[]),verifier_sha256=detail.get('verifier_sha256'),build=detail.get('build'))
  report['samples'].append(entry);(out/'matrix.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({'sample':name,'exit_code':result.returncode}),flush=True)
report['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'matrix.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
