"""
Reverie Agent - The AI core

This is the main agent class that:
- Manages conversation with the LLM
- Handles tool calls
- Integrates with Context Engine
- Supports both streaming and non-streaming modes
"""

from dataclasses import dataclass, field
from contextlib import contextmanager, ExitStack
from typing import List, Dict, Any, Optional, Generator, AsyncGenerator, Callable, Tuple
from pathlib import Path
from urllib.parse import urlsplit
import json
import hashlib
import time
import re
import logging
import uuid
import threading
import math
from email.utils import parsedate_to_datetime

from rich.markup import escape as rich_escape

from .permission_review import describe_call
from .system_prompt import build_system_prompt, normalize_runtime_surface
from .tool_executor import ToolExecutor
from ..tools.base import INVALID_TOOL_ARGUMENTS
from ..security_policy import (
    normalize_permission_level,
    normalize_permission_mode,
    resolve_review_config,
    risk_requires_approval,
)
from ..diagnostics import report_suppressed_exception
from ..context_engine.handoff import build_session_handoff_packet
from ..inline_images import resolve_inline_image_content_for_request
from ..memory import MEMORY_CONTEXT_PROMPT_HEADER, MemoryOS
from ..modes import normalize_mode
from ..config import derive_model_display_name, model_source_display_name, normalize_model_provider
from ..request_identity import apply_reverie_client_identity
from ..provider_transport import provider_client, provider_post, check_cancel, interruptible_sleep, on_cancel
from ..proxy import normalize_proxy_url, requests_proxy_dict, resolve_proxy_url
from ..thinking_tool import is_think_tool
from ..api_compatibility import build_compatibility_messages, parse_compatibility_reply
from ..stream_protocol import (
    HIDDEN_STREAM_TOKEN,
    STREAM_EVENT_MARKER,
    THINKING_END_MARKER,
    THINKING_START_MARKER,
    decode_stream_event,
    encode_stream_event,
)
from ..prompt_cache import (
    anthropic_stream_with_prompt_cache_fallback,
    apply_anthropic_prompt_cache,
    apply_openai_prompt_cache,
    call_with_prompt_cache_fallback,
    has_prompt_cache_hints,
    is_prompt_cache_rejection,
    without_prompt_cache,
)
from ..sse import iter_sse_data_strings as iter_provider_sse_data_strings
from ..tools.base import ToolResult
from ..tools.serial_novel import (
    DEFAULT_OUTPUT_DIR,
    PENDING_RECOVERY_APPEND_ONLY,
    SerialNovelTool,
    STATE_SCHEMA,
)
from ..tools.task_manager import cleanup_completed_task_artifacts
from ..nvidia import (
    apply_nvidia_request_defaults,
    build_nvidia_openai_options,
    get_nvidia_model_metadata,
    is_nvidia_api_url,
    is_nvidia_model,
    nvidia_model_allows_tools,
    nvidia_model_requires_preserved_reasoning_history,
    nvidia_model_requires_system_message_first,
)
from ..aihubmix import build_aihubmix_openai_options
from ..agnes import build_agnes_openai_options
from ..opencode import (
    build_opencode_openai_options,
    build_opencode_request_headers_from_config,
)
from ..sensenova import build_sensenova_openai_options
from ..modelscope import build_modelscope_openai_options
from ..custom_providers import (
    CUSTOM_PROVIDER_REASONING_FIELD_TIERS,
    CUSTOM_PROVIDER_REASONING_FIELDS,
    build_custom_provider_anthropic_options,
    build_custom_provider_openai_options,
    build_custom_provider_responses_options,
    narrow_custom_provider_reasoning_payload,
    remember_custom_provider_reasoning_narrowing,
)
from ..webgemini import (
    generate_webgemini_message,
    iter_webgemini_text_deltas,
    normalize_webgemini_config,
)

THINKING_OPEN_TAG_LITERAL = "<think>"
THINKING_CLOSE_TAG_LITERAL = "</think>"

# Hosted reasoning models sometimes open `reasoning_content` with a verbatim
# replay of the user's message, which then shows the request twice in the UI and
# twice in the saved transcript. Only replays of prompts at least this long are
# stripped: below it, a coincidental match is more likely than a real echo.

# Memory tools are useful for durable project context, but a greeting or other
# one-off acknowledgement should never pay for a tool-result follow-up turn.
_MEMORY_TOOL_NAMES = frozenset({"memory_manager", "memory_retrieval"})
_CASUAL_TURN_PHRASES = frozenset(
    {
        "hi",
        "hello",
        "hey",
        "yo",
        "greetings",
        "good morning",
        "good afternoon",
        "good evening",
        "thanks",
        "thank you",
        "thx",
        "ok",
        "okay",
        "你好",
        "您好",
        "嗨",
        "哈喽",
        "早上好",
        "下午好",
        "晚上好",
        "谢谢",
        "多谢",
        "好的",
        "收到",
        "再见",
        "拜拜",
    }
)
_MEMORY_INTENT_MARKERS = (
    "memory_manager",
    "memory retrieval",
    "memory",
    "remember",
    "recall",
    "forget",
    "记忆",
    "记住",
    "回忆",
    "遗忘",
    "偏好",
    "持久",
    "长期",
)


def _should_hide_memory_tools_for_prompt(prompt: Any) -> bool:
    """Keep memory tools out of transient conversational turns."""
    normalized = re.sub(r"[\W_]+", " ", str(prompt or "").casefold(), flags=re.UNICODE).strip()
    if not normalized or len(normalized) > 48:
        return False
    if any(marker in normalized for marker in _MEMORY_INTENT_MARKERS):
        return False
    return normalized in _CASUAL_TURN_PHRASES

# Configure logging for debugging
logger = logging.getLogger(__name__)

API_RETRY_DELAYS_SECONDS = (1, 3, 5, 7, 15)
API_RETRY_ATTEMPTS = len(API_RETRY_DELAYS_SECONDS)
NVIDIA_MIN_REQUEST_INTERVAL_SECONDS = 1.5
_NVIDIA_RATE_LIMIT_LOCK = threading.Lock()
_NVIDIA_LAST_REQUEST_AT = 0.0


def _api_retry_delay(attempt: int, initial_backoff: float, error: Optional[BaseException] = None) -> float:
    delay = API_RETRY_DELAYS_SECONDS[min(attempt, len(API_RETRY_DELAYS_SECONDS) - 1)] * max(0.0, float(initial_backoff))
    response = getattr(error, "response", None)
    headers = getattr(response, "headers", {})
    value = headers.get("Retry-After") or headers.get("retry-after")
    if value:
        try:
            cooldown = float(value)
        except (TypeError, ValueError):
            try:
                cooldown = parsedate_to_datetime(value).timestamp() - time.time()
            except (TypeError, ValueError, OverflowError):
                cooldown = 0.0
        if math.isfinite(cooldown):
            delay = max(delay, cooldown)
    return delay


def _is_provider_rate_limit(status: Any, error: BaseException) -> bool:
    # Some anonymous gateways document 402 + Retry-After for a free slot.
    # A normal payment-required response remains a terminal client error.
    headers = getattr(getattr(error, "response", None), "headers", {})
    return status == 429 or status == 402 and bool(headers.get("Retry-After") or headers.get("retry-after"))


def _wait_for_nvidia_rate_limit() -> None:
    global _NVIDIA_LAST_REQUEST_AT
    with _NVIDIA_RATE_LIMIT_LOCK:
        now = time.monotonic()
        elapsed = now - _NVIDIA_LAST_REQUEST_AT
        if elapsed < NVIDIA_MIN_REQUEST_INTERVAL_SECONDS:
            interruptible_sleep(NVIDIA_MIN_REQUEST_INTERVAL_SECONDS - elapsed)
            now = time.monotonic()
        _NVIDIA_LAST_REQUEST_AT = now


def _get_object_value(value: Any, key: str, default: Any = None) -> Any:
    """Return a dict key or object attribute without raising."""
    if isinstance(value, dict):
        return value.get(key, default)
    return getattr(value, key, default)


def _coerce_text_fragments(value: Any) -> str:
    """Flatten provider-specific text payloads into a plain string."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, (int, float, bool)):
        return str(value)
    if isinstance(value, (list, tuple)):
        return "".join(_coerce_text_fragments(item) for item in value)
    if isinstance(value, dict):
        for key in (
            "text",
            "content",
            "value",
            "output_text",
            "input_text",
            "thinking",
            "reasoning_content",
        ):
            if key in value:
                text = _coerce_text_fragments(value.get(key))
                if text:
                    return text
        if isinstance(value.get("parts"), list):
            return _coerce_text_fragments(value.get("parts"))
        return ""

    for attr in (
        "text",
        "content",
        "value",
        "output_text",
        "input_text",
        "thinking",
        "reasoning_content",
    ):
        candidate = getattr(value, attr, None)
        if candidate is not None:
            text = _coerce_text_fragments(candidate)
            if text:
                return text
    return ""


def _normalize_message_content_for_relay(content: Any) -> Any:
    """Preserve multimodal content blocks for OpenAI-compatible relays when present."""
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, (int, float, bool)):
        return str(content)
    if not isinstance(content, list):
        return str(content)

    normalized_parts: List[Dict[str, Any]] = []
    text_parts: List[str] = []
    has_media = False

    for part in content:
        if isinstance(part, str):
            text_value = str(part)
            if text_value:
                normalized_parts.append({"type": "text", "text": text_value})
                text_parts.append(text_value)
            continue

        if not isinstance(part, dict):
            continue

        part_type = str(part.get("type", "") or "").strip().lower()
        if part_type in ("text", "input_text", "output_text"):
            text_value = _coerce_text_fragments(part.get("text"))
            if text_value:
                normalized_parts.append({"type": "text", "text": text_value})
                text_parts.append(text_value)
            continue

        if part_type == "image_url":
            image_payload = part.get("image_url")
            url = ""
            if isinstance(image_payload, dict):
                url = str(image_payload.get("url", "") or "").strip()
            elif image_payload is not None:
                url = str(image_payload).strip()
            if url:
                normalized_parts.append({"type": "image_url", "image_url": {"url": url}})
                has_media = True
            continue

        if part_type == "input_audio" and isinstance(part.get("input_audio"), dict):
            normalized_parts.append({"type": "input_audio", "input_audio": dict(part["input_audio"])})
            has_media = True
            continue

        if part_type == "video_url":
            video_payload = part.get("video_url")
            url = ""
            if isinstance(video_payload, dict):
                url = str(video_payload.get("url", "") or "").strip()
            elif video_payload is not None:
                url = str(video_payload).strip()
            if url:
                normalized_parts.append({"type": "video_url", "video_url": {"url": url}})
                has_media = True
            continue

        if part_type in ("image", "input_image"):
            source = part.get("source") if isinstance(part.get("source"), dict) else {}
            media_type = str(source.get("media_type", "image/png") or "image/png").strip()
            data = str(source.get("data", "") or "").strip()
            if data:
                normalized_parts.append(
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:{media_type};base64,{data}"},
                    }
                )
                has_media = True

    if has_media:
        return normalized_parts
    return "\n".join(piece for piece in text_parts if piece).strip()


def _merge_extra_body(base: Optional[Dict[str, Any]], extra: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Merge provider-specific extra_body blocks without losing nested kwargs."""
    if not base and not extra:
        return None
    if not base:
        return dict(extra or {})
    if not extra:
        return dict(base or {})

    merged = dict(base)
    for key, value in extra.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            nested = dict(merged.get(key, {}))
            nested.update(value)
            merged[key] = nested
        else:
            merged[key] = value
    return merged


def _extract_text_from_candidates(value: Any, *candidate_keys: str) -> str:
    """Return the first non-empty flattened text from the provided field names."""
    for key in candidate_keys:
        candidate = _get_object_value(value, key, None)
        text = _coerce_text_fragments(candidate)
        if text:
            return text
    return ""


def _stream_state_has_partial_output(state: Any) -> bool:
    """Whether a streaming turn already yielded enough state to attempt recovery."""
    return bool(
        str(getattr(state, "collected_content", "") or "").strip()
        or str(getattr(state, "collected_thinking", "") or "").strip()
    )


def _is_recoverable_stream_exception(exc: Exception) -> bool:
    """Return whether a mid-stream transport failure is safe to treat as interrupted output."""
    text = str(exc or "").strip().lower()
    exception_names = {
        type(exc).__name__.strip().lower(),
        type(exc).__qualname__.strip().lower(),
    }
    known_names = {
        "apitimeouterror",
        "apiconnectionerror",
        "chunkedencodingerror",
        "connectionerror",
        "connecttimeout",
        "httpxreadtimeout",
        "incompleteread",
        "protocolerror",
        "readtimeout",
        "readtimeouterror",
        "remoteprotocolerror",
        "streamclosederror",
        "timeout",
    }
    if exception_names & known_names:
        return True
    recoverable_markers = (
        "peer closed connection",
        "incomplete chunked read",
        "incomplete read",
        "remote protocol error",
        "response ended prematurely",
        "server disconnected without sending a response",
        "stream closed unexpectedly",
        "request timed out",
        "read timed out",
    )
    return any(marker in text for marker in recoverable_markers)


def _should_recover_partial_stream_error(state: Any, exc: Exception) -> bool:
    """Recover only when the stream already produced user-visible text and no tool call is mid-flight."""
    if not _stream_state_has_partial_output(state):
        return False
    tool_calls = getattr(state, "tool_calls", []) or []
    if tool_calls:
        return False
    return _is_recoverable_stream_exception(exc)


def _raise_for_wrapped_api_error(payload: Any, provider_label: str = "API") -> None:
    """Raise a readable error for wrapped OpenAI-compatible error payloads."""
    if not isinstance(payload, dict):
        return

    error_block = payload.get("error")
    if isinstance(error_block, dict):
        error_message = str(
            error_block.get("message")
            or error_block.get("msg")
            or payload.get("msg")
            or payload.get("message")
            or ""
        ).strip()
        if error_message:
            error_code = error_block.get("code") or payload.get("status")
            if error_code is not None:
                raise ValueError(f"{provider_label} returned an error ({error_code}): {error_message}")
            raise ValueError(f"{provider_label} returned an error: {error_message}")

    status = payload.get("status")
    message = str(payload.get("msg") or payload.get("message") or "").strip()
    success_statuses = {None, 0, 200, "0", "200", "success", True}
    if message and status not in success_statuses:
        raise ValueError(f"{provider_label} returned an error ({status}): {message}")


def _unwrap_openai_compatible_payload(payload: Any) -> Dict[str, Any]:
    """Return the dict that actually contains OpenAI-style `choices`, if present."""
    if not isinstance(payload, dict):
        return {}

    if isinstance(payload.get("choices"), list):
        return payload

    for key in ("body", "data", "response"):
        candidate = payload.get(key)
        if isinstance(candidate, dict) and isinstance(candidate.get("choices"), list):
            return candidate

    return {}


def _tool_result_content(result: ToolResult) -> Any:
    """Return the most expressive content payload for a tool result."""
    if isinstance(result.data, dict):
        for key in ("message_content", "relay_content"):
            candidate = result.data.get(key)
            if isinstance(candidate, list) and candidate:
                return candidate
            if isinstance(candidate, str) and candidate.strip():
                return candidate
    return result.output if result.success else f"Error: {result.error}"


def _tool_result_history_content(result: ToolResult) -> str:
    """Persist a compact tool result without inline media payloads."""
    text = str(result.output if result.success else f"Error: {result.error}")
    if isinstance(result.data, dict):
        file_path = str(result.data.get("file_path") or "").strip()
        if file_path and file_path not in text:
            text = f"{text}\nMedia: {file_path}".strip()
    return text


def _build_assistant_history_message(
    content: Any,
    tool_calls: Optional[List[Dict[str, Any]]] = None,
    reasoning_content: str = "",
) -> Dict[str, Any]:
    """Build a normalized assistant history message with optional reasoning trace."""
    message: Dict[str, Any] = {
        "role": "assistant",
        "content": content,
    }
    if isinstance(tool_calls, list):
        message["tool_calls"] = tool_calls
    if str(reasoning_content or "").strip():
        message["reasoning_content"] = str(reasoning_content)
    return message


def _build_anthropic_assistant_tool_blocks(
    assistant_text: str,
    tool_calls: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Convert collected tool calls into Anthropic assistant content blocks."""
    blocks: List[Dict[str, Any]] = []
    if assistant_text:
        blocks.append({"type": "text", "text": assistant_text})

    for tool_call in tool_calls:
        function = tool_call.get("function") if isinstance(tool_call, dict) else {}
        raw_arguments = ""
        if isinstance(function, dict):
            raw_arguments = str(function.get("arguments", "") or "")
        blocks.append(
            {
                "type": "tool_use",
                "id": str(tool_call.get("id", "") or ""),
                "name": str(function.get("name", "") or ""),
                "input": parse_tool_arguments(raw_arguments),
            }
        )
    return blocks


def _build_anthropic_tool_result_block(tool_call_id: str, result: ToolResult) -> Dict[str, Any]:
    """Build an Anthropic `tool_result` block from a tool execution result."""
    return {
        "type": "tool_result",
        "tool_use_id": str(tool_call_id or ""),
        "content": _convert_messages_to_anthropic_format([{"role": "user", "content": _tool_result_content(result)}])[1][0]["content"],
        "is_error": not bool(result.success),
    }


def _convert_tools_to_anthropic_format(tools: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Convert OpenAI-format function tools into Anthropic tool schemas."""
    converted: List[Dict[str, Any]] = []
    for tool in tools or []:
        if not isinstance(tool, dict):
            continue
        if "input_schema" in tool and "name" in tool:
            converted.append(dict(tool))
            continue

        function = tool.get("function")
        if not isinstance(function, dict):
            continue

        name = str(function.get("name", "") or "").strip()
        if not name:
            continue

        input_schema = function.get("parameters")
        if not isinstance(input_schema, dict):
            input_schema = {"type": "object", "properties": {}}

        converted.append(
            {
                "name": name,
                "description": str(function.get("description", "") or "").strip() or name,
                "input_schema": input_schema,
            }
        )
    return converted


@dataclass
class _StreamingTurnState:
    """Shared state machine for streaming providers."""

    collected_content: str = ""
    collected_thinking: str = ""
    tool_calls: List[Dict[str, Any]] = field(default_factory=list)
    usage: Dict[str, int] = field(default_factory=dict)
    finish_reason: Optional[str] = None
    thinking_started: bool = False
    stream_buffer: str = ""
    content_tag_buffer: str = ""
    inline_thinking: bool = False
    token_to_hide: str = HIDDEN_STREAM_TOKEN

    @staticmethod
    def _find_tag(text: str, tag: str) -> int:
        return str(text or "").lower().find(str(tag or "").lower())

    @staticmethod
    def _split_partial_tag_suffix(text: str, tags: tuple[str, ...]) -> tuple[str, str]:
        lower_text = str(text or "").lower()
        if not lower_text:
            return "", ""

        best_length = 0
        for tag in tags:
            lower_tag = str(tag or "").lower()
            for suffix_length in range(1, min(len(lower_text), len(lower_tag) - 1) + 1):
                if lower_tag.startswith(lower_text[-suffix_length:]):
                    best_length = max(best_length, suffix_length)

        if best_length <= 0:
            return text, ""
        return text[:-best_length], text[-best_length:]

    def add_reasoning(self, text: Any) -> List[str]:
        reasoning_text = str(text or "")
        if not reasoning_text:
            return []
        return self._emit_reasoning(reasoning_text)

    def _emit_reasoning(self, text: str) -> List[str]:
        if not text:
            return []
        chunks: List[str] = []
        self.collected_thinking += text
        if not self.thinking_started:
            chunks.append(THINKING_START_MARKER)
            self.thinking_started = True
        chunks.append(text)
        return chunks

    def _add_visible_content(self, text: Any) -> List[str]:
        content_text = str(text or "")
        if not content_text:
            return []

        chunks: List[str] = []
        if self.thinking_started:
            chunks.append(THINKING_END_MARKER)
            self.thinking_started = False

        self.collected_content += content_text
        self.stream_buffer += content_text

        if self.token_to_hide in self.stream_buffer:
            parts = self.stream_buffer.split(self.token_to_hide)
            if parts[0]:
                chunks.append(parts[0])
            self.stream_buffer = "".join(parts[1:])

        partial_match_len = 0
        for i in range(1, len(self.token_to_hide)):
            if len(self.stream_buffer) >= i:
                suffix = self.stream_buffer[-i:]
                if self.token_to_hide.startswith(suffix):
                    partial_match_len = i

        if partial_match_len > 0:
            safe_text = self.stream_buffer[:-partial_match_len]
            self.stream_buffer = self.stream_buffer[-partial_match_len:]
            if safe_text:
                chunks.append(safe_text)
        else:
            if self.stream_buffer:
                chunks.append(self.stream_buffer)
            self.stream_buffer = ""

        return chunks

    def _drain_content_tag_buffer(self, *, final: bool = False) -> List[str]:
        chunks: List[str] = []

        while self.content_tag_buffer:
            buffer = self.content_tag_buffer
            if self.inline_thinking:
                close_index = self._find_tag(buffer, THINKING_CLOSE_TAG_LITERAL)
                if close_index >= 0:
                    thinking_text = buffer[:close_index]
                    if thinking_text:
                        chunks.extend(self._emit_reasoning(thinking_text))
                    self.content_tag_buffer = buffer[close_index + len(THINKING_CLOSE_TAG_LITERAL):]
                    self.inline_thinking = False
                    continue

                if final:
                    chunks.extend(self._emit_reasoning(buffer))
                    self.content_tag_buffer = ""
                    break

                safe_text, pending_suffix = self._split_partial_tag_suffix(
                    buffer,
                    (THINKING_CLOSE_TAG_LITERAL,),
                )
                if safe_text:
                    chunks.extend(self._emit_reasoning(safe_text))
                self.content_tag_buffer = pending_suffix
                break

            open_index = self._find_tag(buffer, THINKING_OPEN_TAG_LITERAL)
            close_index = self._find_tag(buffer, THINKING_CLOSE_TAG_LITERAL)
            if close_index >= 0 and (open_index < 0 or close_index < open_index):
                visible_text = buffer[:close_index]
                if visible_text:
                    chunks.extend(self._add_visible_content(visible_text))
                self.content_tag_buffer = buffer[close_index + len(THINKING_CLOSE_TAG_LITERAL):]
                continue

            if open_index >= 0:
                visible_text = buffer[:open_index]
                if visible_text:
                    chunks.extend(self._add_visible_content(visible_text))
                self.content_tag_buffer = buffer[open_index + len(THINKING_OPEN_TAG_LITERAL):]
                self.inline_thinking = True
                continue

            if final:
                chunks.extend(self._add_visible_content(buffer))
                self.content_tag_buffer = ""
                break

            safe_text, pending_suffix = self._split_partial_tag_suffix(
                buffer,
                (THINKING_OPEN_TAG_LITERAL, THINKING_CLOSE_TAG_LITERAL),
            )
            if safe_text:
                chunks.extend(self._add_visible_content(safe_text))
            self.content_tag_buffer = pending_suffix
            break

        return chunks

    def add_content(self, text: Any) -> List[str]:
        content_text = str(text or "")
        if not content_text:
            return []

        self.content_tag_buffer += content_text
        return self._drain_content_tag_buffer(final=False)

    def ensure_tool_call(self, index: int) -> Dict[str, Any]:
        normalized_index = max(0, int(index or 0))
        while len(self.tool_calls) <= normalized_index:
            self.tool_calls.append(
                {
                    "id": "",
                    "type": "function",
                    "thought_signature": "",
                    "function": {
                        "name": "",
                        "arguments": "",
                    },
                }
            )
        return self.tool_calls[normalized_index]

    def update_tool_call(
        self,
        index: int,
        *,
        tool_call_id: str = "",
        name: str = "",
        arguments: Optional[Any] = None,
        append_arguments: bool = False,
        thought_signature: str = "",
    ) -> None:
        tool_call = self.ensure_tool_call(index)

        normalized_id = str(tool_call_id or "").strip()
        if normalized_id:
            tool_call["id"] = normalized_id

        normalized_name = str(name or "").strip()
        if normalized_name:
            tool_call["function"]["name"] = normalized_name

        if arguments is not None:
            if isinstance(arguments, (dict, list)):
                argument_text = json.dumps(arguments, ensure_ascii=False)
            else:
                argument_text = str(arguments or "")
            if append_arguments:
                tool_call["function"]["arguments"] += argument_text
            else:
                tool_call["function"]["arguments"] = argument_text

        normalized_signature = str(thought_signature or "").strip()
        if normalized_signature:
            tool_call["thought_signature"] = normalized_signature

    def set_finish_reason(self, reason: Any) -> None:
        normalized_reason = str(reason or "").strip()
        if normalized_reason:
            self.finish_reason = normalized_reason

    def finalize_tool_calls(self) -> None:
        # Sparse indices and terminal empty deltas can create placeholder
        # entries. They have no callable identity and must never get a result.
        self.tool_calls[:] = [call for call in self.tool_calls
                              if str((call.get("function") or {}).get("name") or "").strip()]
        for call in self.tool_calls:
            if not str(call.get("id") or "").strip():
                # Bind once, before BOTH history and execution see this call.
                call["id"] = f"call_{uuid.uuid4().hex[:24]}"

    def flush(self) -> List[str]:
        self.finalize_tool_calls()
        chunks: List[str] = []
        chunks.extend(self._drain_content_tag_buffer(final=True))
        self.inline_thinking = False
        if self.thinking_started:
            chunks.append(THINKING_END_MARKER)
            self.thinking_started = False
        if self.stream_buffer and self.token_to_hide not in self.stream_buffer:
            chunks.append(self.stream_buffer)
        self.stream_buffer = ""
        return chunks

    def cleaned_content(self) -> str:
        return self.collected_content.replace(self.token_to_hide, "").strip()


def _convert_messages_to_anthropic_format(messages: List[Dict[str, Any]]) -> tuple[Optional[str], List[Dict[str, Any]]]:
    """Translate Reverie history into Anthropic-compatible message blocks."""
    system_message: Optional[str] = None
    anthropic_messages: List[Dict[str, Any]] = []

    for msg in messages:
        role = str(msg.get("role", "") or "").strip().lower()
        raw_content = msg.get("content", "")
        content_text = _extract_text_from_candidates(msg, "content")

        anthropic_content: Any = content_text
        if isinstance(raw_content, list):
            blocks: List[Dict[str, Any]] = []
            for part in raw_content:
                if not isinstance(part, dict):
                    if str(part or ""):
                        blocks.append({"type": "text", "text": str(part)})
                    continue
                part_type = str(part.get("type", "") or "").strip().lower()
                if part_type in {"text", "input_text", "output_text"}:
                    text = _coerce_text_fragments(part.get("text"))
                    if text:
                        blocks.append({"type": "text", "text": text})
                    continue
                if part_type == "image_url":
                    image_payload = part.get("image_url")
                    url = str(image_payload.get("url", "") if isinstance(image_payload, dict) else image_payload or "").strip()
                    if not url:
                        continue
                    data_match = re.match(r"^data:([^;,]+);base64,(.+)$", url, re.IGNORECASE | re.DOTALL)
                    if data_match:
                        source = {"type": "base64", "media_type": data_match.group(1), "data": data_match.group(2)}
                    else:
                        source = {"type": "url", "url": url}
                    blocks.append({"type": "image", "source": source})
                    continue
                if part_type in {"image", "input_image"} and isinstance(part.get("source"), dict):
                    blocks.append({"type": "image", "source": dict(part["source"])})
                if part_type == "input_audio":
                    blocks.append({"type": "text", "text": "MCP audio was returned; this provider does not accept audio input."})
            anthropic_content = blocks or content_text

        if role == "system":
            system_message = content_text
            continue

        if role == "assistant":
            tool_calls = msg.get("tool_calls", [])
            thinking = msg.get("anthropic_thinking", [])
            if isinstance(tool_calls, list) and tool_calls:
                anthropic_messages.append(
                    {
                        "role": "assistant",
                        "content": _build_anthropic_assistant_tool_blocks(content_text, tool_calls),
                    }
                )
            else:
                anthropic_messages.append({"role": "assistant", "content": anthropic_content})
            if isinstance(thinking, list) and thinking:
                content = anthropic_messages[-1]["content"]
                blocks = content if isinstance(content, list) else ([{"type": "text", "text": content}] if content else [])
                anthropic_messages[-1]["content"] = [*thinking, *blocks]
            continue

        if role == "tool":
            anthropic_messages.append(
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "tool_result",
                            "tool_use_id": str(msg.get("tool_call_id", "") or ""),
                            "content": anthropic_content,
                            "is_error": content_text.startswith("Error:"),
                        }
                    ],
                }
            )
            continue

        anthropic_messages.append({"role": "user", "content": anthropic_content})

    return system_message, anthropic_messages


def validate_and_sanitize_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate and sanitize the API request payload to prevent JSON serialization errors.
    
    This function:
    - Ensures all strings can be encoded and serialized safely
    - Validates that all values are JSON-serializable
    - Removes or fixes problematic control/unicode characters
    - Logs any issues found
    
    Args:
        payload: The payload dictionary to validate
        
    Returns:
        A sanitized payload dictionary
        
    Raises:
        ValueError: If the payload cannot be sanitized
    """
    def sanitize_string(value: str, path: str) -> str:
        """Keep user/tool text intact while removing only truly unsafe characters."""
        sanitized = ''.join(
            char for char in value
            if ord(char) >= 32 or char in '\n\r\t'
        )

        if sanitized != value:
            logger.debug(f"Removed control characters from {path}")

        try:
            sanitized.encode('utf-8')
        except UnicodeEncodeError:
            logger.warning(f"Replaced invalid unicode characters in {path}")
            sanitized = sanitized.encode('utf-8', errors='replace').decode('utf-8')

        try:
            json.dumps(sanitized, ensure_ascii=False)
        except (TypeError, ValueError) as e:
            logger.error(f"Failed to encode string at {path}: {e}")
            sanitized = ''.join(
                char for char in sanitized
                if ord(char) >= 32 or char in '\n\r\t'
            )
            json.dumps(sanitized, ensure_ascii=False)

        return sanitized

    def sanitize_value(value: Any, path: str = "") -> Any:
        """Recursively sanitize a value"""
        if value is None:
            return None
        
        elif isinstance(value, (str, int, float, bool)):
            if isinstance(value, str):
                value = sanitize_string(value, path)
            return value
        
        elif isinstance(value, dict):
            return {k: sanitize_value(v, f"{path}.{k}") for k, v in value.items()}
        
        elif isinstance(value, list):
            return [sanitize_value(item, f"{path}[{i}]") for i, item in enumerate(value)]
        
        else:
            raise ValueError(f"Unsupported type at {path}: {type(value)}")
    
    try:
        # Validate the payload structure
        if not isinstance(payload, dict):
            raise ValueError(f"Payload must be a dict, got {type(payload)}")
        
        # Sanitize the payload
        sanitized = sanitize_value(payload, "payload")
        
        # Test JSON serialization
        try:
            json_str = json.dumps(sanitized, ensure_ascii=False)
            # Verify it can be parsed back
            json.loads(json_str)
        except (TypeError, ValueError) as e:
            logger.error(f"JSON serialization failed: {e}")
            logger.error(f"Payload preview: {str(payload)[:500]}")
            raise ValueError(f"Payload cannot be serialized to JSON: {e}")
        
        return sanitized
    
    except Exception as e:
        logger.error(f"Payload validation failed: {e}")
        raise


def _decode_jsonish_escapes(value: str) -> str:
    """Decode common JSON escapes without corrupting literal non-ASCII text."""
    if "\\" not in value:
        return value

    def _replace_unicode(match: re.Match[str]) -> str:
        try:
            return chr(int(match.group(1), 16))
        except Exception:
            return match.group(0)

    decoded = re.sub(r"\\u([0-9a-fA-F]{4})", _replace_unicode, value)
    replacements = {
        r"\\": "\\",
        r"\"": '"',
        r"\'": "'",
        r"\/": "/",
        r"\n": "\n",
        r"\r": "\r",
        r"\t": "\t",
        r"\b": "\b",
        r"\f": "\f",
    }
    return re.sub(
        r"\\[\\\"'\/nrtbf]",
        lambda match: replacements.get(match.group(0), match.group(0)),
        decoded,
    )


def _decode_jsonish_string(body: str, quote: str) -> str:
    """Decode a string value from strict JSON or a relaxed JSON-like payload."""
    if quote == '"':
        try:
            return json.loads(f'"{body}"')
        except json.JSONDecodeError as exc:
            logger.debug("Relaxed JSON string decode fallback: %s", exc)
    return _decode_jsonish_escapes(body)


_JSONISH_ARGUMENT_BOUNDARY_KEYS = {
    "action",
    "allow_cancel",
    "body",
    "command",
    "confirm_delete",
    "content",
    "contents",
    "default_value",
    "destination",
    "dest",
    "dest_path",
    "file",
    "file_path",
    "file_text",
    "filename",
    "insert_line",
    "markdown",
    "max_results",
    "multiline",
    "new_str",
    "old_str",
    "operation",
    "overwrite",
    "path",
    "query",
    "question",
    "reason",
    "text",
    "url",
    "view_range",
}


def _next_property_name(raw: str, index: int) -> str:
    """Return the next quoted object property name after a comma."""
    match = re.match(r"\s*['\"]([^'\"]+)['\"]\s*:", raw[index:])
    return str(match.group(1) or "").strip() if match else ""


def _has_later_string_boundary(raw: str, start: int, quote: str) -> bool:
    """Return whether a later quote is a stronger closing-boundary candidate."""
    escaped = False
    i = start
    while i < len(raw):
        char = raw[i]
        if escaped:
            escaped = False
            i += 1
            continue
        if char == "\\":
            escaped = True
            i += 1
            continue
        if char != quote:
            i += 1
            continue

        j = i + 1
        while j < len(raw) and raw[j].isspace():
            j += 1
        if j >= len(raw) or raw[j] == "}":
            return True
        if raw[j] == "," and _next_property_name(raw, j + 1).lower() in _JSONISH_ARGUMENT_BOUNDARY_KEYS:
            return True
        i += 1
    return False


def _scan_jsonish_string(
    raw: str,
    start: int,
    quote: str,
    *,
    tolerate_embedded_quotes: bool = False,
) -> tuple[str, int, bool]:
    """Read a possibly long JSON-like string, preserving malformed long text."""
    pieces: List[str] = []
    escaped = False
    i = start

    while i < len(raw):
        char = raw[i]
        if escaped:
            pieces.append("\\" + char)
            escaped = False
            i += 1
            continue

        if char == "\\":
            escaped = True
            i += 1
            continue

        if char == quote:
            if tolerate_embedded_quotes:
                j = i + 1
                while j < len(raw) and raw[j].isspace():
                    j += 1
                is_boundary = j >= len(raw) or raw[j] == "}"
                if j < len(raw) and raw[j] == ",":
                    next_key = _next_property_name(raw, j + 1).lower()
                    if next_key not in _JSONISH_ARGUMENT_BOUNDARY_KEYS:
                        pieces.append(char)
                        i += 1
                        continue
                    is_boundary = True
                if j < len(raw) and raw[j] not in {",", "}"}:
                    pieces.append(char)
                    i += 1
                    continue
                if is_boundary and _has_later_string_boundary(raw, i + 1, quote):
                    pieces.append(char)
                    i += 1
                    continue

            return "".join(pieces), i + 1, True

        pieces.append(char)
        i += 1

    if escaped:
        pieces.append("\\")
    return "".join(pieces), len(raw), False


def _parse_jsonish_primitive(token: str) -> Any:
    """Parse a relaxed JSON primitive."""
    stripped = token.strip()
    lowered = stripped.lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if lowered == "null":
        return None
    try:
        return int(stripped)
    except ValueError:
        pass
    try:
        return float(stripped)
    except ValueError:
        return stripped


def _parse_jsonish_arguments(raw: str) -> Dict[str, Any]:
    """Salvage key/value pairs from malformed or very large tool arguments."""
    args: Dict[str, Any] = {}
    i = 0
    long_text_keys = {"content", "file_text", "new_str", "old_str", "text", "body", "contents"}

    while i < len(raw):
        match = re.search(r"(['\"])([^'\"]+)\1\s*:", raw[i:])
        if not match:
            break

        key = match.group(2).strip()
        value_start = i + match.end()
        while value_start < len(raw) and raw[value_start].isspace():
            value_start += 1

        if value_start >= len(raw):
            break

        first = raw[value_start]
        if first in {"'", '"'}:
            body, next_index, _closed = _scan_jsonish_string(
                raw,
                value_start + 1,
                first,
                tolerate_embedded_quotes=key.lower() in long_text_keys,
            )
            if not _closed:
                return {INVALID_TOOL_ARGUMENTS: "Incomplete tool arguments; resend the complete JSON object."}
            args[key] = _decode_jsonish_string(body, first)
            i = max(next_index, value_start + 1)
            continue

        end = value_start
        while end < len(raw) and raw[end] not in ",}":
            end += 1
        args[key] = _parse_jsonish_primitive(raw[value_start:end])
        i = max(end + 1, value_start + 1)

    return args


def parse_tool_arguments(raw: str) -> Dict[str, Any]:
    """Robustly parse a tool 'arguments' string into a dict.

    This helper attempts several fallbacks so streaming or partially-escaped
    JSON fragments won't cause the whole tool call to fail. Returns an empty
    dict on unrecoverable parse errors.
    """
    if isinstance(raw, dict):
        return dict(raw)

    if not raw:
        return {}

    raw = str(raw)

    # Fast path: valid JSON
    try:
        return json.loads(raw)
    except json.JSONDecodeError as e:
        logger.debug(f"Tool arguments JSON decode failed (fast path): {e}")

    if not raw.strip().endswith("}"):
        return {INVALID_TOOL_ARGUMENTS: "Incomplete tool arguments; resend the complete JSON object."}

    # Try a sanitized JSON attempt (remove control chars / trailing commas)
    sanitized = re.sub(r"[\x00-\x08\x0b-\x0c\x0e-\x1f]", "", raw)
    sanitized = re.sub(r",\s*([\}\]])", r"\1", sanitized)
    try:
        return json.loads(sanitized)
    except json.JSONDecodeError as exc:
        logger.debug("Tool arguments JSON decode failed (sanitized path): %s", exc)

    # Generic key/value fallback for simple primitive payloads.
    # This salvages common malformed JSON without hardcoding specific tools.
    generic_args: Dict[str, Any] = {}

    for m in re.finditer(
        r'["\']([^"\']+)["\']\s*:\s*("([^"\\]*(?:\\.[^"\\]*)*)"|\'([^\'\\]*(?:\\.[^\'\\]*)*)\'|true|false|null|-?\d+(?:\.\d+)?)',
        raw,
        re.I,
    ):
        key = m.group(1)
        token = m.group(2)
        if token.lower() == "true":
            generic_args[key] = True
        elif token.lower() == "false":
            generic_args[key] = False
        elif token.lower() == "null":
            generic_args[key] = None
        elif (token.startswith('"') and token.endswith('"')) or (token.startswith("'") and token.endswith("'")):
            generic_args[key] = _decode_jsonish_string(token[1:-1], token[0])
        else:
            try:
                generic_args[key] = int(token)
            except ValueError:
                try:
                    generic_args[key] = float(token)
                except ValueError:
                    generic_args[key] = token

    # Heuristic fallback: extract known keys (safe and targeted)
    args: Dict[str, Any] = {}

    # path
    m = re.search(r'"path"\s*:\s*"([^"]+)"', raw)
    if not m:
        m = re.search(r"'path'\s*:\s*'([^']+)'", raw)
    if m:
        args['path'] = m.group(1)

    # content (allow multiline capture)
    m = re.search(r'"content"\s*:\s*"([\s\S]*?)"(?=,\s*"|\s*\})', raw)
    if not m:
        m = re.search(r"'content'\s*:\s*'([\s\S]*?)'(?=,\s*'|\s*\})", raw)
    if m:
        content_val = m.group(1)
        content_val = _decode_jsonish_string(content_val, '"' if raw[m.start()] == '"' else "'")
        args['content'] = content_val

    # overwrite
    m = re.search(r'"overwrite"\s*:\s*(true|false)', raw, re.I)
    if m:
        args['overwrite'] = m.group(1).lower() == 'true'

    # Merge generic fallback only for keys not already parsed by targeted heuristics.
    for key, value in generic_args.items():
        args.setdefault(key, value)

    # Scanner fallback: preserves long multiline values containing quotes, code
    # fences, or incomplete closing braces that regex-based salvage can miss.
    long_text_keys = {"content", "file_text", "new_str", "old_str", "text", "body", "contents"}
    for key, value in _parse_jsonish_arguments(raw).items():
        existing = args.get(key)
        if key not in args:
            args[key] = value
        elif (
            key.lower() in long_text_keys
            and isinstance(value, str)
            and isinstance(existing, str)
            and len(value) > len(existing)
        ):
            args[key] = value

    if not args:
        logger.debug("Tool arguments were not valid strict JSON; returning empty dict (preview: %s)", raw[:200])

    return args


def _sanitize_tool_calls(tool_calls: list) -> None:
    """Ensure each tool_call.function.arguments is valid JSON string.

    Mutates tool_calls in-place: if arguments are parseable by
    parse_tool_arguments, replace with a clean json.dumps(dict).
    If not parseable, replace with '{}' to avoid sending malformed
    JSON to the provider (which previously produced 400s).
    """
    for tc in tool_calls:
        fn = tc.get("function") or {}
        raw = fn.get("arguments", "")
        if not raw:
            fn["arguments"] = json.dumps({})
            tc["function"] = fn
            continue

        # If already valid JSON string, keep as-is
        try:
            json.loads(raw)
            continue
        except Exception:
            # Try to salvage
            parsed = parse_tool_arguments(raw)
            try:
                fn["arguments"] = json.dumps(parsed, ensure_ascii=False)
            except Exception:
                fn["arguments"] = json.dumps({})
            tc["function"] = fn


def _writer_history_elision(label: str, *, chars: int = 0, items: int = 0) -> str:
    """Build a compact placeholder for large Writer-native payloads kept in history only."""
    details: List[str] = []
    if items > 0:
        details.append(f"{items} items")
    if chars > 0:
        details.append(f"{chars} chars")
    suffix = f" ({', '.join(details)})" if details else ""
    return f"[Writer history elided: {label}{suffix}]"


def _compact_writer_serial_novel_history_arguments(arguments: Dict[str, Any]) -> Dict[str, Any]:
    """Strip large Writer-native prose payloads from stored history while keeping valid tool JSON."""
    if not isinstance(arguments, dict):
        return {}

    compacted = dict(arguments)
    data = compacted.get("data")
    compacted_data = dict(data) if isinstance(data, dict) else None
    action = str(compacted.get("action", "") or "").strip().lower()

    def _compact_string_field(container: Dict[str, Any], key: str) -> None:
        value = container.get(key)
        if isinstance(value, str) and value.strip():
            container[key] = _writer_history_elision(key, chars=len(value))

    def _compact_list_field(container: Dict[str, Any], key: str) -> None:
        value = container.get(key)
        if not isinstance(value, list) or not value:
            return
        total_chars = sum(len(str(item)) for item in value)
        container[key] = [_writer_history_elision(key, items=len(value), chars=total_chars)]

    if action == "commit_chapter":
        if compacted_data is not None:
            for key in ("content", "append_content"):
                value = compacted_data.get(key)
                if isinstance(value, str) and value.strip():
                    compacted_data.pop(key, None)
    elif action == "configure":
        if compacted_data is not None:
            for key in ("world_bible", "cast_bible", "story_architecture", "style_guide", "roadmap"):
                _compact_string_field(compacted_data, key)
    elif action == "prepare_chapter":
        if compacted_data is not None:
            for key in ("outline", "opening_hook", "ending_hook"):
                _compact_string_field(compacted_data, key)
            for key in ("scene_beats", "continuity_requirements", "relationship_progression"):
                _compact_list_field(compacted_data, key)

    if compacted_data is not None:
        compacted["data"] = compacted_data
    return compacted


def _compact_tool_calls_for_history(tool_calls: list, *, mode: str = "") -> list:
    """Return a history-safe copy of tool calls without mutating live execution arguments."""
    compacted: List[Dict[str, Any]] = []
    writer_mode = normalize_mode(mode) == "writer"

    for tool_call in tool_calls or []:
        if not isinstance(tool_call, dict):
            continue

        function = tool_call.get("function")
        if not isinstance(function, dict):
            continue

        cloned = {
            "id": str(tool_call.get("id", "") or f"call_{uuid.uuid4().hex[:24]}"),
            "type": "function",
            "function": {
                "name": str(function.get("name", "") or "").strip(),
                "arguments": str(function.get("arguments", "") or ""),
            },
        }
        thought_signature = str(
            tool_call.get("thought_signature")
            or tool_call.get("gemini_thought_signature")
            or ""
        ).strip()
        if thought_signature:
            cloned["thought_signature"] = thought_signature

        if writer_mode and cloned["function"]["name"] == "serial_novel":
            parsed = parse_tool_arguments(cloned["function"]["arguments"])
            compacted_args = _compact_writer_serial_novel_history_arguments(parsed)
            cloned["function"]["arguments"] = json.dumps(compacted_args, ensure_ascii=False)

        compacted.append(cloned)

    _sanitize_tool_calls(compacted)
    return compacted


def _sanitize_messages_for_relay(
    messages: List[Dict[str, Any]], *, preserve_assistant_reasoning: bool = False,
) -> List[Dict[str, Any]]:
    """Normalize message payloads before sending them to proxied/native providers."""
    sanitized_messages: List[Dict[str, Any]] = []

    for message in messages or []:
        if not isinstance(message, dict):
            continue

        sanitized = dict(message)
        role = str(sanitized.get("role", "") or "").strip().lower()
        if not preserve_assistant_reasoning or role != "assistant":
            sanitized.pop("reasoning_content", None)
        if role:
            sanitized["role"] = role

        sanitized["content"] = _normalize_message_content_for_relay(sanitized.get("content", ""))

        if role == "tool":
            sanitized["tool_call_id"] = str(sanitized.get("tool_call_id", "") or "").strip()
            if not sanitized["tool_call_id"]:
                # Old nameless SSE fragments left these unowned errors in
                # history. Preserve that evidence on disk, but no native API
                # accepts a tool result without an associated call identity.
                continue

        raw_tool_calls = sanitized.get("tool_calls")
        if isinstance(raw_tool_calls, list):
            normalized_tool_calls = []
            for index, tool_call in enumerate(raw_tool_calls):
                if not isinstance(tool_call, dict):
                    continue
                function_data = tool_call.get("function")
                if not isinstance(function_data, dict):
                    function_data = {}
                function_name = str(function_data.get("name", "") or "").strip()
                if not function_name:
                    continue

                arguments = function_data.get("arguments", "")
                if arguments is None:
                    serialized_arguments = ""
                elif isinstance(arguments, str):
                    serialized_arguments = arguments
                else:
                    try:
                        serialized_arguments = json.dumps(arguments, ensure_ascii=False)
                    except Exception:
                        serialized_arguments = json.dumps({})

                normalized_tool_calls.append(
                    {
                        "id": str(tool_call.get("id", "") or f"call_{uuid.uuid4().hex[:24]}"),
                        "type": "function",
                        "function": {
                            "name": function_name,
                            "arguments": serialized_arguments,
                        },
                    }
                )
                thought_signature = str(
                    tool_call.get("thought_signature")
                    or tool_call.get("gemini_thought_signature")
                    or ""
                ).strip()
                if thought_signature:
                    normalized_tool_calls[-1]["thought_signature"] = thought_signature

            if normalized_tool_calls:
                _sanitize_tool_calls(normalized_tool_calls)
                sanitized["tool_calls"] = normalized_tool_calls
            else:
                sanitized.pop("tool_calls", None)
        else:
            sanitized.pop("tool_calls", None)

        sanitized_messages.append(sanitized)

    return sanitized_messages


def _coalesce_system_messages_to_front(messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Merge all system-role messages into the first transcript slot.

    NVIDIA's hosted chat-completions endpoint is strict about system messages
    being positioned at the beginning. Reverie can accumulate additional
    system notes during compression, resume, and manual context operations, so
    we normalize only the outbound provider payload and keep the in-memory
    conversation history unchanged.
    """
    if not isinstance(messages, list):
        return []

    system_texts: List[str] = []
    non_system_messages: List[Dict[str, Any]] = []

    for message in messages:
        if not isinstance(message, dict):
            continue
        role = str(message.get("role", "") or "").strip().lower()
        if role == "system":
            text = _coerce_text_fragments(message.get("content")).strip()
            if text:
                system_texts.append(text)
            continue
        non_system_messages.append(dict(message))

    if not system_texts:
        return [dict(message) for message in messages if isinstance(message, dict)]

    deduped_texts: List[str] = []
    seen: set[str] = set()
    for index, text in enumerate(system_texts):
        if text in seen:
            continue
        seen.add(text)
        if index == 0:
            deduped_texts.append(text)
        else:
            deduped_texts.append(f"[Merged System Note]\n{text}")

    merged_system = {
        "role": "system",
        "content": "\n\n".join(deduped_texts).strip(),
    }
    return [merged_system] + non_system_messages


def _strip_tooling_from_messages(messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Remove OpenAI tool-call transcript artifacts for providers that reject them."""
    sanitized_messages: List[Dict[str, Any]] = []

    for message in messages or []:
        if not isinstance(message, dict):
            continue

        role = str(message.get("role", "") or "").strip().lower()
        if role == "tool":
            continue

        sanitized = dict(message)
        had_tool_calls = isinstance(sanitized.get("tool_calls"), list) and bool(sanitized.get("tool_calls"))
        sanitized.pop("tool_calls", None)

        content_text = _coerce_text_fragments(sanitized.get("content", "")).strip()
        if role == "assistant" and had_tool_calls and not content_text:
            continue

        sanitized_messages.append(sanitized)

    return sanitized_messages


def _strip_tooling_from_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Remove tool-calling request fields and related transcript artifacts."""
    compatibility_payload = dict(payload or {})
    compatibility_payload.pop("tools", None)
    compatibility_payload.pop("tool_choice", None)
    compatibility_payload.pop("parallel_tool_calls", None)
    compatibility_payload.pop("stream_options", None)

    messages = compatibility_payload.get("messages")
    if isinstance(messages, list):
        compatibility_payload["messages"] = _coalesce_system_messages_to_front(
            _strip_tooling_from_messages(messages)
        )

    return compatibility_payload


def _should_retry_without_tooling(status_code: Any) -> bool:
    """Whether a provider error is worth retrying with plain chat messages."""
    return isinstance(status_code, int) and 400 <= status_code < 600 and status_code != 429


# Thinking is enabled by default, and a gateway that does not understand the
# flags must degrade to a plain request instead of failing the turn.  The tiers
# are ordered most-vendor-specific first, so a provider that only speaks plain
# `reasoning_effort` keeps thinking on instead of losing it to one blanket strip.
_THINKING_HINT_TIERS: Tuple[Tuple[str, ...], ...] = CUSTOM_PROVIDER_REASONING_FIELD_TIERS
_THINKING_HINT_FIELDS: Tuple[str, ...] = CUSTOM_PROVIDER_REASONING_FIELDS


def _has_thinking_hints(payload: Dict[str, Any]) -> bool:
    """Whether this request carries Reverie's thinking flags."""
    extra_body = payload.get("extra_body")
    if not isinstance(extra_body, dict):
        return False
    return any(field in extra_body for field in _THINKING_HINT_FIELDS)


def _without_thinking_hints(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Drop only the thinking flags, preserving every other request field."""
    prepared = dict(payload or {})
    extra_body = prepared.get("extra_body")
    if isinstance(extra_body, dict):
        cleaned = {key: value for key, value in extra_body.items() if key not in _THINKING_HINT_FIELDS}
        if cleaned:
            prepared["extra_body"] = cleaned
        else:
            prepared.pop("extra_body", None)
    return prepared


def _narrow_thinking_hints(payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Drop the most vendor-specific thinking tier still in the request.

    Returns ``None`` once no reasoning field is left, which is how the caller
    tells "retry with a narrower payload" from "stop retrying".
    """
    prepared = dict(payload or {})
    extra_body = prepared.get("extra_body")
    if not isinstance(extra_body, dict):
        return None
    narrowed = narrow_custom_provider_reasoning_payload(extra_body)
    if narrowed is None:
        return None
    if narrowed:
        prepared["extra_body"] = narrowed
    else:
        prepared.pop("extra_body", None)
    return prepared


def _is_thinking_hint_rejection(error: BaseException) -> bool:
    """Whether a failure looks like the provider refusing the thinking flags."""
    status = getattr(error, "status_code", None)
    if not isinstance(status, int):
        status = getattr(getattr(error, "response", None), "status_code", None)
    if isinstance(status, int) and (status == 429 or not 400 <= status < 500):
        return False
    text = str(error or "").lower()
    response = getattr(error, "response", None)
    if response is not None:
        text = f"{text} {str(getattr(response, 'text', '') or '')}".lower()
    if any(field in text for field in _THINKING_HINT_FIELDS):
        return True
    # A bare validation failure is worth one narrowing pass: the reasoning union
    # is the only speculative part of the request, so it is the likeliest cause
    # and narrowing keeps every other field -- tools included -- intact.
    if isinstance(status, int) and status in (400, 422):
        return True
    if not text:
        return False
    if "thinking" not in text and "extra_body" not in text:
        return False
    return any(
        marker in text
        for marker in (
            "unexpected", "unknown", "unsupported", "not supported", "unrecognized",
            "invalid", "not permitted", "extra field", "extra fields", "additional propert",
        )
    )


def _compact_payload_for_plain_chat(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Build a minimal chat payload for small/local compatibility providers."""
    compact_payload = _strip_tooling_from_payload(payload)
    messages = compact_payload.get("messages")
    if not isinstance(messages, list):
        return compact_payload

    compact_messages: List[Dict[str, Any]] = []
    for message in messages:
        if not isinstance(message, dict):
            continue
        role = str(message.get("role", "") or "").strip().lower()
        if role == "system":
            compact_messages.append(
                {
                    "role": "system",
                    "content": (
                        "You are Reverie, a concise coding assistant. "
                        "Answer the user directly. Tools may be unavailable on this provider."
                    ),
                }
            )
            continue
        compact_messages.append(dict(message))

    compact_payload["messages"] = compact_messages
    return compact_payload


def _is_stream_usage_rejection(error: BaseException) -> bool:
    response = getattr(error, "response", None)
    status = getattr(error, "status_code", None) or getattr(response, "status_code", None)
    if status not in {400, 422} and not isinstance(error, TypeError):
        return False
    message = (str(error) + " " + _extract_safe_http_error_message(response)).lower()
    return any(key in message for key in ("stream_options", "include_usage")) and any(
        marker in message for marker in ("unsupported", "not supported", "unknown", "unrecognized", "unexpected", "not permitted", "not allowed", "extra inputs")
    )


def _extract_safe_http_error_message(response: Any) -> str:
    """Extract a concise provider error message without dumping full payloads."""
    if response is None:
        return ""

    try:
        payload = response.json()
    except Exception:
        payload = None

    candidates: List[str] = []
    if isinstance(payload, dict):
        error_block = payload.get("error")
        if isinstance(error_block, dict):
            for key in ("message", "msg", "detail", "type", "code"):
                value = error_block.get(key)
                if value is not None:
                    text = str(value).strip()
                    if text:
                        candidates.append(text)
        for key in ("message", "msg", "detail", "title", "status"):
            value = payload.get(key)
            if value is not None:
                text = str(value).strip()
                if text:
                    candidates.append(text)

    for candidate in candidates:
        compact = " ".join(candidate.split())
        if compact:
            return compact[:300]
    return ""


def make_api_request_with_retry(
    url: str,
    headers: Dict[str, str],
    payload: Dict[str, Any],
    max_retries: int = 3,
    initial_backoff: float = 1.0,
    stream: bool = False,
    timeout: int = 60,
    on_retry: Optional[Callable[[float, int, int, BaseException], None]] = None,
    proxies: Optional[Dict[str, str]] = None,
) -> Any:
    """
    Make an API request with bounded retries and configurable delay scaling.
    
    Args:
        url: The API endpoint URL
        headers: Request headers
        payload: Request payload (will be validated and sanitized)
        max_retries: Maximum retries after the initial request; zero disables retries.
        initial_backoff: Scale for the 1, 3, 5, 7, and 15 second delay schedule.
        stream: Whether to stream the response
        timeout: Request timeout in seconds
        on_retry: Optional callback invoked before each retry sleep.
        
    Returns:
        The response object
        
    Raises:
        requests.RequestException: If all retries fail
    """
    import requests
    
    # Validate and sanitize payload
    try:
        sanitized_payload = validate_and_sanitize_payload(payload)
    except ValueError as e:
        logger.error(f"Payload validation failed before request: {e}")
        raise
    
    last_error = None
    try:
        timeout_value = max(1, int(timeout or 60))
    except (TypeError, ValueError):
        timeout_value = 60
    request_timeout = (min(15, timeout_value), timeout_value)
    is_nvidia_request = (
        is_nvidia_api_url(url)
        or is_nvidia_model(str(sanitized_payload.get("model", "") or ""))
    )
    attempts = max(0, int(max_retries))
    for attempt in range(attempts + 1):
        check_cancel()
        try:
            if is_nvidia_request:
                _wait_for_nvidia_rate_limit()
            logger.debug(f"API request attempt {attempt + 1}/{attempts + 1}")

            request_headers = dict(headers or {})
            if stream:
                request_headers.setdefault("Connection", "keep-alive")
                request_headers.setdefault("Cache-Control", "no-cache")

            def post_request(request_payload: Dict[str, Any]) -> Any:
                request_kwargs: Dict[str, Any] = {
                    "headers": request_headers,
                    "json": request_payload,
                    "stream": stream,
                    "timeout": request_timeout,
                }
                if proxies:
                    request_kwargs["proxies"] = proxies
                return provider_post(url, **request_kwargs)

            response = post_request(sanitized_payload)
            
            # Check for HTTP errors
            response.raise_for_status()
            
            # Success - return response
            logger.debug(f"API request succeeded on attempt {attempt + 1}")
            return response
            
        except requests.exceptions.HTTPError as e:
            last_error = e
            status_code = e.response.status_code if e.response is not None else "unknown"
            safe_error_message = _extract_safe_http_error_message(getattr(e, "response", None))

            if sanitized_payload.get("stream_options") and _is_stream_usage_rejection(e):
                compatibility_payload = dict(sanitized_payload)
                compatibility_payload.pop("stream_options")
                logger.warning("Provider rejected streaming usage options; retrying without them")
                try:
                    fallback_response = post_request(compatibility_payload)
                    fallback_response.raise_for_status()
                    return fallback_response
                except requests.exceptions.RequestException as fallback_error:
                    last_error = fallback_error
                    sanitized_payload = compatibility_payload
                    e = fallback_error
                    status_code = getattr(getattr(e, "response", None), "status_code", "unknown")
                    safe_error_message = _extract_safe_http_error_message(getattr(e, "response", None))

            if has_prompt_cache_hints(sanitized_payload) and is_prompt_cache_rejection(e):
                compatibility_payload = without_prompt_cache(sanitized_payload)
                logger.warning("Provider rejected prompt-cache hints; retrying once without them")
                try:
                    fallback_response = post_request(compatibility_payload)
                    fallback_response.raise_for_status()
                    return fallback_response
                except requests.exceptions.RequestException as fallback_error:
                    last_error = fallback_error
                    sanitized_payload = compatibility_payload
                    e = fallback_error
                    status_code = getattr(getattr(fallback_error, "response", None), "status_code", "unknown")
                    safe_error_message = _extract_safe_http_error_message(
                        getattr(fallback_error, "response", None)
                    )

            # Don't retry on client errors (4xx) except 429 (rate limit)
            if isinstance(status_code, int) and 400 <= status_code < 500 and not _is_provider_rate_limit(status_code, e):
                logger.error(f"Client error {status_code}, not retrying: {e}")
                if safe_error_message:
                    logger.error("Provider returned: %s", safe_error_message)
                # Avoid dumping raw response bodies because they may contain prompts or credentials.
                if e.response is not None:
                    try:
                        error_detail = e.response.json()
                        if isinstance(error_detail, dict):
                            detail_keys = ", ".join(sorted(str(key) for key in error_detail.keys())[:8])
                            logger.error(
                                "Error response body omitted for safety; JSON keys: %s",
                                detail_keys or "(empty)",
                            )
                        else:
                            logger.error("Error response body omitted for safety")
                    except Exception:
                        logger.error("Error response body omitted for safety")
                if safe_error_message:
                    raise requests.exceptions.HTTPError(
                        f"{e} | Provider said: {safe_error_message}",
                        response=e.response,
                        request=e.request,
                    ) from e
                raise
            
            # Retry on server errors (5xx) and rate limit (429)
            logger.warning(f"HTTP error {status_code} on attempt {attempt + 1}: {e}")
            
        except requests.exceptions.RequestException as e:
            last_error = e
            logger.warning(f"Request exception on attempt {attempt + 1}: {e}")
        
        if attempt < attempts:
            backoff = _api_retry_delay(attempt, initial_backoff, last_error)
            if callable(on_retry) and last_error is not None:
                try:
                    on_retry(float(backoff), attempt + 1, attempts, last_error)
                except Exception:
                    logger.debug("Retry callback failed", exc_info=True)
            logger.debug(f"Waiting {backoff}s before retry...")
            interruptible_sleep(backoff)
    
    # All retries failed
    logger.error(f"All {attempts} retry attempts failed")
    raise last_error or requests.RequestException("All retry attempts failed")


class _CurlResponse:
    """Small requests-like wrapper around a system curl invocation."""

    def __init__(self, process: Any = None, *, stdout: str = "", stderr: str = "", returncode: int = 0, cancel_release=None):
        self._process = process
        self._stdout = stdout
        self._stderr = stderr
        self._returncode = int(returncode)
        self._cancel_release = cancel_release or (lambda: None)

    def json(self) -> Any:
        if self._returncode != 0:
            raise RuntimeError(self._stderr.strip() or f"curl exited with code {self._returncode}")
        return json.loads(self._stdout)

    def iter_lines(self, decode_unicode: bool = False, chunk_size: int = 0):
        del chunk_size
        if self._process is None or self._process.stdout is None:
            for line in self._stdout.splitlines():
                yield line if decode_unicode else line.encode("utf-8")
            return
        for line in self._process.stdout:
            text = str(line).rstrip("\r\n")
            yield text if decode_unicode else text.encode("utf-8")
        stderr = self._process.stderr.read() if self._process.stderr is not None else ""
        returncode = self._process.wait()
        check_cancel()
        if returncode != 0:
            raise RuntimeError(str(stderr or "").strip() or f"curl exited with code {returncode}")

    def close(self) -> None:
        if self._process is None:
            return
        try:
            if self._process.poll() is None:
                self._process.terminate()
            self._process.wait(timeout=5)
        finally:
            self._cancel_release()
            for pipe in (self._process.stdout, self._process.stderr):
                if pipe is not None:
                    pipe.close()


def _invoke_system_curl(
    *,
    url: str,
    headers: Dict[str, str],
    payload: Dict[str, Any],
    stream: bool,
    timeout: int,
    proxy: Optional[str] = None,
) -> _CurlResponse:
    """POST JSON through the system curl executable without shell interpolation."""
    import shutil
    import subprocess

    executable = shutil.which("curl.exe") or shutil.which("curl")
    if not executable:
        raise RuntimeError("System curl executable was not found on PATH")

    command = [
        executable,
        "--silent",
        "--show-error",
        "--fail-with-body",
        "--request",
        "POST",
        "--url",
        str(url),
        "--max-time",
        str(max(int(timeout or 60), 1)),
    ]
    if stream:
        command.append("--no-buffer")
    if proxy:
        command.extend(["--proxy", str(proxy)])
    elif urlsplit(str(url)).hostname in {"localhost", "127.0.0.1", "::1"}:
        command.extend(["--noproxy", "*"])
    for name, value in headers.items():
        command.extend(["--header", f"{name}: {value}"])
    command.extend(["--data-binary", "@-"])
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))

    check_cancel()
    process = subprocess.Popen(
        command,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    def terminate():
        try:
            process.terminate()
        except OSError:
            pass
    release = on_cancel(terminate)
    if stream:
        try:
            process.stdin.write(body)
            process.stdin.close()
        except BaseException:
            terminate()
            process.wait()
            release()
            raise
        return _CurlResponse(process, cancel_release=release)
    try:
        stdout, stderr = process.communicate(input=body, timeout=max(int(timeout or 60), 1) + 5)
        check_cancel()
    except BaseException:
        if process.poll() is None:
            process.kill()
            process.wait()
        raise
    finally:
        release()
    return _CurlResponse(
        stdout=stdout,
        stderr=stderr,
        returncode=process.returncode,
    )


class ReverieAgent:
    """
    The Reverie AI Agent.
    
    Uses OpenAI SDK for API interaction and integrates deeply
    with the Context Engine for reduced hallucinations.
    """
    
    def __init__(
        self,
        base_url: str,
        api_key: str,
        model: str,
        model_display_name: Optional[str] = None,
        project_root: Optional[Path] = None,
        retriever=None,
        indexer=None,
        git_integration=None,
        additional_rules: str = "",
        mode: str = "reverie",
        provider: str = "openai-chat",
        thinking_mode: Optional[str] = None,
        endpoint: str = "",
        custom_headers: Optional[Dict[str, str]] = None,
        operation_history=None,
        rollback_manager=None,
        config=None,
        runtime_surface: str = "terminal",
        agent_id: str = "main",
        agent_color: str = "",
        parent_agent_id: str = "",
    ):
        self.base_url = base_url
        self.api_key = api_key
        self.model = model
        self.model_display_name = derive_model_display_name(model, model_display_name)
        self.project_root = project_root or Path.cwd()
        self.agent_id = str(agent_id or "main").strip() or "main"
        self.agent_color = str(agent_color or "").strip()
        self.parent_agent_id = str(parent_agent_id or "").strip()
        self.additional_rules = additional_rules
        self.mode = mode
        self.task_stage = "PLANNING"
        self.provider = normalize_model_provider(provider)
        self.config = config
        self.runtime_surface = normalize_runtime_surface(runtime_surface)
        self.thinking_mode = thinking_mode
        self.endpoint = str(endpoint or "").strip()
        self.custom_headers: Dict[str, str] = {}
        if isinstance(custom_headers, dict):
            for key, value in custom_headers.items():
                k = str(key or "").strip()
                v = str(value or "").strip()
                if k and v:
                    self.custom_headers[k] = v
        # Runtime flag: when true, openai-sdk calls are routed via request provider
        # to support full endpoint overrides (GCMP-like behavior).
        self._openai_request_fallback_active = False
        
        # API configuration for stability
        self.api_max_retries = API_RETRY_ATTEMPTS
        self.api_initial_backoff = API_RETRY_DELAYS_SECONDS[0]
        self.api_timeout = 60
        self.api_enable_debug_logging = False

        if config:
            self.api_max_retries = max(0, int(getattr(config, 'api_max_retries', API_RETRY_ATTEMPTS)))
            self.api_initial_backoff = max(0.0, float(getattr(config, 'api_initial_backoff', API_RETRY_DELAYS_SECONDS[0])))
            self.api_timeout = getattr(config, 'api_timeout', 60)
            self.api_enable_debug_logging = getattr(config, 'api_enable_debug_logging', False)
        
        # Configure logging level based on config
        if self.api_enable_debug_logging:
            logging.getLogger(__name__).setLevel(logging.DEBUG)
        else:
            logging.getLogger(__name__).setLevel(logging.WARNING)
        
        # Provider clients are initialized lazily on the first actual model call.
        self._client = None
        self._client_config_key: Optional[tuple[Any, ...]] = None
        
        # Initialize tool executor
        self.tool_executor = ToolExecutor(
            project_root=self.project_root,
            retriever=retriever,
            indexer=indexer,
            git_integration=git_integration
        )
        # Inject agent instance into tool context
        self.tool_executor.update_context('agent', self)
        
        # Conversation history
        self.messages: List[Dict] = []
        self._token_estimate_cache_key: Optional[tuple[Any, ...]] = None
        self._token_estimate_cache_value: int = 0
        self._token_estimate_cache_time = 0.0
        self._auto_context_compaction_active = False
        self._auto_context_compaction_retry_after = 0.0
        self._auto_context_rotation_active = False
        self._auto_context_rotation_retry_after = 0.0
        self._last_context_safety_signature: Optional[tuple[Any, ...]] = None
        self._memory_os: Optional[MemoryOS] = None
        self._prompt_history_limit = 28
        # Thinking Tool spin guard, reset at the start of every user turn.
        self._consecutive_think_only_batches = 0
        self._think_tool_suppressed = False
        
        # Operation history and rollback support
        self.operation_history = operation_history
        self.rollback_manager = rollback_manager
        self.current_checkpoint_id: Optional[str] = None
        
        self.system_prompt = build_system_prompt(
            model_name=self.model_display_name,
            model_id=self.model,
            additional_rules=additional_rules,
            mode=self.mode,
            config=self.config,
            runtime_surface=self.runtime_surface,
        )

    def set_task_stage(self, stage: str) -> None:
        """Record the declared execution stage (PLANNING/EXECUTION/VERIFICATION).

        Informational only: the system prompt no longer varies by stage, so this
        does not rebuild it.
        """
        if stage in ("PLANNING", "EXECUTION", "VERIFICATION"):
            self.task_stage = stage

    def _check_tool_side_effects(self, tool_name: str, args: Dict[str, Any]) -> None:
        """Check for tools that modify agent state"""
        if tool_name == "task_boundary":
            self.set_task_stage(str(args.get("Mode") or ""))

    def update_mode(self, mode: str) -> None:
        """Update the agent's mode and rebuild the system prompt"""
        self.mode = mode
        self.task_stage = "PLANNING"  # Reset stage on mode switch
        self.system_prompt = build_system_prompt(
            model_name=self.model_display_name,
            model_id=self.model,
            additional_rules=self.additional_rules,
            mode=self.mode,
            config=self.config,
            runtime_surface=self.runtime_surface,
        )

    def reconfigure_runtime(
        self,
        *,
        base_url: str,
        api_key: str,
        model: str,
        model_display_name: Optional[str] = None,
        additional_rules: str = "",
        mode: str = "reverie",
        provider: str = "openai-chat",
        thinking_mode: Optional[str] = None,
        endpoint: str = "",
        custom_headers: Optional[Dict[str, str]] = None,
        config=None,
        runtime_surface: Optional[str] = None,
    ) -> None:
        """Refresh provider/model settings in place to speed up model switches."""
        self.base_url = base_url
        self.api_key = api_key
        self.model = model
        self.model_display_name = derive_model_display_name(model, model_display_name)
        self.additional_rules = additional_rules
        self.mode = mode
        self.task_stage = "PLANNING"
        self.provider = normalize_model_provider(provider)
        self.config = config
        if runtime_surface is not None:
            self.runtime_surface = normalize_runtime_surface(runtime_surface)
        self.thinking_mode = thinking_mode
        self.endpoint = str(endpoint or "").strip()
        self.custom_headers = {}
        if isinstance(custom_headers, dict):
            for key, value in custom_headers.items():
                k = str(key or "").strip()
                v = str(value or "").strip()
                if k and v:
                    self.custom_headers[k] = v

        self._openai_request_fallback_active = False
        self.api_max_retries = API_RETRY_ATTEMPTS
        self.api_initial_backoff = API_RETRY_DELAYS_SECONDS[0]
        self.api_timeout = 60
        self.api_enable_debug_logging = False
        if config:
            self.api_max_retries = max(0, int(getattr(config, 'api_max_retries', API_RETRY_ATTEMPTS)))
            self.api_initial_backoff = max(0.0, float(getattr(config, 'api_initial_backoff', API_RETRY_DELAYS_SECONDS[0])))
            self.api_timeout = getattr(config, 'api_timeout', 60)
            self.api_enable_debug_logging = getattr(config, 'api_enable_debug_logging', False)

        if self.api_enable_debug_logging:
            logging.getLogger(__name__).setLevel(logging.DEBUG)
        else:
            logging.getLogger(__name__).setLevel(logging.WARNING)

        self._client = None
        self._client_config_key = None
        self._token_estimate_cache_key = None
        self._token_estimate_cache_value = 0
        self._token_estimate_cache_time = 0.0
        self._auto_context_compaction_active = False
        self._auto_context_compaction_retry_after = 0.0
        self._auto_context_rotation_active = False
        self._auto_context_rotation_retry_after = 0.0
        self._last_context_safety_signature = None
        self.system_prompt = build_system_prompt(
            model_name=self.model_display_name,
            model_id=self.model,
            additional_rules=self.additional_rules,
            mode=self.mode,
            config=self.config,
            runtime_surface=self.runtime_surface,
        )
    
    @staticmethod
    def _fix_proxy_url(url_str: Optional[str]) -> Optional[str]:
        if not url_str:
            return url_str
        url_str = url_str.strip()
        if url_str.startswith("socks://"):
            return "socks5://" + url_str[len("socks://"):]
        return url_str

    def _build_proxied_http_client(self) -> Any:
        config = getattr(self, "config", None)
        configured_proxy = getattr(config, "api_proxy", "") if config is not None else ""
        if not normalize_proxy_url(configured_proxy) and urlsplit(str(getattr(self, "base_url", "") or "")).hostname in {"localhost", "127.0.0.1", "::1"}:
            return provider_client()
        proxy_val = resolve_proxy_url(configured_proxy)
        if proxy_val:
            proxy_val = self._fix_proxy_url(proxy_val)
            try:
                return provider_client(proxy=proxy_val)
            except Exception:
                report_suppressed_exception("create provider proxy client", logger=logger)
        return provider_client()

    def _init_client(self) -> None:
        """Initialize client based on provider"""
        self._client = None
        if self.provider in {"openai-chat", "openai-responses"}:
            try:
                from openai import OpenAI
                sdk_base_url = str(self.base_url or "").strip().rstrip("/")
                if self.provider == "openai-responses" and sdk_base_url.lower().endswith("/responses"):
                    sdk_base_url = sdk_base_url[: -len("/responses")]
                client_kwargs: Dict[str, Any] = {
                    "base_url": sdk_base_url,
                    "api_key": self.api_key,
                    "timeout": self._resolve_provider_timeout(),
                    "max_retries": 0,
                }
                http_client = self._build_proxied_http_client()
                if http_client is not None:
                    client_kwargs["http_client"] = http_client
                client_kwargs["default_headers"] = apply_reverie_client_identity(self.custom_headers)
                optional_kwargs = ("default_headers", "timeout", "http_client", "max_retries")
                while True:
                    try:
                        self._client = OpenAI(**client_kwargs)
                        break
                    except TypeError:
                        # Backward compatibility for OpenAI SDK versions without
                        # newer optional kwargs.
                        removed = False
                        for optional_key in optional_kwargs:
                            if optional_key in client_kwargs:
                                client_kwargs.pop(optional_key, None)
                                removed = True
                                break
                        if not removed:
                            raise
            except ImportError:
                raise ImportError(
                    "OpenAI SDK not installed. Run: pip install openai"
                )
        elif self.provider == "anthropic":
            try:
                import anthropic
                client_kwargs: Dict[str, Any] = {
                    "base_url": self.base_url if self.base_url else None,
                    "timeout": self._resolve_provider_timeout(),
                    "http_client": self._build_proxied_http_client(),
                    "max_retries": 0,
                }
                if self._is_active_model_source("sensenova"):
                    client_kwargs["auth_token"] = self.api_key
                else:
                    client_kwargs["api_key"] = self.api_key
                # OpenCode's Claude/Qwen models expect the official client's
                # identity, so Reverie's own header is suppressed for that source.
                client_kwargs["default_headers"] = apply_reverie_client_identity(
                    self.custom_headers,
                    include_identity=not self._is_active_model_source("opencode"),
                )
                try:
                    self._client = anthropic.Anthropic(**client_kwargs)
                except TypeError:
                    if "auth_token" in client_kwargs:
                        client_kwargs["api_key"] = client_kwargs.pop("auth_token")
                        headers = dict(client_kwargs.get("default_headers") or {})
                        headers["Authorization"] = f"Bearer {self.api_key}"
                        client_kwargs["default_headers"] = headers
                    client_kwargs.pop("timeout", None)
                    self._client = anthropic.Anthropic(**client_kwargs)
            except ImportError:
                raise ImportError(
                    "Anthropic SDK not installed. Run: pip install anthropic"
                )
        elif self.provider in {"request", "curl"}:
            # For request provider, we don't need a client object
            # We'll use requests library directly
            self._client = None
        elif self.provider in ("codex", "webgemini"):
            self._client = None
        else:
            raise ValueError(
                f"Unknown provider: {self.provider}. "
                f"Supported providers: openai-chat, openai-responses, request, curl, anthropic, codex, webgemini"
            )
        self._client_config_key = self._provider_client_key()

    def _provider_client_key(self) -> tuple[Any, ...]:
        """Return the settings that define the reusable SDK client."""
        return (
            self.provider,
            self.base_url,
            self.api_key,
            self._resolve_provider_timeout(),
            tuple(sorted((self.custom_headers or {}).items())),
            normalize_proxy_url(getattr(getattr(self, "config", None), "api_proxy", "")),
        )

    def _ensure_client(self) -> Any:
        """Create the SDK client only when a model call actually needs it."""
        if self.provider not in {"openai-chat", "openai-responses", "anthropic"}:
            return None
        client_key = self._provider_client_key()
        if self._client is None or self._client_config_key != client_key:
            self._init_client()
        return self._client

    def _should_use_openai_http_fallback(self) -> bool:
        """
        Whether to route openai-sdk requests through the request-provider path.

        This is used for endpoint override scenarios to mimic GCMP's per-model
        endpoint replacement behavior.
        """
        if self.provider != "openai-chat":
            return False

        # The SDK requires credentials at construction even for anonymous
        # gateways. Our Chat HTTP path sends no invented key or bearer token.
        if not str(self.api_key or "").strip():
            return True

        if self._is_active_model_source("opencode"):
            return True

        if (
            self._is_active_model_source("sensenova")
            and normalize_mode(self.mode) == "writer"
            and self._writer_should_hide_tools_for_direct_prose()
        ):
            return True

        endpoint = str(self.endpoint or "").strip()
        if endpoint:
            return True

        base_url = str(self.base_url or "").strip().lower()
        return base_url.endswith("/chat/completions")

    def _resolve_openai_request_url(self) -> str:
        """Resolve OpenAI-compatible request URL with optional endpoint override."""
        endpoint = str(self.endpoint or "").strip()
        base_url = str(self.base_url or "").strip().rstrip("/")

        if endpoint:
            if endpoint.startswith("http://") or endpoint.startswith("https://"):
                return endpoint
            if not base_url:
                return endpoint
            if endpoint.startswith("/"):
                return f"{base_url}{endpoint}"
            return f"{base_url}/{endpoint}"

        if not base_url:
            return ""

        if base_url.lower().endswith("/chat/completions"):
            return base_url

        return f"{base_url}/chat/completions"

    def _resolve_curl_url(self) -> str:
        """Resolve a curl endpoint, defaulting bare API roots to chat completions."""
        endpoint = str(self.endpoint or "").strip()
        base_url = str(self.base_url or "").strip().rstrip("/")
        if endpoint:
            if endpoint.startswith(("http://", "https://")):
                return endpoint
            return f"{base_url}/{endpoint.lstrip('/')}" if base_url else endpoint
        lowered = base_url.lower()
        if lowered.endswith(("/responses", "/chat/completions")):
            return base_url
        return f"{base_url}/chat/completions" if base_url else ""

    def _curl_uses_responses(self) -> bool:
        """Whether the configured curl URL targets the Responses API."""
        return self._resolve_curl_url().lower().rstrip("/").endswith("/responses")

    def _process_streaming_openai_http_fallback(self, session_id: str = "default") -> Generator[str, None, None]:
        """
        OpenAI-compatible HTTP fallback path.

        Reuses request-provider logic while allowing exact endpoint override URL.
        """
        request_url = self._resolve_openai_request_url()
        if not request_url:
            raise ValueError("OpenAI-compatible request URL is empty")

        original_provider = self.provider
        original_base_url = self.base_url
        original_endpoint = self.endpoint
        original_flag = self._openai_request_fallback_active
        try:
            self.provider = "request"
            self.base_url = request_url
            self.endpoint = ""
            self._openai_request_fallback_active = True
            yield from self._process_streaming_request(session_id=session_id)
        finally:
            self.provider = original_provider
            self.base_url = original_base_url
            self.endpoint = original_endpoint
            self._openai_request_fallback_active = original_flag

    def _process_non_streaming_openai_http_fallback(self, session_id: str = "default") -> str:
        """Non-streaming OpenAI-compatible HTTP fallback path."""
        request_url = self._resolve_openai_request_url()
        if not request_url:
            raise ValueError("OpenAI-compatible request URL is empty")

        original_provider = self.provider
        original_base_url = self.base_url
        original_endpoint = self.endpoint
        original_flag = self._openai_request_fallback_active
        try:
            self.provider = "request"
            self.base_url = request_url
            self.endpoint = ""
            self._openai_request_fallback_active = True
            return self._process_non_streaming_request(session_id=session_id)
        finally:
            self.provider = original_provider
            self.base_url = original_base_url
            self.endpoint = original_endpoint
            self._openai_request_fallback_active = original_flag

    def _is_active_model_source(self, source_name: str) -> bool:
        """Whether the current config says this agent is using a specific external source."""
        config = getattr(self, "config", None)
        if not config:
            return False
        active_source = str(getattr(config, "active_model_source", "") or "").strip().lower()
        return active_source == str(source_name or "").strip().lower()

    def _is_nvidia_request(self) -> bool:
        """Whether current request-provider config targets the NVIDIA endpoint."""
        if self.provider != "request":
            return False
        base_url = str(self.base_url or "").strip().lower()
        return "integrate.api.nvidia.com" in base_url and "/chat/completions" in base_url

    def _resolve_provider_timeout(self) -> int:
        """Resolve effective timeout with provider-specific overrides."""
        timeout_value = int(self.api_timeout or 60)

        config = getattr(self, "config", None)
        if not config:
            return timeout_value

        if self.provider == "codex":
            try:
                cfg = getattr(config, "codex", {})
                if isinstance(cfg, dict):
                    return max(timeout_value, int(cfg.get("timeout", timeout_value)))
            except Exception:
                return timeout_value

        if self.provider == "webgemini" or self._is_active_model_source("webgemini"):
            try:
                cfg = getattr(config, "webgemini", {})
                if isinstance(cfg, dict):
                    return max(timeout_value, int(cfg.get("timeout", timeout_value)))
            except Exception:
                return timeout_value

        if self._is_nvidia_request() or self._is_active_model_source("nvidia"):
            try:
                cfg = getattr(config, "nvidia", {})
                if isinstance(cfg, dict):
                    provider_timeout = int(cfg.get("timeout", timeout_value))
                    # Older NVIDIA configs persisted 300s as the implicit
                    # default, which made global /setting timeout ineffective.
                    if provider_timeout == 300:
                        return timeout_value
                    return max(1, provider_timeout)
            except Exception:
                return timeout_value

        if self._is_active_model_source("modelscope") and self.provider in ("openai-chat", "anthropic"):
            try:
                cfg = getattr(config, "modelscope", {})
                if isinstance(cfg, dict):
                    return max(timeout_value, int(cfg.get("timeout", timeout_value)))
            except Exception:
                return timeout_value

        if self._is_active_model_source("aihubmix") and self.provider == "openai-chat":
            try:
                cfg = getattr(config, "aihubmix", {})
                if isinstance(cfg, dict):
                    return max(timeout_value, int(cfg.get("timeout", timeout_value)))
            except Exception:
                return timeout_value

        if self._is_active_model_source("opencode") and self.provider in (
            "openai-chat",
            "openai-responses",
            "anthropic",
            "request",
        ):
            try:
                cfg = getattr(config, "opencode", {})
                if isinstance(cfg, dict):
                    return max(timeout_value, int(cfg.get("timeout", timeout_value)))
            except Exception:
                return timeout_value

        if self._is_active_model_source("agnes") and self.provider == "openai-chat":
            try:
                cfg = getattr(config, "agnes", {})
                if isinstance(cfg, dict):
                    return max(timeout_value, int(cfg.get("timeout", timeout_value)))
            except Exception:
                return timeout_value

        if self._is_active_model_source("sensenova") and self.provider in ("anthropic", "openai-chat"):
            try:
                cfg = getattr(config, "sensenova", {})
                if isinstance(cfg, dict):
                    return max(timeout_value, int(cfg.get("timeout", timeout_value)))
            except Exception:
                return timeout_value

        if self._is_active_model_source("custom"):
            try:
                from ..custom_providers import resolve_active_custom_provider

                record = resolve_active_custom_provider(getattr(config, "custom_providers", {}))
                if record:
                    return max(timeout_value, int(record.get("timeout", timeout_value)))
            except Exception:
                return timeout_value

        return timeout_value

    def _build_request_headers(self, stream: bool, session_id: str = "default") -> Dict[str, str]:
        """Build HTTP headers for the request provider."""
        headers = {
            "Content-Type": "application/json",
        }
        if str(self.api_key or "").strip():
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.custom_headers:
            headers.update(self.custom_headers)
        is_opencode = self._is_active_model_source("opencode")
        if is_opencode:
            headers.update(build_opencode_request_headers_from_config(
                getattr(self.config, "opencode", {}), session_id=session_id))
        if "Accept" not in headers:
            headers["Accept"] = "text/event-stream" if stream else "application/json"
        # OpenCode requests must look like the official client, so Reverie's own
        # identity header is suppressed for that source only.
        return apply_reverie_client_identity(headers, include_identity=not is_opencode)

    def _make_direct_request(self, payload: Dict[str, Any], *, stream: bool, session_id: str = "default") -> Any:
        """Execute a basic JSON POST through requests or the system curl binary."""
        effective_timeout = self._resolve_provider_timeout()
        headers = self._build_request_headers(stream=stream, session_id=session_id)
        if self.provider == "curl":
            url = self._resolve_curl_url()
            if not url:
                raise ValueError("curl request URL is empty")
            return _invoke_system_curl(
                url=url,
                headers=headers,
                payload=payload,
                stream=stream,
                timeout=effective_timeout,
                proxy=normalize_proxy_url(getattr(getattr(self, "config", None), "api_proxy", "")) or None,
            )

        configured_proxy = normalize_proxy_url(getattr(getattr(self, "config", None), "api_proxy", ""))
        request_url = self._resolve_openai_request_url() if self.provider == "openai-responses" else self.base_url
        return make_api_request_with_retry(
            url=request_url,
            headers=headers,
            payload=payload,
            max_retries=self.api_max_retries,
            initial_backoff=self.api_initial_backoff,
            stream=stream,
            timeout=effective_timeout,
            proxies=requests_proxy_dict(configured_proxy) if configured_proxy else None,
            on_retry=lambda delay, attempt, max_attempts, error: self._emit_api_retry_event(
                provider_label=self._request_provider_label(),
                model=payload.get("model", self.model),
                stream=stream,
                delay_seconds=delay,
                attempt=attempt,
                max_attempts=max_attempts,
                error=error,
            ),
        )

    def _prepare_request_payload(self, payload: Dict[str, Any], session_id: str = "default") -> Dict[str, Any]:
        """Prepare request-provider payload for the generic request or NVIDIA direct API."""
        prepared = dict(payload)
        if prepared.get("stream"):
            prepared["stream_options"] = {**(prepared.get("stream_options") or {}), "include_usage": True}
        if isinstance(prepared.get("messages"), list):
            prepared["messages"] = _coalesce_system_messages_to_front(
                _sanitize_messages_for_relay(
                    prepared["messages"],
                    preserve_assistant_reasoning=(
                        self._is_nvidia_request()
                        and nvidia_model_requires_preserved_reasoning_history(prepared.get("model"))
                    ),
                )
            )

        if self._openai_request_fallback_active:
            extra_body = prepared.pop("extra_body", None)
            if isinstance(extra_body, dict):
                prepared.update(extra_body)
            return apply_openai_prompt_cache(
                prepared,
                namespace="agent-chat",
                include_legacy_cache_prompt=True,
            )

        if self._is_nvidia_request():
            prepared = apply_nvidia_request_defaults(prepared, getattr(self.config, "nvidia", {}))
            if nvidia_model_requires_system_message_first(prepared.get("model")):
                prepared["messages"] = _coalesce_system_messages_to_front(prepared.get("messages", []))
            if not nvidia_model_allows_tools(prepared.get("model")):
                prepared = _strip_tooling_from_payload(prepared)
                if nvidia_model_requires_system_message_first(prepared.get("model")):
                    prepared["messages"] = _coalesce_system_messages_to_front(prepared.get("messages", []))
            prepared = self._clamp_nvidia_request_max_tokens(prepared)
            if prepared.get("stream"):
                prepared["stream_options"] = {**(prepared.get("stream_options") or {}), "include_usage": True}
            return apply_openai_prompt_cache(
                prepared,
                namespace="agent-chat",
                include_legacy_cache_prompt=True,
            )

        # Generic `request` provider: accept model(depth) but only convert to
        # a boolean `thinking` flag (do NOT forward thinking depth). Explicit
        # `self.thinking_mode` (config) takes precedence over model suffix.
        if self.provider == "request":
            if not (isinstance(self.thinking_mode, str) and self.thinking_mode.lower() in ["true", "false"]):
                model_name = str(prepared.get("model", "")).strip()
                if "(" in model_name and ")" in model_name:
                    base_model = model_name.split("(", 1)[0].strip()
                    suffix = model_name.split("(", 1)[1].split(")", 1)[0].strip().lower()
                    thinking_suffixes = {"auto", "low", "medium", "high", "xhigh", "minimal"}
                    if suffix in thinking_suffixes or suffix.isdigit():
                        prepared["model"] = base_model
                        chat_kwargs = prepared.get("chat_template_kwargs")
                        if not isinstance(chat_kwargs, dict):
                            chat_kwargs = {}
                            prepared["chat_template_kwargs"] = chat_kwargs
                        chat_kwargs["thinking"] = True
                    elif suffix in {"none", "0"}:
                        prepared["model"] = base_model
                        chat_kwargs = prepared.get("chat_template_kwargs")
                        if not isinstance(chat_kwargs, dict):
                            chat_kwargs = {}
                            prepared["chat_template_kwargs"] = chat_kwargs
                        chat_kwargs["thinking"] = False

        # Explicit thinking_mode from config takes precedence
        if self.thinking_mode and self.thinking_mode.lower() in ["true", "false"]:
            chat_kwargs = prepared.get("chat_template_kwargs")
            if not isinstance(chat_kwargs, dict):
                chat_kwargs = {}
                prepared["chat_template_kwargs"] = chat_kwargs
                chat_kwargs["thinking"] = self.thinking_mode.lower() == "true"
        
        return apply_openai_prompt_cache(
            prepared,
            namespace="agent-chat",
            include_legacy_cache_prompt=True,
        )

    def _estimate_request_input_tokens(
        self,
        *,
        messages: Optional[List[Dict[str, Any]]] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> int:
        """Estimate provider-counted input tokens for messages plus tool schemas."""
        normalized_messages = list(messages or [])
        workspace_stats_manager = self.tool_executor.context.get("workspace_stats_manager")
        if workspace_stats_manager and hasattr(workspace_stats_manager, "count_messages_tokens"):
            try:
                total = max(int(workspace_stats_manager.count_messages_tokens(normalized_messages)), 0)
            except Exception:
                total = 0
        else:
            total = 0

        if total <= 0:
            try:
                total = max(
                    len(
                        json.dumps(
                            normalized_messages,
                            ensure_ascii=False,
                            separators=(",", ":"),
                        )
                    )
                    // 4,
                    0,
                )
            except Exception:
                total = sum(len(_coerce_text_fragments(message.get("content"))) for message in normalized_messages) // 4

        if tools:
            try:
                total += len(json.dumps(tools, ensure_ascii=False, separators=(",", ":"))) // 4
            except Exception:
                total += len(str(tools)) // 4
        return max(total, 0)

    def _resolve_nvidia_context_window(self, model_id: Any) -> int:
        metadata = get_nvidia_model_metadata(model_id)
        if metadata:
            try:
                value = int(metadata.get("context_length") or 0)
                if value > 0:
                    return value
            except (TypeError, ValueError):
                pass
        return self._resolve_max_context_tokens()

    def _clamp_nvidia_max_tokens_value(
        self,
        *,
        model_id: Any,
        requested_max_tokens: Any,
        messages: Optional[List[Dict[str, Any]]] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> int:
        """Keep NVIDIA max_tokens within context after current input and tools."""
        context_window = max(int(self._resolve_nvidia_context_window(model_id) or 0), 1)
        try:
            requested = int(requested_max_tokens or 0)
        except (TypeError, ValueError):
            requested = 0
        if requested <= 0:
            requested = context_window

        input_tokens = self._estimate_request_input_tokens(messages=messages, tools=tools)
        reserve = max(1024, min(8192, context_window // 32))
        available = context_window - input_tokens - reserve
        if available <= 0:
            return 1024
        return max(1, min(requested, available))

    def _clamp_nvidia_request_max_tokens(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        prepared = dict(payload or {})
        prepared["max_tokens"] = self._clamp_nvidia_max_tokens_value(
            model_id=prepared.get("model", self.model),
            requested_max_tokens=prepared.get("max_tokens"),
            messages=prepared.get("messages") if isinstance(prepared.get("messages"), list) else None,
            tools=prepared.get("tools") if isinstance(prepared.get("tools"), list) else None,
        )
        return prepared

    def _clamp_nvidia_options_for_messages(
        self,
        options: Dict[str, Any],
        *,
        model_id: Any,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        if not options:
            return options
        clamped = dict(options)
        clamped["max_tokens"] = self._clamp_nvidia_max_tokens_value(
            model_id=model_id,
            requested_max_tokens=clamped.get("max_tokens"),
            messages=messages,
            tools=tools,
        )
        return clamped

    def get_visible_tool_schemas(self, mode: Optional[str] = None) -> List[Dict[str, Any]]:
        """Return the tool schemas that the current model/provider can actually receive."""
        tool_executor = getattr(self, "tool_executor", None)
        if not tool_executor:
            return []

        effective_mode = mode or self.mode or "reverie"
        if effective_mode == "writer" and self._writer_should_hide_tools_for_direct_prose():
            return []
        schemas = tool_executor.get_tool_schemas(mode=effective_mode)
        if tool_executor.context.get("desktop_read_only_review"):
            schemas = [schema for schema in schemas if str((schema.get("function") or {}).get("name")) in {"file_ops", "read_file", "list_dir", "str_replace_editor", "codebase-retrieval"}]
        if not schemas:
            return []

        latest_prompt_reader = getattr(self, "_latest_user_prompt_text", None)
        latest_prompt = latest_prompt_reader() if callable(latest_prompt_reader) else ""
        if _should_hide_memory_tools_for_prompt(latest_prompt):
            schemas = [
                schema
                for schema in schemas
                if str(((schema or {}).get("function") or {}).get("name") or "").strip()
                not in _MEMORY_TOOL_NAMES
            ]

        if (
            self._is_active_model_source("nvidia")
            or self._is_nvidia_request()
        ) and not nvidia_model_allows_tools(self.model):
            return []

        if getattr(self, "_think_tool_suppressed", False):
            # The spin guard tripped this turn: stop advertising deep_think so the
            # model cannot keep choosing it instead of doing the work.
            schemas = [
                schema
                for schema in schemas
                if not is_think_tool(((schema or {}).get("function") or {}).get("name"))
            ]

        return schemas

    def _writer_should_hide_tools_for_direct_prose(self) -> bool:
        """Hide tools after Writer has prepared a chapter so the model drafts prose instead of empty tool calls."""
        if normalize_mode(self.mode) != "writer":
            return False

        active_project = self._writer_active_project_state()
        if not active_project or bool(active_project.get("pending_requires_reprepare")):
            return False

        latest_action = self._writer_latest_turn_serial_novel_action()
        return latest_action in {"prepare_chapter", "context"}

    def _writer_native_tool_choice(self) -> Optional[Dict[str, Any]]:
        """Require Writer's native project tool for the first novel action in a turn."""
        if normalize_mode(self.mode) != "writer":
            return None

        last_user_index, user_text = self._writer_latest_user_turn()
        if last_user_index < 0:
            return None

        active_project = self._writer_active_project_state()
        latest_action = self._writer_latest_turn_serial_novel_action()
        serial_novel_called_this_turn = bool(latest_action)
        novel_signals = (
            "novel",
            "serialized fiction",
            "serial fiction",
            "long-form fiction",
            "continue",
            "小说",
            "长篇",
            "连载",
            "继续",
            "续写",
            "继续写",
            "下一章",
            "网文",
        )
        if not active_project and not any(signal in user_text for signal in novel_signals):
            return None
        if active_project:
            if (
                str(active_project.get("pending_recovery_mode") or "").strip()
                == PENDING_RECOVERY_APPEND_ONLY
                and not bool(active_project.get("pending_requires_reprepare"))
            ):
                return None
            if bool(active_project.get("active_chapter_has_control_card")):
                if latest_action in {"prepare_chapter", "context"}:
                    return None
                if serial_novel_called_this_turn:
                    return None
                return {"type": "function", "function": {"name": "serial_novel"}}
            if latest_action in {"prepare_chapter", "context"}:
                return None
            return {"type": "function", "function": {"name": "serial_novel"}}

        if serial_novel_called_this_turn:
            if latest_action == "commit_chapter":
                return {"type": "function", "function": {"name": "serial_novel"}}
            return None
        return {"type": "function", "function": {"name": "serial_novel"}}

    def _context_engine_native_tool_choice(
        self,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Require one Context Engine lookup for high-confidence repository turns."""
        if normalize_mode(self.mode) in {"writer", "computer-controller"}:
            return None
        available_names = {
            str((schema.get("function", {}) or {}).get("name", "") or "").strip()
            for schema in (tools or [])
            if isinstance(schema, dict)
        }
        if "codebase-retrieval" not in available_names:
            return None

        last_user_index, user_text = self._writer_latest_user_turn()
        if last_user_index < 0 or not user_text:
            return None
        if (
            "render_view" in user_text
            and "create_file" in user_text
            and re.search(
                r"(?:only\s+(?:use|call)\s+(?:the\s+)?|"
                r"(?:仅|只)(?:允许|使用|用|调用)\s*(?:当前工作区的\s*)?)`?(?:create_file|render_view)\b",
                user_text,
            )
        ):
            # Negative file instructions still contain words such as "files"
            # and "update". Do not force a third tool into a scoped view task.
            return None
        direct_memory_request = re.match(
            r"^(?:please\s+|请\s*)?(?:"
            r"(?:call|invoke|use|调用|使用|用)\s*`?memory_(?:manager|retrieval)\b|"
            r"(?:correct|update|delete|forget|修改|更新|删除|忘记)\s*(?:the\s+)?"
            r"(?:memory\b|记忆)\s*[:：`]?\s*mem_[a-z0-9_]+\b)",
            user_text,
        )
        if direct_memory_request:
            return None
        if any(
            phrase in user_text
            for phrase in (
                "do not use tools",
                "don't use tools",
                "without tools",
                "不要调用工具",
                "不要使用工具",
                "无需查看代码",
            )
        ):
            return None

        context_tool_names = {"codebase-retrieval", "codebase_retrieval", "retrieve_codebase", "repo_context"}
        for message in self.messages[last_user_index + 1 :]:
            for tool_call in message.get("tool_calls", []) if isinstance(message.get("tool_calls"), list) else []:
                function = tool_call.get("function", {}) if isinstance(tool_call, dict) else {}
                if str(function.get("name", "") or "").strip() in context_tool_names:
                    return None

        strong_repository_signals = (
            "codebase", "repository", " repo", "source code", "context engine", "file", "module",
            "github", "git ", "代码", "仓库", "项目", "文件", "模块", "上下文引擎",
        )
        broad_code_signals = (
            "class", "function", "method", "api", "config", "test", "build", "bug", "frontend",
            "backend", "electron", "react", "python", "typescript", "函数", "类", "接口", "配置",
            "测试", "编译", "构建", "前端", "后端",
        )
        implementation_signals = (
            "implement", "fix", "change", "update", "refactor", "optimize", "debug", "review",
            "add", "remove", "migrate", "修改", "修复", "更新", "重构", "优化", "调试", "审查",
            "实现", "添加", "删除", "迁移", "强化",
        )
        repository_question_signals = implementation_signals + (
            "inspect", "analyze", "explain", "find", "where", "why",
            "检查", "分析", "解释", "查找", "哪里", "为什么",
        )
        explicit_path = bool(
            re.search(r"[\w./\\-]+\.(?:py|ts|tsx|js|jsx|css|html|json|yaml|yml|toml|md|rs|go|java|cpp|h)\b", user_text)
        )
        strong_repository_turn = any(signal in user_text for signal in strong_repository_signals) and any(
            signal in user_text for signal in repository_question_signals
        )
        implementation_turn = any(signal in user_text for signal in broad_code_signals) and any(
            signal in user_text for signal in implementation_signals
        )
        path_inspection_turn = explicit_path and any(signal in user_text for signal in repository_question_signals)
        if not (path_inspection_turn or strong_repository_turn or implementation_turn):
            return None
        return {"type": "function", "function": {"name": "codebase-retrieval"}}

    def _native_tool_choice(
        self,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Resolve the single native tool that should lead the current turn."""
        return self._writer_native_tool_choice() or self._context_engine_native_tool_choice(tools)

    def _anthropic_tool_choice(
        self,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Optional[Dict[str, str]]:
        """Translate the current native tool choice into Anthropic's schema."""
        choice = self._native_tool_choice(tools)
        if not choice:
            return None
        name = str((choice.get("function", {}) or {}).get("name", "") or "").strip()
        return {"type": "tool", "name": name} if name else None

    def _writer_latest_user_turn(self) -> tuple[int, str]:
        """Return the latest user-message index plus flattened text for Writer turn analysis."""
        for index in range(len(self.messages) - 1, -1, -1):
            message = self.messages[index]
            if str(message.get("role", "") or "").strip().lower() != "user":
                continue
            return index, _coerce_text_fragments(message.get("content", "")).lower()
        return -1, ""

    def _writer_latest_turn_serial_novel_action(self) -> str:
        """Return the last Writer-native action issued after the most recent user message."""
        if normalize_mode(self.mode) != "writer":
            return ""

        last_user_index, _ = self._writer_latest_user_turn()
        if last_user_index < 0:
            return ""

        latest_action = ""
        for message in self.messages[last_user_index + 1 :]:
            tool_calls = message.get("tool_calls", []) if isinstance(message.get("tool_calls"), list) else []
            for tool_call in tool_calls:
                function = tool_call.get("function", {}) if isinstance(tool_call, dict) else {}
                if str(function.get("name", "") or "").strip() != "serial_novel":
                    continue
                arguments = parse_tool_arguments(function.get("arguments", ""))
                latest_action = str(arguments.get("action", "") or "").strip().lower()
        return latest_action

    def _writer_latest_turn_serial_novel_id(self) -> str:
        """Return the most recent Writer-native novel_id issued after the latest user message."""
        if normalize_mode(self.mode) != "writer":
            return ""

        last_user_index, _ = self._writer_latest_user_turn()
        if last_user_index < 0:
            return ""

        latest_novel_id = ""
        for message in self.messages[last_user_index + 1 :]:
            tool_calls = message.get("tool_calls", []) if isinstance(message.get("tool_calls"), list) else []
            for tool_call in tool_calls:
                function = tool_call.get("function", {}) if isinstance(tool_call, dict) else {}
                if str(function.get("name", "") or "").strip() != "serial_novel":
                    continue
                arguments = parse_tool_arguments(function.get("arguments", ""))
                novel_id = str(arguments.get("novel_id", "") or "").strip()
                if novel_id:
                    latest_novel_id = novel_id
        return latest_novel_id

    def _writer_active_project_state(self) -> Optional[Dict[str, Any]]:
        """Return the single active Writer project with a prepared chapter, if one exists."""
        if normalize_mode(self.mode) != "writer":
            return None

        root = self.project_root / DEFAULT_OUTPUT_DIR
        if not root.is_dir():
            return None

        candidates: List[Dict[str, Any]] = []
        for state_path in sorted(root.glob("*/tracking/state.json")):
            try:
                state = json.loads(state_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError, TypeError, ValueError):
                continue
            if not isinstance(state, dict):
                continue
            if state.get("schema") != STATE_SCHEMA or state.get("status") == "complete":
                continue

            novel_id = str(state.get("novel_id", "") or "").strip()
            if not novel_id:
                continue
            try:
                active_chapter = int(state.get("active_chapter") or 0)
            except (TypeError, ValueError):
                active_chapter = 0
            if active_chapter < 1:
                continue
            project_dir = state_path.parent.parent
            active_card_path = project_dir / "control-cards" / f"chapter-{active_chapter:04d}.json"
            pending_recovery_mode = ""
            pending_requires_reprepare = False
            pending_recommended_append_chars = 0
            pending_draft_path = project_dir / "drafts" / f"chapter-{active_chapter:04d}.json"
            if pending_draft_path.is_file():
                try:
                    pending_draft = json.loads(pending_draft_path.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError, TypeError, ValueError):
                    pending_draft = None
                if isinstance(pending_draft, dict):
                    pending_recovery_mode = str(pending_draft.get("recovery_mode") or "").strip()
                    pending_requires_reprepare = bool(pending_draft.get("requires_reprepare"))
                    try:
                        pending_recommended_append_chars = int(
                            pending_draft.get("recommended_append_chars") or 0
                        )
                    except (TypeError, ValueError):
                        pending_recommended_append_chars = 0

            candidates.append(
                {
                    "novel_id": novel_id,
                    "active_chapter": active_chapter,
                    "project_dir": project_dir,
                    "active_chapter_has_control_card": active_card_path.is_file(),
                    "pending_draft_path": pending_draft_path if pending_draft_path.is_file() else None,
                    "pending_recovery_mode": pending_recovery_mode,
                    "pending_requires_reprepare": pending_requires_reprepare,
                    "pending_recommended_append_chars": pending_recommended_append_chars,
                }
            )

        if len(candidates) == 1:
            return candidates[0]

        latest_novel_id = self._writer_latest_turn_serial_novel_id()
        if latest_novel_id:
            for candidate in candidates:
                if candidate.get("novel_id") == latest_novel_id:
                    return candidate

        return None

    @staticmethod
    def _writer_normalize_direct_chapter_draft(content: str) -> str:
        """Strip a model-added chapter heading before auto-committing raw prose."""
        text = str(content or "").strip()
        if not text:
            return ""
        lines = text.splitlines()
        if not lines:
            return text

        first_line = re.sub(r"^#+\s*", "", lines[0]).strip()
        if re.match(
            r"^(?:第\s*[一二三四五六七八九十百零〇\d]+\s*[章节回卷集].*|chapter\s*\d+.*)$",
            first_line,
            flags=re.IGNORECASE,
        ):
            remainder = "\n".join(lines[1:]).lstrip()
            if remainder:
                return remainder.strip()
        return text

    @staticmethod
    def _writer_count_non_whitespace_chars(content: str) -> int:
        return sum(1 for char in str(content or "") if not char.isspace())

    def _writer_pending_draft_content(self, active_project: Dict[str, Any]) -> str:
        """Load the currently preserved Writer draft, if one exists."""
        if not isinstance(active_project, dict):
            return ""

        pending_draft_path = active_project.get("pending_draft_path")
        if not isinstance(pending_draft_path, Path) or not pending_draft_path.is_file():
            return ""

        try:
            pending_draft = json.loads(pending_draft_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, TypeError, ValueError):
            return ""
        if not isinstance(pending_draft, dict):
            return ""
        data = pending_draft.get("data")
        if isinstance(data, dict):
            return str(data.get("content") or "").strip()
        return str(pending_draft.get("content") or "").strip()

    def _writer_trim_append_only_direct_prose(
        self,
        active_project: Dict[str, Any],
        content: str,
    ) -> str:
        """Drop any preserved-tail overlap before auto-submitting append-only prose."""
        normalized = self._writer_normalize_direct_chapter_draft(content)
        if not normalized or not isinstance(active_project, dict):
            return normalized

        if (
            str(active_project.get("pending_recovery_mode") or "").strip()
            != PENDING_RECOVERY_APPEND_ONLY
            or bool(active_project.get("pending_requires_reprepare"))
        ):
            return normalized

        prior_content = self._writer_pending_draft_content(active_project)
        if not prior_content:
            return normalized

        try:
            trimmed = SerialNovelTool._trim_append_only_overlap(prior_content, normalized)
        except Exception:
            logger.debug("Failed to trim Writer append-only overlap", exc_info=True)
            return normalized
        return str(trimmed or "").strip()

    def _writer_direct_prose_autocommit_min_chars(self, active_project: Dict[str, Any]) -> int:
        """Use a smaller floor for append-only recovery so short valid continuations still commit."""
        if (
            isinstance(active_project, dict)
            and str(active_project.get("pending_recovery_mode") or "").strip() == PENDING_RECOVERY_APPEND_ONLY
            and not bool(active_project.get("pending_requires_reprepare"))
        ):
            return 80
        return 500

    @staticmethod
    def _writer_commit_call_has_prose(arguments: Dict[str, Any]) -> bool:
        """Whether a Writer commit_chapter payload actually contains prose to commit."""
        if str(arguments.get("action", "") or "").strip().lower() != "commit_chapter":
            return False

        data = arguments.get("data")
        if isinstance(data, str) and data.strip():
            parsed = parse_tool_arguments(data)
            data = parsed if isinstance(parsed, dict) else {}
        if not isinstance(data, dict):
            data = {}

        return bool(
            str(data.get("content") or "").strip()
            or str(data.get("append_content") or "").strip()
        )

    def _writer_retry_instruction_for_invalid_commit_tool_call(
        self,
        tool_calls: List[Dict[str, Any]],
    ) -> str:
        """Turn metadata-only Writer commit calls back into plain-prose drafting retries."""
        if normalize_mode(self.mode) != "writer" or len(tool_calls) != 1:
            return ""

        function = (tool_calls[0].get("function") or {}) if isinstance(tool_calls[0], dict) else {}
        if str(function.get("name", "") or "").strip() != "serial_novel":
            return ""

        arguments = parse_tool_arguments(function.get("arguments", ""))
        if not isinstance(arguments, dict):
            return ""
        if str(arguments.get("action", "") or "").strip().lower() != "commit_chapter":
            return ""
        if self._writer_commit_call_has_prose(arguments):
            return ""

        active_project = self._writer_active_project_state()
        if not active_project or not bool(active_project.get("active_chapter_has_control_card")):
            return ""
        if bool(active_project.get("pending_requires_reprepare")):
            return ""

        target_novel_id = str(arguments.get("novel_id", "") or "").strip()
        if target_novel_id and target_novel_id != str(active_project.get("novel_id", "") or "").strip():
            return ""
        try:
            target_chapter = int(arguments.get("chapter") or 0)
        except (TypeError, ValueError):
            target_chapter = 0
        if target_chapter and target_chapter != int(active_project.get("active_chapter") or 0):
            return ""

        if str(active_project.get("pending_recovery_mode") or "").strip() == PENDING_RECOVERY_APPEND_ONLY:
            return (
                "Writer correction: a preserved draft tail already exists for the current chapter. "
                "Do not emit JSON, XML, summaries, or serial_novel calls. "
                "Write only the missing continuation in plain text starting immediately after the preserved tail. "
                "Do not repeat preserved paragraphs. The client will send it as data.append_content automatically."
            )

        return (
            "Writer correction: the current chapter control card is already prepared. "
            "Do not emit JSON, XML, summaries, or serial_novel calls. "
            "Write only the chapter prose in plain text for the current chapter. "
            "The client will commit it automatically after the prose is complete."
        )

    def _writer_retry_instruction_for_short_direct_prose(self, content: str) -> str:
        """Keep Writer recovery inside the same turn when direct prose is too short or repeats the tail."""
        if normalize_mode(self.mode) != "writer":
            return ""

        raw_content = str(content or "").strip()
        if not raw_content:
            return ""

        active_project = self._writer_active_project_state()
        if not active_project or not bool(active_project.get("active_chapter_has_control_card")):
            return ""
        if bool(active_project.get("pending_requires_reprepare")):
            return ""
        if self._writer_latest_turn_serial_novel_action() not in {"prepare_chapter", "context"}:
            return ""

        normalized_content = self._writer_trim_append_only_direct_prose(active_project, raw_content)
        min_chars = self._writer_direct_prose_autocommit_min_chars(active_project)
        if self._writer_count_non_whitespace_chars(normalized_content) >= min_chars:
            return ""

        novel_id = str(active_project.get("novel_id", "") or "").strip()
        try:
            active_chapter = int(active_project.get("active_chapter") or 0)
        except (TypeError, ValueError):
            active_chapter = 0

        scope_bits = []
        if novel_id:
            scope_bits.append(f"novel '{novel_id}'")
        if active_chapter > 0:
            scope_bits.append(f"chapter {active_chapter}")
        prefix = "Continue the active Writer request from the immediately preceding tool result. "
        if scope_bits:
            prefix = (
                "Continue the active Writer request from the immediately preceding tool result "
                f"for {', '.join(scope_bits)}. "
            )

        if str(active_project.get("pending_recovery_mode") or "").strip() == PENDING_RECOVERY_APPEND_ONLY:
            try:
                append_chars = int(active_project.get("pending_recommended_append_chars") or 0)
            except (TypeError, ValueError):
                append_chars = 0
            append_requirement = ""
            if append_chars > 0:
                append_requirement = f"Provide at least {append_chars} new non-whitespace characters. "
            if not normalized_content:
                return (
                    f"{prefix}"
                    "Your previous reply only repeated the preserved tail instead of adding new prose. "
                    "Write only the missing new chapter continuation in plain text starting immediately after the "
                    f"preserved tail shown in the tool result. {append_requirement}"
                    "Do not repeat preserved paragraphs, do not lightly paraphrase them, and do not emit "
                    "chapter headings, summaries, notes, JSON, XML, Markdown fences, or serial_novel/tool calls. "
                    "The client will submit your text as data.append_content automatically."
                )
            return (
                f"{prefix}"
                "Your previous reply was still too short to submit as append-only recovery. "
                "Write only the missing new chapter continuation in plain text starting immediately after the "
                f"preserved tail shown in the tool result. {append_requirement}"
                "Do not repeat preserved paragraphs, do not lightly paraphrase them, and do not emit "
                "chapter headings, summaries, notes, JSON, XML, Markdown fences, or serial_novel/tool calls. "
                "The client will submit your text as data.append_content automatically."
            )

        return (
            f"{prefix}"
            "The current chapter draft is not complete yet. Continue writing only the same chapter prose in plain "
            "text. Provide substantially more content, and do not emit chapter headings, summaries, notes, JSON, "
            "XML, Markdown fences, or serial_novel/tool calls. The client will commit the prose automatically after "
            "it is long enough."
        )

    def _append_internal_system_message(
        self,
        messages: List[Dict[str, Any]],
        content: str,
    ) -> None:
        """Append a deduplicated internal system reminder for the next continuation request."""
        instruction = str(content or "").strip()
        if not instruction:
            return

        def _append_once(target: List[Dict[str, Any]]) -> None:
            if target:
                last = target[-1]
                if (
                    str(last.get("role", "") or "").strip().lower() == "system"
                    and _coerce_text_fragments(last.get("content", "")).strip() == instruction
                ):
                    return
            target.append({"role": "system", "content": instruction})

        _append_once(self.messages)
        if messages is not self.messages:
            _append_once(messages)

    @staticmethod
    def _latest_tool_name_from_messages(messages: List[Dict[str, Any]]) -> str:
        """Resolve the function name for the most recent tool result in a message list."""
        if not messages:
            return ""
        last_message = messages[-1]
        if str(last_message.get("role", "") or "").strip().lower() != "tool":
            return ""

        target_tool_call_id = str(last_message.get("tool_call_id", "") or "").strip()
        for message in reversed(messages[:-1]):
            tool_calls = message.get("tool_calls", []) if isinstance(message.get("tool_calls"), list) else []
            if not tool_calls:
                continue
            for tool_call in tool_calls:
                if not isinstance(tool_call, dict):
                    continue
                if target_tool_call_id and str(tool_call.get("id", "") or "").strip() != target_tool_call_id:
                    continue
                function = tool_call.get("function", {}) if isinstance(tool_call.get("function"), dict) else {}
                return str(function.get("name", "") or "").strip()
        return ""

    def _writer_sensenova_tool_result_followup(self, messages: List[Dict[str, Any]]) -> str:
        """Return Writer-specific tool-result continuation guidance for SenseNova."""
        if normalize_mode(self.mode) != "writer":
            return ""
        if self._latest_tool_name_from_messages(messages) != "serial_novel":
            return ""

        active_project = self._writer_active_project_state()
        if not active_project:
            return ""

        latest_action = self._writer_latest_turn_serial_novel_action()
        novel_id = str(active_project.get("novel_id", "") or "").strip()
        try:
            active_chapter = int(active_project.get("active_chapter") or 0)
        except (TypeError, ValueError):
            active_chapter = 0

        scope_bits = []
        if novel_id:
            scope_bits.append(f"novel '{novel_id}'")
        if active_chapter > 0:
            scope_bits.append(f"chapter {active_chapter}")
        scope = ", ".join(scope_bits)
        prefix = "Continue the active Writer request from the immediately preceding tool result. "
        if scope:
            prefix = (
                "Continue the active Writer request from the immediately preceding tool result "
                f"for {scope}. "
            )

        if bool(active_project.get("pending_requires_reprepare")):
            return (
                f"{prefix}"
                "Fix the planning failure by calling serial_novel with action='prepare_chapter' and a materially "
                "revised outline/control card. Do not call commit_chapter yet, and do not draft chapter prose "
                "until prepare_chapter succeeds. Preserve the original user requirements."
            )

        if latest_action not in {"prepare_chapter", "context"}:
            return ""
        if not bool(active_project.get("active_chapter_has_control_card")):
            return ""

        if str(active_project.get("pending_recovery_mode") or "").strip() == PENDING_RECOVERY_APPEND_ONLY:
            try:
                append_chars = int(active_project.get("pending_recommended_append_chars") or 0)
            except (TypeError, ValueError):
                append_chars = 0
            append_requirement = ""
            if append_chars > 0:
                append_requirement = f"Provide at least {append_chars} new non-whitespace characters. "
            return (
                f"{prefix}"
                "Write only the missing new chapter prose in plain text. Start immediately after the preserved tail "
                f"shown in the tool result. {append_requirement}"
                "Do not repeat the preserved tail, do not lightly paraphrase it, and do not include chapter headings, "
                "summaries, notes, JSON, XML, Markdown fences, or serial_novel/tool calls. The client will submit "
                "your text as data.append_content automatically. Preserve the prepared control card, continuity, "
                "and original user requirements."
            )

        return (
            f"{prefix}"
            "The current chapter control card is already prepared. Write only the chapter prose in plain text for "
            "this chapter. Do not emit chapter headings, summaries, notes, JSON, XML, Markdown fences, or "
            "serial_novel/tool calls. Preserve the prepared control card, continuity, and original user "
            "requirements. The client will commit the prose automatically after it is complete."
        )

    def _writer_anthropic_tool_choice(self) -> Optional[Dict[str, str]]:
        """Translate Writer's required first tool into Anthropic tool-choice syntax."""
        choice = self._writer_native_tool_choice()
        if not choice:
            return None
        function = choice.get("function", {}) if isinstance(choice, dict) else {}
        name = str(function.get("name", "") or "").strip()
        return {"type": "tool", "name": name} if name else None

    def _latest_user_text(self) -> str:
        for message in reversed(self.messages):
            if str(message.get("role", "") or "").strip().lower() == "user":
                return _coerce_text_fragments(message.get("content", "")).strip()
        return ""

    def _writer_extract_textual_tool_call(self, raw: str) -> Optional[Dict[str, Any]]:
        """Parse Writer pseudo-tool XML-ish wrappers that some providers emit as plain text."""
        if normalize_mode(self.mode) != "writer":
            return None

        text = str(raw or "").strip()
        marker_index = text.lower().find("<tool_call>")
        if marker_index < 0:
            return None
        text = text[marker_index:]

        function_match = re.search(r"<function=([A-Za-z0-9_.-]+)>", text, flags=re.IGNORECASE)
        if not function_match:
            return None

        function_name = function_match.group(1).strip()
        if not function_name:
            return None

        arguments: Dict[str, Any] = {}
        for match in re.finditer(
            r"<parameter=([A-Za-z0-9_.-]+)>\s*(.*?)\s*</parameter>",
            text,
            flags=re.IGNORECASE | re.DOTALL,
        ):
            key = match.group(1).strip()
            value = match.group(2).strip()
            if not key:
                continue
            arguments[key] = value

        if not arguments:
            return None

        for key in ("chapter", "target_chars", "chapter_target_chars"):
            value = arguments.get(key)
            if not isinstance(value, str):
                continue
            try:
                arguments[key] = int(value.strip())
            except (TypeError, ValueError):
                continue

        data_value = arguments.get("data")
        if isinstance(data_value, str) and data_value.strip():
            parsed_data = parse_tool_arguments(data_value)
            if parsed_data:
                arguments["data"] = parsed_data

        return {
            "name": function_name,
            "arguments": arguments,
        }

    def _promote_writer_json_tool_call(self, state: _StreamingTurnState) -> bool:
        """Promote JSON text to a tool call for providers that ignore tool-call envelopes."""
        if state.tool_calls:
            return False
        raw = state.cleaned_content()
        if not raw:
            return False

        textual_tool_call = self._writer_extract_textual_tool_call(raw)
        if textual_tool_call and textual_tool_call.get("name") == "serial_novel":
            arguments = textual_tool_call.get("arguments")
            if isinstance(arguments, dict) and arguments:
                state.tool_calls = [
                    {
                        "id": f"writer_native_{uuid.uuid4().hex[:16]}",
                        "type": "function",
                        "function": {
                            "name": "serial_novel",
                            "arguments": json.dumps(arguments, ensure_ascii=False),
                        },
                    }
                ]
                state.collected_content = ""
                state.set_finish_reason("tool_calls")
                return True

        if not self._writer_native_tool_choice():
            return False

        fenced = re.sub(r"^\s*```(?:json)?\s*|\s*```\s*$", "", raw, flags=re.IGNORECASE).strip()
        start = fenced.find("{")
        end = fenced.rfind("}")
        if start < 0 or end <= start:
            return False
        try:
            arguments = json.loads(fenced[start : end + 1])
        except json.JSONDecodeError:
            arguments = parse_tool_arguments(fenced[start : end + 1])
        if not isinstance(arguments, dict) or not arguments:
            return False
        if isinstance(arguments.get("arguments"), dict):
            arguments = dict(arguments["arguments"])

        user_text = self._latest_user_text()
        action = str(arguments.get("action", "") or "").strip().lower() or "bootstrap"
        arguments["action"] = action
        if action == "bootstrap":
            arguments.setdefault("brief", user_text)
            if not str(arguments.get("novel_id", "") or "").strip():
                id_match = re.search(r"novel_id\s*(?:为|=|:)\s*([\w.-]+)", user_text, flags=re.IGNORECASE)
                arguments["novel_id"] = (
                    id_match.group(1)
                    if id_match
                    else f"novel-{hashlib.sha256(user_text.encode('utf-8')).hexdigest()[:10]}"
                )
            arguments.setdefault("title", "Untitled Novel")
            target_match = re.search(
                r"(\d[\d,]*)\s*(?:个)?(?:非空白)?(?:字|字符)|\b(\d+)\s*k\b",
                user_text,
                flags=re.IGNORECASE,
            )
            if target_match and not arguments.get("target_chars"):
                if target_match.group(1):
                    arguments["target_chars"] = int(target_match.group(1).replace(",", ""))
                else:
                    arguments["target_chars"] = int(target_match.group(2)) * 1000
            elif "十万" in user_text and not arguments.get("target_chars"):
                arguments["target_chars"] = 100000

        state.tool_calls = [
            {
                "id": f"writer_native_{uuid.uuid4().hex[:16]}",
                "type": "function",
                "function": {
                    "name": "serial_novel",
                    "arguments": json.dumps(arguments, ensure_ascii=False),
                },
            }
        ]
        state.collected_content = ""
        state.set_finish_reason("tool_calls")
        return True

    def _promote_writer_direct_prose_commit(self, state: _StreamingTurnState) -> bool:
        """Recover a streamed chapter draft by committing it through serial_novel."""
        if state.tool_calls or normalize_mode(self.mode) != "writer":
            return False

        active_project = self._writer_active_project_state()
        if not active_project:
            return False

        normalized_content = self._writer_trim_append_only_direct_prose(
            active_project,
            state.cleaned_content(),
        )
        non_whitespace_chars = self._writer_count_non_whitespace_chars(normalized_content)
        if non_whitespace_chars < self._writer_direct_prose_autocommit_min_chars(active_project):
            return False

        arguments = {
            "action": "commit_chapter",
            "novel_id": active_project["novel_id"],
            "chapter": active_project["active_chapter"],
            "data": {
                (
                    "append_content"
                    if str(active_project.get("pending_recovery_mode") or "").strip()
                    == PENDING_RECOVERY_APPEND_ONLY
                    and not bool(active_project.get("pending_requires_reprepare"))
                    else "content"
                ): normalized_content,
            },
        }
        state.tool_calls = [
            {
                "id": f"writer_commit_{uuid.uuid4().hex[:16]}",
                "type": "function",
                "function": {
                    "name": "serial_novel",
                    "arguments": json.dumps(arguments, ensure_ascii=False),
                },
            }
        ]
        state.collected_content = ""
        state.set_finish_reason("tool_calls")
        return True

    def _resolve_messages_for_request(self, messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Resolve lightweight local-image markers into actual multimodal request payloads."""
        resolved_messages: List[Dict[str, Any]] = []
        for message in messages or []:
            if not isinstance(message, dict):
                continue
            normalized = dict(message)
            if self.provider != "anthropic":
                normalized.pop("anthropic_thinking", None)
            content = normalized.get("content")
            if isinstance(content, list):
                normalized["content"] = resolve_inline_image_content_for_request(content, self.project_root)
                if normalized.get("role") == "tool" and self.provider != "anthropic":
                    media = [part for part in normalized["content"] if isinstance(part, dict) and part.get("type") in {"image_url", "input_audio"}]
                    if media:
                        normalized["content"] = _coerce_text_fragments(normalized["content"])
                        resolved_messages.append(normalized)
                        resolved_messages.append({"role": "user", "content": [{"type": "text", "text": f"Media returned by tool {normalized.get('tool_call_id', '')}:"}, *media]})
                        continue
            resolved_messages.append(normalized)
        return resolved_messages

    def _build_openai_chat_completion_kwargs(
        self,
        *,
        messages: List[Dict[str, Any]],
        tools: List[Dict[str, Any]],
        stream: bool,
    ) -> Dict[str, Any]:
        """Build OpenAI SDK chat-completions kwargs, including NVIDIA-specific adapters."""
        model_for_sdk = self.model
        prepared_messages = list(messages or [])
        
        provider_options: Dict[str, Any] = {}
        extra_body: Optional[Dict[str, Any]] = None
        
        if self._is_active_model_source("nvidia"):
            provider_options = build_nvidia_openai_options(
                getattr(self.config, "nvidia", {}), model_for_sdk, messages=prepared_messages,
            )
            if provider_options:
                option_model = str(provider_options.get("model", "") or "").strip()
                if option_model:
                    model_for_sdk = option_model
                extra_body = provider_options.get("extra_body")
        elif self._is_active_model_source("aihubmix"):
            provider_options = build_aihubmix_openai_options(getattr(self.config, "aihubmix", {}), model_for_sdk)
        elif self._is_active_model_source("opencode"):
            provider_options = build_opencode_openai_options(getattr(self.config, "opencode", {}), model_for_sdk)
            extra_body = provider_options.get("extra_body")
        elif self._is_active_model_source("modelscope"):
            provider_options = build_modelscope_openai_options(getattr(self.config, "modelscope", {}), model_for_sdk)
            extra_body = provider_options.get("extra_body")
        elif self._is_active_model_source("agnes"):
            provider_options = build_agnes_openai_options(getattr(self.config, "agnes", {}), model_for_sdk)
            extra_body = provider_options.get("extra_body")
        elif self._is_active_model_source("sensenova"):
            provider_options = build_sensenova_openai_options(
                getattr(self.config, "sensenova", {}),
                model_for_sdk,
            )
            extra_body = provider_options.get("extra_body")
        elif self._is_active_model_source("custom"):
            provider_options = build_custom_provider_openai_options(
                getattr(self.config, "custom_providers", {}),
                model_id=model_for_sdk,
            )
            extra_body = provider_options.get("extra_body")
        else:
            extra_body = self._openai_extra_body_for_thinking()
            if extra_body is not None and isinstance(model_for_sdk, str) and "(" in model_for_sdk and ")" in model_for_sdk:
                model_for_sdk = model_for_sdk.split("(", 1)[0].strip()

        if self._is_active_model_source("nvidia") and nvidia_model_requires_system_message_first(model_for_sdk):
            prepared_messages = _coalesce_system_messages_to_front(prepared_messages)
        elif prepared_messages:
            prepared_messages = _coalesce_system_messages_to_front(prepared_messages)
        if self._is_active_model_source("nvidia"):
            provider_options = self._clamp_nvidia_options_for_messages(
                provider_options,
                model_id=model_for_sdk,
                messages=prepared_messages,
                tools=tools if tools else None,
            )

        kwargs: Dict[str, Any] = {
            "model": model_for_sdk,
            "messages": prepared_messages,
            "stream": bool(stream),
        }
        if tools:
            kwargs["tools"] = tools
            tool_choice = self._native_tool_choice(tools)
            if tool_choice:
                kwargs["tool_choice"] = tool_choice

        if extra_body is not None:
            kwargs["extra_body"] = extra_body
        
        # Add provider-specific OpenAI-compatible options.
        if provider_options:
            for key in ("temperature", "top_p", "presence_penalty", "max_tokens"):
                if key in provider_options:
                    kwargs[key] = provider_options[key]
        
        return kwargs

    def _call_openai_chat_completion_once(self, call_kwargs: Dict[str, Any]) -> Any:
        """Call the OpenAI SDK once, handling SDK versions without per-call timeout."""
        try:
            client = self._ensure_client()
            return client.chat.completions.create(**call_kwargs)
        except TypeError as exc:
            if "timeout" not in call_kwargs or "timeout" not in str(exc).lower():
                raise
            retry_kwargs = dict(call_kwargs)
            retry_kwargs.pop("timeout", None)
            client = self._ensure_client()
            return client.chat.completions.create(**retry_kwargs)

    def _create_openai_chat_completion(self, **kwargs: Any) -> Any:
        """Call OpenAI-compatible chat completions with SDK compatibility and transient retries."""
        retries = self.api_max_retries
        last_error: Optional[Exception] = None
        call_kwargs = apply_openai_prompt_cache(kwargs, namespace="agent-chat")
        if call_kwargs.get("stream"):
            call_kwargs["stream_options"] = {**(call_kwargs.get("stream_options") or {}), "include_usage": True}
        fresh_user_query_retry_used = False
        prompt_cache_fallback_used = False
        thinking_tiers_dropped = 0
        attempt = 0

        while True:
            try:
                if self._is_active_model_source("nvidia"):
                    _wait_for_nvidia_rate_limit()
                return self._call_openai_chat_completion_once(call_kwargs)
            except Exception as exc:
                last_error = exc
                check_cancel()
                status_code = getattr(exc, "status_code", None)
                if call_kwargs.get("stream_options") and _is_stream_usage_rejection(exc):
                    call_kwargs.pop("stream_options")
                    logger.warning("Provider rejected streaming usage options; retrying without them")
                    continue
                if (
                    not prompt_cache_fallback_used
                    and has_prompt_cache_hints(call_kwargs)
                    and is_prompt_cache_rejection(exc)
                ):
                    logger.warning("Provider rejected prompt-cache hints; retrying once without them")
                    call_kwargs = without_prompt_cache(call_kwargs)
                    prompt_cache_fallback_used = True
                    continue
                if _has_thinking_hints(call_kwargs) and _is_thinking_hint_rejection(exc):
                    # One tier at a time, so a gateway that only dislikes the
                    # vendor-specific knobs still gets to keep thinking on.
                    narrowed = _narrow_thinking_hints(call_kwargs)
                    if narrowed is not None:
                        thinking_tiers_dropped += 1
                        call_kwargs = narrowed
                        self._remember_thinking_narrowing(
                            call_kwargs.get("model"), thinking_tiers_dropped
                        )
                        logger.warning(
                            "Provider rejected reasoning fields; retrying with a narrower payload (tier %s)",
                            thinking_tiers_dropped,
                        )
                        continue
                if (
                    (
                        self._is_active_model_source("agnes")
                        or self._is_active_model_source("sensenova")
                    )
                    and not fresh_user_query_retry_used
                    and "no user query found in messages" in str(exc).lower()
                ):
                    retry_messages = list(call_kwargs.get("messages") or [])
                    latest_user_query = self._latest_user_message_text().strip()
                    retry_messages.append(
                        {
                            "role": "user",
                            "content": latest_user_query
                            or "Continue the active request using the completed tool results and report the verified outcome.",
                        }
                    )
                    call_kwargs["messages"] = retry_messages
                    fresh_user_query_retry_used = True
                    source_label = model_source_display_name(
                        str(getattr(self.config, "active_model_source", "") or "")
                    )
                    logger.warning(
                        "%s requested a fresh user query after tool execution; retrying once with the active request",
                        source_label,
                    )
                    continue
                if isinstance(status_code, int) and 400 <= status_code < 500 and not _is_provider_rate_limit(status_code, exc):
                    raise
                transient_status = isinstance(status_code, int) and (_is_provider_rate_limit(status_code, exc) or 500 <= status_code < 600)
                if attempt >= retries or not (transient_status or _is_recoverable_stream_exception(exc)):
                    raise
                backoff = _api_retry_delay(attempt, self.api_initial_backoff, exc)
                self._emit_api_retry_event(
                    provider_label=self._openai_sdk_provider_label(),
                    model=call_kwargs.get("model", self.model),
                    stream=bool(call_kwargs.get("stream")),
                    delay_seconds=backoff,
                    attempt=attempt + 1,
                    max_attempts=retries,
                    error=exc,
                )
                logger.warning(
                    "OpenAI-compatible SDK call failed transiently; retrying in %.1fs (%s/%s): %s",
                    backoff,
                    attempt + 1,
                    retries,
                    exc,
                )
                attempt += 1
                interruptible_sleep(backoff)

        if last_error:
            raise last_error
        raise RuntimeError("OpenAI-compatible SDK call failed without an exception")

    def _remember_thinking_narrowing(self, model_id: Any, tiers_dropped: int) -> None:
        """Remember a custom provider's refused reasoning tier for this process.

        Without this, every turn would re-probe the same rejected dialect and pay
        one wasted request per tier before the payload the gateway accepts.
        """
        if not self._is_active_model_source("custom"):
            return
        try:
            provider_id = str(
                (getattr(self.config, "custom_providers", {}) or {}).get("active_provider_id") or ""
            )
            remember_custom_provider_reasoning_narrowing(
                provider_id, model_id or self.model, tiers_dropped
            )
        except Exception:
            logger.debug("Could not remember the custom provider reasoning narrowing", exc_info=True)

    def _openai_sdk_provider_label(self) -> str:
        """Return a user-facing label for OpenAI SDK backed requests."""
        source = str(getattr(getattr(self, "config", None), "active_model_source", "standard") or "standard")
        if source != "standard":
            return f"{model_source_display_name(source)} API"
        return "OpenAI-compatible API"

    def _model_request_stream_event(
        self,
        *,
        provider_label: str,
        model: Any,
        stream: bool,
        timeout: int,
    ) -> str:
        """Build a visible status event before a potentially slow provider call."""
        model_text = str(model or self.model or "model").strip() or "model"
        transport = "stream" if stream else "non-stream"
        activity_id = f"model-{uuid.uuid4().hex}"
        self._pending_model_activity = {
            "activity_id": activity_id,
            "provider_label": str(provider_label or "Model API").strip() or "Model API",
            "model": model_text,
            "transport": transport,
            "started_at": time.monotonic(),
        }
        return encode_stream_event(
            "model_request",
            activity_id=activity_id,
            category="Model",
            message=f"Connecting to {provider_label} stream" if stream else f"Requesting {provider_label} response",
            status="working",
            detail=f"{model_text} | {transport}",
            meta=f"connect timeout {int(timeout or 60)}s",
        )

    def _model_stream_connected_event(self) -> Optional[str]:
        """Close the pending model-request activity when upstream starts yielding."""
        activity = getattr(self, "_pending_model_activity", None)
        if not isinstance(activity, dict):
            return None
        self._pending_model_activity = None
        elapsed_ms = max(0, int((time.monotonic() - float(activity.get("started_at", time.monotonic()))) * 1000))
        provider_label = str(activity.get("provider_label") or "Model API")
        transport = str(activity.get("transport") or "stream")
        return encode_stream_event(
            "model_response",
            activity_id=str(activity.get("activity_id") or ""),
            category="Model",
            message=f"{provider_label} stream connected" if transport == "stream" else f"{provider_label} responded",
            status="success",
            detail=f"{activity.get('model') or self.model} | {transport}",
            meta=f"first event in {elapsed_ms}ms",
        )

    def _humanize_turn_error(self, error: BaseException) -> Optional[str]:
        """Rewrite known, self-inflicted gateway errors into actionable guidance.

        The OpenCode Zen free tier is gated server-side: an anonymous request to
        a ``-free`` model (or ``big-pickle``/muse-spark via ``/responses``) comes
        back ``403 FreeTierError: "...can only be used from within OpenCode"``.
        No client change bypasses it, so surfacing the raw HTTP traceback only
        confuses the user. Detect that exact case and explain the real fix: a
        valid Zen API key (or a reverse proxy that injects one).
        """
        text = str(error or "")
        lowered = text.lower()
        is_free_tier_gate = (
            "free tier can only be used from within opencode" in lowered
            or "freetiererror" in lowered
        )
        if is_free_tier_gate and self._is_active_model_source("opencode"):
            has_key = bool(str(self.api_key or "").strip())
            if has_key:
                # A key was sent but the gateway still refused it as free-tier
                # (e.g. the key lacks free-model access). Point at the account.
                return (
                    "OpenCode rejected this free model even with your configured API key "
                    "(HTTP 403 free-tier gate). The key may not have access to free models "
                    "or the model is contributor-only. Pick a paid model your key can use, "
                    "or check your plan at https://opencode.ai/docs/zen."
                )
            return (
                "OpenCode's free tier is gated server-side and can only be used from within "
                "OpenCode itself — anonymous requests are refused with HTTP 403, and no client "
                "setting bypasses it. To use OpenCode models from Reverie, set a real OpenCode "
                "Zen API key with /opencode key <your-key> (or point the source at a reverse "
                "proxy that injects one via /opencode url ...). Get a key at "
                "https://opencode.ai/docs/zen."
            )
        return None

    def _model_stream_failed_event(self, error: BaseException) -> Optional[str]:
        """Close the pending model-request activity with its real failure."""
        activity = getattr(self, "_pending_model_activity", None)
        if not isinstance(activity, dict):
            return None
        self._pending_model_activity = None
        provider_label = str(activity.get("provider_label") or "Model API")
        error_text = self._humanize_turn_error(error) or str(error or "Model stream failed").strip()
        if len(error_text) > 300:
            error_text = f"{error_text[:297]}..."
        return encode_stream_event(
            "model_error",
            activity_id=str(activity.get("activity_id") or ""),
            category="Model",
            message=f"{provider_label} stream failed",
            status="error",
            detail=error_text,
            meta=f"{activity.get('model') or self.model} | {activity.get('transport') or 'stream'}",
        )

    def _emit_api_retry_event(
        self,
        *,
        provider_label: str,
        model: Any,
        stream: bool,
        delay_seconds: float,
        attempt: int,
        max_attempts: int,
        error: BaseException,
    ) -> None:
        model_text = str(model or self.model or "model").strip() or "model"
        transport = "stream" if stream else "non-stream"
        error_text = str(error or "").strip()
        if len(error_text) > 180:
            error_text = f"{error_text[:177]}..."
        self._emit_ui_event(
            category="Model",
            message=f"{provider_label} error; retrying in {int(delay_seconds)}s",
            status="warning",
            detail=error_text,
            meta=f"{model_text} | {transport} | retry {attempt}/{max_attempts}",
        )

    def _request_provider_label(self) -> str:
        """Return a user-facing provider label for request-provider errors."""
        source = str(getattr(getattr(self, "config", None), "active_model_source", "standard") or "standard")
        if source != "standard":
            return f"{model_source_display_name(source)} API"
        return "Python requests"

    def _responses_provider_label(self, *, use_curl: bool = False) -> str:
        """Return the source-aware label for Responses API calls."""
        source = str(getattr(getattr(self, "config", None), "active_model_source", "standard") or "standard")
        if source != "standard":
            return f"{model_source_display_name(source)} API"
        return "curl Responses API" if use_curl else "OpenAI Responses API"

    def _resolve_anthropic_max_tokens(self) -> int:
        """Return max_tokens for Anthropic-compatible providers."""
        max_tokens = 4096
        if self._is_active_model_source("modelscope"):
            try:
                options = build_modelscope_openai_options(getattr(self.config, "modelscope", {}), self.model)
                candidate = int(options.get("max_tokens", max_tokens))
                if candidate > 0:
                    return candidate
            except Exception:
                return max_tokens
        if self._is_active_model_source("sensenova"):
            try:
                cfg = getattr(self.config, "sensenova", {})
                candidate = int(cfg.get("max_tokens", max_tokens)) if isinstance(cfg, dict) else max_tokens
                if candidate > 0:
                    return candidate
            except Exception:
                return max_tokens
        if self._is_active_model_source("custom"):
            try:
                options = build_custom_provider_openai_options(
                    getattr(self.config, "custom_providers", {}),
                    model_id=self.model,
                )
                candidate = int(options.get("max_tokens", max_tokens))
                if candidate > 0:
                    return candidate
            except Exception:
                return max_tokens
        return max_tokens

    def _apply_sensenova_anthropic_options(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """Apply SenseNova's documented Anthropic-compatible request options."""
        if not self._is_active_model_source("sensenova"):
            return kwargs
        cfg = getattr(self.config, "sensenova", {})
        if not isinstance(cfg, dict):
            return kwargs
        prepared = dict(kwargs)
        prepared["temperature"] = float(cfg.get("temperature", 0.6))
        prepared["top_p"] = float(cfg.get("top_p", 0.95))
        effort = str(cfg.get("reasoning_effort", self.thinking_mode or "high") or "high").strip().lower()
        if effort in {"low", "medium", "high", "max"}:
            prepared["extra_body"] = {"output_config": {"effort": effort}}
        return prepared

    def _apply_custom_provider_anthropic_options(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """Add the native Anthropic thinking block for a custom provider."""
        if not self._is_active_model_source("custom"):
            return kwargs
        try:
            options = build_custom_provider_anthropic_options(
                getattr(self.config, "custom_providers", {}),
                model_id=self.model,
            )
        except Exception:
            logger.debug("Could not build the custom provider thinking block", exc_info=True)
            return kwargs
        thinking = options.get("thinking")
        if not isinstance(thinking, dict):
            return kwargs
        prepared = dict(kwargs)
        prepared["thinking"] = thinking
        # Anthropic rejects a budget that does not fit inside the output cap, and
        # rejects sampling overrides while thinking is on.
        cap = int(prepared.get("max_tokens") or 0)
        budget = int(thinking.get("budget_tokens") or 0)
        if budget and cap and budget >= cap:
            prepared["max_tokens"] = int(options.get("max_tokens") or cap)
        prepared.pop("temperature", None)
        prepared.pop("top_p", None)
        return prepared

    def _completion_continuation_limit(self) -> int:
        """Return the continuation budget for a turn."""
        if normalize_mode(self.mode) == "computer-controller":
            return 24
        return 3

    def _should_stop_on_finish_reason(self) -> bool:
        """Whether a natural provider stop reason should end the turn."""
        # Tool calls are committed and continued before this completion check.
        # Once a provider reports a natural stop, every mode has finished the
        # current assistant turn; requiring a textual //END// marker here makes
        # computer-controller resend the same conversation until its much larger
        # continuation budget is exhausted.
        return True

    def _should_end_generation(self, collected_content: str, finish_reason: Optional[str]) -> bool:
        """Decide whether the current assistant turn is complete."""
        content = str(collected_content or "")
        if "//END//" in content:
            return True
        if not self._should_stop_on_finish_reason():
            return False
        return finish_reason in ("stop", "end_turn", "end", None)

    # ------------------------------------------------------------------
    # Output-less model turns
    #
    # A turn that returns neither a tool call nor visible text used to end the
    # run outright. With a reasoning model that is a routine event -- the whole
    # response lands in `reasoning_content` -- and ending there leaves the user
    # with a half-finished task, no summary, and a transcript whose last entry
    # is a tool result. These helpers turn that dead end into a bounded retry
    # that asks for the next tool call or the closing summary.
    # ------------------------------------------------------------------

    def _empty_turn_retry_limit(self) -> int:
        """How many output-less model turns to recover from before giving up."""
        if normalize_mode(self.mode) == "computer-controller":
            return 6
        return 3

    def _empty_turn_recovery_instruction(
        self,
        messages: List[Dict[str, Any]],
        *,
        attempt: int,
        limit: int,
    ) -> str:
        """Build the reminder sent after a turn produced no tool call and no text."""
        parts = [
            f"Recovery notice {attempt}/{limit}: your previous turn returned no tool call and no visible "
            "text, so nothing reached the user and the request is still unfinished.",
        ]
        if self._latest_tool_name_from_messages(messages):
            parts.append("Re-read the tool result above before deciding what to do next.")
        if attempt >= limit:
            parts.append(
                "Do not call another tool in this turn. Reply now in plain text describing what was "
                "accomplished, what is still missing, and the next step you would take."
            )
        else:
            parts.append(
                "Either call the next tool the request needs, or -- only once the request is genuinely "
                "complete -- reply with a short plain-text summary of the result."
            )
        if normalize_mode(self.mode) == "computer-controller":
            parts.append("End a final summary with //END//.")
        return " ".join(parts)

    def _recover_empty_model_turn(
        self,
        messages: List[Dict[str, Any]],
        *,
        attempt: int,
    ) -> bool:
        """Nudge the model after an output-less turn.

        ``messages`` is the request that just came back empty; it is read to
        describe the situation but never mutated -- it has already been handed to
        the provider, and every caller rebuilds its request from ``self.messages``
        before asking again, which is where the reminder has to live.

        Returns True when the caller should request another turn, False when the
        recovery budget is spent and the run has to stop.
        """
        limit = self._empty_turn_retry_limit()
        if attempt > limit:
            return False
        self._append_internal_system_message(
            self.messages,
            self._empty_turn_recovery_instruction(messages, attempt=attempt, limit=limit),
        )
        return True

    def _history_lacks_closing_assistant_text(self) -> bool:
        """Whether the run would end without any assistant text for this turn."""
        for message in reversed(self.messages):
            if not isinstance(message, dict):
                continue
            role = str(message.get("role", "") or "").strip().lower()
            if role == "user":
                return True
            if role != "assistant":
                continue
            if message.get("tool_calls"):
                continue
            return not _coerce_text_fragments(message.get("content", "")).strip()
        return False

    def _record_unsummarized_turn(
        self,
        *,
        request_messages: Optional[List[Dict[str, Any]]] = None,
        session_id: str,
    ) -> str:
        """Persist a visible notice when the model never returned a closing summary.

        ``request_messages`` is the prompt of the model call that came back
        empty; pass it so the spent request is still accounted for.  The
        end-of-turn safety net has no such call to attribute and omits it.
        """
        if not self._history_lacks_closing_assistant_text():
            return ""
        notice = (
            "The model stopped without returning any text for this turn, so the request is not finished. "
            "The tool results above are the only progress made. Send the request again to continue from here."
        )
        self.messages.append(_build_assistant_history_message(notice))
        if request_messages is not None:
            self._record_model_usage(
                request_messages=request_messages,
                assistant_text=notice,
                session_id=session_id,
            )
        return notice

    # ------------------------------------------------------------------
    # Reasoning traces
    # ------------------------------------------------------------------

    def _latest_user_prompt_text(self) -> str:
        """Return the plain text of the most recent user message."""
        for message in reversed(self.messages):
            if not isinstance(message, dict):
                continue
            if str(message.get("role", "") or "").strip().lower() != "user":
                continue
            return _coerce_text_fragments(message.get("content", "")).strip()
        return ""

    def _new_turn_state(self) -> _StreamingTurnState:
        """Preserve native reasoning verbatim, including repeated instructions."""
        state = _StreamingTurnState()
        self._pending_stream_state = state
        return state

    def _emit_ui_event(
        self,
        *,
        category: str,
        message: str,
        status: str = "info",
        detail: str = "",
        meta: str = "",
        compact: bool = False,
    ) -> None:
        """Send a structured UI event to the CLI surface when available."""
        handler = None
        try:
            handler = self.tool_executor.context.get("ui_event_handler")
        except Exception:
            handler = None

        payload = {
            "category": str(category or "").strip() or "Activity",
            "message": str(message or "").strip(),
            "status": str(status or "info").strip().lower(),
            "detail": str(detail or "").strip(),
            "meta": str(meta or "").strip(),
            "compact": bool(compact),
        }

        if callable(handler):
            try:
                handler(payload)
                return
            except Exception:
                logger.debug("Failed to emit UI event through handler", exc_info=True)

        plain = f"[{payload['category']}] {payload['message']}"
        if payload["detail"]:
            plain = f"{plain} ({payload['detail']})"
        if payload["meta"]:
            plain = f"{plain} [{payload['meta']}]"
        print(f"\n{plain}\n")

    def _emit_tool_stream_event(self, event_type: str, **payload: Any) -> None:
        """Forward non-streaming tool lifecycle events to the same UI surface."""
        if event_type == "tool_start":
            self._persist_history_to_session()
        handler = None
        try:
            handler = self.tool_executor.context.get("ui_event_handler")
        except Exception:
            handler = None
        if not callable(handler):
            return

        event = {
            "kind": "stream_event",
            "event": str(event_type or "").strip().lower(),
            **payload,
        }
        try:
            handler(event)
        except Exception:
            logger.debug("Failed to emit non-streaming tool event", exc_info=True)

    def _iter_sse_data_strings(self, response) -> Generator[str, None, None]:
        """Yield decoded SSE/JSON payloads from an HTTP streaming response."""
        yield from iter_provider_sse_data_strings(response)

    def _close_stream_response(self, response: Any) -> None:
        """Close a provider response object when it exposes a close method."""
        try:
            close = getattr(response, "close", None)
            if callable(close):
                close()
        except Exception:
            logger.debug("Failed to close streaming response", exc_info=True)

    def _apply_stream_event(
        self,
        state: _StreamingTurnState,
        event: Dict[str, Any],
    ) -> Generator[str, None, None]:
        """Apply one normalized stream event to the shared turn state."""
        control = getattr(self, "desktop_control", None)
        if control is not None:
            control.check_cancel()
        if not isinstance(event, dict):
            return

        event_type = str(event.get("type", "") or "").strip().lower()
        if event_type != "error":
            connected_event = self._model_stream_connected_event()
            if connected_event:
                yield connected_event
        if event_type == "usage":
            from ..session.workspace_stats import WorkspaceStatsManager

            # Streaming usage events are cumulative snapshots, not increments.
            state.usage.update(WorkspaceStatsManager._usage_dict(event.get("usage")))
            return
        if event_type == "reasoning":
            for chunk in state.add_reasoning(event.get("text", "")):
                yield chunk
            return

        if event_type == "content":
            for chunk in state.add_content(event.get("text", "")):
                yield chunk
            return

        if event_type in {"tool_call", "tool_call_start", "tool_call_args", "tool_call_delta"}:
            append_arguments = event_type in {"tool_call_args", "tool_call_delta"} and bool(
                event.get("append_arguments", event_type == "tool_call_args")
            )
            state.update_tool_call(
                int(event.get("index", 0) or 0),
                tool_call_id=str(event.get("id", "") or "").strip(),
                name=str(event.get("name", "") or "").strip(),
                arguments=event.get("arguments") if "arguments" in event else None,
                append_arguments=append_arguments,
                thought_signature=str(event.get("thought_signature", "") or "").strip(),
            )
            return

        if event_type == "finish":
            state.set_finish_reason(event.get("reason"))
            return

        if event_type == "error":
            raise RuntimeError(str(event.get("message", "") or "Codex upstream request failed"))

    def _iter_openai_sdk_stream_events(self, response: Any) -> Generator[Dict[str, Any], None, None]:
        """Translate OpenAI SDK streaming chunks into normalized events."""
        for chunk in response:
            if getattr(chunk, "usage", None) is not None:
                yield {"type": "usage", "usage": chunk.usage}
            choice = chunk.choices[0] if chunk.choices else None
            if choice is None:
                continue

            if choice.finish_reason:
                yield {"type": "finish", "reason": choice.finish_reason}

            delta = choice.delta
            if delta is None:
                continue

            reasoning_content = _extract_text_from_candidates(
                delta,
                "reasoning_content",
                "thinking",
                "reasoning",
            )
            if reasoning_content:
                yield {"type": "reasoning", "text": reasoning_content}

            content_piece = _extract_text_from_candidates(delta, "content")
            if content_piece:
                yield {"type": "content", "text": content_piece}

            if not delta.tool_calls:
                continue

            for tool_call in delta.tool_calls:
                function = getattr(tool_call, "function", None)
                yield {
                    "type": "tool_call_delta",
                    "index": int(getattr(tool_call, "index", 0) or 0),
                    "id": str(getattr(tool_call, "id", "") or "").strip(),
                    "name": str(getattr(function, "name", "") or "").strip() if function else "",
                    "arguments": getattr(function, "arguments", None) if function else None,
                    "append_arguments": True,
                }

    def _iter_request_stream_events(
        self,
        response: Any,
        provider_label: str,
    ) -> Generator[Dict[str, Any], None, None]:
        """Translate OpenAI-compatible SSE chunks into normalized events."""
        for data_str in self._iter_sse_data_strings(response):
            try:
                chunk_data = json.loads(data_str)
            except json.JSONDecodeError:
                continue

            _raise_for_wrapped_api_error(chunk_data, provider_label=provider_label)
            normalized_chunk = _unwrap_openai_compatible_payload(chunk_data) or chunk_data
            if isinstance(normalized_chunk.get("usage"), dict):
                yield {"type": "usage", "usage": normalized_chunk["usage"]}

            choices = normalized_chunk.get("choices", [])
            if not choices:
                continue

            choice = choices[0]
            finish_reason = choice.get("finish_reason")
            if finish_reason:
                yield {"type": "finish", "reason": finish_reason}

            delta = choice.get("delta") or {}
            if not isinstance(delta, dict):
                delta = {}

            reasoning_content = _extract_text_from_candidates(
                delta,
                "reasoning_content",
                "thinking",
                "reasoning",
            )
            if not reasoning_content:
                reasoning_content = _extract_text_from_candidates(
                    choice,
                    "reasoning_content",
                    "thinking",
                    "reasoning",
                )
            if not reasoning_content:
                reasoning_content = _extract_text_from_candidates(
                    choice.get("message") if isinstance(choice, dict) else None,
                    "reasoning_content",
                    "thinking",
                    "reasoning",
                )
            if reasoning_content:
                yield {"type": "reasoning", "text": reasoning_content}

            content = _extract_text_from_candidates(delta, "content")
            if not content:
                content = _extract_text_from_candidates(
                    choice.get("message") if isinstance(choice, dict) else None,
                    "content",
                )
            if content:
                yield {"type": "content", "text": content}

            tool_calls_delta = delta.get("tool_calls", [])
            if not tool_calls_delta:
                continue

            for tool_call_delta in tool_calls_delta:
                function_delta = tool_call_delta.get("function", {})
                yield {
                    "type": "tool_call_delta",
                    "index": int(tool_call_delta.get("index", 0) or 0),
                    "id": str(tool_call_delta.get("id", "") or "").strip(),
                    "name": str(function_delta.get("name", "") or "").strip(),
                    "arguments": function_delta.get("arguments") if "arguments" in function_delta else None,
                    "append_arguments": "arguments" in function_delta,
                }

    def _commit_stream_state(
        self,
        *,
        state: _StreamingTurnState,
        request_messages: List[Dict[str, Any]],
        messages: List[Dict[str, Any]],
        session_id: str,
        usage: Any = None,
    ) -> tuple[str, str]:
        """Store the finalized turn and report which follow-up path to take."""
        state.finalize_tool_calls()
        self._pending_stream_state = None
        self._record_model_usage(
            request_messages=request_messages,
            assistant_text=state.cleaned_content(),
            reasoning_text=state.collected_thinking,
            tool_calls=state.tool_calls,
            usage=usage if usage is not None else state.usage,
            session_id=session_id,
        )
        self._promote_writer_json_tool_call(state)
        self._promote_writer_direct_prose_commit(state)
        retry_instruction = self._writer_retry_instruction_for_invalid_commit_tool_call(state.tool_calls)
        if retry_instruction:
            self._append_internal_system_message(messages, retry_instruction)
            state.tool_calls = []
            state.collected_content = ""
            return "retry_direct_prose", ""
        clean_content = state.cleaned_content()
        retry_instruction = self._writer_retry_instruction_for_short_direct_prose(clean_content)
        if retry_instruction:
            self._append_internal_system_message(messages, retry_instruction)
            state.collected_content = ""
            return "retry_direct_prose", ""

        if state.tool_calls:
            history_tool_calls = _compact_tool_calls_for_history(state.tool_calls, mode=self.mode)
            # Some providers emit a provisional natural-language reply in the
            # same response as a pure deep_think call. That reply is not a
            # completed answer: the tool explicitly hands control back for the
            # next response. Keeping it in history makes the GUI render it and
            # the actual final answer as two assistant messages.
            thought_only = all(
                is_think_tool((call.get("function") or {}).get("name"))
                for call in state.tool_calls
                if isinstance(call, dict)
            )
            history_content = "" if thought_only else clean_content
            assistant_message = _build_assistant_history_message(
                history_content or None,
                tool_calls=history_tool_calls,
                reasoning_content=state.collected_thinking,
            )
            self.messages.append(assistant_message)
            messages.append(assistant_message)
            return "tool_calls", history_content

        if clean_content:
            self.messages.append(
                _build_assistant_history_message(
                    clean_content,
                    reasoning_content=state.collected_thinking,
                )
            )
            return "content", clean_content

        if state.collected_thinking:
            # An unsuccessful response still has a real, user-visible trace.
            # Keep each attempt before recovery can replace the live timeline.
            self.messages.append(_build_assistant_history_message(None, reasoning_content=state.collected_thinking))
            self._persist_history_to_session()
        return "empty", clean_content

    def _prepare_tool_call_review(
        self,
        tool_calls: List[Dict[str, Any]],
    ) -> Optional[Dict[str, Any]]:
        """Run the Auto Check pass over one response's tool calls.

        Returns a summary payload for the UI, or None when the mode is not
        Auto Check or there is nothing worth reviewing.
        """
        executor = getattr(self, "tool_executor", None)
        if executor is None or not tool_calls:
            return None

        security = getattr(self.config, "security", {}) if getattr(self, "config", None) is not None else {}
        if not isinstance(security, dict):
            return None
        if normalize_permission_mode(security.get("permission_mode")) != "auto_check":
            executor.clear_review_verdicts()
            return None

        review = resolve_review_config(security)
        batch: List[Dict[str, Any]] = []
        for tool_call in tool_calls:
            function = tool_call.get("function") or {}
            tool_name = str(function.get("name", "")).strip()
            tool = executor.get_tool(tool_name)
            if tool is None:
                continue
            if bool(getattr(tool, "read_only", False)) and not review.get("review_read_only"):
                continue
            call_id = str(tool_call.get("id", "")).strip()
            arguments = parse_tool_arguments(function.get("arguments", ""))
            batch.append(describe_call(tool, arguments, call_id or f"{tool_name}-{len(batch)}"))

        executor.clear_review_verdicts()
        if not batch:
            return None

        try:
            from .permission_reviewer import review_tool_calls

            outcome = review_tool_calls(
                batch,
                agent=self,
                config=getattr(self, "config", None),
                review=review,
                workspace_root=str(getattr(self, "project_root", "") or ""),
                permission_level=normalize_permission_level(security.get("permission_level")),
            )
        except Exception:
            logger.debug("Auto Check batch review failed", exc_info=True)
            return None

        if not outcome.ok and review.get("fail_open"):
            return {
                "reviewed": len(batch),
                "flagged": 0,
                "batch_risk": "none",
                "ok": False,
                "error": outcome.error,
                "model": outcome.model_display_name,
                "elapsed_ms": outcome.elapsed_ms,
                "verdicts": [],
            }

        executor.set_review_verdicts(outcome.verdicts)
        threshold = review.get("approve_risk_at")
        flagged = [
            verdict.to_dict()
            for verdict in outcome.verdicts.values()
            if risk_requires_approval(verdict.risk, threshold)
        ]
        return {
            "reviewed": len(batch),
            "flagged": len(flagged),
            "batch_risk": outcome.batch_risk,
            "ok": outcome.ok,
            "error": outcome.error,
            "model": outcome.model_display_name,
            "elapsed_ms": outcome.elapsed_ms,
            "verdicts": flagged,
        }

    # A thinking-only turn is real progress the first time and pure spin after
    # that: every tool loop -- streaming and non-streaming alike -- restarts
    # unconditionally after a tool batch, so a model that only ever calls
    # deep_think would never terminate.
    THINK_TOOL_NUDGE_AT = 2
    THINK_TOOL_HARD_LIMIT = 4

    def _reset_think_tool_budget(self) -> None:
        """Clear the per-turn Thinking Tool spin guard."""
        self._consecutive_think_only_batches = 0
        self._think_tool_suppressed = False

    def _think_tool_budget_state(self) -> tuple[int, bool]:
        """Return the current (consecutive thought-only batches, suppressed) pair."""
        return (
            int(getattr(self, "_consecutive_think_only_batches", 0) or 0),
            bool(getattr(self, "_think_tool_suppressed", False)),
        )

    def _guard_think_tool_spin(
        self,
        tool_calls: List[Dict[str, Any]],
        messages: List[Dict[str, Any]],
    ) -> None:
        """Stop a model from thinking forever instead of acting.

        Called once per executed tool-call batch. A batch that did any real work
        clears the counter; consecutive thought-only batches first earn a nudge
        and then lose access to the tool for the rest of the turn.
        """
        names: List[str] = []
        for call in tool_calls or []:
            if isinstance(call, dict):
                raw_name = (call.get("function") or {}).get("name", "")
            else:
                # Provider SDK objects (OpenAI ChatCompletionMessageToolCall, ...).
                raw_name = getattr(getattr(call, "function", None), "name", "")
            name = str(raw_name or "").strip()
            if name:
                names.append(name)
        if not names:
            return

        if not all(is_think_tool(name) for name in names):
            self._reset_think_tool_budget()
            return

        count = int(getattr(self, "_consecutive_think_only_batches", 0) or 0) + 1
        self._consecutive_think_only_batches = count

        if count >= self.THINK_TOOL_HARD_LIMIT:
            self._think_tool_suppressed = True
            self._append_internal_system_message(
                messages,
                "You have used deep_think several turns in a row without doing anything "
                "else. The tool is now unavailable for the rest of this turn. Act on the "
                "reasoning you already have: call a working tool or answer the user.",
            )
            return

        if count >= self.THINK_TOOL_NUDGE_AT:
            self._append_internal_system_message(
                messages,
                "That was another deep_think call with no work in between. Stop thinking "
                "and take the next concrete step now - call a working tool or answer the "
                "user. Do not call deep_think again until you have.",
            )

    def _execute_streamed_tool_calls(
        self,
        tool_calls: List[Dict[str, Any]],
        messages: List[Dict[str, Any]],
        session_id: str,
    ) -> Generator[str, None, None]:
        """Execute collected tool calls using the shared stream event surface."""
        review_summary = self._prepare_tool_call_review(tool_calls)
        if review_summary:
            yield encode_stream_event(
                "tool_review",
                agent_id=self.agent_id,
                agent_color=self.agent_color,
                **review_summary,
            )
        try:
            for tool_call in tool_calls:
                yield from self._stream_execute_tool_call(
                    tool_call,
                    messages,
                    session_id=session_id,
                )
        finally:
            executor = getattr(self, "tool_executor", None)
            if executor is not None:
                executor.clear_review_verdicts()
            self._guard_think_tool_spin(tool_calls, messages)

    def _stream_execute_tool_call(
        self,
        tool_call: Dict[str, Any],
        messages: List[Dict[str, Any]],
        session_id: str = "default",
    ) -> Generator[str, None, None]:
        """Execute one tool call and emit structured UI events."""
        control = getattr(self, "desktop_control", None)
        if control is not None:
            control.safe_point(self, receive=False)
        tool_name = str((tool_call.get("function") or {}).get("name", "")).strip()
        tool = self.tool_executor.get_tool(tool_name)
        args = parse_tool_arguments((tool_call.get("function") or {}).get("arguments", ""))

        self._check_tool_side_effects(tool_name, args)

        from ..desktop_changes import read_edit_snapshot
        edit_path = None
        old_edit_content = None
        edit_operation = None
        canonical_name = getattr(tool, "name", tool_name)
        if canonical_name == "str_replace_editor":
            command = str(args.get("command") or "")
            if command in {"str_replace", "insert", "create"}:
                edit_operation = "create" if command == "create" else "modify"
        elif canonical_name in {"create_file", "delete_file"}:
            edit_operation = "create" if canonical_name == "create_file" else "delete"
        if self.operation_history and edit_operation and args.get("path") and tool:
            try:
                edit_path = tool.resolve_workspace_path(args["path"], purpose="preview file edit")
                if edit_operation == "create" and edit_path.exists():
                    edit_operation = "modify"
                old_edit_content = read_edit_snapshot(edit_path)
            except Exception:
                logger.debug("File edit snapshot unavailable", exc_info=True)

        if self.rollback_manager:
            try:
                self.rollback_manager.create_pre_tool_checkpoint(
                    session_id=session_id,
                    messages=self.messages,
                    tool_name=tool_name,
                    arguments=args,
                )
            except Exception:
                logger.debug("Pre-tool checkpoint creation failed", exc_info=True)

        exec_msg = tool.get_execution_message(**args) if tool else f"Executing {tool_name}..."
        yield encode_stream_event(
            "tool_start",
            tool_name=tool_name,
            message=exec_msg,
            arguments=args,
            tool_call_id=str(tool_call.get("id", "")).strip(),
            agent_id=self.agent_id,
            agent_color=self.agent_color,
        )

        result = self.tool_executor.execute(
            tool_name,
            args,
            tool_call_id=str(tool_call.get("id", "")).strip(),
        )

        if self.operation_history:
            try:
                last_question = self.operation_history.get_last_user_question()
                parent_id = last_question.id if last_question else None
                tool_operation = self.operation_history.add_tool_call(
                    tool_name=tool_name,
                    arguments=args,
                    result=result.output if result.success else None,
                    success=result.success,
                    error=result.error,
                    parent_id=parent_id,
                )
                if result.success and edit_operation and edit_path is not None:
                    self.operation_history.add_file_operation(
                        file_path=str(edit_path),
                        operation=edit_operation,
                        old_content=old_edit_content,
                        new_content=read_edit_snapshot(edit_path),
                        parent_id=tool_operation.id,
                        session_id=session_id,
                    )
            except Exception:
                logger.debug("Operation history tool logging failed", exc_info=True)

        relay_tool_result_message = {
            "role": "tool",
            "tool_call_id": tool_call["id"],
            "content": _tool_result_content(result),
        }
        self.messages.append(
            {
                "role": "tool",
                "tool_call_id": tool_call["id"],
                "content": _tool_result_history_content(result),
            }
        )
        messages.append(relay_tool_result_message)
        yield encode_stream_event(
            "tool_result",
            tool_name=tool_name,
            message=exec_msg,
            arguments=args,
            tool_call_id=str(tool_call.get("id", "")).strip(),
            success=bool(result.success),
            output=str(result.output or ""),
            error=str(result.error or ""),
            status=str(getattr(result.status, "value", "success")),
            task_list=result.data.get("tasks") if canonical_name == "task_manager" and isinstance(result.data, dict) else None,
            agent_id=self.agent_id,
            agent_color=self.agent_color,
        )

    def _process_streaming_native_provider(self, provider_name: str, session_id: str = "default") -> Generator[str, None, None]:
        """Process streaming responses for the native Codex provider."""
        import requests

        max_continuations = self._completion_continuation_limit()
        continuation_count = 0
        empty_turn_count = 0

        while True:
            self._check_and_compress_context(session_id=session_id)
            tools = self.get_visible_tool_schemas()
            messages = _sanitize_messages_for_relay(self._build_messages(resolve_local_images=True))
            request_messages = list(messages)
            parser_state: Dict[str, Any] = {}

            from ..codex import (
                build_codex_request_payload,
                get_codex_request_headers,
                normalize_codex_config,
                parse_codex_sse_event,
                resolve_codex_credentials,
                resolve_codex_request_url,
            )

            cfg = normalize_codex_config(getattr(self.config, "codex", {}))
            request_url = resolve_codex_request_url(self.base_url, self.endpoint or cfg.get("endpoint", ""))
            cred = resolve_codex_credentials(cfg, request_url=request_url)
            if not cred.get("found"):
                raise ValueError(
                    "Codex credentials were not found. Run /codex login or configure the reverse proxy auth_mode/api_key_env."
                )
            self.api_key = str(cred.get("api_key", "")).strip()
            payload = build_codex_request_payload(
                model_name=self.model,
                messages=messages,
                tools=tools if tools else None,
                reasoning_effort=self.thinking_mode or cfg.get("reasoning_effort", "medium"),
                stream=True,
            )
            tool_choice = self._native_tool_choice(tools) if tools else None
            if tool_choice:
                tool_name = str((tool_choice.get("function", {}) or {}).get("name", "") or "").strip()
                if tool_name:
                    payload["tool_choice"] = {"type": "function", "name": tool_name}
            headers = get_codex_request_headers(
                api_key=self.api_key,
                account_id=str(cred.get("account_id", "")).strip(),
                auth_mode=str(cred.get("auth_mode", "")).strip(),
                extra_headers=self.custom_headers,
                stream=True,
                request_url=request_url,
            )

            effective_timeout = self._resolve_provider_timeout()
            configured_proxy = normalize_proxy_url(getattr(getattr(self, "config", None), "api_proxy", ""))
            try:
                response = make_api_request_with_retry(
                    url=request_url,
                    headers=headers,
                    payload=payload,
                    max_retries=self.api_max_retries,
                    initial_backoff=self.api_initial_backoff,
                    stream=True,
                    timeout=effective_timeout,
                    proxies=requests_proxy_dict(configured_proxy) if configured_proxy else None,
                    on_retry=lambda delay, attempt, max_attempts, error: self._emit_api_retry_event(
                        provider_label=provider_name,
                        model=payload.get("model", self.model),
                        stream=True,
                        delay_seconds=delay,
                        attempt=attempt,
                        max_attempts=max_attempts,
                        error=error,
                    ),
                )
            except requests.RequestException as e:
                logger.error(f"Streaming API request failed for {provider_name}: {e}")
                raise

            state = self._new_turn_state()
            try:
                for data_str in self._iter_sse_data_strings(response):
                    events, parser_state = parse_codex_sse_event(data_str, parser_state)

                    for event in events:
                        yield from self._apply_stream_event(state, event)
            except Exception as exc:
                if _should_recover_partial_stream_error(state, exc):
                    logger.warning("Recovered partial streaming output after %s interruption: %s", provider_name, exc)
                    state.set_finish_reason("interrupted")
                else:
                    raise
            finally:
                for chunk in state.flush():
                    yield chunk
                self._close_stream_response(response)

            outcome, _ = self._commit_stream_state(
                state=state,
                request_messages=request_messages,
                messages=messages,
                session_id=session_id,
            )

            if outcome == "tool_calls":
                yield from self._execute_streamed_tool_calls(
                    state.tool_calls,
                    messages,
                    session_id=session_id,
                )

                continuation_count = 0
                continue

            if outcome == "retry_direct_prose":
                continuation_count += 1
                if continuation_count >= max_continuations:
                    break

                messages = _sanitize_messages_for_relay(self._build_messages(resolve_local_images=True))
                continue

            if outcome == "content":
                if self._should_end_generation(state.collected_content, state.finish_reason):
                    break

                continuation_count += 1
                if continuation_count >= max_continuations:
                    break

                messages = _sanitize_messages_for_relay(self._build_messages(resolve_local_images=True))
                continue

            empty_turn_count += 1
            if self._recover_empty_model_turn(messages, attempt=empty_turn_count):
                continue

            notice = self._record_unsummarized_turn(
                session_id=session_id,
            )
            if notice:
                yield notice
            break

    def _process_non_streaming_native_provider(self, provider_name: str, session_id: str = "default") -> str:
        """Fallback non-streaming path for native providers via streaming aggregation."""
        return self._collect_non_streaming_output(
            self._process_streaming_native_provider(provider_name=provider_name, session_id=session_id)
        )

    def _collect_non_streaming_output(self, stream: Generator[str, None, None]) -> str:
        """Buffer answer text while preserving the native stream's tool events."""
        chunks: List[str] = []
        in_thinking = False
        for chunk in stream:
            if chunk == THINKING_START_MARKER:
                in_thinking = True
                continue
            if chunk == THINKING_END_MARKER:
                in_thinking = False
                continue
            event = decode_stream_event(chunk)
            if event is not None:
                self._emit_tool_stream_event(str(event.pop("event", "")), **event)
                continue
            # The provider stores reasoning_content separately in history.
            if not in_thinking:
                chunks.append(chunk)
        return "".join(chunks)

    def _process_streaming_webgemini(self, session_id: str = "default") -> Generator[str, None, None]:
        """Process streaming responses through Gemini Web's anonymous StreamGenerate endpoint."""
        cfg = normalize_webgemini_config(getattr(self.config, "webgemini", {}))
        max_continuations = self._completion_continuation_limit()
        continuation_count = 0
        empty_turn_count = 0

        while True:
            self._check_and_compress_context(session_id=session_id)
            tools = self.get_visible_tool_schemas()
            request_messages = self._build_messages()
            messages = _sanitize_messages_for_relay(self._build_messages(resolve_local_images=True))
            effective_timeout = self._resolve_provider_timeout()
            yield self._model_request_stream_event(
                provider_label="WebGemini",
                model=self.model,
                stream=True,
                timeout=effective_timeout,
            )

            state = self._new_turn_state()
            try:
                if tools:
                    text, tool_calls = generate_webgemini_message(
                        messages=messages,
                        model=self.model,
                        webgemini_config={**cfg, "timeout": effective_timeout},
                        tools=tools,
                    )
                    if text:
                        yield from self._apply_stream_event(state, {"type": "content", "text": text})
                    for tool_call in tool_calls:
                        fn = tool_call.get("function", {}) if isinstance(tool_call, dict) else {}
                        state.update_tool_call(
                            len(state.tool_calls),
                            tool_call_id=str(tool_call.get("id", "") or ""),
                            name=str(fn.get("name", "") or ""),
                            arguments=str(fn.get("arguments", "") or "{}"),
                        )
                    state.set_finish_reason("tool_calls" if tool_calls else "stop")
                    if not text and not tool_calls:
                        raise ValueError(
                            "WebGemini returned an empty response. Check network/proxy access to gemini.google.com, "
                            "or configure a Gemini cookie/XSRF token if upstream now requires authentication."
                        )
                else:
                    saw_delta = False
                    for delta in iter_webgemini_text_deltas(
                        messages=messages,
                        model=self.model,
                        webgemini_config={**cfg, "timeout": effective_timeout},
                    ):
                        if str(delta or "").strip():
                            saw_delta = True
                        yield from self._apply_stream_event(state, {"type": "content", "text": delta})
                    if not saw_delta:
                        text, _ = generate_webgemini_message(
                            messages=messages,
                            model=self.model,
                            webgemini_config={**cfg, "timeout": effective_timeout},
                            tools=None,
                        )
                        if not text:
                            raise ValueError(
                                "WebGemini returned an empty response. Check network/proxy access to gemini.google.com, "
                                "or configure a Gemini cookie/XSRF token if upstream now requires authentication."
                            )
                        yield from self._apply_stream_event(state, {"type": "content", "text": text})
                    state.set_finish_reason("stop")
            except Exception as exc:
                if _should_recover_partial_stream_error(state, exc):
                    logger.warning("Recovered partial streaming output after WebGemini interruption: %s", exc)
                    state.set_finish_reason("interrupted")
                else:
                    raise
            finally:
                for chunk in state.flush():
                    yield chunk

            outcome, _ = self._commit_stream_state(
                state=state,
                request_messages=request_messages,
                messages=messages,
                session_id=session_id,
            )

            if outcome == "tool_calls":
                yield from self._execute_streamed_tool_calls(
                    state.tool_calls,
                    messages,
                    session_id=session_id,
                )
                continuation_count = 0
                continue

            if outcome == "retry_direct_prose":
                continuation_count += 1
                if continuation_count >= max_continuations:
                    break
                continue

            if outcome == "content":
                if self._should_end_generation(state.collected_content, state.finish_reason):
                    break

                continuation_count += 1
                if continuation_count >= max_continuations:
                    break
                continue

            empty_turn_count += 1
            if self._recover_empty_model_turn(messages, attempt=empty_turn_count):
                continue

            notice = self._record_unsummarized_turn(
                session_id=session_id,
            )
            if notice:
                yield notice
            break

    def _process_non_streaming_webgemini(self, session_id: str = "default") -> str:
        """Fallback non-streaming WebGemini path via streaming aggregation."""
        return self._collect_non_streaming_output(
            self._process_streaming_webgemini(session_id=session_id)
        )

    def _openai_extra_body_for_thinking(self) -> Optional[Dict[str, Any]]:
        """Build `extra_body` (OpenAI SDK) to enable/disable thinking for compatible models.

        Rules:
        - If `thinking_mode` is explicitly set to 'true', return chat_template_kwargs enabling thinking.
        - If `thinking_mode` is 'false', return None (do not send thinking flags).
        - If `thinking_mode` is unset, detect model suffix like "model(thinking)" and enable thinking for
          recognized suffixes (auto, low, medium, high, xhigh, minimal, digits).
        - For GLM-family models include `clear_thinking: False` when enabling thinking.
        - For NVIDIA-hosted models, defer to model-specific configuration.
        """
        # Skip if using NVIDIA source - let NVIDIA-specific options handle it
        if self._is_active_model_source("nvidia"):
            return None

        # Explicit override from config
        if isinstance(self.thinking_mode, str) and self.thinking_mode.lower() in ("true", "false"):
            if self.thinking_mode.lower() == "false":
                return None
            enable_thinking = True
        else:
            # Derive from model name suffix if present
            model_name = str(self.model or "").strip()
            enable_thinking = False
            if "(" in model_name and ")" in model_name:
                base_model = model_name.split("(", 1)[0].strip()
                suffix = model_name.split("(", 1)[1].split(")", 1)[0].strip().lower()
                thinking_suffixes = {"auto", "low", "medium", "high", "xhigh", "minimal"}
                if suffix in thinking_suffixes or suffix.isdigit():
                    enable_thinking = True
                elif suffix in {"none", "0"}:
                    return None
            else:
                # No explicit hint; do not enable thinking by default
                return None

        if not enable_thinking:
            return None

        chat_kwargs: Dict[str, Any] = {"enable_thinking": True, "thinking": True}
        if "glm" in (self.model or "").lower():
            # GLM variants prefer clear_thinking=False per hosted-provider logic
            chat_kwargs["clear_thinking"] = False

        return {"chat_template_kwargs": chat_kwargs}
    
    def set_context_engine(self, retriever, indexer, git_integration) -> None:
        """Update Context Engine references"""
        previous_context = dict(getattr(self.tool_executor, "context", {}) or {})
        self.tool_executor = ToolExecutor(
            project_root=self.project_root,
            retriever=retriever,
            indexer=indexer,
            git_integration=git_integration,
            lsp_manager=previous_context.get("lsp_manager"),
            memory_indexer=previous_context.get("memory_indexer"),
        )
        for key, value in previous_context.items():
            if key in {"project_root", "retriever", "indexer", "git_integration", "lsp_manager", "memory_indexer"}:
                continue
            self.tool_executor.update_context(key, value)
        self.tool_executor.update_context("agent", self)

    def _get_memory_os(self) -> Optional[MemoryOS]:
        """Return the Memory OS facade for this workspace, creating it lazily."""
        context = getattr(self.tool_executor, "context", {}) if self.tool_executor else {}
        existing = context.get("memory_os") if isinstance(context, dict) else None
        if isinstance(existing, MemoryOS):
            self._memory_os = existing
            return existing
        if isinstance(self._memory_os, MemoryOS):
            if isinstance(context, dict):
                context["memory_os"] = self._memory_os
            return self._memory_os

        try:
            from ..config import get_project_data_dir

            project_root = Path(context.get("project_root") or self.project_root) if isinstance(context, dict) else self.project_root
            project_data_dir = context.get("project_data_dir") if isinstance(context, dict) else None
            base_dir = Path(project_data_dir) if project_data_dir else get_project_data_dir(Path(project_root))
            self._memory_os = MemoryOS(base_dir, project_root=Path(project_root))
            if isinstance(context, dict):
                context["memory_os"] = self._memory_os
            return self._memory_os
        except Exception:
            logger.debug("Failed to initialize Memory OS", exc_info=True)
            return None

    def _record_memory_event(
        self,
        event_type: str,
        payload: Dict[str, Any],
        *,
        actor: str = "",
        session_id: str = "default",
        tags: Optional[List[str]] = None,
        consolidate: bool = True,
    ) -> None:
        """Best-effort event-store write for traceable memory evidence."""
        memory_os = self._get_memory_os()
        if not memory_os:
            return
        try:
            resolved_session_id, _ = self._current_session_details(session_id)
            memory_os.record_event(
                event_type,
                payload,
                actor=actor,
                session_id=resolved_session_id,
                tags=tags,
                consolidate=consolidate,
            )
        except Exception:
            logger.debug("Failed to record Memory OS event", exc_info=True)

    def _select_prompt_history(self) -> List[Dict[str, Any]]:
        """Return bounded history for model prompts while preserving tool-call safety."""
        messages = [dict(message) for message in self.messages if isinstance(message, dict)]
        if len(messages) <= self._prompt_history_limit:
            return messages

        working_memory = [
            message
            for message in messages
            if str(message.get("role", "") or "").strip().lower() == "system"
            and "[WORKING MEMORY" in _coerce_text_fragments(message.get("content"))
        ][-2:]

        tail = messages[-self._prompt_history_limit :]
        while tail and str(tail[0].get("role", "") or "").strip().lower() == "tool":
            tail = tail[1:]

        selected: List[Dict[str, Any]] = []
        seen: set[int] = set()
        for message in working_memory + tail:
            marker = id(message)
            if marker in seen:
                continue
            selected.append(message)
            seen.add(marker)
        return selected

    def _memory_context_package_message(self) -> Optional[Dict[str, Any]]:
        """Build one bounded retrieved context package for the active request."""
        memory_os = self._get_memory_os()
        if not memory_os:
            return None
        query = self._latest_user_message_text()
        if not query:
            return None
        try:
            resolved_session_id, _ = self._current_session_details("default")
            context_budget = max(3500, min(10000, int(self._resolve_max_context_tokens() * 0.06)))
            package = memory_os.assemble_context(
                query,
                code_retriever=self.tool_executor.context.get("retriever"),
                session_id=resolved_session_id,
                recent_messages=self.messages,
                max_tokens=context_budget,
            )
        except Exception:
            logger.debug("Failed to assemble Memory OS context package", exc_info=True)
            return None
        content = str(getattr(package, "content", "") or "").strip()
        if not content:
            return None
        return {"role": "system", "content": content}
    
    def _request_system_prompt(self) -> str:
        return "\n\n".join(part for part in (
            self.system_prompt, getattr(self, "_pinned_turn_guidance", ""), getattr(self, "goal_context", "")
        ) if part)

    def _build_messages(
        self,
        include_reasoning: bool = False,
        resolve_local_images: bool = False,
        read_only: bool = False,
    ) -> List[Dict]:
        """Build message list for API calls, optionally resolving local multimodal parts."""
        control = getattr(self, "desktop_control", None)
        if control is not None and not read_only:
            control.safe_point(self)
        messages = [{"role": "system", "content": self._request_system_prompt()}]
        memory_context = self._memory_context_package_message()
        if memory_context:
            messages.append(memory_context)
        # View-authored summaries are transient user data, never system rules or history.
        from ..views import ViewStore, model_context_message
        manager = self.tool_executor.context.get("session_manager")
        session = manager.get_current_session() if manager is not None else None
        if session is not None:
            context = model_context_message(ViewStore.for_project(self.project_root), session.id, session.messages)
            if context:
                messages.append(context)
        preserve_nvidia_reasoning = (
            self._is_active_model_source("nvidia")
            and nvidia_model_requires_preserved_reasoning_history(self.model)
        )
        for message in self._select_prompt_history():
            if not isinstance(message, dict):
                continue
            if (
                message.get("role") == "assistant"
                and not message.get("content")
                and not message.get("tool_calls")
            ):
                # Retained in transcript/UI; an answerless attempt is not a
                # valid assistant content/tool message for the next API call.
                continue
            normalized = dict(message)
            if not include_reasoning and not preserve_nvidia_reasoning:
                normalized.pop("reasoning_content", None)
            messages.append(normalized)
        if (
            self._is_active_model_source("sensenova")
            and self.provider == "openai-chat"
            and messages
            and str(messages[-1].get("role", "")).lower() == "tool"
        ):
            followup_content = self._writer_sensenova_tool_result_followup(messages)
            if not followup_content:
                followup_content = (
                    "Continue the active request from the immediately preceding tool result. "
                    "If it failed, correct the exact error and do not resend unchanged tool arguments. "
                    "Preserve the original user requirements."
                )
            messages.append(
                {
                    "role": "user",
                    "content": followup_content,
                }
            )
        if resolve_local_images:
            return self._resolve_messages_for_request(messages)
        return messages
    
    def process_message(
        self,
        user_message: Any,
        stream: bool = True,
        session_id: str = "default",
        user_display_text: Optional[str] = None,
        resume: bool = False,
    ) -> Generator[str, None, None]:
        """
        Process a user message and yield responses.
        
        Args:
            user_message: The user's input
            stream: Whether to stream the response
            session_id: Current session ID for checkpointing
            user_display_text: Plain-text version used for checkpoints/history summaries
        
        Yields:
            Response chunks (or full response if not streaming)
        """
        self._pinned_turn_guidance = ""
        # RIU: mint a per-turn provenance id so an interactive view rendered this
        # turn is bound to the turn by the kernel, never chosen by the model.
        # This is provenance / visual-grouping only -- the security-critical
        # identity is the session id (ownership + storage path) and the
        # crypto-random view id. A resumed request keeps the turn it resumes.
        try:
            existing_turn = str(self.tool_executor.context.get("turn_id") or "").strip()
            if not (resume and existing_turn):
                self.tool_executor.context["turn_id"] = "t" + uuid.uuid4().hex
        except Exception:
            report_suppressed_exception("RIU turn provenance minting", logger=logger)
        skills = self.tool_executor.context.get("skills_manager")
        if skills is not None:
            loaded = skills.load_pinned_instructions()
            self._pinned_turn_guidance = loaded["instructions"]
            if loaded["records"]:
                self._emit_ui_event(category="Skills", message="Required Skills loaded for this turn",
                                    detail=", ".join(item["name"] for item in loaded["records"]),
                                    meta=json.dumps(loaded["records"], ensure_ascii=False))
        display_text = str(user_display_text or "").strip()
        if not display_text:
            display_text = _coerce_text_fragments(user_message).strip()
        if not display_text and isinstance(user_message, list):
            display_text = "[image attachment]"

        if resume:
            if not any(message.get("role") == "user" for message in self.messages):
                raise ValueError("Cannot resume a session without a user request.")
            # Keep the provider's tool-call protocol valid without replaying an
            # operation whose side effects are uncertain after a hard stop.
            completed = {str(message.get("tool_call_id") or "") for message in self.messages if message.get("role") == "tool"}
            for message in list(self.messages):
                if message.get("role") != "assistant":
                    continue
                for call in message.get("tool_calls") or []:
                    call_id = str(call.get("id") or "") if isinstance(call, dict) else ""
                    if call_id and call_id not in completed:
                        self.messages.append({
                            "role": "tool", "tool_call_id": call_id,
                            "content": "Tool call was interrupted; its result is unknown. Check the workspace before retrying it.",
                        })
                        completed.add(call_id)
        else:
            self._record_memory_event(
                "user_message",
                {
                    "content": user_message,
                    "display_text": display_text,
                    "mode": self.mode,
                    "model": self.model,
                    "provider": self.provider,
                },
                actor="user",
                session_id=session_id,
                tags=["user", "message"],
            )

            # A resumed request uses the existing turn and its checkpoint.
            if self.rollback_manager:
                self.current_checkpoint_id = self.rollback_manager.create_pre_question_checkpoint(
                    session_id=session_id,
                    messages=self.messages,
                    question=display_text
                )
            self.messages.append({"role": "user", "content": user_message})
            if self.operation_history:
                self.operation_history.add_user_question(
                    question=display_text,
                    message_index=len(self.messages) - 1,
                    checkpoint_id=self.current_checkpoint_id
                )
            self._reset_think_tool_budget()

        # Call model with tools
        self._pending_stream_state = None
        try:
            self._check_and_compress_context(session_id=session_id)
            if stream:
                yield from self._process_streaming(session_id=session_id)
                # Safety net: no provider path may end a turn whose last history
                # entry is a tool result. The per-provider loops already retry an
                # output-less turn; this covers every other way a loop can exit
                # without the model having said anything.
                notice = self._record_unsummarized_turn(session_id=session_id)
                if notice:
                    yield notice
            else:
                response = self._process_non_streaming(session_id=session_id)
                control = getattr(self, "desktop_control", None)
                if control is not None:
                    control.check_cancel()
                notice = self._record_unsummarized_turn(session_id=session_id)
                if notice:
                    response = f"{response}\n{notice}" if response else notice
                yield response
        except Exception as e:
            control = getattr(self, "desktop_control", None)
            if control is not None and control.cancelled.is_set():
                e = RuntimeError("Run stopped by user; check completed actions before continuing.")
            humanized = self._humanize_turn_error(e)
            error_msg = f"Error processing message: {humanized or str(e)}"
            self._record_memory_event(
                "error",
                {
                    "message": error_msg,
                    "error": str(e),
                    "mode": self.mode,
                    "model": self.model,
                    "provider": self.provider,
                },
                actor="agent",
                session_id=session_id,
                tags=["error", "turn"],
            )
            failed_event = self._model_stream_failed_event(e)
            if failed_event:
                yield failed_event
            yield error_msg
        finally:
            pending = self._pending_stream_state
            self._pending_stream_state = None
            if pending is not None and pending.collected_thinking:
                # A failed/cancelled stream can have already shown a real trace.
                # Retain it without turning unfinished tool arguments into calls.
                self.messages.append(_build_assistant_history_message(None, reasoning_content=pending.collected_thinking))
                self._persist_history_to_session()
            self._cleanup_completed_task_artifacts()

    def _cleanup_completed_task_artifacts(self) -> None:
        """Keep task drawer artifacts from lingering after a completed turn."""
        try:
            cleanup_completed_task_artifacts(self.project_root)
        except Exception:
            logger.debug("Completed task artifact cleanup failed", exc_info=True)
    
    def _process_streaming(self, session_id: str = "default") -> Generator[str, None, None]:
        """Process with streaming response"""
        if self._api_compatibility_enabled():
            yield from self._process_api_compatibility(session_id=session_id)
            return
        if self.provider == "openai-chat":
            if self._should_use_openai_http_fallback():
                yield from self._process_streaming_openai_http_fallback(session_id=session_id)
            else:
                yield from self._process_streaming_openai_sdk(session_id=session_id)
        elif self.provider == "openai-responses":
            yield from self._process_streaming_openai_responses(session_id=session_id)
        elif self.provider == "request":
            yield from self._process_streaming_request(session_id=session_id)
        elif self.provider == "curl":
            if self._curl_uses_responses():
                yield from self._process_streaming_openai_responses(session_id=session_id, use_curl=True)
            else:
                yield from self._process_streaming_request(session_id=session_id)
        elif self.provider == "anthropic":
            yield from self._process_streaming_anthropic(session_id=session_id)
        elif self.provider == "codex":
            yield from self._process_streaming_native_provider("codex", session_id=session_id)
        elif self.provider == "webgemini":
            yield from self._process_streaming_webgemini(session_id=session_id)
        else:
            raise ValueError(f"Unknown provider: {self.provider}")

    def _build_openai_responses_payload(
        self, *, stream: bool, messages: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """Build a minimal, provider-neutral OpenAI Responses request."""
        from ..codex import build_codex_request_payload

        tools = self.get_visible_tool_schemas()
        converted = build_codex_request_payload(
            model_name=self.model,
            messages=self._resolve_messages_for_request(messages if messages is not None else self._build_messages()),
            tools=tools or None,
            stream=stream,
        )
        payload: Dict[str, Any] = {
            "model": converted["model"],
            "input": converted["input"],
            "stream": bool(stream),
        }
        if converted.get("tools"):
            payload["tools"] = converted["tools"]
            tool_choice = self._native_tool_choice(tools)
            if tool_choice:
                tool_name = str((tool_choice.get("function", {}) or {}).get("name", "") or "").strip()
                if tool_name:
                    payload["tool_choice"] = {"type": "function", "name": tool_name}
        if self._is_active_model_source("opencode"):
            # Muse Spark is exposed by Zen through Responses rather than chat
            # completions.  The Responses field is the equivalent of the
            # OpenAI-compatible `max_tokens` option used by chat models.
            try:
                options = build_opencode_openai_options(
                    getattr(self.config, "opencode", {}),
                    self.model,
                )
            except Exception:
                logger.debug("Could not build OpenCode Responses options", exc_info=True)
                options = {}
            max_output_tokens = options.get("max_tokens")
            if max_output_tokens:
                payload["max_output_tokens"] = max_output_tokens
        elif self._is_active_model_source("custom"):
            # `build_codex_request_payload` reasons for Codex's own account; a
            # custom provider gets its own resolved depth instead.
            try:
                options = build_custom_provider_responses_options(
                    getattr(self.config, "custom_providers", {}),
                    model_id=self.model,
                )
            except Exception:
                logger.debug("Could not build custom provider Responses options", exc_info=True)
                options = {}
            for key in ("reasoning", "include", "max_output_tokens"):
                value = options.get(key)
                if value:
                    payload[key] = value
        return apply_openai_prompt_cache(payload, namespace="agent-responses")

    def _create_openai_response(self, payload: Dict[str, Any]) -> Any:
        """Create an OpenAI Responses call with a cache-hint compatibility fallback."""
        client = self._ensure_client()
        return self._retry_provider_call(lambda: call_with_prompt_cache_fallback(
            client.responses.create, payload, log=logger,
        ))

    def _retry_provider_call(self, call):
        """One interruptible retry policy for SDK calls before output begins."""
        for attempt in range(self.api_max_retries + 1):
            check_cancel()
            try:
                return call()
            except Exception as exc:
                check_cancel()
                status = getattr(exc, "status_code", None)
                transient = _is_provider_rate_limit(status, exc) or isinstance(status, int) and 500 <= status < 600
                if attempt == self.api_max_retries or not (transient or _is_recoverable_stream_exception(exc)):
                    raise
                interruptible_sleep(_api_retry_delay(attempt, self.api_initial_backoff, exc))

    @contextmanager
    def _provider_stream_context(self, factory):
        with ExitStack() as stack:
            stream = self._retry_provider_call(lambda: stack.enter_context(factory()))
            yield stream

    def _response_json_with_prompt_cache_fallback(
        self,
        response: Any,
        payload: Dict[str, Any],
        session_id: str = "default",
    ) -> Any:
        """Read a direct response, retrying a rejected cache hint once."""
        try:
            return response.json()
        except Exception as exc:
            if not has_prompt_cache_hints(payload) or not is_prompt_cache_rejection(exc):
                raise
            self._close_stream_response(response)
            logger.warning("Provider rejected prompt-cache hints; retrying once without them")
            fallback = self._make_direct_request(
                without_prompt_cache(payload),
                stream=False,
                session_id=session_id,
            )
            return fallback.json()

    def _iter_openai_responses_sdk_events(self, response: Any) -> Generator[Dict[str, Any], None, None]:
        """Translate OpenAI SDK Responses events to Reverie's shared event shape."""
        from ..codex import parse_codex_sse_event

        parser_state: Dict[str, Any] = {}
        for sdk_event in response:
            if isinstance(sdk_event, dict):
                event_data = sdk_event
            elif hasattr(sdk_event, "model_dump"):
                event_data = sdk_event.model_dump()
            else:
                continue
            events, parser_state = parse_codex_sse_event(
                json.dumps(event_data, ensure_ascii=False),
                parser_state,
            )
            for event in events:
                yield event

    def _iter_curl_responses_events(self, response: Any) -> Generator[Dict[str, Any], None, None]:
        """Translate Responses SSE emitted by curl to Reverie's shared event shape."""
        from ..codex import parse_codex_sse_event

        parser_state: Dict[str, Any] = {}
        for data_str in self._iter_sse_data_strings(response):
            events, parser_state = parse_codex_sse_event(data_str, parser_state)
            for event in events:
                yield event

    def _process_streaming_openai_responses(
        self,
        session_id: str = "default",
        *,
        use_curl: bool = False,
    ) -> Generator[str, None, None]:
        """Process a turn through OpenAI Responses using the SDK or system curl."""
        max_continuations = self._completion_continuation_limit()
        continuation_count = 0
        empty_turn_count = 0
        direct_http = use_curl or self._is_active_model_source("opencode")

        while True:
            self._check_and_compress_context(session_id=session_id)
            request_messages = self._build_messages()
            messages = self._resolve_messages_for_request(request_messages)
            payload = self._build_openai_responses_payload(stream=True, messages=messages)
            effective_timeout = self._resolve_provider_timeout()
            yield self._model_request_stream_event(
                provider_label=self._responses_provider_label(use_curl=direct_http),
                model=self.model,
                stream=True,
                timeout=effective_timeout,
            )

            if direct_http:
                response = self._make_direct_request(payload, stream=True, session_id=session_id)
                events = self._iter_curl_responses_events(response)
            else:
                response = self._create_openai_response(payload)
                events = self._iter_openai_responses_sdk_events(response)

            state = self._new_turn_state()
            try:
                for event in events:
                    yield from self._apply_stream_event(state, event)
            except Exception as exc:
                if (
                    direct_http
                    and not _stream_state_has_partial_output(state)
                    and has_prompt_cache_hints(payload)
                    and is_prompt_cache_rejection(exc)
                ):
                    self._close_stream_response(response)
                    logger.warning("Provider rejected prompt-cache hints; retrying stream once without them")
                    response = self._make_direct_request(
                        without_prompt_cache(payload),
                        stream=True,
                        session_id=session_id,
                    )
                    for event in self._iter_curl_responses_events(response):
                        yield from self._apply_stream_event(state, event)
                else:
                    raise
            finally:
                for chunk in state.flush():
                    yield chunk
                self._close_stream_response(response)

            outcome, _ = self._commit_stream_state(
                state=state,
                request_messages=request_messages,
                messages=messages,
                session_id=session_id,
            )
            if outcome == "tool_calls":
                yield from self._execute_streamed_tool_calls(state.tool_calls, messages, session_id=session_id)
                continue
            if outcome == "retry_direct_prose":
                continuation_count += 1
                if continuation_count >= max_continuations:
                    break
                continue
            if outcome == "content":
                break

            empty_turn_count += 1
            if self._recover_empty_model_turn(messages, attempt=empty_turn_count):
                continue

            notice = self._record_unsummarized_turn(
                session_id=session_id,
            )
            if notice:
                yield notice
            break

    def _process_streaming_openai_sdk(self, session_id: str = "default") -> Generator[str, None, None]:
        """Process with streaming response using OpenAI SDK"""
        max_continuations = self._completion_continuation_limit()
        continuation_count = 0
        empty_turn_count = 0

        while True:
            self._check_and_compress_context(session_id=session_id)
            tools = self.get_visible_tool_schemas()
            request_messages = self._build_messages()
            messages = self._resolve_messages_for_request(request_messages)
            effective_timeout = self._resolve_provider_timeout()
            # For OpenAI-compatible SDK calls, include thinking flags via extra_body when applicable
            provider_options: Dict[str, Any] = {}
            model_for_sdk = self.model
            if self._is_active_model_source("nvidia"):
                provider_options = build_nvidia_openai_options(
                    getattr(self.config, "nvidia", {}),
                    model_for_sdk,
                    messages=messages,
                )
                option_model = str(provider_options.get("model", "") or "").strip()
                if option_model:
                    model_for_sdk = option_model
                # For NVIDIA models, use NVIDIA-specific extra_body (don't merge with generic thinking)
                extra_body = provider_options.get("extra_body")
            elif self._is_active_model_source("aihubmix"):
                provider_options = build_aihubmix_openai_options(
                    getattr(self.config, "aihubmix", {}),
                    model_for_sdk,
                )
                extra_body = None
            elif self._is_active_model_source("opencode"):
                provider_options = build_opencode_openai_options(
                    getattr(self.config, "opencode", {}),
                    model_for_sdk,
                )
                extra_body = provider_options.get("extra_body")
            elif self._is_active_model_source("modelscope"):
                provider_options = build_modelscope_openai_options(
                    getattr(self.config, "modelscope", {}),
                    model_for_sdk,
                )
                extra_body = provider_options.get("extra_body")
            elif self._is_active_model_source("agnes"):
                provider_options = build_agnes_openai_options(
                    getattr(self.config, "agnes", {}),
                    model_for_sdk,
                )
                extra_body = provider_options.get("extra_body")
            elif self._is_active_model_source("sensenova"):
                provider_options = build_sensenova_openai_options(
                    getattr(self.config, "sensenova", {}),
                    model_for_sdk,
                )
                extra_body = provider_options.get("extra_body")
            elif self._is_active_model_source("custom"):
                provider_options = build_custom_provider_openai_options(
                    getattr(self.config, "custom_providers", {}),
                    model_id=model_for_sdk,
                )
                # The provider's own reasoning union already covers every dialect
                # the generic thinking hint would have sent, and it carries the
                # resolved depth as well.
                extra_body = provider_options.get("extra_body")
            else:
                extra_body = self._openai_extra_body_for_thinking()
            if extra_body is not None and isinstance(model_for_sdk, str) and "(" in model_for_sdk and ")" in model_for_sdk:
                # Strip depth suffix for ordinary SDK calls — only send boolean thinking
                model_for_sdk = model_for_sdk.split("(", 1)[0].strip()
            if self._is_active_model_source("nvidia") and nvidia_model_requires_system_message_first(model_for_sdk):
                messages = _coalesce_system_messages_to_front(messages)
            elif messages:
                messages = _coalesce_system_messages_to_front(messages)
            if self._is_active_model_source("nvidia"):
                provider_options = self._clamp_nvidia_options_for_messages(
                    provider_options,
                    model_id=model_for_sdk,
                    messages=messages,
                    tools=tools if tools else None,
                )
            yield self._model_request_stream_event(
                provider_label=self._openai_sdk_provider_label(),
                model=model_for_sdk,
                stream=True,
                timeout=effective_timeout,
            )
            if extra_body is not None:
                tool_choice = self._native_tool_choice(tools) if tools else None
                response = self._create_openai_chat_completion(
                    model=model_for_sdk,
                    messages=messages,
                    tools=tools if tools else None,
                    stream=True,
                    timeout=effective_timeout,
                    extra_body=extra_body,
                    **({"tool_choice": tool_choice} if tool_choice else {}),
                    **{
                        key: value
                        for key, value in {
                            "temperature": provider_options.get("temperature"),
                            "top_p": provider_options.get("top_p"),
                            "presence_penalty": provider_options.get("presence_penalty"),
                            "max_tokens": provider_options.get("max_tokens"),
                        }.items()
                        if value is not None
                    },
                )
            else:
                tool_choice = self._native_tool_choice(tools) if tools else None
                response = self._create_openai_chat_completion(
                    model=model_for_sdk,
                    messages=messages,
                    tools=tools if tools else None,
                    stream=True,
                    timeout=effective_timeout,
                    **({"tool_choice": tool_choice} if tool_choice else {}),
                    **{
                        key: value
                        for key, value in {
                            "temperature": provider_options.get("temperature"),
                            "top_p": provider_options.get("top_p"),
                            "presence_penalty": provider_options.get("presence_penalty"),
                            "max_tokens": provider_options.get("max_tokens"),
                        }.items()
                        if value is not None
                    },
                )
            state = self._new_turn_state()
            try:
                for event in self._iter_openai_sdk_stream_events(response):
                    yield from self._apply_stream_event(state, event)
            except Exception as exc:
                if _should_recover_partial_stream_error(state, exc):
                    logger.warning("Recovered partial streaming output after OpenAI-compatible interruption: %s", exc)
                    state.set_finish_reason("interrupted")
                else:
                    raise
            finally:
                for chunk in state.flush():
                    yield chunk
                self._close_stream_response(response)

            outcome, _ = self._commit_stream_state(
                state=state,
                request_messages=request_messages,
                messages=messages,
                session_id=session_id,
            )

            if outcome == "tool_calls":
                yield from self._execute_streamed_tool_calls(
                    state.tool_calls,
                    messages,
                    session_id=session_id,
                )
                continuation_count = 0
                continue

            if outcome == "retry_direct_prose":
                continuation_count += 1
                if continuation_count >= max_continuations:
                    break

                messages = self._build_messages(resolve_local_images=True)
                continue

            if outcome == "content":
                if self._should_end_generation(state.collected_content, state.finish_reason):
                    break

                continuation_count += 1
                if continuation_count >= max_continuations:
                    break

                messages = self._build_messages(resolve_local_images=True)
                continue

            empty_turn_count += 1
            if self._recover_empty_model_turn(messages, attempt=empty_turn_count):
                messages = self._build_messages(resolve_local_images=True)
                continue

            notice = self._record_unsummarized_turn(
                session_id=session_id,
            )
            if notice:
                yield notice
            break

    def _process_streaming_request(self, session_id: str = "default") -> Generator[str, None, None]:
        """Process with streaming response using requests library"""
        import requests

        max_continuations = self._completion_continuation_limit()
        continuation_count = 0
        empty_turn_count = 0

        while True:
            self._check_and_compress_context(session_id=session_id)
            tools = self.get_visible_tool_schemas()
            request_messages = self._build_messages()
            messages = self._resolve_messages_for_request(request_messages)
            if self._openai_request_fallback_active:
                payload = self._build_openai_chat_completion_kwargs(
                    messages=messages,
                    tools=tools,
                    stream=True,
                )
            else:
                payload = {
                    "model": self.model,
                    "messages": messages,
                    "stream": True,
                }

                if tools:
                    payload["tools"] = tools
                    tool_choice = self._native_tool_choice(tools)
                    if tool_choice:
                        payload["tool_choice"] = tool_choice
            payload = self._prepare_request_payload(payload, session_id=session_id)
            # Make request with retry logic.
            # Streaming request-provider calls can take longer for large outputs,
            # so we respect the provider timeout resolution here.
            effective_timeout = self._resolve_provider_timeout()
            yield self._model_request_stream_event(
                provider_label=self._request_provider_label(),
                model=payload.get("model", self.model),
                stream=True,
                timeout=effective_timeout,
            )
            try:
                response = self._make_direct_request(payload, stream=True, session_id=session_id)
            except (requests.RequestException, RuntimeError) as e:
                logger.error(f"Streaming API request failed: {e}")
                raise
            
            state = self._new_turn_state()
            provider_label = self._request_provider_label()

            try:
                for event in self._iter_request_stream_events(response, provider_label):
                    yield from self._apply_stream_event(state, event)
            except Exception as exc:
                if (
                    not _stream_state_has_partial_output(state)
                    and has_prompt_cache_hints(payload)
                    and is_prompt_cache_rejection(exc)
                ):
                    self._close_stream_response(response)
                    logger.warning("Provider rejected prompt-cache hints; retrying stream once without them")
                    response = self._make_direct_request(
                        without_prompt_cache(payload),
                        stream=True,
                        session_id=session_id,
                    )
                    for event in self._iter_request_stream_events(response, provider_label):
                        yield from self._apply_stream_event(state, event)
                elif _should_recover_partial_stream_error(state, exc):
                    logger.warning("Recovered partial streaming output after %s interruption: %s", provider_label, exc)
                    state.set_finish_reason("interrupted")
                else:
                    raise
            finally:
                for chunk in state.flush():
                    yield chunk
                self._close_stream_response(response)

            outcome, _ = self._commit_stream_state(
                state=state,
                request_messages=request_messages,
                messages=messages,
                session_id=session_id,
            )

            if outcome == "tool_calls":
                yield from self._execute_streamed_tool_calls(
                    state.tool_calls,
                    messages,
                    session_id=session_id,
                )
                continuation_count = 0
                continue

            if outcome == "retry_direct_prose":
                continuation_count += 1
                if continuation_count >= max_continuations:
                    break

                messages = self._build_messages(resolve_local_images=True)
                continue

            if outcome == "content":
                if self._should_end_generation(state.collected_content, state.finish_reason):
                    break

                continuation_count += 1
                if continuation_count >= max_continuations:
                    break

                messages = self._build_messages(resolve_local_images=True)
                continue

            empty_turn_count += 1
            if self._recover_empty_model_turn(messages, attempt=empty_turn_count):
                messages = self._build_messages(resolve_local_images=True)
                continue

            notice = self._record_unsummarized_turn(
                session_id=session_id,
            )
            if notice:
                yield notice
            break

    def _process_streaming_anthropic(self, session_id: str = "default") -> Generator[str, None, None]:
        """Process with streaming response using Anthropic SDK"""
        max_continuations = self._completion_continuation_limit()
        continuation_count = 0
        empty_turn_count = 0

        while True:
            self._check_and_compress_context(session_id=session_id)
            tools = self.get_visible_tool_schemas()
            anthropic_tools = _convert_tools_to_anthropic_format(tools)
            request_messages = self._build_messages()
            messages = self._resolve_messages_for_request(request_messages)
            system_message, anthropic_messages = _convert_messages_to_anthropic_format(messages)
            # Build kwargs for Anthropic API
            kwargs = {
                "model": self.model,
                "messages": anthropic_messages,
                "max_tokens": self._resolve_anthropic_max_tokens(),
            }
            
            if system_message:
                kwargs["system"] = system_message
            
            if anthropic_tools:
                kwargs["tools"] = anthropic_tools
                tool_choice = self._anthropic_tool_choice(tools)
                if tool_choice:
                    kwargs["tool_choice"] = tool_choice
            kwargs = self._apply_sensenova_anthropic_options(kwargs)
            kwargs = self._apply_custom_provider_anthropic_options(kwargs)
            if self._is_active_model_source("opencode"):
                kwargs["extra_headers"] = build_opencode_request_headers_from_config(
                    getattr(self.config, "opencode", {}), session_id=session_id)
            kwargs = apply_anthropic_prompt_cache(kwargs)
            
            # Make request
            client = self._ensure_client()
            with self._provider_stream_context(lambda: anthropic_stream_with_prompt_cache_fallback(
                client.messages.stream, kwargs, log=logger,
            )) as stream:
                state = self._new_turn_state()

                for event in stream:
                    if event.type == "content_block_delta" and hasattr(event.delta, "type"):
                        if event.delta.type == "thinking_delta" and hasattr(event.delta, "thinking"):
                            yield from self._apply_stream_event(
                                state,
                                {"type": "reasoning", "text": event.delta.thinking},
                            )
                        elif event.delta.type == "text_delta" and hasattr(event.delta, "text"):
                            yield from self._apply_stream_event(
                                state,
                                {"type": "content", "text": event.delta.text},
                            )
                    elif event.type == "message_stop":
                        break

                for chunk in state.flush():
                    yield chunk
                
                # Get final message for tool calls
                final_message = stream.get_final_message()
                state.set_finish_reason(getattr(final_message, "stop_reason", None))
                
                # Check for tool use blocks
                tool_use_blocks = [block for block in final_message.content if block.type == "tool_use"]
                
                for block in tool_use_blocks:
                    state.update_tool_call(
                        len(state.tool_calls),
                        tool_call_id=block.id,
                        name=block.name,
                        arguments=json.dumps(block.input),
                    )

                outcome, _ = self._commit_stream_state(
                    state=state,
                    request_messages=request_messages,
                    messages=messages,
                    session_id=session_id,
                    usage=getattr(final_message, "usage", None),
                )
                thinking_blocks = [block.model_dump(include={"type", "thinking", "signature", "data"}, exclude_none=True) for block in final_message.content if block.type in {"thinking", "redacted_thinking"}]
                if thinking_blocks and outcome in {"tool_calls", "content"}:
                    self.messages[-1]["anthropic_thinking"] = thinking_blocks

                if outcome == "tool_calls":
                    yield from self._execute_streamed_tool_calls(
                        state.tool_calls,
                        messages,
                        session_id=session_id,
                    )
                    continuation_count = 0
                    continue

                if outcome == "retry_direct_prose":
                    continuation_count += 1
                    if continuation_count >= max_continuations:
                        break

                    system_message, anthropic_messages = _convert_messages_to_anthropic_format(self._build_messages())
                    continue

                if outcome == "content":
                    if self._should_end_generation(state.collected_content, state.finish_reason):
                        break

                    continuation_count += 1
                    if continuation_count >= max_continuations:
                        break

                    system_message, anthropic_messages = _convert_messages_to_anthropic_format(self._build_messages())
                    continue

                empty_turn_count += 1
                if self._recover_empty_model_turn(messages, attempt=empty_turn_count):
                    system_message, anthropic_messages = _convert_messages_to_anthropic_format(self._build_messages())
                    continue

                notice = self._record_unsummarized_turn(
                    session_id=session_id,
                )
                if notice:
                    yield notice

            break

    def _process_non_streaming(self, session_id: str = "default") -> str:
        """Process without streaming"""
        if self._api_compatibility_enabled():
            return self._collect_non_streaming_output(self._process_api_compatibility(session_id=session_id))
        if self.provider == "openai-chat":
            if self._should_use_openai_http_fallback():
                return self._process_non_streaming_openai_http_fallback(session_id=session_id)
            return self._process_non_streaming_openai_sdk(session_id=session_id)
        elif self.provider == "openai-responses":
            return self._process_non_streaming_openai_responses(session_id=session_id)
        elif self.provider == "request":
            return self._process_non_streaming_request(session_id=session_id)
        elif self.provider == "curl":
            if self._curl_uses_responses():
                return self._process_non_streaming_openai_responses(session_id=session_id, use_curl=True)
            return self._process_non_streaming_request(session_id=session_id)
        elif self.provider == "anthropic":
            return self._process_non_streaming_anthropic(session_id=session_id)
        elif self.provider == "codex":
            return self._process_non_streaming_native_provider("codex", session_id=session_id)
        elif self.provider == "webgemini":
            return self._process_non_streaming_webgemini(session_id=session_id)
        else:
            raise ValueError(f"Unknown provider: {self.provider}")

    def _api_compatibility_enabled(self) -> bool:
        return bool(getattr(getattr(self, "config", None), "api_compatibility", False)) and self.provider in {
            "openai-chat", "openai-responses", "anthropic", "request", "curl",
        }

    def _process_api_compatibility(self, session_id: str = "default") -> Generator[str, None, None]:
        """Use text-only non-streaming requests and the normal reviewed tool executor."""
        continuation_count = 0
        while True:
            check_cancel()
            self._check_and_compress_context(session_id=session_id)
            tools = self.get_visible_tool_schemas()
            messages = self._build_messages()
            request_messages = build_compatibility_messages(messages, tools)
            payload = {"model": self.model, "stream": False, "messages": request_messages,
                       "max_tokens": self._resolve_anthropic_max_tokens()}
            self._emit_ui_event(category="Model", message=f"Waiting for {self._request_provider_label()} response",
                                status="working", detail=f"{self.model} | non-stream")
            responses_format = self.provider == "openai-responses" or (self.provider == "curl" and self._curl_uses_responses())
            if responses_format:
                payload["input"] = payload.pop("messages")
                payload["max_output_tokens"] = payload.pop("max_tokens")
            if self.provider == "openai-chat" and self._should_use_openai_http_fallback():
                original_base_url = self.base_url
                try:
                    self.base_url = self._resolve_openai_request_url()
                    response = self._make_direct_request(payload, stream=False, session_id=session_id)
                finally:
                    self.base_url = original_base_url
                try:
                    data = response.json()
                finally:
                    self._close_stream_response(response)
            elif self.provider in {"request", "curl"}:
                response = self._make_direct_request(payload, stream=False, session_id=session_id)
                try:
                    data = response.json()
                finally:
                    self._close_stream_response(response)
            else:
                client = self._ensure_client()
                if self.provider == "anthropic":
                    response = self._retry_provider_call(lambda: client.messages.create(**payload))
                elif responses_format:
                    response = self._retry_provider_call(lambda: client.responses.create(**payload))
                else:
                    if self._is_active_model_source("nvidia"):
                        _wait_for_nvidia_rate_limit()
                    response = self._retry_provider_call(lambda: self._call_openai_chat_completion_once(payload))
                data = response.model_dump()
            usage = data.get("usage")
            if self.provider == "anthropic":
                raw = "".join(block.get("text", "") for block in data.get("content", []) if block.get("type") == "text")
                truncated = data.get("stop_reason") == "max_tokens"
            elif responses_format:
                state, _ = self._responses_result_state(data)
                raw = state.cleaned_content()
                truncated = data.get("status") == "incomplete"
            else:
                choice = (data.get("choices") or [{}])[0]
                raw = _coerce_text_fragments((choice.get("message") or {}).get("content"))
                truncated = choice.get("finish_reason") == "length"
            try:
                if truncated:
                    raise ValueError("API compatibility response was truncated; no tool actions were executed.")
                content, calls = parse_compatibility_reply(raw, tools)
            except ValueError:
                self._record_model_usage(request_messages=request_messages, assistant_text=raw,
                                         usage=usage, session_id=session_id)
                raise
            state = self._new_turn_state()
            state.collected_content = content
            state.tool_calls = calls
            outcome, content = self._commit_stream_state(state=state, request_messages=request_messages,
                                                         messages=messages, session_id=session_id, usage=usage)
            if content:
                yield content
            if outcome == "tool_calls":
                yield from self._execute_streamed_tool_calls(state.tool_calls, messages, session_id=session_id)
                self._persist_history_to_session()
                continue
            if outcome == "retry_direct_prose":
                continuation_count += 1
                if continuation_count >= self._completion_continuation_limit():
                    break
                continue
            break

    def _responses_result_state(self, result: Any) -> tuple[_StreamingTurnState, Any]:
        """Extract text, tool calls, and usage from one non-streaming Responses result."""
        data = result if isinstance(result, dict) else result.model_dump()
        state = _StreamingTurnState()
        for item in data.get("output", []) or []:
            item_type = str(item.get("type", "") or "").strip().lower()
            if item_type == "reasoning":
                # Codex returns a summary, other Responses gateways return the raw
                # trace under ``content``; either one is the thinking to surface.
                for key in ("summary", "content"):
                    for part in item.get(key, []) or []:
                        if isinstance(part, dict):
                            state.add_reasoning(part.get("text", ""))
                        elif isinstance(part, str):
                            state.add_reasoning(part)
                continue
            if item_type == "message":
                for part in item.get("content", []) or []:
                    part_type = str(part.get("type", "") or "").strip().lower()
                    if part_type in {"output_text", "text"}:
                        state.add_content(part.get("text", ""))
                continue
            if item_type == "function_call":
                state.update_tool_call(
                    len(state.tool_calls),
                    tool_call_id=str(item.get("call_id", "") or item.get("id", "")).strip(),
                    name=str(item.get("name", "") or "").strip(),
                    arguments=str(item.get("arguments", "") or ""),
                )
        state.flush()
        state.set_finish_reason("tool_calls" if state.tool_calls else "stop")
        return state, data.get("usage")

    def _process_non_streaming_openai_responses(
        self,
        session_id: str = "default",
        *,
        use_curl: bool = False,
    ) -> str:
        """Process non-streaming Responses calls through the SDK or system curl."""
        all_content: List[str] = []
        max_continuations = self._completion_continuation_limit()
        continuation_count = 0
        empty_turn_count = 0
        direct_http = use_curl or self._is_active_model_source("opencode")
        while True:
            self._check_and_compress_context(session_id=session_id)
            request_messages = self._build_messages()
            messages = self._resolve_messages_for_request(request_messages)
            payload = self._build_openai_responses_payload(stream=False, messages=messages)
            if direct_http:
                response = self._make_direct_request(payload, stream=False, session_id=session_id)
                result = self._response_json_with_prompt_cache_fallback(
                    response,
                    payload,
                    session_id=session_id,
                )
            else:
                result = self._create_openai_response(payload)
            state, usage = self._responses_result_state(result)
            outcome, content = self._commit_stream_state(
                state=state,
                request_messages=request_messages,
                messages=messages,
                session_id=session_id,
                usage=usage,
            )
            if content:
                all_content.append(content)
            if outcome == "tool_calls":
                for _ in self._execute_streamed_tool_calls(state.tool_calls, messages, session_id=session_id):
                    pass
                continue
            if outcome == "retry_direct_prose":
                continuation_count += 1
                if continuation_count >= max_continuations:
                    break
                continue
            if outcome == "content":
                break

            empty_turn_count += 1
            if self._recover_empty_model_turn(messages, attempt=empty_turn_count):
                continue

            notice = self._record_unsummarized_turn(
                session_id=session_id,
            )
            if notice:
                all_content.append(notice)
            break
        return "\n".join(all_content)

    def _process_non_streaming_openai_sdk(self, session_id: str = "default") -> str:
        """Process without streaming using OpenAI SDK"""
        all_content = []
        empty_turn_count = 0

        while True:
            self._check_and_compress_context(session_id=session_id)
            tools = self.get_visible_tool_schemas()
            request_messages = self._build_messages()
            messages = self._resolve_messages_for_request(request_messages)
            effective_timeout = self._resolve_provider_timeout()
            # For OpenAI-compatible SDK calls, include thinking flags via extra_body when applicable
            provider_options: Dict[str, Any] = {}
            model_for_sdk = self.model
            if self._is_active_model_source("nvidia"):
                provider_options = build_nvidia_openai_options(
                    getattr(self.config, "nvidia", {}),
                    model_for_sdk,
                    messages=messages,
                )
                option_model = str(provider_options.get("model", "") or "").strip()
                if option_model:
                    model_for_sdk = option_model
                # For NVIDIA models, use NVIDIA-specific extra_body (don't merge with generic thinking)
                extra_body = provider_options.get("extra_body")
            elif self._is_active_model_source("aihubmix"):
                provider_options = build_aihubmix_openai_options(
                    getattr(self.config, "aihubmix", {}),
                    model_for_sdk,
                )
                extra_body = None
            elif self._is_active_model_source("opencode"):
                provider_options = build_opencode_openai_options(
                    getattr(self.config, "opencode", {}),
                    model_for_sdk,
                )
                extra_body = provider_options.get("extra_body")
            elif self._is_active_model_source("modelscope"):
                provider_options = build_modelscope_openai_options(
                    getattr(self.config, "modelscope", {}),
                    model_for_sdk,
                )
                extra_body = provider_options.get("extra_body")
            elif self._is_active_model_source("agnes"):
                provider_options = build_agnes_openai_options(
                    getattr(self.config, "agnes", {}),
                    model_for_sdk,
                )
                extra_body = provider_options.get("extra_body")
            elif self._is_active_model_source("sensenova"):
                provider_options = build_sensenova_openai_options(
                    getattr(self.config, "sensenova", {}),
                    model_for_sdk,
                )
                extra_body = provider_options.get("extra_body")
            elif self._is_active_model_source("custom"):
                provider_options = build_custom_provider_openai_options(
                    getattr(self.config, "custom_providers", {}),
                    model_id=model_for_sdk,
                )
                # The provider's own reasoning union already covers every dialect
                # the generic thinking hint would have sent, and it carries the
                # resolved depth as well.
                extra_body = provider_options.get("extra_body")
            else:
                extra_body = self._openai_extra_body_for_thinking()
            if extra_body is not None and isinstance(model_for_sdk, str) and "(" in model_for_sdk and ")" in model_for_sdk:
                # Strip depth suffix for ordinary SDK calls — only send boolean thinking
                model_for_sdk = model_for_sdk.split("(", 1)[0].strip()
            if self._is_active_model_source("nvidia") and nvidia_model_requires_system_message_first(model_for_sdk):
                messages = _coalesce_system_messages_to_front(messages)
            elif messages:
                messages = _coalesce_system_messages_to_front(messages)
            if self._is_active_model_source("nvidia"):
                provider_options = self._clamp_nvidia_options_for_messages(
                    provider_options,
                    model_id=model_for_sdk,
                    messages=messages,
                    tools=tools if tools else None,
                )
            self._emit_ui_event(
                category="Model",
                message=f"Waiting for {self._openai_sdk_provider_label()} response",
                status="working",
                detail=f"{model_for_sdk} | non-stream",
                meta=f"timeout {effective_timeout}s",
            )
            if extra_body is not None:
                response = self._create_openai_chat_completion(
                    model=model_for_sdk,
                    messages=messages,
                    tools=tools if tools else None,
                    stream=False,
                    timeout=effective_timeout,
                    extra_body=extra_body,
                    **{
                        key: value
                        for key, value in {
                            "temperature": provider_options.get("temperature"),
                            "top_p": provider_options.get("top_p"),
                            "presence_penalty": provider_options.get("presence_penalty"),
                            "max_tokens": provider_options.get("max_tokens"),
                        }.items()
                        if value is not None
                    },
                )
            else:
                response = self._create_openai_chat_completion(
                    model=model_for_sdk,
                    messages=messages,
                    tools=tools if tools else None,
                    stream=False,
                    timeout=effective_timeout,
                    **{
                        key: value
                        for key, value in {
                            "temperature": provider_options.get("temperature"),
                            "top_p": provider_options.get("top_p"),
                            "presence_penalty": provider_options.get("presence_penalty"),
                            "max_tokens": provider_options.get("max_tokens"),
                        }.items()
                        if value is not None
                    },
                )
            choice = response.choices[0]
            message = choice.message
            message_content = _coerce_text_fragments(getattr(message, "content", None))
            message_reasoning = _extract_text_from_candidates(
                message,
                "reasoning_content",
                "thinking",
                "reasoning",
            )
            
            # Check for tool calls
            if message.tool_calls:
                history_tool_calls = _compact_tool_calls_for_history(
                    [
                        {
                            "id": tc.id,
                            "type": "function",
                            "function": {
                                "name": tc.function.name,
                                "arguments": tc.function.arguments,
                            },
                        }
                        for tc in message.tool_calls
                    ],
                    mode=self.mode,
                )
                # Add assistant message
                assistant_message = _build_assistant_history_message(
                    message_content or None,
                    tool_calls=history_tool_calls,
                    reasoning_content=message_reasoning,
                )
                self.messages.append(assistant_message)
                messages.append(assistant_message)
                self._record_model_usage(
                    request_messages=request_messages,
                    assistant_text=message_content,
                    reasoning_text=message_reasoning,
                    tool_calls=history_tool_calls,
                    usage=getattr(response, "usage", None),
                    session_id=session_id,
                )
                
                if message_content:
                    all_content.append(message_content)
                
                # Execute each tool
                for tool_call in message.tool_calls:
                    tool_name = tool_call.function.name
                    tool = self.tool_executor.get_tool(tool_name)
                    
                    args = parse_tool_arguments(tool_call.function.arguments)
                    
                    # Check side effects
                    self._check_tool_side_effects(tool_name, args)
                    
                    exec_msg = tool.get_execution_message(**args) if tool else f"Executing {tool_name}..."
                    self._emit_tool_stream_event(
                        "tool_start",
                        tool_name=tool_name,
                        message=exec_msg,
                        arguments=args,
                        tool_call_id=str(tool_call.id or ""),
                        agent_id=self.agent_id,
                        agent_color=self.agent_color,
                    )
                    
                    all_content.append(f"[bold #ffb8d1]✧[/bold #ffb8d1] [bold #e4b0ff]{rich_escape(exec_msg)}[/bold #e4b0ff]")
                    
                    result = self.tool_executor.execute(tool_name, args, tool_call_id=str(tool_call.id or ""))
                    self._emit_tool_stream_event(
                        "tool_result",
                        tool_name=tool_name,
                        message=exec_msg,
                        arguments=args,
                        tool_call_id=str(tool_call.id or ""),
                        success=bool(result.success),
                        output=str(result.output or ""),
                        error=str(result.error or ""),
                        status=str(getattr(result.status, "value", "success")),
                        agent_id=self.agent_id,
                        agent_color=self.agent_color,
                    )
                    
                    if result.success:
                        all_content.append(f"[bold #66bb6a]   ✔ Success[/bold #66bb6a]")
                    else:
                        all_content.append(f"[bold #ff5252]   ✘ Failed:[/bold #ff5252] [#ff8a80]{rich_escape(result.error or '')}[/#ff8a80]")
                    
                    # Add tool result
                    relay_tool_result_message = {
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": _tool_result_content(result)
                    }
                    self.messages.append({
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": _tool_result_history_content(result),
                    })
                    messages.append(relay_tool_result_message)
                    self._persist_history_to_session()
                
                # Continue to get response to tool results
                self._guard_think_tool_spin(message.tool_calls, messages)
                continue
            
            # No tool calls, final response check
            if message_content:
                content = message_content
                
                if self._should_end_generation(content, None):
                    clean_content = content.replace("//END//", "").strip()
                    self.messages.append(
                        _build_assistant_history_message(
                            clean_content,
                            reasoning_content=message_reasoning,
                        )
                    )
                    self._record_model_usage(
                        request_messages=request_messages,
                        assistant_text=clean_content,
                        reasoning_text=message_reasoning,
                        usage=getattr(response, "usage", None),
                        session_id=session_id,
                    )
                    all_content.append(clean_content) # Use clean content for return
                    break
                
                # Missing termination token - continue
                if self.messages and self.messages[-1].get("role") == "assistant" and "tool_calls" not in self.messages[-1]:
                    self.messages[-1]["content"] += content
                else:
                    self.messages.append(
                        _build_assistant_history_message(
                            content,
                            reasoning_content=message_reasoning,
                        )
                    )
                
                self._record_model_usage(
                    request_messages=request_messages,
                    assistant_text=content,
                    reasoning_text=message_reasoning,
                    usage=getattr(response, "usage", None),
                    session_id=session_id,
                )
                
                all_content.append(content)

                # Rebuild messages for next call
                messages = self._build_messages(resolve_local_images=True)
                continue

            self._record_model_usage(
                request_messages=request_messages,
                assistant_text="",
                usage=getattr(response, "usage", None),
                session_id=session_id,
            )
            empty_turn_count += 1
            if self._recover_empty_model_turn(messages, attempt=empty_turn_count):
                messages = self._build_messages(resolve_local_images=True)
                continue

            notice = self._record_unsummarized_turn(
                session_id=session_id,
            )
            if notice:
                all_content.append(notice)
            break

        return '\n'.join(all_content)

    def _process_non_streaming_request(self, session_id: str = "default") -> str:
        """Process without streaming using requests library"""
        import requests

        all_content = []
        empty_turn_count = 0

        while True:
            self._check_and_compress_context(session_id=session_id)
            tools = self.get_visible_tool_schemas()
            request_messages = self._build_messages()
            messages = self._resolve_messages_for_request(request_messages)
            if self._openai_request_fallback_active:
                payload = self._build_openai_chat_completion_kwargs(
                    messages=messages,
                    tools=tools,
                    stream=False,
                )
            else:
                payload = {
                    "model": self.model,
                    "messages": messages,
                    "stream": False,
                }

                if tools:
                    payload["tools"] = tools
            payload = self._prepare_request_payload(payload, session_id=session_id)
            # Make request with retry logic.
            # Long request-provider responses may need the provider timeout.
            effective_timeout = self._resolve_provider_timeout()
            try:
                response = self._make_direct_request(payload, stream=False, session_id=session_id)
            except (requests.RequestException, RuntimeError) as e:
                logger.error(f"API request failed: {e}")
                raise
            
            response_data = self._response_json_with_prompt_cache_fallback(
                response,
                payload,
                session_id=session_id,
            )
            provider_label = self._request_provider_label()
            _raise_for_wrapped_api_error(response_data, provider_label=provider_label)
            normalized_response = _unwrap_openai_compatible_payload(response_data) or response_data
            usage_payload = normalized_response.get("usage") if isinstance(normalized_response, dict) else None
            
            # Extract choice
            choices = normalized_response.get("choices", [])
            if not choices:
                raise ValueError(f"{provider_label} returned no choices in the response payload")
            
            choice = choices[0]
            message = choice.get("message", {})
            message_content = _extract_text_from_candidates(message, "content")
            message_reasoning = _extract_text_from_candidates(
                message,
                "reasoning_content",
                "thinking",
                "reasoning",
            )
            
            # Check for tool calls
            tool_calls = message.get("tool_calls", [])
            if tool_calls:
                # Sanitize incoming tool-call argument strings before storing
                _sanitize_tool_calls(tool_calls)
                history_tool_calls = _compact_tool_calls_for_history(tool_calls, mode=self.mode)
                # Add assistant message
                assistant_message = _build_assistant_history_message(
                    message_content or None,
                    tool_calls=history_tool_calls,
                    reasoning_content=message_reasoning,
                )
                self.messages.append(assistant_message)
                messages.append(assistant_message)
                self._record_model_usage(
                    request_messages=request_messages,
                    assistant_text=message_content,
                    reasoning_text=message_reasoning,
                    tool_calls=history_tool_calls,
                    usage=usage_payload,
                    session_id=session_id,
                )
                
                if message_content:
                    all_content.append(message_content)
                
                # Execute each tool
                for tool_call in tool_calls:
                    tool_name = tool_call["function"]["name"]
                    tool = self.tool_executor.get_tool(tool_name)
                    
                    args = parse_tool_arguments(tool_call["function"]["arguments"])
                    
                    self._check_tool_side_effects(tool_name, args)
                    
                    exec_msg = tool.get_execution_message(**args) if tool else f"Executing {tool_name}..."
                    self._emit_tool_stream_event(
                        "tool_start",
                        tool_name=tool_name,
                        message=exec_msg,
                        arguments=args,
                        tool_call_id=str(tool_call.get("id", "")).strip(),
                        agent_id=self.agent_id,
                        agent_color=self.agent_color,
                    )
                    all_content.append(f"[bold #ffb8d1]✧[/bold #ffb8d1] [bold #e4b0ff]{rich_escape(exec_msg)}[/bold #e4b0ff]")
                    
                    result = self.tool_executor.execute(
                        tool_name,
                        args,
                        tool_call_id=str(tool_call.get("id", "")).strip(),
                    )
                    self._emit_tool_stream_event(
                        "tool_result",
                        tool_name=tool_name,
                        message=exec_msg,
                        arguments=args,
                        tool_call_id=str(tool_call.get("id", "")).strip(),
                        success=bool(result.success),
                        output=str(result.output or ""),
                        error=str(result.error or ""),
                        status=str(getattr(result.status, "value", "success")),
                        agent_id=self.agent_id,
                        agent_color=self.agent_color,
                    )
                    
                    if result.success:
                        all_content.append(f"[bold #66bb6a]   ✔ Success[/bold #66bb6a]")
                    else:
                        all_content.append(f"[bold #ff5252]   ✘ Failed:[/bold #ff5252] [#ff8a80]{rich_escape(result.error or '')}[/#ff8a80]")
                    
                    relay_tool_result_message = {
                        "role": "tool",
                        "tool_call_id": tool_call["id"],
                        "content": _tool_result_content(result)
                    }
                    self.messages.append({
                        "role": "tool",
                        "tool_call_id": tool_call["id"],
                        "content": _tool_result_history_content(result),
                    })
                    messages.append(relay_tool_result_message)
                    self._persist_history_to_session()

                self._guard_think_tool_spin(tool_calls, messages)
                continue
            
            # No tool calls, final response check
            content = message_content
            if content:
                if self._should_end_generation(content, None):
                    clean_content = content.replace("//END//", "").strip()
                    self.messages.append(
                        _build_assistant_history_message(
                            clean_content,
                            reasoning_content=message_reasoning,
                        )
                    )
                    self._record_model_usage(
                        request_messages=request_messages,
                        assistant_text=clean_content,
                        reasoning_text=message_reasoning,
                        usage=usage_payload,
                        session_id=session_id,
                    )
                    all_content.append(clean_content)
                    break
                
                if self.messages and self.messages[-1].get("role") == "assistant" and "tool_calls" not in self.messages[-1]:
                    self.messages[-1]["content"] += content
                else:
                    self.messages.append(
                        _build_assistant_history_message(
                            content,
                            reasoning_content=message_reasoning,
                        )
                    )
                
                self._record_model_usage(
                    request_messages=request_messages,
                    assistant_text=content,
                    reasoning_text=message_reasoning,
                    usage=usage_payload,
                    session_id=session_id,
                )
                
                all_content.append(content)
                messages = self._build_messages(resolve_local_images=True)
                continue

            self._record_model_usage(
                request_messages=request_messages,
                assistant_text="",
                usage=usage_payload,
                session_id=session_id,
            )
            empty_turn_count += 1
            if self._recover_empty_model_turn(messages, attempt=empty_turn_count):
                messages = self._build_messages(resolve_local_images=True)
                continue

            notice = self._record_unsummarized_turn(
                session_id=session_id,
            )
            if notice:
                all_content.append(notice)
            break

        return '\n'.join(all_content)

    def _process_non_streaming_anthropic(self, session_id: str = "default") -> str:
        """Process without streaming using Anthropic SDK"""
        all_content = []
        empty_turn_count = 0
        continuation_count = 0

        while True:
            self._check_and_compress_context(session_id=session_id)
            tools = self.get_visible_tool_schemas()
            anthropic_tools = _convert_tools_to_anthropic_format(tools)
            messages = self._build_messages()
            request_messages = list(messages)
            system_message, anthropic_messages = _convert_messages_to_anthropic_format(messages)
            # Build kwargs for Anthropic API
            kwargs = {
                "model": self.model,
                "stream": False,
                "messages": anthropic_messages,
                "max_tokens": self._resolve_anthropic_max_tokens(),
            }
            
            if system_message:
                kwargs["system"] = system_message
            
            if anthropic_tools:
                kwargs["tools"] = anthropic_tools
                tool_choice = self._anthropic_tool_choice(tools)
                if tool_choice:
                    kwargs["tool_choice"] = tool_choice
            kwargs = self._apply_sensenova_anthropic_options(kwargs)
            kwargs = self._apply_custom_provider_anthropic_options(kwargs)
            if self._is_active_model_source("opencode"):
                kwargs["extra_headers"] = build_opencode_request_headers_from_config(
                    getattr(self.config, "opencode", {}), session_id=session_id)
            kwargs = apply_anthropic_prompt_cache(kwargs)
            
            # Make request
            client = self._ensure_client()
            response = self._retry_provider_call(lambda: call_with_prompt_cache_fallback(client.messages.create, kwargs, log=logger))
            
            # Extract content
            content_blocks = response.content
            collected_content = ""
            collected_thinking = ""
            thinking_blocks = []
            collected_tool_calls = []
            
            for block in content_blocks:
                if block.type == "text":
                    collected_content += block.text
                elif block.type in {"thinking", "redacted_thinking"}:
                    thinking_blocks.append(block.model_dump(include={"type", "thinking", "signature", "data"}, exclude_none=True))
                    if block.type == "thinking":
                        collected_thinking += block.thinking
                elif block.type == "tool_use":
                    collected_tool_calls.append({
                        "id": block.id,
                        "type": "function",
                        "function": {
                            "name": block.name,
                            "arguments": json.dumps(block.input)
                        }
                    })
            
            # Check for tool calls
            if collected_tool_calls:
                # Sanitize tool args before adding to message history
                _sanitize_tool_calls(collected_tool_calls)
                history_tool_calls = _compact_tool_calls_for_history(collected_tool_calls, mode=self.mode)
                assistant_message = _build_assistant_history_message(
                    collected_content or None,
                    tool_calls=history_tool_calls,
                    reasoning_content=collected_thinking,
                )
                if thinking_blocks:
                    assistant_message["anthropic_thinking"] = thinking_blocks
                self.messages.append(assistant_message)
                self._record_model_usage(
                    request_messages=request_messages,
                    assistant_text=collected_content,
                    reasoning_text=collected_thinking,
                    tool_calls=history_tool_calls,
                    usage=getattr(response, "usage", None),
                    session_id=session_id,
                )
                anthropic_messages.append(
                    {
                        "role": "assistant",
                        "content": _build_anthropic_assistant_tool_blocks(collected_content, collected_tool_calls),
                    }
                )
                
                if collected_content:
                    all_content.append(collected_content)
                
                # Execute each tool
                tool_result_blocks: List[Dict[str, Any]] = []
                for tool_call in collected_tool_calls:
                    tool_name = tool_call["function"]["name"]
                    tool = self.tool_executor.get_tool(tool_name)
                    
                    args = parse_tool_arguments(tool_call["function"]["arguments"])
                    
                    self._check_tool_side_effects(tool_name, args)
                    
                    exec_msg = tool.get_execution_message(**args) if tool else f"Executing {tool_name}..."
                    self._emit_tool_stream_event(
                        "tool_start",
                        tool_name=tool_name,
                        message=exec_msg,
                        arguments=args,
                        tool_call_id=str(tool_call.get("id", "")).strip(),
                        agent_id=self.agent_id,
                        agent_color=self.agent_color,
                    )
                    all_content.append(f"[bold #ffb8d1]✧[/bold #ffb8d1] [bold #e4b0ff]{rich_escape(exec_msg)}[/bold #e4b0ff]")
                    
                    result = self.tool_executor.execute(
                        tool_name,
                        args,
                        tool_call_id=str(tool_call.get("id", "")).strip(),
                    )
                    self._emit_tool_stream_event(
                        "tool_result",
                        tool_name=tool_name,
                        message=exec_msg,
                        arguments=args,
                        tool_call_id=str(tool_call.get("id", "")).strip(),
                        success=bool(result.success),
                        output=str(result.output or ""),
                        error=str(result.error or ""),
                        status=str(getattr(result.status, "value", "success")),
                        agent_id=self.agent_id,
                        agent_color=self.agent_color,
                    )
                    
                    if result.success:
                        all_content.append(f"[bold #66bb6a]   ✔ Success[/bold #66bb6a]")
                    else:
                        all_content.append(f"[bold #ff5252]   ✘ Failed:[/bold #ff5252] [#ff8a80]{rich_escape(result.error or '')}[/#ff8a80]")
                    
                    tool_result_message = {
                        "role": "tool",
                        "tool_call_id": tool_call["id"],
                        "content": _tool_result_history_content(result)
                    }
                    self.messages.append(tool_result_message)
                    self._persist_history_to_session()
                    tool_result_blocks.append(_build_anthropic_tool_result_block(tool_call["id"], result))

                if tool_result_blocks:
                    anthropic_messages.append({"role": "user", "content": tool_result_blocks})

                # `messages` is the OpenAI-shaped list this loop rebuilds every
                # iteration, so a nudge here reaches the next request safely.
                self._guard_think_tool_spin(collected_tool_calls, messages)
                continue
            
            # No tool calls, final response check
            if collected_content:
                finish_reason = getattr(response, "stop_reason", None)
                if self._should_end_generation(collected_content, "end_turn" if finish_reason == "stop_sequence" else finish_reason):
                    clean_content = collected_content.replace("//END//", "").strip()
                    assistant_message = _build_assistant_history_message(clean_content, reasoning_content=collected_thinking)
                    if thinking_blocks:
                        assistant_message["anthropic_thinking"] = thinking_blocks
                    self.messages.append(assistant_message)
                    self._record_model_usage(
                        request_messages=request_messages,
                        assistant_text=clean_content,
                        reasoning_text=collected_thinking,
                        usage=getattr(response, "usage", None),
                        session_id=session_id,
                    )
                    all_content.append(clean_content)
                    break
                
                assistant_message = _build_assistant_history_message(collected_content, reasoning_content=collected_thinking)
                if thinking_blocks:
                    assistant_message["anthropic_thinking"] = thinking_blocks
                self.messages.append(assistant_message)
                
                self._record_model_usage(
                    request_messages=request_messages,
                    assistant_text=collected_content,
                    reasoning_text=collected_thinking,
                    usage=getattr(response, "usage", None),
                    session_id=session_id,
                )
                
                all_content.append(collected_content)
                continuation_count += 1
                if continuation_count >= self._completion_continuation_limit():
                    break
                continue

            self._record_model_usage(
                request_messages=request_messages,
                assistant_text="",
                reasoning_text=collected_thinking,
                usage=getattr(response, "usage", None),
                session_id=session_id,
            )
            if collected_thinking:
                self.messages.append(_build_assistant_history_message(None, reasoning_content=collected_thinking))
                self._persist_history_to_session()
            if self._is_active_model_source("custom") and int(getattr(getattr(response, "usage", None), "output_tokens", 0) or 0) > 0:
                raise RuntimeError("The provider reported output tokens but returned no text or client tool calls. Check its /v1/messages response; no automatic retry was sent.")
            empty_turn_count += 1
            if self._recover_empty_model_turn(messages, attempt=empty_turn_count):
                system_message, anthropic_messages = _convert_messages_to_anthropic_format(self._build_messages())
                continue

            notice = self._record_unsummarized_turn(
                session_id=session_id,
            )
            if notice:
                all_content.append(notice)
            break

        return '\n'.join(all_content)
    
    def clear_history(self) -> None:
        """Clear conversation history"""
        self.messages = []
    
    def get_history(self) -> List[Dict]:
        """Get conversation history"""
        return self.messages.copy()
    
    def set_history(self, messages: List[Dict]) -> None:
        """Set conversation history (for session restore)"""
        self.messages = messages.copy()

    def _history_from_request_messages(self, messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Convert request messages back into persisted history without duplicating the base system prompt."""
        if not isinstance(messages, list):
            return []

        history = [dict(message) for message in messages if isinstance(message, dict)]
        if history:
            first = history[0]
            if (
                str(first.get("role", "") or "").strip().lower() == "system"
                and _coerce_text_fragments(first.get("content")) in (self.system_prompt, self._request_system_prompt())
            ):
                history = history[1:]
        history = [
            message
            for message in history
            if not (
                str(message.get("role", "") or "").strip().lower() == "system"
                and _coerce_text_fragments(message.get("content")).startswith(MEMORY_CONTEXT_PROMPT_HEADER)
            )
        ]
        return history

    def _persist_history_to_session(self) -> None:
        """Persist the current in-memory history to the active session when available."""
        session_manager = self.tool_executor.context.get("session_manager")
        if not session_manager:
            return
        try:
            session_manager.update_messages(self.messages)
        except Exception:
            logger.debug("Failed to persist session messages", exc_info=True)

    def _token_estimate_signature(self) -> tuple[Any, ...]:
        """Build a cheap cache key for repeated context-usage checks."""
        messages = self.messages if isinstance(self.messages, list) else []
        tail_signature: List[tuple[Any, ...]] = []
        for message in messages[-3:]:
            if not isinstance(message, dict):
                tail_signature.append((type(message).__name__, len(str(message))))
                continue
            content_len = len(_coerce_text_fragments(message.get("content")))
            reasoning_len = len(_coerce_text_fragments(message.get("reasoning_content")))
            tool_calls = message.get("tool_calls")
            tool_count = len(tool_calls) if isinstance(tool_calls, list) else 0
            tool_call_id = str(message.get("tool_call_id", "") or "").strip()
            name = str(message.get("name", "") or "").strip()
            tail_signature.append(
                (
                    str(message.get("role", "") or "").strip().lower(),
                    content_len,
                    reasoning_len,
                    tool_count,
                    len(tool_call_id),
                    len(name),
                )
            )
        return (
            len(messages),
            len(self._request_system_prompt()),
            tuple(tail_signature),
        )

    def _current_session_details(self, fallback_session_id: str = "default") -> tuple[str, str]:
        """Return the active session id/name for stats and continuity features."""
        session_id = str(fallback_session_id or "").strip() or "default"
        session_name = ""

        session_manager = self.tool_executor.context.get("session_manager")
        if not session_manager or not hasattr(session_manager, "get_current_session"):
            return session_id, session_name

        try:
            current_session = session_manager.get_current_session()
        except Exception:
            logger.debug("Failed to fetch current session details", exc_info=True)
            return session_id, session_name

        if not current_session:
            return session_id, session_name

        current_session_id = str(getattr(current_session, "id", "") or "").strip()
        current_session_name = str(getattr(current_session, "name", "") or "").strip()
        return current_session_id or session_id, current_session_name

    def _record_model_usage(
        self,
        *,
        request_messages: List[Dict[str, Any]],
        assistant_text: str = "",
        reasoning_text: str = "",
        tool_calls: Optional[List[Dict[str, Any]]] = None,
        usage: Any = None,
        session_id: str = "default",
        source: str = "chat",
        interaction_type: str = "chat",
    ) -> None:
        """Record workspace-level token usage for one model call."""
        workspace_stats_manager = self.tool_executor.context.get("workspace_stats_manager")
        resolved_session_id, session_name = self._current_session_details(session_id)
        context_handler = self.tool_executor.context.get("context_usage_handler")
        if callable(context_handler):
            try:
                from ..session.workspace_stats import WorkspaceStatsManager

                response_message = {"role": "assistant", "content": assistant_text, "tool_calls": tool_calls or []}
                report = self.describe_context_usage(request_messages=[*request_messages, response_message])
                api_usage = WorkspaceStatsManager._usage_dict(usage)
                if api_usage:
                    input_tokens = api_usage.get("input_tokens")
                    output_tokens = api_usage.get("output_tokens")
                    total_tokens = api_usage.get("total_tokens")
                    api_tokens = total_tokens if total_tokens is not None else (input_tokens or 0) + (output_tokens or 0)
                    known_tokens = total_tokens if total_tokens is not None else (input_tokens if input_tokens is not None else self._count_request_tokens(request_messages)) + (output_tokens if output_tokens is not None else WorkspaceStatsManager.count_message_tokens(response_message))
                    report["api_baseline"] = {"tokens": known_tokens, "api_tokens": api_tokens, "estimated_tokens": report["estimated_history_tokens"], "history_hashes": report["history_hashes"]}
                    self._apply_api_context_baseline(report, report["api_baseline"])
                context_handler(report)
            except Exception:
                logger.debug("Failed to publish context usage", exc_info=True)
        if workspace_stats_manager:
            try:
                workspace_stats_manager.record_model_usage(
                    provider=self.provider,
                    source=source,
                    model=self.model,
                    model_display_name=self.model_display_name,
                    request_messages=request_messages,
                    assistant_text=assistant_text,
                    reasoning_text=reasoning_text,
                    tool_calls=tool_calls,
                    usage=usage,
                    session_id=resolved_session_id,
                    session_name=session_name,
                    interaction_type=interaction_type,
                )
            except Exception:
                logger.debug("Failed to record workspace model usage", exc_info=True)

        self._record_memory_event(
            "model_result",
            {
                "assistant_text": assistant_text,
                "reasoning_text": reasoning_text,
                "tool_calls": tool_calls or [],
                "provider": self.provider,
                "model": self.model,
                "model_display_name": self.model_display_name,
                "interaction_type": interaction_type,
            },
            actor="assistant",
            session_id=session_id,
            tags=["model", "result"],
            consolidate=False,
        )

    def _resolve_max_context_tokens(self) -> int:
        """Resolve the active model context window from runtime configuration."""
        max_tokens = 128000
        config_manager = self.tool_executor.context.get('config_manager')

        if config_manager:
            model_config = config_manager.get_active_model()
            if model_config and model_config.max_context_tokens:
                return model_config.max_context_tokens
            config = config_manager.load()
            return getattr(config, 'max_context_tokens', max_tokens)

        if hasattr(self, 'config'):
            return getattr(self.config, 'max_context_tokens', max_tokens)

        return max_tokens

    def _latest_user_message_text(self) -> str:
        """Return the latest user message text from the live conversation."""
        for message in reversed(self.messages):
            if str(message.get("role", "") or "").strip().lower() != "user":
                continue
            text = _coerce_text_fragments(message.get("content"))
            if text:
                return text
        return ""

    def _workspace_memory_for_rotation(self, latest_user_message: str) -> str:
        """Fetch a compact workspace-memory hint for auto-rotation handoff."""
        if normalize_mode(self.mode) == "computer-controller":
            return ""
        memory_indexer = self.tool_executor.context.get("memory_indexer")
        if not memory_indexer:
            return ""
        try:
            return memory_indexer.build_workspace_memory_summary(
                query=latest_user_message or None,
                max_fragments=6,
                max_chars=2400,
            )
        except Exception:
            logger.debug("Workspace memory fetch failed during auto-rotation", exc_info=True)
            return ""

    def _record_compaction_memory(self, compressed_messages: List[Dict[str, Any]], session_id: str) -> None:
        """Persist the latest compaction memory into the cross-session memory index."""
        memory_indexer = self.tool_executor.context.get("memory_indexer")
        if not memory_indexer:
            return
        try:
            from ..context_engine.compressor import MEMORY_BLOCK_END, MEMORY_BLOCK_HEADER
        except Exception:
            return

        summary = ""
        for message in compressed_messages or []:
            if str(message.get("role", "") or "").strip().lower() != "system":
                continue
            content = _coerce_text_fragments(message.get("content"))
            stripped = content.strip()
            if not stripped.startswith(MEMORY_BLOCK_HEADER):
                continue
            summary = stripped[len(MEMORY_BLOCK_HEADER):].strip()
            if summary.endswith(MEMORY_BLOCK_END):
                summary = summary[: -len(MEMORY_BLOCK_END)].strip()
        if not summary:
            return

        try:
            memory_indexer.set_session_summary(
                str(session_id or "default"),
                f"Compaction memory: {summary[:1800]}",
            )
            memory_indexer.refresh_session(str(session_id or "default"))
        except Exception:
            logger.debug("Failed to persist compaction memory summary", exc_info=True)

    def _handle_context_compaction(
        self,
        current_tokens: int,
        max_tokens: int,
        session_id: str = "default",
    ) -> int:
        """Compress the active conversation in-place before a full session rotation becomes necessary."""
        if self._auto_context_compaction_active:
            return current_tokens
        if self._auto_context_compaction_retry_after and time.time() < self._auto_context_compaction_retry_after:
            return current_tokens

        from ..config import get_project_data_dir
        from ..context_engine.compressor import ContextCompressor

        project_root = self.tool_executor.context.get("project_root") or self.project_root
        project_data_dir = self.tool_executor.context.get("project_data_dir")
        cache_dir = Path(project_data_dir) if project_data_dir else get_project_data_dir(Path(project_root))
        request_messages = self._build_messages()
        client = self._ensure_client() if self.provider in {"openai-chat", "openai-responses", "anthropic"} else None
        provider_base_url = self.base_url
        if self.provider == "codex":
            from ..codex import resolve_codex_request_url

            provider_base_url = resolve_codex_request_url(self.base_url, self.endpoint)

        self._auto_context_compaction_active = True
        try:
            try:
                compressor = ContextCompressor(cache_dir)
                compressed_messages = compressor.compress(
                    messages=request_messages,
                    client=client,
                    model=self.model,
                    session_id=session_id,
                    provider=self.provider,
                    base_url=provider_base_url,
                    api_key=self.api_key,
                    custom_headers=self.custom_headers,
                    workspace_stats_manager=self.tool_executor.context.get("workspace_stats_manager"),
                    model_display_name=self.model_display_name,
                )
            except Exception:
                logger.debug(
                    "Automatic context compaction failed; deferring retry window",
                    exc_info=True,
                )
                self._auto_context_compaction_retry_after = time.time() + 30.0
                return current_tokens

            new_history = self._history_from_request_messages(compressed_messages)
            if new_history and new_history != self.messages:
                self.messages = new_history
                self._persist_history_to_session()
                self._record_compaction_memory(compressed_messages, session_id)
                self._record_memory_event(
                    "context_compaction",
                    {
                        "current_tokens": current_tokens,
                        "compressed_tokens": self.get_token_estimate(),
                        "session_id": session_id,
                    },
                    actor="memory_os",
                    session_id=session_id,
                    tags=["context", "compaction"],
                )
                self._auto_context_compaction_retry_after = 0.0
                compressed_tokens = self.get_token_estimate()
                self._emit_ui_event(
                    category="Context",
                    message=f"Context compressed: {current_tokens:,} -> {compressed_tokens:,} tokens",
                    status="success",
                    compact=True,
                )
                return compressed_tokens
            else:
                self._auto_context_compaction_retry_after = time.time() + 30.0

            return self.get_token_estimate()
        finally:
            self._auto_context_compaction_active = False

    def _context_safety_signature(self) -> tuple[Any, ...]:
        """Cheap signature used to avoid repeated context scans for the same state."""
        return self._token_estimate_signature()

    def _quick_context_char_estimate(self) -> int:
        """Fast lower-cost estimate for deciding whether a full token count is needed."""
        total = len(self._request_system_prompt())
        for message in self.messages if isinstance(self.messages, list) else []:
            if not isinstance(message, dict):
                total += len(str(message))
                continue
            total += len(_coerce_text_fragments(message.get("content")))
            total += len(_coerce_text_fragments(message.get("reasoning_content")))
            tool_calls = message.get("tool_calls")
            if isinstance(tool_calls, list) and tool_calls:
                total += min(16000, len(str(tool_calls)))
        return total

    def _should_run_context_safety_check(self, max_tokens: int) -> bool:
        """Return whether this turn is large enough to justify compaction checks."""
        signature = self._context_safety_signature()
        if self._last_context_safety_signature == signature:
            return False

        message_count = len(self.messages) if isinstance(self.messages, list) else 0
        quick_tokens = self._quick_context_char_estimate() // 4
        if message_count < 16 and quick_tokens < max(12000, int(max_tokens * 0.45)):
            self._last_context_safety_signature = signature
            return False

        return True
    
    def _check_and_compress_context(self, session_id: str = "default") -> None:
        """
        Compact the active session before rotating to a fresh one when the context is too large.

        First attempt an in-place LLM compression pass. If the prompt still
        remains too large, prepare a model-authored handoff and rotate into a
        fresh session while keeping the active request alive.
        """
        if self._auto_context_rotation_active:
            return

        max_tokens = self._resolve_max_context_tokens()
        if max_tokens <= 0:
            return
        if not self._should_run_context_safety_check(max_tokens):
            return

        token_estimate = self.get_token_estimate()
        self._last_context_safety_signature = self._context_safety_signature()
        compaction_threshold = max_tokens * self.CONTEXT_COMPACTION_RATIO
        rotation_threshold = max_tokens * self.CONTEXT_ROTATION_RATIO

        if token_estimate >= compaction_threshold:
            token_estimate = self._handle_context_compaction(token_estimate, max_tokens, session_id=session_id)

        if self._auto_context_rotation_retry_after and time.time() < self._auto_context_rotation_retry_after:
            return
        if token_estimate >= rotation_threshold:
            self._handle_session_rotation(token_estimate, max_tokens, session_id=session_id)
    
    def _handle_session_rotation(self, current_tokens: int, max_tokens: int, session_id: str = "default") -> None:
        """
        Handle session rotation at 80% threshold.

        Generates a model-authored handoff packet, creates a fresh session, and
        keeps the active request alive inside the new context automatically.
        """
        session_manager = self.tool_executor.context.get('session_manager')
        
        if not session_manager:
            return
        
        latest_user_message = self._latest_user_message_text()
        workspace_memory = self._workspace_memory_for_rotation(latest_user_message)
        rotation_reason = (
            f"Token usage reached {current_tokens:,} / {max_tokens:,} "
            f"({current_tokens/max_tokens*100:.1f}%)"
        )

        self._auto_context_rotation_active = True
        try:
            try:
                provider_base_url = self.base_url
                if self.provider == "codex":
                    from ..codex import resolve_codex_request_url

                    provider_base_url = resolve_codex_request_url(self.base_url, self.endpoint)
                handoff = build_session_handoff_packet(
                    messages=self._build_messages(),
                    client=self._ensure_client() if self.provider in {"openai-chat", "openai-responses", "anthropic"} else None,
                    model=self.model,
                    provider=self.provider,
                    session_id=session_id,
                    current_tokens=current_tokens,
                    max_tokens=max_tokens,
                    base_url=provider_base_url,
                    api_key=self.api_key,
                    custom_headers=self.custom_headers,
                    workspace_memory=workspace_memory,
                    latest_user_request=latest_user_message,
                    reason=rotation_reason,
                    workspace_stats_manager=self.tool_executor.context.get("workspace_stats_manager"),
                    model_display_name=self.model_display_name,
                )
            except Exception:
                check_cancel()
                logger.debug(
                    "Automatic handoff generation failed; skipping session rotation until retry window",
                    exc_info=True,
                )
                self._auto_context_rotation_retry_after = time.time() + 30.0
                return

            new_session = session_manager.rotate_session(
                working_memory=handoff.carryover_text,
                reason=rotation_reason,
                handoff_packet=handoff.to_dict(),
            )
            self._record_memory_event(
                "session_rotation",
                {
                    "reason": rotation_reason,
                    "from_session_id": session_id,
                    "new_session_id": getattr(new_session, "id", ""),
                    "working_memory": handoff.carryover_text,
                    "handoff": handoff.to_dict(),
                },
                actor="memory_os",
                session_id=session_id,
                tags=["session", "rotation", "handoff"],
            )

            self.messages = list(new_session.messages)
            if latest_user_message:
                self.messages.append({"role": "user", "content": latest_user_message})

            self._persist_history_to_session()

            self._auto_context_rotation_retry_after = 0.0
        finally:
            self._auto_context_rotation_active = False
    
    def _token_counter(self):
        """Resolve the one token counter every readout in this process must share.

        The workspace stats manager owns the counter, but it is optional in the
        tool-executor context (subagents and bare embeddings run without it), so
        fall back to the class itself rather than to a second, looser estimate.
        """
        manager = self.tool_executor.context.get("workspace_stats_manager")
        if manager is not None and hasattr(manager, "count_messages_tokens"):
            return manager
        from ..session.workspace_stats import WorkspaceStatsManager

        return WorkspaceStatsManager

    def _count_request_tokens(self, request_messages: List[Dict[str, Any]]) -> int:
        """Count the tokens one built request payload will occupy."""
        counter = self._token_counter()
        try:
            return max(int(counter.count_messages_tokens(request_messages)), 0)
        except Exception:
            logger.debug("Token counter failed; falling back to character heuristic", exc_info=True)

        total_chars = 0
        for message in request_messages or []:
            if not isinstance(message, dict):
                total_chars += len(str(message))
                continue
            total_chars += len(_coerce_text_fragments(message.get("content")))
            tool_calls = message.get("tool_calls")
            if isinstance(tool_calls, list) and tool_calls:
                total_chars += len(str(tool_calls))
        return total_chars // 4

    #: System-message content prefixes that mark injected memory rather than
    #: general context, so the token audit can bill them to their own segment.
    #: Both are literal markers written by the two memory paths: the Memory OS
    #: context package (agent._memory_context_package_message) and the workspace
    #: global memory note (interface._sync_workspace_memory_message).
    _MEMORY_CONTEXT_MARKERS = (MEMORY_CONTEXT_PROMPT_HEADER, "[WORKSPACE GLOBAL MEMORY]")

    def describe_context_usage(self, request_messages: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        """Break the live request payload into an auditable token budget.

        Every figure below comes from one counter and one build of the payload the
        next API call would send, so the total is exactly the number the
        compaction and rotation thresholds are compared against.
        """
        counter = self._token_counter()
        count_one = getattr(counter, "count_message_tokens", None)
        if not callable(count_one):
            from ..session.workspace_stats import WorkspaceStatsManager

            count_one = WorkspaceStatsManager.count_message_tokens

        cache_estimate = request_messages is None
        request_messages = self._build_messages(read_only=True) if cache_estimate else request_messages
        total_tokens = self._count_request_tokens(request_messages)
        if cache_estimate:
            self._token_estimate_cache_key = self._token_estimate_signature()
            self._token_estimate_cache_value = total_tokens
            self._token_estimate_cache_time = time.monotonic()

        buckets: Dict[str, Dict[str, int]] = {}
        heaviest = {"role": "", "index": -1, "tokens": 0, "preview": ""}
        for index, message in enumerate(request_messages):
            if not isinstance(message, dict):
                continue
            role = str(message.get("role", "") or "").strip().lower() or "unknown"
            if index == 0 and role == "system":
                key = "system_prompt"
            elif role == "system" and _coerce_text_fragments(
                message.get("content")
            ).lstrip().startswith(self._MEMORY_CONTEXT_MARKERS):
                key = "memory"
            elif role == "system":
                key = "injected_context"
            else:
                key = role
            try:
                tokens = max(int(count_one(message)), 0)
            except Exception:
                tokens = 0
            bucket = buckets.setdefault(key, {"tokens": 0, "messages": 0})
            bucket["tokens"] += tokens
            bucket["messages"] += 1
            if tokens > int(heaviest["tokens"]):
                preview = " ".join(_coerce_text_fragments(message.get("content")).split())
                heaviest = {
                    "role": role,
                    "index": index,
                    "tokens": tokens,
                    "preview": preview[:117] + "..." if len(preview) > 120 else preview,
                }

        return self._context_usage_report(request_messages, total_tokens, buckets, heaviest)

    @staticmethod
    def _apply_api_context_baseline(report: Dict[str, Any], baseline: Dict[str, Any]) -> None:
        """Use provider usage for the measured payload and count subsequent edits locally."""
        estimated = max(int(baseline.get("estimated_tokens", 0)), 0)
        current = report.get("estimated_history_tokens", report["total_tokens"])
        history_hashes = baseline.get("history_hashes")
        if history_hashes is not None and report.get("history_hashes", [])[:len(history_hashes)] != history_hashes:
            return
        if current < estimated:
            return  # A shortened/compacted history no longer matches this measurement.
        measured_tokens = max(int(baseline.get("tokens", 0)), 0)
        api_tokens = min(max(int(baseline.get("api_tokens", measured_tokens)), 0), measured_tokens)
        delta = measured_tokens - api_tokens + current - estimated
        total = api_tokens + delta
        report.update(total_tokens=total, remaining_tokens=max(report["max_tokens"] - total, 0), percentage=total / report["max_tokens"] * 100 if report["max_tokens"] else 0, overhead_tokens=0, usage_source="api" if not delta else "mixed")
        report["segments"] = [
            {"key": key, "tokens": tokens, "messages": 0, "share": tokens / total * 100 if total else 0}
            for key, tokens in (("api_context", api_tokens), ("local_delta", delta)) if tokens
        ]

    #: Fractions of the context window at which the agent compacts, then rotates.
    CONTEXT_COMPACTION_RATIO = 0.7
    CONTEXT_ROTATION_RATIO = 0.82

    def _context_usage_report(
        self,
        request_messages: List[Dict[str, Any]],
        total_tokens: int,
        buckets: Dict[str, Dict[str, int]],
        heaviest: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Assemble the /status context-usage payload from a counted payload."""
        from ..session.workspace_stats import WorkspaceStatsManager

        max_tokens = max(int(self._resolve_max_context_tokens() or 0), 0)
        percentage = (total_tokens / max_tokens * 100.0) if max_tokens else 0.0
        history = self.messages if isinstance(self.messages, list) else []
        reasoning_tokens = 0
        for message in history:
            if not isinstance(message, dict):
                continue
            reasoning = _coerce_text_fragments(message.get("reasoning_content"))
            if reasoning:
                reasoning_tokens += WorkspaceStatsManager.count_text_tokens(reasoning)

        segment_order = ("system_prompt", "injected_context", "memory", "user", "assistant", "tool")
        segments = [
            {
                "key": key,
                "tokens": buckets[key]["tokens"],
                "messages": buckets[key]["messages"],
                "share": (buckets[key]["tokens"] / total_tokens * 100.0) if total_tokens else 0.0,
            }
            for key in list(segment_order) + sorted(set(buckets) - set(segment_order))
            if key in buckets
        ]
        counted = sum(item["tokens"] for item in segments)

        return {
            "tokenizer": WorkspaceStatsManager.describe_tokenizer(),
            "total_tokens": total_tokens,
            "estimated_history_tokens": sum(item["tokens"] for item in segments if item["key"] in {"user", "assistant", "tool"}) + max(total_tokens - counted, 0),
            "history_hashes": [hashlib.sha256(json.dumps({key: value for key, value in message.items() if key in {"role", "content", "tool_calls", "tool_call_id", "name"} and value not in (None, [], "")}, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")).hexdigest() for message in request_messages if isinstance(message, dict) and message.get("role") != "system"],
            "max_tokens": max_tokens,
            "remaining_tokens": max(max_tokens - total_tokens, 0) if max_tokens else 0,
            "percentage": percentage,
            "overhead_tokens": max(total_tokens - counted, 0),
            "segments": segments,
            "heaviest_message": heaviest,
            "reasoning_tokens": reasoning_tokens,
            "payload_message_count": len(request_messages),
            "history_message_count": len(history),
            "history_limit": int(getattr(self, "_prompt_history_limit", 0) or 0),
            "compaction_tokens": int(max_tokens * self.CONTEXT_COMPACTION_RATIO) if max_tokens else 0,
            "rotation_tokens": int(max_tokens * self.CONTEXT_ROTATION_RATIO) if max_tokens else 0,
        }

    def get_token_estimate(self) -> int:
        """Estimate tokens in current conversation"""
        cache_key = self._token_estimate_signature()
        cache_now = time.monotonic()
        if (
            self._token_estimate_cache_key == cache_key
            and (cache_now - self._token_estimate_cache_time) < 0.5
        ):
            return self._token_estimate_cache_value

        request_messages = self._build_messages()
        estimate = self._count_request_tokens(request_messages)
        self._token_estimate_cache_key = cache_key
        self._token_estimate_cache_value = estimate
        self._token_estimate_cache_time = cache_now
        return estimate
