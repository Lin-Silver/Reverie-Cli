import { FloatingMenu } from "./FloatingMenu";
import { AvatarEditor, UserAvatar } from "./AvatarEditor";
import { StarterActions, WelcomeHeader } from "./StartPage";
import { desktopCommand, desktopCommandAvailable } from "./desktop-commands";
import {
  Activity,
  AlertCircle,
  Archive,
  ArchiveRestore,
  AtSign,
  Bot,
  Brain,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Circle,
  Clock3,
  Code2,
  Command,
  Copy,
  Database,
  Eye,
  EyeOff,
  FileText,
  FileSearch,
  Folder,
  FolderOpen,
  Gamepad2,
  GitBranch,
  Globe,
  Image,
  ImagePlus,
  Info,
  LayoutGrid,
  List,
  ListFilter,
  MessageSquare,
  Monitor,
  MoreHorizontal,
  Moon,
  Palette,
  PanelLeftClose,
  PanelLeftOpen,
  PanelRightClose,
  PanelRightOpen,
  Paperclip,
  Pencil,
  Pin,
  Plug,
  Plus,
  RefreshCw,
  RotateCcw,
  Search,
  Send,
  Settings,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Square,
  SquareTerminal,
  Sun,
  Terminal,
  Trash2,
  Type,
  Wrench,
  X,
  Zap,
} from "lucide-react";
import {
  CSSProperties,
  DragEvent,
  FormEvent,
  KeyboardEvent,
  ReactNode,
  RefObject,
  memo,
  useCallback,
  useDeferredValue,
  useEffect,
  useLayoutEffect,
  useId,
  useMemo,
  useRef,
  useState,
} from "react";
import { createPortal } from "react-dom";
import { AnswerMarkdown as Markdown } from "./AnswerMarkdown";
import { Workbench } from "./Workbench";
import { SessionWorkbench } from "./SessionWorkbench";
import { ConversationDisplay, DisplayPresets } from "./ConversationDisplay";
import { ComposerSuggestions } from "./ComposerSuggestions";
import { composerToken, slashOptions, type CompletionOption } from "./composer-completion";
import { FileChanges } from "./FileChanges";
import { InteractiveView } from "./InteractiveView";
import { ViewPresentationProvider } from "./ViewPresentation";
import type {
  CommandRecord,
  ConfigField,
  ContextUsage,
  CustomProviderFormat,
  CustomProviderModel,
  CustomProviderRecord,
  DesktopPaths,
  DesktopState,
  ImageModelRecord,
  ImageModelSourcesState,
  LiveTurn,
  ModelRecord,
  ModelSource,
  PluginRecord,
  ProviderProbe,
  RatsCustomProviderDefinition,
  RatsPermission,
  RatsProviderRecord,
  RatsServiceRecord,
  RatsState,
  RatsTaskRecord,
  RecoveryState,
  SessionInfo,
  SessionMessage,
  SessionState,
  SettingItem,
  SkillRecord,
  SkillsState,
  SubagentRunLog,
  SubagentRunRecord,
  SubagentSpecRecord,
  SubagentsState,
  TaskListEntry,
  ToolRecord,
  ViewId,
} from "./types";
import {
  groupTranscriptMessages,
  messageReasoningText,
  previousTurnBoundary,
  resolveToolResultNames,
  sessionIsEmpty,
  toolCallRecords,
  visibleSessionMessages,
} from "./session-utils";
import { applyTheme, normalizeTheme, THEME_STORAGE_KEY, type ThemePreference } from "./theme";
import {
  applyUiPreferences,
  backgroundPresetUrl,
  DEFAULT_UI_PREFERENCES,
  effectiveBackgroundUrl,
  normalizeUiPreferences,
  type AccentPreference,
  type BackgroundPreset,
  type FontSizePreference,
  type MessageWidthPreference,
  type UiPreferences,
} from "./preferences";
import {
  INSPECTOR_DEFAULT_WIDTH,
  INSPECTOR_MAX_WIDTH,
  INSPECTOR_MIN_WIDTH,
  SIDEBAR_DEFAULT_WIDTH,
  SIDEBAR_MAX_WIDTH,
  SIDEBAR_MIN_WIDTH,
  clampPaneWidth,
  normalizeSidebarCollapsed,
  paneDragLimit,
  resolveSidebarCollapsed,
  SIDEBAR_AUTO_COLLAPSE_QUERY,
  SIDEBAR_COLLAPSED_STORAGE_KEY,
} from "./layout";
import { I18nProvider, UI_LANGUAGE_OPTIONS, translate, useI18n } from "./i18n";
import {
  LIVE_STREAM_RENDER_INTERVAL_MS,
  emptyLiveTurnBatch,
  mergeLiveTurnBatch,
  type LiveTurnBatch,
} from "./live-stream";
import { isThinkTool, thinkToolText } from "./thinking-tool";
import { isViewEventRecord, parseViewEvent, toViewSegment } from "./view-events";
import {
  CUSTOM_SOURCE_ID,
  activeSourceId,
  coreSourceId,
  customProviderIdOf,
  expandModelSources,
  settingsModelSources,
} from "./model-sources";
import { SessionCache } from "./session-cache";
import {
  NEW_SESSION_DRAFT_ID,
  clearDraft,
  clearProjectDrafts,
  loadProjectDrafts,
  saveDraft,
  loadStructuredDraft,
  saveStructuredDraft,
} from "./drafts";
import { InputContext, AttachmentCards, QueueStrip, GoalSummary, useInputControls } from "./ComposerExtras";
import { loadQueue, saveQueue, ownerKey, type QueuedMessage } from "./execution-state";
import { useSidebarOrganization } from "./sidebar-organization";
import type { ComposerAttachment } from "../electron/attachments";
import type { ApprovalDecision } from "./core-protocol";
import type { GitWorkspaceStatus } from "../electron/git-workspace";

type Toast = { id: number; kind: "success" | "error" | "info"; message: string };


const REVERIE_MARK_URL = new URL("reverie-mark.png", document.baseURI).href;

const MODES = [
  ["reverie", "Reverie", Code2],
  ["reverie-atlas", "Atlas", FileText],
  ["reverie-gamer", "Gamer", Gamepad2],
  ["writer", "Writer", Pencil],
  ["computer-controller", "Computer", SquareTerminal],
] as const;

const THEME_OPTIONS: Array<{
  id: ThemePreference;
  label: string;
  description: string;
  icon: typeof Sun;
}> = [
  { id: "system", label: "跟随系统", description: "自动匹配 Windows 外观", icon: Monitor },
  { id: "dark", label: "深色", description: "低眩光的专注工作台", icon: Moon },
  { id: "light", label: "浅色", description: "明亮清晰的日间外观", icon: Sun },
];

const ACCENT_OPTIONS: Array<{ id: AccentPreference; label: string; color: string }> = [
  { id: "violet", label: "暮光紫", color: "#9678e4" },
  { id: "blue", label: "星海蓝", color: "#4f91e8" },
  { id: "teal", label: "极光青", color: "#35a99a" },
  { id: "rose", label: "晨曦玫", color: "#d56a8a" },
  { id: "amber", label: "琥珀金", color: "#c58a35" },
];

const FONT_SIZE_OPTIONS: Array<{ id: FontSizePreference; label: string; description: string }> = [
  { id: "compact", label: "紧凑", description: "适合高信息密度" },
  { id: "comfortable", label: "舒适", description: "默认阅读尺寸" },
  { id: "large", label: "大字体", description: "更清晰、更易阅读" },
];

const MESSAGE_WIDTH_OPTIONS: Array<{ id: MessageWidthPreference; label: string }> = [
  { id: "focused", label: "聚焦" },
  { id: "balanced", label: "平衡" },
  { id: "wide", label: "宽屏" },
];

const BACKGROUND_OPTIONS: Array<{
  id: Exclude<BackgroundPreset, "custom">;
  label: string;
  description: string;
  icon: typeof Image;
}> = [
  { id: "none", label: "纯净界面", description: "保留主题原生底色", icon: EyeOff },
  { id: "aurora-archive", label: "极光档案", description: "靛蓝、星尘与暮光", icon: Sparkles },
  { id: "moss-library", label: "苔影书库", description: "深青植物与静谧雾光", icon: Image },
  { id: "ember-manuscript", label: "余烬手稿", description: "炭黑纸张与暖铜墨迹", icon: FileText },
];

function asRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" ? (value as Record<string, unknown>) : {};
}

function formatTime(value: string, language: string): string {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  const now = new Date();
  const sameDay = date.toDateString() === now.toDateString();
  return sameDay
    ? date.toLocaleTimeString(language, { hour: "2-digit", minute: "2-digit" })
    : date.toLocaleDateString(language, { month: "short", day: "numeric" });
}

function formatTokens(value?: number | null): string {
  if (!value) return "—";
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(value % 1_000_000 ? 1 : 0)}M`;
  if (value >= 1_000) return `${Math.round(value / 1_000)}K`;
  return String(value);
}

function projectNameFromPath(value: string): string {
  const parts = value.split(/[\\/]/).filter(Boolean);
  return parts.at(-1) || value || "Workspace";
}

function workspaceMention(value: string): string {
  const normalized = String(value || "").replaceAll("\\", "/").trim();
  if (!normalized) return "@";
  return /[\s"']/.test(normalized)
    ? `@"${normalized.replaceAll('"', '\\"')}"`
    : `@${normalized}`;
}

function formatFileSize(value: number): string {
  if (value >= 1024 * 1024) return `${(value / (1024 * 1024)).toFixed(1)} MB`;
  return `${Math.max(1, Math.round(value / 1024))} KB`;
}

function messageText(content: unknown, language: "zh-CN" | "en-US" = "zh-CN"): string {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content
      .map((item) => {
        const part = asRecord(item);
        if (typeof part.text === "string") return part.text;
        if (part.type === "image_url" || part.type === "image") return translate(language, "[图片]");
        return "";
      })
      .filter(Boolean)
      .join("\n");
  }
  return content == null ? "" : JSON.stringify(content, null, 2);
}

function eventText(value: unknown): string {
  if (typeof value === "string") return value;
  if (value == null) return "";
  try {
    return JSON.stringify(value, null, 2);
  } catch {
    return String(value);
  }
}

function eventLabel(event: Record<string, unknown>): { title: string; detail: string; status: string; category: string; meta: string; toolName: string; agentId: string } {
  const type = String(event.type ?? event.kind ?? event.event ?? "activity");
  const eventType = String(event.event ?? type);
  const toolName = String(event.tool_name ?? event.name ?? "");
  const title = String(event.title ?? event.message ?? event.tool_name ?? event.name ?? eventType);
  // For the Thinking Tool the payload the user wants to read is the reasoning the
  // model wrote into the call, not the acknowledgement it got back.
  const detail = isThinkTool(toolName)
    ? thinkToolText(event.arguments) || eventText(event.detail ?? event.error ?? "")
    : eventText(event.detail ?? event.output ?? event.error ?? event.text ?? "");
  const inferredStatus = eventType === "model_request" || eventType === "tool_start"
    ? "working"
    : eventType === "model_response" || (eventType === "tool_result" && event.success !== false)
      ? "success"
      : type.includes("error") || eventType.includes("error") || (eventType === "tool_result" && event.success === false)
        ? "error"
        : "info";
  const rawStatus = String(event.status ?? inferredStatus).toLowerCase();
  const status = ["working", "running", "queued", "pending"].includes(rawStatus)
    ? "working"
    : rawStatus === "completed" || rawStatus === "done" ? "success" : rawStatus;
  const category = String(event.category ?? (eventType.includes("tool") ? "Tool" : eventType.includes("model") ? "Model" : "Activity"));
  const meta = String(event.meta ?? "");
  const agentId = String(event.agent_id ?? "");
  return { title, detail, status, category, meta, toolName, agentId };
}

function IconButton({
  label,
  children,
  onClick,
  active = false,
  disabled = false,
  ariaKeyShortcuts,
}: {
  label: string;
  children: ReactNode;
  onClick?: () => void;
  active?: boolean;
  disabled?: boolean;
  ariaKeyShortcuts?: string;
}) {
  return (
    <button
      type="button"
      className={`icon-button ${active ? "active" : ""}`}
      aria-label={label}
      aria-keyshortcuts={ariaKeyShortcuts}
      title={label}
      onClick={onClick}
      disabled={disabled}
    >
      {children}
    </button>
  );
}

const StreamingMarkdown = memo(function StreamingMarkdown({ children, running }: { children: string; running: boolean }) {
  const latestText = useRef(children);
  const [sampledText, setSampledText] = useState(children);
  useLayoutEffect(() => { latestText.current = children; }, [children]);
  useEffect(() => {
    if (!running) return;
    const timer = window.setInterval(() => setSampledText(latestText.current), 100);
    return () => window.clearInterval(timer);
  }, [running]);
  const deferredText = useDeferredValue(sampledText);
  return <Markdown streaming={running}>{running ? deferredText : children}</Markdown>;
});

function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`brand ${compact ? "compact" : ""}`}>
      <div className="brand-mark"><img src={REVERIE_MARK_URL} alt="" /></div>
      {!compact && <span>Reverie</span>}
    </div>
  );
}

function LoadingScreen({ message = "正在连接 Reverie 内核" }: { message?: string }) {
  const { t } = useI18n();
  return (
    <div className="loading-screen">
      <BrandMark />
      <div className="loading-orbit"><span /></div>
      <p>{t(message)}</p>
      <small>Electron UI · Reverie CLI Core</small>
    </div>
  );
}

function ErrorScreen({ error, retry }: { error: string; retry: () => void }) {
  const { t } = useI18n();
  return (
    <div className="loading-screen error-screen">
      <div className="error-glyph"><AlertCircle size={28} /></div>
      <h1>{t("无法启动 Reverie")}</h1>
      <p>{error}</p>
      <button type="button" className="primary-button" onClick={retry}>
        <RefreshCw size={15} /> {t("重试")}
      </button>
    </div>
  );
}

/**
 * Drag handle for one of the two side panes.
 *
 * `edge` says which shell edge the pane is anchored to, which is all that is
 * needed to turn a pointer position into a width. Pointer capture keeps the
 * events coming to this element even when the cursor outruns the handle, so no
 * window-level listeners are involved and a lost pointerup cannot wedge the
 * shell in resizing state.
 */
function PaneResizer({
  edge,
  label,
  width,
  minimum,
  maximum,
  fallback,
  shell,
  opposite,
  preview,
  commit,
  overlay = false,
}: {
  edge: "left" | "right";
  overlay?: boolean;
  label: string;
  width: number;
  minimum: number;
  maximum: number;
  fallback: number;
  shell: RefObject<HTMLDivElement | null>;
  opposite: number;
  preview: (width: number) => void;
  commit: (width: number) => void;
}) {
  const dragging = useRef(false);
  const [active, setActive] = useState(false);

  /**
   * Capture keeps the events coming when the cursor outruns the 9px handle. It
   * is absent under jsdom and throws in a browser once the pointer has already
   * gone away, and neither case should abort a drag that otherwise works.
   */
  const capture = useCallback((target: Element, pointerId: number, hold: boolean) => {
    try {
      if (hold) target.setPointerCapture?.(pointerId);
      else target.releasePointerCapture?.(pointerId);
    } catch {
      // Direct events on the handle still drive the drag without capture.
    }
  }, []);

  const resolve = useCallback((clientX: number): number => {
    const bounds = shell.current?.getBoundingClientRect();
    const ceiling = bounds
      ? Math.max(minimum, overlay ? Math.min(maximum, bounds.width - 48) : paneDragLimit(bounds.width, opposite, maximum))
      : maximum;
    const raw = bounds
      ? edge === "left" ? clientX - bounds.left : bounds.right - clientX
      : width;
    return clampPaneWidth(raw, minimum, ceiling, fallback);
  }, [edge, fallback, maximum, minimum, opposite, overlay, shell, width]);

  const step = useCallback((delta: number) => {
    const bounds = shell.current?.getBoundingClientRect();
    const ceiling = bounds
      ? Math.max(minimum, overlay ? Math.min(maximum, bounds.width - 48) : paneDragLimit(bounds.width, opposite, maximum))
      : maximum;
    commit(clampPaneWidth(width + delta, minimum, ceiling, fallback));
  }, [commit, fallback, maximum, minimum, opposite, overlay, shell, width]);

  return (
    <div
      role="separator"
      tabIndex={0}
      aria-orientation="vertical"
      aria-label={label}
      aria-valuenow={width}
      aria-valuemin={minimum}
      aria-valuemax={maximum}
      className={`pane-resizer ${edge === "left" ? "sidebar-resizer" : "inspector-resizer"} ${active ? "dragging" : ""}`}
      onPointerDown={(event) => {
        if (event.button !== 0) return;
        event.preventDefault();
        capture(event.currentTarget, event.pointerId, true);
        dragging.current = true;
        setActive(true);
      }}
      onPointerMove={(event) => {
        if (!dragging.current) return;
        preview(resolve(event.clientX));
      }}
      onPointerUp={(event) => {
        if (!dragging.current) return;
        dragging.current = false;
        setActive(false);
        capture(event.currentTarget, event.pointerId, false);
        commit(resolve(event.clientX));
      }}
      onPointerCancel={() => {
        if (!dragging.current) return;
        dragging.current = false;
        setActive(false);
        commit(width);
      }}
      onDoubleClick={() => commit(fallback)}
      onKeyDown={(event) => {
        // A left-anchored pane grows as the handle moves right, and vice versa.
        const grow = edge === "left" ? "ArrowRight" : "ArrowLeft";
        const shrink = edge === "left" ? "ArrowLeft" : "ArrowRight";
        const amount = event.shiftKey ? 4 : 16;
        if (event.key === grow) step(amount);
        else if (event.key === shrink) step(-amount);
        else if (event.key === "Home") step(minimum - width);
        else if (event.key === "End") step(maximum - width);
        else if (event.key === "Enter" || event.key === " ") commit(fallback);
        else return;
        event.preventDefault();
      }}
    />
  );
}

function Sidebar({
  state,
  view,
  setView,
  activeSessionId,
  openSession,
  newSession,
  newProjectSession,
  sessionBusy,
  selectWorkspace,
  switchWorkspace,
  openSearch,
  preferences,
  toggleSidebar,
  renameSession,
  toggleArchive,
  deleteSession,
  deleteArchivedSessions,
  deleteProject,
}: {
  state: DesktopState;
  view: ViewId;
  setView: (view: ViewId) => void;
  activeSessionId: string;
  openSession: (id: string) => void;
  newSession: () => void;
  newProjectSession: (projectRoot: string) => void;
  sessionBusy: boolean;
  selectWorkspace: () => void;
  switchWorkspace: (projectRoot: string) => void;
  openSearch: () => void;
  preferences: UiPreferences;
  toggleSidebar: () => void;
  renameSession: (session: SessionInfo) => void;
  toggleArchive: (session: SessionInfo, archived: boolean) => void;
  deleteSession: (session: SessionInfo) => void;
  deleteArchivedSessions: (sessions: SessionInfo[]) => void;
  deleteProject: (project: { root: string; name: string; active: boolean }) => void;
}) {
  const { language, t } = useI18n();
  const [sessionFilter, setSessionFilter] = useState("");
  const [filterOpen, setFilterOpen] = useState(false);
  const [activeProjectOpen, setActiveProjectOpen] = useState(true);
  const [archivedOpen, setArchivedOpen] = useState(false);
  const [archiveMenuOpen, setArchiveMenuOpen] = useState(false);
  const [sessionMenuId, setSessionMenuId] = useState("");
  const [projectMenuRoot, setProjectMenuRoot] = useState("");
  const organization = useSidebarOrganization();
  const inputControls = useInputControls();
  const sessionStatus = (id: string) => inputControls?.sessionStates[ownerKey(state.workspace.project_root, id)] || (id === inputControls?.sessionId && inputControls.running ? inputControls.approval ? "approval" : "running" : "");
  const archivedIds = useMemo(
    () => new Set(preferences.archivedSessions[state.workspace.project_root] ?? []),
    [preferences.archivedSessions, state.workspace.project_root],
  );
  const filteredSessions = state.sessions.items.filter(session => session.name.toLowerCase().includes(sessionFilter.toLowerCase())).sort((left, right) => {
    const pin = Number(organization.value.sessions.includes(ownerKey(state.workspace.project_root, right.id))) - Number(organization.value.sessions.includes(ownerKey(state.workspace.project_root, left.id)));
    if (pin) return pin;
    return 0;
  });
  const activeSessions = filteredSessions.filter((session) => !archivedIds.has(session.id));
  const archivedSessions = filteredSessions.filter((session) => archivedIds.has(session.id));
  const allArchivedSessions = state.sessions.items.filter((session) => archivedIds.has(session.id));
  const recentProjects = (preferences.recentProjects.length
    ? preferences.recentProjects
    : [state.workspace.project_root]).slice().sort((a, b) => Number(organization.value.projects.includes(b)) - Number(organization.value.projects.includes(a)));

  useEffect(() => {
    const closeMenu = () => {
      setSessionMenuId("");
      setProjectMenuRoot("");
      setArchiveMenuOpen(false);
    };
    const keyDown = (event: globalThis.KeyboardEvent) => {
      if (event.key === "Escape") closeMenu();
    };
    window.addEventListener("pointerdown", closeMenu);
    window.addEventListener("keydown", keyDown);
    return () => {
      window.removeEventListener("pointerdown", closeMenu);
      window.removeEventListener("keydown", keyDown);
    };
  }, []);

  const renderSession = (session: SessionInfo, archived: boolean) => (
    <div className={`session-row ${session.id === activeSessionId ? "active" : ""}`} key={session.id}>
      <button
        type="button"
        className={`session-item ${session.id === activeSessionId ? "active" : ""}`}
        onClick={() => openSession(session.id)}
        onDoubleClick={() => openSession(session.id)}
        title={session.name}
      >
        <span className="session-title">{session.name}</span>
        {sessionStatus(session.id) && <small className="session-state">{t({ running: "运行中", approval: "需审批", failed: "失败", unread: "完成未读", queued: "排队中" }[sessionStatus(session.id)] || "")}</small>}
        <span className="session-meta">{t("session.count", { count: session.message_count, time: formatTime(session.updated_at, language) })}</span>
      </button>
      <button
        type="button"
        className="session-more"
        aria-label={t("session.manage", { name: session.name })}
        aria-expanded={sessionMenuId === session.id}
        onPointerDown={(event) => event.stopPropagation()}
        onClick={(event) => {
          event.stopPropagation();
          setSessionMenuId((current) => current === session.id ? "" : session.id);
        }}
      >
        <MoreHorizontal size={14} />
      </button>
      {sessionMenuId === session.id && (
        <FloatingMenu className="session-menu" close={() => setSessionMenuId("")} side="bottom">
          <button type="button" onClick={() => { organization.pinSession(state.workspace.project_root, session.id); setSessionMenuId(""); }}>{t(organization.value.sessions.includes(ownerKey(state.workspace.project_root, session.id)) ? "取消置顶" : "置顶")}</button>
          <button type="button" onClick={() => { setSessionMenuId(""); renameSession(session); }}>
            <Pencil size={14} /><span>{t("重命名")}</span>
          </button>
          <button type="button" onClick={() => { setSessionMenuId(""); toggleArchive(session, archived); }}>
            {archived ? <ArchiveRestore size={14} /> : <Archive size={14} />}
            <span>{t(archived ? "移出归档" : "归档")}</span>
          </button>
          <div className="session-menu-separator" />
          <button type="button" className="danger" onClick={() => { setSessionMenuId(""); deleteSession(session); }}>
            <Trash2 size={14} /><span>{t("删除")}</span>
          </button>
        </FloatingMenu>
      )}
    </div>
  );

  return (
    <aside className="sidebar">
      <div className="sidebar-drag">
        <BrandMark />
        <button type="button" className="sidebar-collapse-button" aria-label={t("收起左侧栏")} aria-keyshortcuts="Control+B Meta+B" title={`${t("收起左侧栏")} (Ctrl+B)`} onClick={toggleSidebar}>
          <PanelLeftClose size={16} />
        </button>
      </div>
      <div className="sidebar-actions">
        <button type="button" className="new-chat-button" onClick={newSession} disabled={sessionBusy}>
          <Plus size={16} /> {t("新对话")}
          <span>Ctrl N</span>
        </button>
        <button type="button" className="sidebar-action" onClick={openSearch}>
          <Search size={15} /> {t("搜索对话")} <span>Ctrl F</span>
        </button>
      </div>

      <nav className="main-nav" aria-label={t("主导航")}>
        <div className="nav-primary">
        <button type="button" className={view === "chat" ? "active" : ""} onClick={() => setView("chat")}>
          <MessageSquare size={16} /> {t("对话")}
        </button>
        <button type="button" className={view === "tools" ? "active" : ""} onClick={() => setView("tools")}>
          <Wrench size={16} /> {t("工具")}
        </button>
        <button type="button" className={view === "subagents" ? "active" : ""} onClick={() => setView("subagents")}>
          <Bot size={16} /> {t("SubAgents")}
        </button>
        </div>
        <div className="nav-automation">
        <button type="button" className={view === "rats" ? "active" : ""} onClick={() => setView("rats")}>
          <Database size={16} /> RATS
        </button>
        <button type="button" className={view === "tasks" ? "active" : ""} onClick={() => setView("tasks")}>
          <Clock3 size={16} /> {t("RTP 任务")}
        </button>
        </div>
        <div className="nav-utilities">
        <button type="button" className={view === "skills" ? "active" : ""} onClick={() => setView("skills")}>
          <Sparkles size={16} /> {t("技能")}
        </button>
        <button type="button" className={view === "plugins" ? "active" : ""} onClick={() => setView("plugins")}>
          <Plug size={16} /> {t("插件")}
        </button>
        <button type="button" className={view === "recovery" ? "active" : ""} onClick={() => setView("recovery")}>
          <ArchiveRestore size={16} /> {t("恢复")}
        </button>
        </div>
      </nav>

      <div className="project-heading">
        <span>{t("项目与会话")}</span>
        <button type="button" aria-label={t("添加工作区")} onClick={selectWorkspace}><Plus size={14} /></button>
      </div>
      <div className="project-list">
        {organization.error && <p role="alert" className="persistent-error">{organization.error}</p>}
        {recentProjects.map((projectRoot) => {
          const active = projectRoot.toLowerCase() === state.workspace.project_root.toLowerCase();
          const projectName = active ? state.workspace.project_name : projectNameFromPath(projectRoot);
          return (
            <section className={`project-group ${active ? "active" : ""}`} key={projectRoot}>
              <div className="project-row-shell">
                <button
                  type="button"
                  className="project-row"
                  onClick={() => active ? setActiveProjectOpen((value) => !value) : switchWorkspace(projectRoot)}
                >
                  {active && activeProjectOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                  <Folder size={15} />
                  <span>{projectName}</span>
                  {active && <small>{state.sessions.items.length}</small>}
                </button>
                <button
                  type="button"
                  className="project-more"
                  aria-label={t("project.manage", { name: projectName })}
                  aria-expanded={projectMenuRoot === projectRoot}
                  onPointerDown={(event) => event.stopPropagation()}
                  onClick={(event) => {
                    event.stopPropagation();
                    setProjectMenuRoot((current) => current === projectRoot ? "" : projectRoot);
                  }}
                >
                  <MoreHorizontal size={14} />
                </button>
                {projectMenuRoot === projectRoot && (
                  <FloatingMenu className="project-menu" close={() => setProjectMenuRoot("")} side="bottom">
                    <button type="button" onClick={() => { organization.pinProject(projectRoot); setProjectMenuRoot(""); }}>{t(organization.value.projects.includes(projectRoot) ? "取消置顶" : "置顶")}</button>
                    <button type="button" disabled={sessionBusy} onClick={() => { setProjectMenuRoot(""); newProjectSession(projectRoot); }}>
                      <Plus size={14} /><span>{t("新对话")}</span>
                    </button>
                    <button type="button" onClick={() => { setProjectMenuRoot(""); void window.reverie.reveal(projectRoot); }}>
                      <FolderOpen size={14} /><span>{t("显示项目目录")}</span>
                    </button>
                    <div className="session-menu-separator" />
                    <button type="button" className="danger" onClick={() => { setProjectMenuRoot(""); deleteProject({ root: projectRoot, name: projectName, active }); }}>
                      <Trash2 size={14} /><span>{t("删除项目与记录")}</span>
                    </button>
                  </FloatingMenu>
                )}
              </div>
              {active && activeProjectOpen && (
                <>
                  <div className="project-session-actions">
                    <button type="button" onClick={openSearch}><Search size={13} />{t("搜索")}</button>
                    {state.sessions.items.length > 8 && (
                      <button type="button" className={filterOpen ? "active" : ""} onClick={() => { setFilterOpen((value) => !value); setSessionFilter(""); }}>
                        <ListFilter size={13} />{t("筛选")}
                      </button>
                    )}
                  </div>
                  {filterOpen && (
                    <div className="inline-search project-filter">
                      <Search size={13} />
                      <input autoFocus value={sessionFilter} placeholder={t("筛选当前项目")} onChange={(event) => setSessionFilter(event.target.value)} />
                    </div>
                  )}
                  <div className="session-list">
                    {activeSessions.length === 0 && <div className="sidebar-empty">{t("当前项目还没有活跃会话")}</div>}
                    {activeSessions.map((session) => renderSession(session, false))}
                    {allArchivedSessions.length > 0 && (
                      <div className="archived-sessions">
                        <div className="archived-heading-shell">
                          <button type="button" className="archived-heading" onClick={() => setArchivedOpen((value) => !value)}>
                            {archivedOpen ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
                            <Archive size={13} /><span>{t("已归档")}</span><small>{allArchivedSessions.length}</small>
                          </button>
                          <button
                            type="button"
                            className="archived-more"
                            aria-label={t("管理归档会话")}
                            aria-expanded={archiveMenuOpen}
                            onPointerDown={(event) => event.stopPropagation()}
                            onClick={(event) => {
                              event.stopPropagation();
                              setArchiveMenuOpen((current) => !current);
                            }}
                          >
                            <MoreHorizontal size={14} />
                          </button>
                          {archiveMenuOpen && (
                            <FloatingMenu className="project-menu archived-menu" close={() => setArchiveMenuOpen(false)} side="bottom">
                              <button type="button" className="danger" onClick={() => { setArchiveMenuOpen(false); deleteArchivedSessions(allArchivedSessions); }}>
                                <Trash2 size={14} /><span>{t("清空全部归档会话")}</span>
                              </button>
                            </FloatingMenu>
                          )}
                        </div>
                        {archivedOpen && archivedSessions.map((session) => renderSession(session, true))}
                      </div>
                    )}
                  </div>
                </>
              )}
            </section>
          );
        })}
      </div>

      <div className="sidebar-footer">
        <button type="button" className="workspace-button" onClick={selectWorkspace}>
          <div className="workspace-icon"><Folder size={15} /></div>
          <div>
            <strong>{state.workspace.project_name}</strong>
            <span>{state.workspace.project_root}</span>
          </div>
          <MoreHorizontal size={15} />
        </button>
        <button type="button" className={view === "settings" ? "footer-settings active" : "footer-settings"} onClick={() => setView(view === "settings" ? "chat" : "settings")}>
          <Settings size={16} /> {t("设置")}
        </button>
      </div>
    </aside>
  );
}

function ModelPicker({
  state,
  onSelect,
  close,
}: {
  state: DesktopState;
  onSelect: (source: ModelSource, model: ModelRecord, reasoning?: string) => void;
  close: () => void;
}) {
  const { t } = useI18n();
  const dialogRef = useRef<HTMLDivElement>(null);
  useDialogFocus(dialogRef, close);
  const sources = expandModelSources(state.models.sources);
  const [sourceId, setSourceId] = useState(() => activeSourceId(sources, state.models.active_source));
  const [query, setQuery] = useState("");
  const [pendingSelection, setPendingSelection] = useState<{ source: ModelSource; model: ModelRecord } | null>(null);
  const source = sources.find((item) => item.id === sourceId) ?? sources[0];
  if (!source) return null;
  const models = source.models.filter((model) =>
    `${model.display_name} ${model.id}`.toLowerCase().includes(query.toLowerCase()),
  );
  const pendingReasoning = pendingSelection?.model.reasoning;
  return (
    <div className="popover-backdrop" onMouseDown={close}>
      <div ref={dialogRef} className="model-picker" role="dialog" aria-modal="true" aria-label={t("模型来源")} tabIndex={-1} onMouseDown={(event) => event.stopPropagation()}>
        <div className="model-picker-sources">
          <div className="popover-title">{t("模型来源")}</div>
          {sources.map((item) => (
            <button
              type="button"
              key={item.id}
              className={item.id === source.id ? "active" : ""}
              onClick={() => {
                setSourceId(item.id);
                setQuery("");
                setPendingSelection(null);
              }}
            >
              <span>{item.display_name}</span>
              <small>{item.models.length}</small>
            </button>
          ))}
        </div>
        <div className="model-picker-models">
          {pendingSelection && pendingReasoning && pendingReasoning.options.length > 0 ? (
            <>
              <div className="model-picker-header">
                <div>
                  <strong>{t("选择思考程度")}</strong>
                  <span>{pendingSelection.model.display_name}</span>
                </div>
                <button type="button" className="ghost-button" onClick={() => setPendingSelection(null)}>
                  <ChevronLeft size={14} /> {t("返回模型列表")}
                </button>
              </div>
              <div className="model-option-list" aria-label={t("思考程度")}>
                {pendingReasoning.options.map((option) => (
                  <button
                    type="button"
                    key={option.id}
                    className={option.id === pendingReasoning.value ? "active" : ""}
                    onClick={() => onSelect(pendingSelection.source, pendingSelection.model, option.id)}
                  >
                    <div className="model-option-icon"><Brain size={15} /></div>
                    <div>
                      <strong>{t(option.label)}</strong>
                      <span>{t(option.description || "")}</span>
                    </div>
                    {option.id === pendingReasoning.value && <Check size={16} />}
                  </button>
                ))}
              </div>
            </>
          ) : (
            <>
          <div className="model-picker-header">
            <div>
              <strong>{source.display_name}</strong>
              <span>{t("选择用于当前工作区的模型")}</span>
            </div>
            <div className="inline-search model-search">
              <Search size={14} />
              <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t("搜索模型")} autoFocus />
            </div>
          </div>
          <div className="model-option-list" data-source={source.id}>
            {models.map((model) => (
              <button
                type="button"
                key={model.id}
                className={source.active && source.selected_model_id === model.id ? "active" : ""}
                onClick={() => {
                  if (model.reasoning.options.length > 0) {
                    setPendingSelection({ source, model });
                    return;
                  }
                  onSelect(source, model);
                }}
              >
                <div className="model-option-icon">{model.vision ? <Eye size={15} /> : <Brain size={15} />}</div>
                <div>
                  <strong>{model.display_name}</strong>
                  <span>{t(model.description || model.id)}</span>
                  <small>
                    {t(model.transport || "custom")} · {formatTokens(model.context_length)} {t("上下文")}
                    {model.reasoning.control !== "none" ? ` · ${t(model.reasoning.control)}` : ""}
                  </small>
                </div>
                {source.active && source.selected_model_id === model.id && <Check size={16} />}
              </button>
            ))}
            {models.length === 0 && <div className="empty-list">{t("没有匹配的模型")}</div>}
          </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

const COMMAND_VIEWS: Record<string, ViewId> = { "/mode": "settings", "/permission": "settings", "/model": "settings", "/settings": "settings", "/setting": "settings", "/tools": "tools", "/rats": "rats", "/tasks": "tasks", "/operations": "tasks", "/skill": "skills", "/skills": "skills", "/plugins": "plugins", "/checkpoints": "recovery", "/rollback": "recovery" };

function Topbar({
  state,
  view,
  sidebarCollapsed,
  toggleSidebar,
  openModelPicker,
  selectReasoning,
  inspectorOpen,
  toggleInspector,
  openCommands,
  theme,
  setTheme,
}: {
  state: DesktopState;
  view: ViewId;
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
  openModelPicker: () => void;
  selectReasoning: (value: string) => void;
  inspectorOpen: boolean;
  toggleInspector: () => void;
  openCommands: () => void;
  theme: ThemePreference;
  setTheme: (theme: ThemePreference) => void;
}) {
  const { t } = useI18n();
  const [reasoningOpen, setReasoningOpen] = useState(false);
  const [themeOpen, setThemeOpen] = useState(false);
  const activeSource = expandModelSources(state.models.sources).find((source) => source.active);
  const reasoning = activeSource?.selected_reasoning;
  const reasoningOptions = reasoning?.options ?? [];
  const selectedReasoning = reasoningOptions.find((item) => item.id === reasoning?.value);
  const modelSelectionLocked = state.workspace.mode === "computer-controller";
  const viewLabels: Record<ViewId, string> = { chat: "对话", tools: "工具", subagents: "SubAgents", rats: "RATS", tasks: "RTP 任务", skills: "技能", plugins: "插件", recovery: "恢复", settings: "设置" };
  useEffect(() => {
    const closeMenus = (event: globalThis.KeyboardEvent) => {
      if (event.key !== "Escape") return;
      setReasoningOpen(false);
      setThemeOpen(false);
    };
    window.addEventListener("keydown", closeMenus);
    return () => window.removeEventListener("keydown", closeMenus);
  }, []);

  return (
    <header className="topbar">
      <div className="topbar-left">
        {sidebarCollapsed && <IconButton label={`${t("展开左侧栏")} (Ctrl+B)`} ariaKeyShortcuts="Control+B Meta+B" onClick={toggleSidebar}><PanelLeftOpen size={16} /></IconButton>}
        <div className="workspace-breadcrumb"><Folder size={14} /><strong>{state.workspace.project_name || projectNameFromPath(state.workspace.project_root)}</strong><ChevronRight size={12} /><span>{t(viewLabels[view])}</span></div>
      </div>
      <div className="topbar-center">
        {!modelSelectionLocked && (
          <button type="button" className="model-trigger" onClick={openModelPicker}>
            <span className="model-copy"><strong>{activeSource ? state.models.active_model?.display_name || t("选择模型") : t("选择模型")}</strong><small>{activeSource?.display_name || t("选择模型来源")}</small></span>
            <ChevronDown size={14} />
          </button>
        )}
        {reasoning && reasoning.control !== "none" && (
          <div className="relative">
            <button
              type="button"
              className={`reasoning-trigger ${reasoningOptions.length ? "" : "disabled"}`}
              onClick={() => {
                if (!reasoningOptions.length) return;
                setReasoningOpen((value) => !value);
                setThemeOpen(false);
              }}
            >
              <Brain size={14} />
              {selectedReasoning?.label ? t(selectedReasoning.label) : t(reasoning.control === "fixed" ? "固定思考" : reasoning.control === "provider-managed" ? "自动思考" : "思考")}
              {reasoningOptions.length > 0 && <ChevronDown size={12} />}
            </button>
            {reasoningOpen && (
              <FloatingMenu className="small-popover reasoning-menu" close={() => setReasoningOpen(false)} side="bottom">
                {reasoningOptions.map((option) => (
                  <button
                    type="button"
                    key={option.id}
                    className={option.id === reasoning.value ? "active" : ""}
                    onClick={() => {
                      selectReasoning(option.id);
                      setReasoningOpen(false);
                    }}
                  >
                    <div><strong>{t(option.label)}</strong><span>{t(option.description || "")}</span></div>
                    {option.id === reasoning.value && <Check size={14} />}
                  </button>
                ))}
              </FloatingMenu>
            )}
          </div>
        )}
      </div>
      <div className="topbar-right">
        <div className="relative">
          <IconButton label={t("切换主题")} onClick={() => {
            setThemeOpen((value) => !value);
            setReasoningOpen(false);
          }} active={themeOpen}>
            <Palette size={16} />
          </IconButton>
          {themeOpen && (
            <FloatingMenu className="small-popover theme-menu" close={() => setThemeOpen(false)} side="bottom">
              <div className="popover-title">{t("界面主题")}</div>
              {THEME_OPTIONS.map(({ id, label, description, icon: Icon }) => (
                <button
                  type="button"
                  key={id}
                  className={id === theme ? "active" : ""}
                  aria-pressed={id === theme}
                  onClick={() => {
                    setTheme(id);
                    setThemeOpen(false);
                  }}
                >
                  <Icon size={15} />
                  <div><strong>{t(label)}</strong><span>{t(description)}</span></div>
                  {id === theme && <Check size={14} />}
                </button>
              ))}
            </FloatingMenu>
          )}
        </div>
        <IconButton label={t("命令面板")} onClick={openCommands}><Command size={16} /></IconButton>
        <IconButton label={t(inspectorOpen ? "关闭工作面板" : "打开工作面板")} onClick={toggleInspector} active={inspectorOpen}>
          {inspectorOpen ? <PanelRightClose size={16} /> : <PanelRightOpen size={16} />}
        </IconButton>
      </div>
    </header>
  );
}

function GitBranchPicker({ status, busy, refresh, switchBranch, createBranch }: {
  status: GitWorkspaceStatus;
  busy: boolean;
  refresh: () => void;
  switchBranch: (name: string, remote: boolean) => void;
  createBranch: (name: string) => void;
}) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [creating, setCreating] = useState(false);
  const [newBranch, setNewBranch] = useState("");
  const container = useRef<HTMLDivElement>(null);
  const needle = query.trim().toLowerCase();
  const local = status.localBranches.filter((branch) => branch.toLowerCase().includes(needle));
  const remote = status.remoteBranches.filter((branch) => branch.toLowerCase().includes(needle));
  return <div className="git-statusbar" ref={container}>
    <button type="button" className="git-branch-trigger" title={status.repositoryRoot} aria-expanded={open} onClick={() => { setOpen((value) => !value); refresh(); }}>
      <GitBranch size={13} /><span>{status.currentBranch}</span>
      {status.dirtyCount > 0 && <small>{t("git.changes", { count: status.dirtyCount })}</small>}
      <ChevronDown size={12} />
    </button>
    {open && <FloatingMenu className="git-branch-menu" close={() => setOpen(false)} side="top" label={t("Git 分支")}>
      <label className="git-branch-search"><Search size={14} /><input autoFocus value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t("搜索分支")} aria-label={t("搜索分支")} /></label>
      <div className="git-branch-list">
        {local.length > 0 && <><div className="git-branch-section">{t("本地分支")}</div>{local.map((branch) => <button type="button" key={branch} disabled={busy} className={branch === status.currentBranch ? "active" : ""} onClick={() => { setOpen(false); if (branch !== status.currentBranch) switchBranch(branch, false); }}><GitBranch size={14} /><span title={[status.branchDetails?.[branch]?.upstream,status.branchDetails?.[branch]?.tracking,status.branchDetails?.[branch]?.lastCommit,status.branchDetails?.[branch]?.worktree].filter(Boolean).join(" · ")}>{branch}<small>{status.branchDetails?.[branch]?.upstream} {status.branchDetails?.[branch]?.tracking} {status.branchDetails?.[branch]?.lastCommit} {status.branchDetails?.[branch]?.worktree}</small>{branch === status.currentBranch && status.dirtyCount > 0 && <small>{t("git.uncommitted", { count: status.dirtyCount })}</small>}</span>{branch === status.currentBranch && <Check size={15} />}</button>)}</>}
        {remote.length > 0 && <><div className="git-branch-section">{t("远端分支")}</div>{remote.map((branch) => <button type="button" key={branch} disabled={busy} onClick={() => { setOpen(false); switchBranch(branch, true); }}><GitBranch size={14} /><span>{branch}</span></button>)}</>}
        {!local.length && !remote.length && <div className="git-branch-empty">{t("没有匹配的分支")}</div>}
      </div>
      <div className="git-branch-footer">
        {creating ? <form onSubmit={(event) => { event.preventDefault(); if (newBranch.trim()) { createBranch(newBranch); setNewBranch(""); setCreating(false); setOpen(false); } }}><input autoFocus value={newBranch} onChange={(event) => setNewBranch(event.target.value)} placeholder={t("新分支名称")} aria-label={t("新分支名称")} /><button type="submit" disabled={busy || !newBranch.trim()}>{t("创建")}</button><button type="button" onClick={() => setCreating(false)} aria-label={t("取消")}><X size={14} /></button></form>
          : <button type="button" disabled={busy} onClick={() => setCreating(true)}><Plus size={15} />{t("创建并切换到新分支")}</button>}
        <details><summary>{t("独立工作目录")}</summary>{[...new Set(Object.values(status.branchDetails || {}).map(item=>item.worktree).filter(directory=>directory && directory.toLowerCase()!==status.repositoryRoot.toLowerCase()))].map(directory=><button type="button" key={directory} title={directory} onClick={()=>{setOpen(false);window.dispatchEvent(new CustomEvent("reverie:workspace-open",{detail:{root:directory}}));}}>{t("打开并创建会话")} · {directory}</button>)}</details>
      </div>
    </FloatingMenu>}
  </div>;
}

const ActivityItem = memo(function ActivityItem({ event }: { event: Record<string, unknown> }) {
  const { t } = useI18n();
  const [expanded, setExpanded] = useState(false);
  const item = eventLabel(event);
  const argumentsText = item.toolName.toLowerCase().startsWith("rats_") ? ""
    : typeof event.arguments === "string" ? event.arguments : event.arguments ? JSON.stringify(event.arguments, null, 2) : "";
  const output = messageText(event.output);
  const error = String(event.error ?? "");
  const statusIcon = item.status === "success"
    ? <CheckCircle2 size={14} />
    : item.status === "error" || item.status === "warning"
      ? <AlertCircle size={14} />
      : item.status === "working"
        ? <RefreshCw className="spin" size={13} />
        : <Circle size={9} />;
  const categoryIcon = item.toolName || item.category.toLowerCase().includes("tool")
    ? <ToolGlyph name={item.toolName || item.title} size={13} />
    : item.category.toLowerCase().includes("subagent")
      ? <Bot size={13} />
      : item.category.toLowerCase().includes("model")
        ? <Brain size={13} />
        : <Activity size={13} />;
  return (
    <details className={`activity-item ${item.status}`} open={expanded} onToggle={(toggle) => setExpanded(toggle.currentTarget.open)}>
      <summary>
      <div className="activity-status">{statusIcon}</div>
      <div className="activity-copy">
        <div className="activity-heading"><strong>{item.title}</strong><small>{categoryIcon}{item.category}</small>{item.agentId && item.agentId !== "main" && <code>{item.agentId}</code>}</div>
      </div>
      <ChevronDown size={12} />
      </summary>
      {expanded && <div className="activity-expanded">
        {argumentsText && <><strong>{t("调用参数")}</strong><pre>{argumentsText}</pre></>}
        {output && <><strong>{t("工具结果")}</strong><pre>{output}</pre></>}
        {error && <pre className="error">{error}</pre>}
        {item.detail && item.detail !== output && item.detail !== error && <pre>{item.detail}</pre>}
        {item.meta && <small className="activity-meta">{item.meta}</small>}
      </div>}
    </details>
  );
});

const ActivityGroup = memo(function ActivityGroup({ events, defaultExpanded = false }: { events: Array<Record<string, unknown>>; defaultExpanded?: boolean }) {
  const { t } = useI18n();
  const [expanded, setExpanded] = useState(defaultExpanded);
  useEffect(() => setExpanded(defaultExpanded), [defaultExpanded]);
  const working = events.find(event => eventLabel(event).status === "working");
  return <details className="activity-group" open={expanded} onToggle={(toggle) => setExpanded(toggle.currentTarget.open)}>
    <summary><Wrench size={14} /><strong>{t("工具调用步骤")}</strong><span>{t("live.activityCount", { count: events.length })}</span>{working && <small>{eventLabel(working).title}</small>}<ChevronDown size={13} /></summary>
    {expanded && <div className="inline-activities">{events.map((event, index) => <ActivityItem key={String(event.tool_call_id || event.activity_id || index)} event={event} />)}</div>}
  </details>;
});

function ToolGlyph({ name, size = 14 }: { name: string; size?: number }) {
  const normalized = name.toLowerCase();
  // The Thinking Tool is reasoning wearing a tool's clothes, so it gets the reasoning icon.
  if (normalized.includes("think")) return <Brain size={size} />;
  if (normalized.includes("search") || normalized.includes("find") || normalized.includes("grep")) return <FileSearch size={size} />;
  if (normalized.includes("shell") || normalized.includes("terminal") || normalized.includes("command") || normalized.includes("exec")) return <Terminal size={size} />;
  if (normalized.includes("browser") || normalized.includes("web") || normalized.includes("http")) return <Globe size={size} />;
  if (normalized.includes("plugin") || normalized.includes("mcp")) return <Plug size={size} />;
  if (normalized.includes("file") || normalized.includes("read") || normalized.includes("write") || normalized.includes("patch")) return <FileText size={size} />;
  return <Wrench size={size} />;
}

function HistoryToolResult({
  message,
  text,
  defaultExpanded,
}: {
  message: SessionMessage;
  text: string;
  defaultExpanded: boolean;
}) {
  const { t } = useI18n();
  const [expanded, setExpanded] = useState(defaultExpanded);
  useEffect(() => setExpanded(defaultExpanded), [defaultExpanded]);
  const name = message.name || t("工具结果");
  const error = /^\s*(error|\[error|failed|exception)/i.test(text);
  return (
    <details
      className={`tool-message history-tool-result ${error ? "error" : ""}`}
      open={expanded}
      onToggle={(event) => setExpanded(event.currentTarget.open)}
    >
      <summary>
        <span className="trace-icon"><ToolGlyph name={name} /></span>
        <span className="trace-summary">
          <strong>{name}</strong>
          <small>{t(error ? "执行失败" : "工具结果")}</small>
        </span>
        <span className="trace-preview">{text.slice(0, 140)}</span>
        <ChevronDown size={13} />
      </summary>
      {expanded && <pre>{text}</pre>}
    </details>
  );
}

function HistoryReasoning({ text, defaultExpanded, active = false }: { text: string; defaultExpanded: boolean; active?: boolean }) {
  const { t } = useI18n();
  const [expanded, setExpanded] = useState(defaultExpanded);
  useEffect(() => setExpanded(defaultExpanded), [defaultExpanded]);
  return <details className={`reasoning-block ${active ? "active" : ""}`} open={expanded} onToggle={event => setExpanded(event.currentTarget.open)}>
    <summary><Brain size={15} /><span>{t(active ? "正在思考" : "已思考")}</span><ChevronDown size={12} /></summary>
    {expanded && <div className="reasoning-content"><Markdown>{text}</Markdown></div>}
  </details>;
}

function ToolCallList({ message }: { message: SessionMessage }) {
  const { t } = useI18n();
  const calls = toolCallRecords(message);
  if (!calls.length) return null;
  return (
    <div className="tool-call-list">
      {calls.map((call, index) => {
        // The Thinking Tool carries prose, not parameters, so render the reasoning
        // itself inside the ordinary tool-call card instead of raw JSON.
        const thinking = isThinkTool(call.name) ? thinkToolText(call.arguments) : "";
        const preview = thinking || call.arguments;
        return (
          <details className="tool-call-card" key={`${call.name}-${index}`}>
            <summary>
              <span className="trace-icon"><ToolGlyph name={call.name} /></span>
              <span><strong>{call.name}</strong><small>{t(thinking ? "推理记录" : "模型调用")}</small></span>
              {preview && <code>{preview.replace(/\s+/g, " ").slice(0, 90)}</code>}
              <ChevronDown size={13} />
            </summary>
            {thinking
              ? <div className="reasoning-content"><Markdown>{thinking}</Markdown></div>
              : call.arguments ? <pre>{call.arguments}</pre> : null}
          </details>
        );
      })}
    </div>
  );
}

/**
 * One transcript row.
 *
 * Memoized: a stored message never changes once it is on screen, so a streaming
 * turn -- which re-renders the conversation up to 25 times a second -- must not
 * rebuild the markdown of every message above it. Both props come straight from
 * state, so their identities are stable between renders.
 */
const Message = memo(function Message({ message, preferences }: { message: SessionMessage; preferences: UiPreferences }) {
  const { language, t } = useI18n();
  const text = messageText(message.content, language);
  const reasoning = messageReasoningText(message);
  const calls = toolCallRecords(message);
  const visibleReasoning = preferences.showReasoning && Boolean(reasoning);
  const visibleCalls = preferences.showToolCalls && calls.length > 0;
  // Older sessions can contain a model's provisional prose alongside a pure
  // deep_think call. It is not the final answer (the call asks the model to
  // continue), so rendering it makes one turn look like two replies.
  const provisionalThinking = message.role === "assistant" && calls.length > 0 && calls.every((call) => isThinkTool(call.name));
  const visibleText = provisionalThinking ? "" : text;
  const userParts = message.role === "user" && Array.isArray(message.content) ? message.content.map(asRecord) : null;
  const hasLocalMedia = userParts?.some(part => ["local_image", "local_video"].includes(String(part.type)) && typeof part.file_path === "string");
  if (message.role === "system" || (!visibleText && !visibleReasoning && !visibleCalls && !hasLocalMedia)) return null;
  if (message.role === "tool") {
    return preferences.showToolResults
      ? <HistoryToolResult message={message} text={text} defaultExpanded={preferences.expandToolResults} />
      : null;
  }
  const user = message.role === "user";
  const userName = preferences.userDisplayName || t("你");
  const technicalOnly = message.role === "assistant" && !visibleText && (visibleReasoning || visibleCalls);
  return (
    <article className={`message ${message.role} ${technicalOnly ? "technical-only" : ""}`}>
      {!technicalOnly && <div className="message-heading">
        {user ? <UserAvatar name={userName} url={preferences.userAvatarUrl} /> : <div className="message-avatar"><Sparkles size={15} strokeWidth={1.7} /></div>}
        <strong>{user ? userName : "Reverie"}</strong>
      </div>}
      <div className="message-body">
        {visibleReasoning && <HistoryReasoning text={reasoning} defaultExpanded={preferences.expandReasoning} />}
        {visibleCalls && <ToolCallList message={message} />}
        {userParts ? userParts.map((part, index) => {
          if (["local_image", "local_video"].includes(String(part.type)) && typeof part.file_path === "string") {
            const name = String(part.file_name || part.file_path);
            return <button key={index} type="button" className="message-attachment" aria-label={`${t("打开文件预览")} ${name}`} onClick={() => window.dispatchEvent(new CustomEvent("reverie:file-open", { detail: { path: part.file_path } }))}>
              <Image size={18} /><span>{name}</span>{typeof part.file_size === "number" && <small>{formatFileSize(part.file_size)}</small>}
            </button>;
          }
          const value = messageText([part], language);
          return value ? <div key={index} className="user-text">{value}</div> : null;
        }) : visibleText && (message.role === "assistant" ? <Markdown>{visibleText}</Markdown> : <div className="user-text">{visibleText}</div>)}
      </div>
    </article>
  );
});

// The turn error is the humanized detail (e.g. the OpenCode free-tier guidance
// with its `/opencode key ...` suggestion) -- it can span several lines, so it
// lives in the message body under the output as a readable block, not a
// one-line flash. The transient toast is only the headline; this is the detail.
function InlineError({ detail }: { detail: string }) {
  const { t } = useI18n();
  const [copied, setCopied] = useState(false);
  const htmlResponse = /<!doctype\s+html|<html[\s>]/i.test(detail);
  const summary = htmlResponse ? t(/Attention Required!.*Cloudflare/i.test(detail)
    ? "供应商返回了 Cloudflare 拦截页面，本轮未获得模型回复。请检查供应商地址或稍后重试。"
    : "供应商返回了网页内容，本轮未获得模型回复。请检查供应商地址或查看原始错误。") : "";
  const copy = useCallback(() => {
    void navigator.clipboard?.writeText(detail).then(() => {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    }).catch(() => {});
  }, [detail]);
  return (
    <div className="inline-error" role="alert">
      <div className="inline-error-head">
        <AlertCircle size={15} />
        <strong>{t("本轮出错")}</strong>
        <button type="button" className="inline-error-copy" onClick={copy} aria-label={t("复制")}>
          {copied ? <><Check size={12} /> {t("已复制")}</> : <><Copy size={12} /> {t("复制")}</>}
        </button>
      </div>
      {summary ? <>
        <p className="inline-error-summary">{summary}</p>
        <details className="inline-error-details"><summary>{t("查看原始错误")}</summary><pre className="inline-error-body">{detail}</pre></details>
      </> : <pre className="inline-error-body">{detail}</pre>}
    </div>
  );
}

const LiveMessage = memo(function LiveMessage({ turn, running, preferences }: { turn: LiveTurn; running: boolean; preferences: UiPreferences }) {
  const { t } = useI18n();
  const userName = preferences.userDisplayName || t("你");
  const liveStatus = turn.error ? t("失败") : running ? t("正在处理") : turn.stopped ? t("已停止") : t("已完成");
  const liveStatusClass = turn.error ? "error" : running ? "working" : turn.stopped ? "stopped" : "success";
  const visibleOutput = (text: string) => turn.error && text.endsWith(turn.error) ? text.slice(0, -turn.error.length).trimEnd() : text;
  return (
    <>
      {!turn.resumed && <article className="message user live-user-message">
        <div className="message-heading"><UserAvatar name={userName} url={preferences.userAvatarUrl} /><strong>{userName}</strong></div>
        <div className="message-body"><div className="user-text">{turn.userText}</div>
          {turn.attachments?.map((attachment, index) => <button key={index} type="button" className="message-attachment" aria-label={`${t("打开文件预览")} ${attachment.name}`} onClick={() => window.dispatchEvent(new CustomEvent("reverie:file-open", { detail: { path: attachment.relativePath } }))}>
            <FileText size={18} /><span>{attachment.name}</span><small>{formatFileSize(attachment.size)}</small>
          </button>)}
        </div>
      </article>}
      <article className="message assistant live-message">
        <div className="message-heading"><div className="message-avatar"><Sparkles size={15} strokeWidth={1.7} /></div><strong>Reverie</strong><span className={`live-status ${liveStatusClass}`}>{liveStatus}</span></div>
        <div className="message-body">
          {(turn.segments ?? []).map((segment, index) => segment.kind === "activity"
            ? preferences.showLiveActivity && <ActivityGroup key={index} events={segment.events} />
            : segment.kind === "reasoning"
              ? preferences.showReasoning && <HistoryReasoning key={index} text={segment.text} defaultExpanded={preferences.expandReasoning} active={running && index === (turn.segments?.length ?? 0) - 1} />
              : segment.kind === "view"
                ? <InteractiveView key={`view-${segment.view.viewId || index}`} segment={segment.view} />
                : <StreamingMarkdown key={index} running={running}>{visibleOutput(segment.text)}</StreamingMarkdown>)}
          {!turn.segments?.length && turn.assistantText && <StreamingMarkdown running={running}>{visibleOutput(turn.assistantText)}</StreamingMarkdown>}
          {running && <div className="typing"><span /><span /><span /></div>}
          {turn.error && <InlineError detail={turn.error} />}
        </div>
      </article>
    </>
  );
});

// One colour per context segment. The lavender accent leads (system prompt),
// then cooler-to-warmer hues for injected context, the conversation roles, and
// a muted grey for the un-bucketed request overhead.
const CONTEXT_SEGMENT_COLORS: Record<string, string> = {
  system_prompt: "#c7b5ff",
  injected_context: "#7fb0ff",
  memory: "#5fc8d6",
  user: "#7fd6ad",
  assistant: "#f0c274",
  tool: "#e59aa0",
  api_context: "#c7b5ff",
  local_delta: "#7fd6ad",
  overhead: "#606a79",
};

// A small ring in the composer showing how full the context window is, split by
// category. The filled sweep is total/max; each coloured arc is one segment's
// share of the window. Hover reveals the exact token split.
function ContextRing({ usage }: { usage: ContextUsage | null }) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const [coords, setCoords] = useState<{ right: number; bottom: number } | null>(null);
  const anchor = useRef<HTMLDivElement>(null);
  const closeTimer = useRef<number | null>(null);

  const cancelClose = useCallback(() => {
    if (closeTimer.current !== null) {
      window.clearTimeout(closeTimer.current);
      closeTimer.current = null;
    }
  }, []);
  const openNow = useCallback(() => {
    cancelClose();
    setOpen(true);
  }, [cancelClose]);
  // Grace period so moving the pointer from the ring across the gap to the
  // portaled popover (a separate DOM subtree) doesn't dismiss it.
  const closeSoon = useCallback(() => {
    cancelClose();
    closeTimer.current = window.setTimeout(() => setOpen(false), 120);
  }, [cancelClose]);
  useEffect(() => cancelClose, [cancelClose]);

  // The popover is portaled to <body> to escape the composer's overflow:hidden
  // (and backdrop-filter) clip, so anchor it manually to the ring each frame.
  useLayoutEffect(() => {
    if (!open) return;
    const place = () => {
      const node = anchor.current;
      if (!node) return;
      const rect = node.getBoundingClientRect();
      setCoords({
        right: Math.max(8, window.innerWidth - rect.right),
        bottom: Math.max(8, window.innerHeight - rect.top + 8),
      });
    };
    place();
    window.addEventListener("scroll", place, true);
    window.addEventListener("resize", place);
    return () => {
      window.removeEventListener("scroll", place, true);
      window.removeEventListener("resize", place);
    };
  }, [open]);

  if (!usage || !usage.max_tokens) return null;

  const size = 26;
  const stroke = 3.5;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const pct = Math.max(0, Math.min(usage.percentage, 100));
  const state = pct >= 82 ? "danger" : pct >= 70 ? "warn" : "ok";

  const withOverhead = usage.overhead_tokens > 0
    ? [...usage.segments, { key: "overhead", tokens: usage.overhead_tokens, messages: 0, share: (usage.overhead_tokens / usage.total_tokens) * 100 }]
    : usage.segments;
  let cumulative = 0;
  const arcs = withOverhead
    .filter((seg) => seg.tokens > 0)
    .map((seg) => {
      const fraction = usage.max_tokens ? seg.tokens / usage.max_tokens : 0;
      const arc = {
        key: seg.key,
        color: CONTEXT_SEGMENT_COLORS[seg.key] ?? CONTEXT_SEGMENT_COLORS.overhead,
        dash: Math.max(0, fraction * circumference),
        offset: -cumulative * circumference,
        tokens: seg.tokens,
      };
      cumulative += fraction;
      return arc;
    });

  const segmentLabel = (key: string) => t(`context.segment.${key}`);

  return (
    <div className="context-ring" ref={anchor} onMouseEnter={openNow} onMouseLeave={closeSoon}>
      <button
        type="button"
        className={`context-ring-button context-ring-${state}`}
        aria-label={t("context.usage.aria", { percent: Math.round(pct) })}
        aria-expanded={open}
        onClick={() => {
          if (open) {
            cancelClose();
            setOpen(false);
          } else {
            openNow();
          }
        }}
      >
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
          <g transform={`rotate(-90 ${size / 2} ${size / 2})`}>
            <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="var(--context-ring-track)" strokeWidth={stroke} />
            {arcs.map((arc) => (
              <circle
                key={arc.key}
                cx={size / 2}
                cy={size / 2}
                r={radius}
                fill="none"
                stroke={arc.color}
                strokeWidth={stroke}
                strokeDasharray={`${arc.dash} ${circumference}`}
                strokeDashoffset={arc.offset}
                strokeLinecap="butt"
              />
            ))}
          </g>
        </svg>
        <span className="context-ring-pct">{Math.round(pct)}</span>
      </button>
      {open && coords && createPortal(
        <div
          className="context-ring-popover"
          role="tooltip"
          style={{ right: coords.right, bottom: coords.bottom }}
          onMouseEnter={openNow}
          onMouseLeave={closeSoon}
        >
          <div className="context-ring-head">
            <strong>{t("context.usage.title")}</strong>
            <span>{formatTokens(usage.total_tokens)} / {formatTokens(usage.max_tokens)} · {Math.round(pct)}%</span>
          </div>
          <ul className="context-ring-list">
            {withOverhead.filter((seg) => seg.tokens > 0).map((seg) => (
              <li key={seg.key}>
                <span className="context-ring-swatch" style={{ background: CONTEXT_SEGMENT_COLORS[seg.key] ?? CONTEXT_SEGMENT_COLORS.overhead }} />
                <span className="context-ring-name">{segmentLabel(seg.key)}</span>
                <span className="context-ring-tokens">{seg.tokens.toLocaleString()}</span>
              </li>
            ))}
          </ul>
          <div className="context-ring-foot">
            <span>{t("context.usage.remaining", { tokens: formatTokens(usage.remaining_tokens) })}</span>
            <span className="context-ring-approx">{t(usage.usage_source === "api" ? "context.usage.api" : usage.usage_source === "mixed" ? "context.usage.mixed" : usage.tokenizer.exact ? "context.usage.local" : "context.usage.approx")}</span>
          </div>
        </div>,
        document.body,
      )}
    </div>
  );
}

function taskListEntries(value: unknown): TaskListEntry[] {
  if (!Array.isArray(value)) return [];
  return value.flatMap((item, index) => {
    const task = asRecord(item);
    const name = String(task.name ?? "").trim();
    return name ? [{ id: String(task.id ?? index), name, state: String(task.state ?? "NOT_STARTED"), indent: Number(task.indent) || 0 }] : [];
  });
}

function TaskBar({ tasks, running, resumable, resume }: { tasks: TaskListEntry[]; running: boolean; resumable: boolean; resume: () => void }) {
  const { t } = useI18n();
  const [expanded, setExpanded] = useState(false);
  if (!tasks.length && !resumable) return null;
  const current = tasks.find(task => task.state === "IN_PROGRESS")
    ?? tasks.find(task => task.state === "NOT_STARTED")
    ?? tasks.at(-1);
  const summary = current?.name ?? t(running ? "正在处理任务" : "继续任务");
  return <div className="task-bar">
    <div className="task-bar-head">
      <button type="button" className="task-bar-toggle" aria-expanded={expanded} aria-label={t("任务列表")} onClick={() => setExpanded(!expanded)}>
        <ChevronDown size={14} className={expanded ? "task-bar-chevron expanded" : "task-bar-chevron"} />
        {running ? <RefreshCw className="spin" size={13} /> : <List size={13} />}
        <span>{summary}</span>
        {tasks.length > 0 && <small>{tasks.filter(task => task.state === "COMPLETED").length}/{tasks.length}</small>}
      </button>
      {resumable && <button type="button" className="task-bar-resume" onClick={resume} disabled={running}><RotateCcw size={13} />{t("继续任务")}</button>}
    </div>
    {expanded && <div className="task-bar-list" role="list" aria-label={t("任务列表")}>
      {tasks.length ? tasks.map((task) => <div key={task.id} className={`task-bar-task ${task.state.toLowerCase()}`} role="listitem" style={{ paddingLeft: `${10 + Math.min(8, Math.max(0, task.indent)) * 14}px` }}>
        {task.state === "COMPLETED" ? <CheckCircle2 size={14} /> : task.state === "IN_PROGRESS" ? <RefreshCw size={14} /> : <Circle size={12} />}
        <span>{task.name}</span>
      </div>) : <div className="task-bar-empty">{t("任务列表尚未建立")}</div>}
    </div>}
  </div>;
}

function ComposerMode() {
  const controls = useInputControls();
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const mode = MODES.find(item => item[0] === controls?.mode) ?? MODES[0];
  const Icon = mode[2];
  return <div className="composer-mode">
    <button type="button" className="mode-trigger" aria-label={t("选择工作模式")} aria-expanded={open} onClick={() => setOpen(value => !value)}><Icon size={15} /><span>{t(mode[1])}</span><ChevronDown size={12} /></button>
    {open && <FloatingMenu className="small-popover mode-menu" side="top" close={() => setOpen(false)}>{MODES.map(([id, label, ModeIcon]) => <button type="button" key={id} className={id === controls?.mode ? "active" : ""} onClick={() => { controls?.setMode?.(id); setOpen(false); }}><ModeIcon size={15} /><span>{t(label)}</span>{id === controls?.mode && <Check size={14} />}</button>)}</FloatingMenu>}
  </div>;
}

function Composer({
  value,
  setValue,
  send,
  running,
  cancel,
  mentionItems,
  mentionOpen,
  mentionLoading,
  requestMentions,
  chooseMention,
  attachments,
  selectAttachment,
  importDroppedFiles,
  removeAttachment,
  pinnedSkills,
  unresolvedSkills,
  unpinSkill,
  modelName,
  contextUsage,
  tasks,
  resumable,
  resume,
  disabled = false,
}: {
  value: string;
  setValue: (value: string) => void;
  send: () => void;
  running: boolean;
  cancel: () => void;
  mentionItems: Array<Record<string, unknown>>;
  mentionOpen: boolean;
  mentionLoading: boolean;
  requestMentions: (query?: string) => void;
  chooseMention: (value: string, range?: { start: number; end: number }) => void;
  attachments: ComposerAttachment[];
  selectAttachment: () => void;
  importDroppedFiles: (files: File[]) => void;
  removeAttachment: (attachment: ComposerAttachment) => void;
  pinnedSkills: string[];
  unresolvedSkills: string[];
  unpinSkill: (name: string) => void;
  modelName: string;
  contextUsage: ContextUsage | null;
  tasks: TaskListEntry[];
  resumable: boolean;
  resume: () => void;
  disabled?: boolean;
}) {
  const { t } = useI18n();
  const textarea = useRef<HTMLTextAreaElement>(null);
  const controls = useInputControls();
  const anchor = useRef<HTMLDivElement>(null);
  const menuId = useId();
  const [caret, setCaret] = useState(value.length);
  const [selected, setSelected] = useState(0);
  const [dismissed, setDismissed] = useState("");
  const [skillBusy, setSkillBusy] = useState(false);
  const token = composerToken(value, Math.min(caret, value.length));
  const tokenKey = token ? `${token.kind}:${token.start}:${token.end}:${token.query}` : "";
  const owner = `${controls?.projectRoot}:${controls?.sessionId}`;
  const menuOpen = Boolean(token && dismissed !== tokenKey && !disabled);
  const mentionMode = token?.kind === "mention";
  const callbacks = useRef({ requestMentions, close: controls?.closeMentions });
  callbacks.current = { requestMentions, close: controls?.closeMentions };
  useEffect(() => {
    callbacks.current.close?.();
    setSelected(0);
    if (!menuOpen || !mentionMode || !token) return;
    const timer = window.setTimeout(() => callbacks.current.requestMentions(token.query), 120);
    return () => window.clearTimeout(timer);
  }, [tokenKey, menuOpen, owner]);
  const full = Boolean(controls?.skills && pinnedSkills.length + unresolvedSkills.length >= controls.skills.pinned.max);
  const options: CompletionOption[] = !token ? [] : mentionMode ? mentionItems.map((item, index) => {
    const path = String(item.path ?? item.file_path ?? "");
    const line = Number(item.line ?? item.start_line ?? 0);
    return { id: `file:${index}:${path}`, kind: "file", label: String(item.name ?? path.split(/[\\/]/).pop() ?? path), description: `${path}${line ? `:${line}` : ""}`, value: `${workspaceMention(path)}${line ? `#L${line}` : ""}` };
  }) : slashOptions(token, controls?.commands ?? [], controls?.skills?.records ?? [], full, t);
  const loading = skillBusy || (mentionMode && (!mentionOpen || mentionLoading));
  const closeMenu = useCallback(() => { setDismissed(tokenKey); controls?.closeMentions(); }, [tokenKey, controls?.closeMentions]);
  const focusAt = (position: number) => requestAnimationFrame(() => { textarea.current?.focus(); textarea.current?.setSelectionRange(position, position); setCaret(position); });
  const insertTrigger = (trigger: string) => {
    if (token?.kind === (trigger === "@" ? "mention" : "command") && menuOpen) { closeMenu(); textarea.current?.focus(); return; }
    const start = textarea.current?.selectionStart ?? value.length;
    const end = textarea.current?.selectionEnd ?? start;
    const prefix = start > 0 && !/\s$/.test(value.slice(0, start)) ? " " : "";
    const next = trigger === "/" && value.trim() ? value : value.slice(0, start) + prefix + trigger + value.slice(end);
    if (trigger === "/" && value.trim()) { window.dispatchEvent(new CustomEvent("reverie:commands")); return; }
    setDismissed(""); setValue(next); focusAt(start + prefix.length + trigger.length);
  };
  const chooseCompletion = async (option: CompletionOption) => {
    if (!token || option.disabled || skillBusy) return;
    if (option.kind === "file") {
      chooseMention(option.value, token);
      closeMenu(); focusAt(token.start); return;
    }
    if (option.kind === "skill") {
      setSkillBusy(true);
      const pinned = await controls?.pinSkill?.(option.value);
      setSkillBusy(false);
      if (!pinned) return;
      setValue(value.slice(0, token.start) + value.slice(token.end));
      closeMenu(); focusAt(token.start); return;
    }
    const next = value.slice(0, token.start) + option.value + value.slice(token.end);
    setValue(next); setDismissed(""); focusAt(token.start + option.value.length);
  };
  const [forceAvailable, setForceAvailable] = useState(false);
  useEffect(() => { setForceAvailable(false); if (!running || !controls?.status.includes(t("正在停止，等待当前操作结束"))) return; const timer = window.setTimeout(() => setForceAvailable(true), 15000); return () => window.clearTimeout(timer); }, [running, controls?.status, t]);
  useEffect(() => setSelected(0), [mentionItems]);
  const dragDepth = useRef(0);
  const [draggingFiles, setDraggingFiles] = useState(false);
  useEffect(() => {
    if (!textarea.current) return;
    textarea.current.style.height = "auto";
    textarea.current.style.height = `${Math.min(textarea.current.scrollHeight, 220)}px`;
  }, [value]);

  const keyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.nativeEvent.isComposing || event.nativeEvent.keyCode === 229) return;
    if (event.key === "Enter" && event.ctrlKey && event.altKey && running) { event.preventDefault(); controls?.steer(); return; }
    if (skillBusy) { if (event.key === "Enter") event.preventDefault(); return; }
    if (menuOpen) {
      if (event.key === "Escape") { event.preventDefault(); event.stopPropagation(); closeMenu(); return; }
      if (!event.shiftKey && !event.ctrlKey && !event.altKey && !event.metaKey) {
        if (event.key === "ArrowDown" || event.key === "ArrowUp") {
          event.preventDefault();
          setSelected(index => options.length ? (index + (event.key === "ArrowDown" ? 1 : -1) + options.length) % options.length : 0);
          return;
        }
        if (event.key === "Enter" || event.key === "Tab") {
          event.preventDefault();
          if (!loading && options[selected]) void chooseCompletion(options[selected]);
          return;
        }
      }
    }
    if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) {
      if (disabled) return;
      event.preventDefault();
      if (value.trim() || attachments.length) send();
    }
  };

  const fileDrag = (event: DragEvent<HTMLDivElement>) => Array.from(event.dataTransfer.types).includes("Files");
  const dragEnter = (event: DragEvent<HTMLDivElement>) => {
    if (disabled || !fileDrag(event)) return;
    event.preventDefault();
    dragDepth.current += 1;
    setDraggingFiles(true);
  };
  const dragOver = (event: DragEvent<HTMLDivElement>) => {
    if (disabled || !fileDrag(event)) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = "copy";
  };
  const dragLeave = (event: DragEvent<HTMLDivElement>) => {
    if (!fileDrag(event)) return;
    dragDepth.current = Math.max(0, dragDepth.current - 1);
    if (!dragDepth.current) setDraggingFiles(false);
  };
  const drop = (event: DragEvent<HTMLDivElement>) => {
    if (disabled || !fileDrag(event)) return;
    event.preventDefault();
    dragDepth.current = 0;
    setDraggingFiles(false);
    const files = Array.from(event.dataTransfer.files);
    if (files.length) importDroppedFiles(files);
  };

  return (
    <div className="composer-shell">
      <GoalSummary />
      <TaskBar tasks={tasks} running={running} resumable={resumable && !disabled} resume={resume} />
      <QueueStrip />
      {menuOpen && <ComposerSuggestions anchor={anchor} id={menuId} title={t(mentionMode ? "引用工作区文件" : token?.kind === "skill" ? "选择必须使用的 Skill" : "指令与 Skills")} hint={t(mentionMode ? "输入文件名筛选，选择后加入附件" : token?.kind === "skill" ? "固定后每轮必须使用，直到取消固定" : "选择指令填入输入框，或固定一个 Skill")} options={options} selected={selected} loading={loading} error={mentionMode ? controls?.mentionError : undefined} choose={option => void chooseCompletion(option)} select={setSelected} close={closeMenu} />}
      <div ref={anchor} className={`composer ${draggingFiles ? "dragging-files" : ""}`} onDragEnter={dragEnter} onDragOver={dragOver} onDragLeave={dragLeave} onDrop={drop}>
        {draggingFiles && <div className="composer-drop-overlay"><Paperclip size={20} /><strong>{t("拖放文件以添加附件")}</strong><span>{t("最多一次添加 20 个本地文件")}</span></div>}
        {(pinnedSkills.length > 0 || unresolvedSkills.length > 0) && (
          <div className="skill-strip"><span className="skill-strip-label"><Pin size={12} />{t("必须使用")}</span>
            {pinnedSkills.map((name) => (
              <span className="skill-chip" key={name} title={t("skill.pinned.hint", { name })}>
                <Sparkles size={12} />
                <span>{name}</span>
                <button type="button" aria-label={t("skill.unpin", { name })} onClick={() => unpinSkill(name)}><X size={11} /></button>
              </span>
            ))}
            {unresolvedSkills.map((name) => (
              <span className="skill-chip skill-chip-stale" key={`stale-${name}`} title={t("skill.pinned.stale", { name })}>
                <Sparkles size={12} />
                <span>{name}</span>
                <button type="button" aria-label={t("skill.unpin", { name })} onClick={() => unpinSkill(name)}><X size={11} /></button>
              </span>
            ))}
          </div>
        )}
        <AttachmentCards items={attachments} remove={removeAttachment} />
        {controls?.error && <p className="persistent-error" role="alert">{controls.error}</p>}
        {running && controls?.status && <p className="composer-status" role="status">{controls.status}</p>}
        {running && forceAvailable && <button type="button" onClick={controls?.forceStop}>{t("强制停止")}</button>}
        {controls && attachments.some(item => /\.(png|jpe?g|webp|gif|bmp)$/i.test(item.relativePath)) && controls.vision !== true && <p className="persistent-error" role="alert">{t(controls.vision === false ? "当前模型不支持图片，请切换模型或移除图片" : "图片输入能力未知，请选择明确支持图片的模型")}</p>}
        <textarea
          ref={textarea}
          aria-label={t("composer.placeholder", { model: modelName || "Reverie" })}
          value={value}
          onChange={(event) => { setValue(event.target.value); setCaret(event.target.selectionStart); setDismissed(""); }}
          onSelect={event => { const position = event.currentTarget.selectionStart; if (position !== caret) { setCaret(position); setDismissed(""); } }}
          aria-autocomplete="list"
          aria-haspopup="listbox"
          aria-controls={menuOpen ? menuId : undefined}
          aria-activedescendant={menuOpen && !loading && options[selected] ? `${menuId}-${selected}` : undefined}
          onKeyDown={keyDown}
          onPaste={event => { if (Array.from(event.clipboardData.items).some(item => item.type === "image/png" || item.type === "image/jpeg")) { event.preventDefault(); controls?.paste(); } }}
          placeholder={t("composer.placeholder", { model: modelName || "Reverie" })}
          rows={1}
          disabled={disabled || skillBusy}
        />
        <div className="composer-toolbar">
          <div>
            <ComposerMode />
            <IconButton label={t("Context Engine 推荐工作区文件")} onClick={() => insertTrigger("@")} disabled={disabled || skillBusy}><AtSign size={16} /></IconButton>
            <IconButton label={t("指令与 Skills")} onClick={() => insertTrigger("/")} disabled={disabled || skillBusy}><Command size={16} /></IconButton>
            <IconButton label={t("选择任意文件作为附件")} onClick={selectAttachment} disabled={disabled}><Paperclip size={16} /></IconButton>
          </div>
          <div className="composer-hint">
            {running && controls && <div className="send-behavior" role="radiogroup" aria-label={t("运行中发送方式")} onKeyDown={event => {
              if (event.nativeEvent.isComposing || event.nativeEvent.keyCode === 229) return;
              if (!["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Home", "End"].includes(event.key)) return;
              event.preventDefault(); event.stopPropagation();
              const next = event.key === "Home" ? "queue" : event.key === "End" ? "steer" : controls.behavior === "queue" ? "steer" : "queue";
              controls.setBehavior(next);
              event.currentTarget.querySelectorAll<HTMLButtonElement>("button")[next === "queue" ? 0 : 1]?.focus();
            }}>
              {(["queue", "steer"] as const).map(behavior => <button key={behavior} type="button" role="radio" aria-checked={controls.behavior === behavior} tabIndex={controls.behavior === behavior ? 0 : -1} onClick={() => controls.setBehavior(behavior)}>{t(behavior === "queue" ? "排队下一轮" : "补充当前任务")}</button>)}
            </div>}
            {controls && <button type="button" className="stream-output-toggle" aria-label={t("流式输出")} aria-pressed={controls.streamReady ? controls.streaming : undefined} aria-busy={controls.streamSettingBusy} aria-disabled={controls.streamSettingBusy} disabled={!controls.streamReady || controls.streamRequired} title={!controls.streamReady ? t("正在读取输出模式") : controls.streamRequired ? t("SenseNova 写作模式需要流式输出") : controls.streamSettingBusy ? t("正在保存输出模式") : `${t(controls.streaming ? "切换为非流式输出" : "切换为流式输出")}${running ? ` · ${t("下一轮生效，当前输出继续")}` : ""}`} onClick={() => { if (!controls.streamSettingBusy) controls.toggleStreaming(); }}>
              <Activity size={14} />

            </button>}
            <ContextRing usage={contextUsage} />
            {running && <button type="button" className="stop-button" onClick={cancel}><Square size={12} fill="currentColor" /> {t("停止")}</button>}
            <button type="button" className="send-button" aria-label={running ? t(controls?.behavior === "steer" ? "补充当前任务" : "排队下一轮") : t("发送")} onClick={send} disabled={disabled || skillBusy || controls?.streamSettingBusy || (!value.trim() && !attachments.length) || attachments.some(item => item.status && item.status !== "ready")}><Send size={16} /></button>
          </div>
        </div>
      </div>
    </div>
  );
}

const HISTORY_PAGE_SIZE = 60;

const HistoryMessages = memo(function HistoryMessages({ messages, preferences, transcript, readingKey, sessionId }: {
  messages: SessionMessage[];
  preferences: UiPreferences;
  transcript: RefObject<HTMLDivElement | null>;
  readingKey: string;
  sessionId: string;
}) {
  const { t } = useI18n();
  const [start, setStart] = useState(() => readingPositions.get(readingKey)?.first ?? Math.max(0, messages.length - HISTORY_PAGE_SIZE));
  const first = Math.min(start, Math.max(0, messages.length - HISTORY_PAGE_SIZE));
  const rows = useMemo(() => groupTranscriptMessages(messages.slice(first), sessionId), [messages, first, sessionId]);
  const pendingScroll = useRef<{ height: number; top: number } | null>(null);
  useLayoutEffect(() => {
    readingPositions.set(readingKey, { top: 0, follow: true, ...readingPositions.get(readingKey), first });
  }, [readingKey, first]);
  const loadEarlier = useCallback(() => {
    const container = transcript.current;
    if (container) pendingScroll.current = { height: container.scrollHeight, top: container.scrollTop };
    setStart(Math.max(0, first - HISTORY_PAGE_SIZE));
  }, [first, transcript]);
  useLayoutEffect(() => {
    const container = transcript.current;
    const previous = pendingScroll.current;
    if (container && previous) {
      container.scrollTop = previous.top + container.scrollHeight - previous.height;
      pendingScroll.current = null;
    }
  }, [start, transcript]);
  useEffect(() => {
    const container = transcript.current;
    if (!container || first === 0) return;
    const onScroll = () => {
      if (container.scrollTop < 80 && !pendingScroll.current) loadEarlier();
    };
    container.addEventListener("scroll", onScroll, { passive: true });
    return () => container.removeEventListener("scroll", onScroll);
  }, [first, transcript, loadEarlier]);
  return <>
    {first > 0 && <button type="button" className="history-load-earlier" onClick={loadEarlier}>{t("加载更早的消息")}</button>}
    {rows.map(row => row.kind === "activity"
      ? (preferences.showToolCalls || preferences.showToolResults) && <ActivityGroup key={`activity-${first + row.index}`} events={row.events.map(event => ({ ...event, ...(!preferences.showToolCalls ? { arguments: undefined } : {}), ...(!preferences.showToolResults ? { output: undefined } : {}) }))} defaultExpanded={preferences.expandToolResults} />
      : row.kind === "view"
        ? <InteractiveView key={`view-${row.view.viewId || first + row.index}`} segment={row.view} />
        : <Message key={`${row.message.role}-${first + row.index}`} message={row.message} preferences={preferences} />)}
  </>;
});

const readingPositions = new Map<string,{top:number;follow:boolean;first?:number}>();

function isStoppedPrompt(detail: string) {
  return /\b(?:Run stopped by user;|Run stopped before tools started\.|Queued run cancelled|Prompt cancelled; core restarted\.)/i.test(detail);
}

function ChatView({
  session,
  liveTurn,
  running,
  prompt,
  setPrompt,
  send,
  cancel,
  resume,
  mentionItems,
  mentionOpen,
  mentionLoading,
  requestMentions,
  chooseMention,
  attachments,
  selectAttachment,
  importDroppedFiles,
  removeAttachment,
  pinnedSkills,
  unresolvedSkills,
  unpinSkill,
  modelName,
  sessionBusy,
  renameSession,
  forkSession,
  rewindSession,
  deleteSession,
  preferences,
  updatePreferences,
  approval,
  resolveApproval,
  contextUsage,
}: {
  session: SessionState | null;
  liveTurn: LiveTurn | null;
  running: boolean;
  prompt: string;
  setPrompt: (prompt: string) => void;
  send: () => void;
  cancel: () => void;
  resume: () => void;
  mentionItems: Array<Record<string, unknown>>;
  mentionOpen: boolean;
  mentionLoading: boolean;
  requestMentions: (query?: string) => void;
  chooseMention: (value: string, range?: { start: number; end: number }) => void;
  attachments: ComposerAttachment[];
  selectAttachment: () => void;
  importDroppedFiles: (files: File[]) => void;
  removeAttachment: (attachment: ComposerAttachment) => void;
  pinnedSkills: string[];
  unresolvedSkills: string[];
  unpinSkill: (name: string) => void;
  modelName: string;
  sessionBusy: boolean;
  renameSession: () => void;
  forkSession: () => void;
  rewindSession: () => void;
  deleteSession: () => void;
  preferences: UiPreferences;
  updatePreferences: (patch: Partial<UiPreferences>) => void;
  approval: Record<string, unknown> | null;
  resolveApproval: (decision: ApprovalDecision, message?: string) => void;
  contextUsage: ContextUsage | null;
}) {
  const { t } = useI18n();
  const transcript = useRef<HTMLDivElement>(null);
  const transcriptContent = useRef<HTMLDivElement>(null);
  const visibleMessages = useMemo(
    () => resolveToolResultNames(visibleSessionMessages(liveTurn?.historyMessageCount === undefined ? session?.messages ?? [] : (session?.messages ?? []).slice(0, liveTurn.historyMessageCount))),
    [session?.messages, liveTurn?.historyMessageCount],
  );
  const canRewind = previousTurnBoundary(session?.messages ?? []) !== null;
  const taskListEvent = [...(liveTurn?.events ?? [])].reverse().find(event => Array.isArray(event.task_list));
  const tasks = taskListEntries(taskListEvent?.task_list ?? session?.metadata?.task_list);
  const runState = asRecord(session?.metadata?.prompt_run).state;
  const resumable = runState === "running" || runState === "interrupted";
  const inputOwner=useInputControls();
  const readingKey=ownerKey(inputOwner?.projectRoot || "",session?.id || "new");
  const followOutput = useRef(true);
  const hasTranscriptContent = visibleMessages.length > 0 || Boolean(liveTurn);
  const chooseStarter = (value: string) => {
    setPrompt(value);
    transcript.current?.parentElement?.querySelector<HTMLTextAreaElement>(".composer textarea")?.focus();
  };
  const [hasNewContent, setHasNewContent] = useState(false);
  const followLatest = () => {
    followOutput.current = true;
    setHasNewContent(false);
  };
  useLayoutEffect(() => {
    const container = transcript.current;
    if (!container) return;
    const onScroll = () => {
      followOutput.current = container.scrollHeight - container.scrollTop - container.clientHeight < 100;
      readingPositions.set(readingKey,{...readingPositions.get(readingKey),top:container.scrollTop,follow:followOutput.current});
      if (followOutput.current) setHasNewContent(false);
    };
    const resize = () => {
      container.style.setProperty("--transcript-height", `${container.clientHeight}px`);
      if (followOutput.current) container.scrollTop = hasTranscriptContent ? container.scrollHeight : 0;
    };
    resize();
    const observer = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(resize);
    observer?.observe(container);
    if (transcriptContent.current) observer?.observe(transcriptContent.current);
    container.addEventListener("scroll", onScroll, { passive: true });
    return () => { observer?.disconnect(); container.removeEventListener("scroll", onScroll); };
  }, [readingKey, hasTranscriptContent]);
  useLayoutEffect(() => {
    const previous=readingPositions.get(readingKey);
    followOutput.current=previous?.follow ?? true;
    const container=transcript.current;
    if(container)container.scrollTop=previous && !previous.follow?previous.top:hasTranscriptContent?container.scrollHeight:0;
  }, [readingKey]);
  useEffect(() => {
    const container = transcript.current;
    if (!container) return;
    if (!followOutput.current) { setHasNewContent(true); return; }
    container.scrollTop = hasTranscriptContent ? container.scrollHeight : 0;
  }, [session?.id, session?.messages.length, liveTurn?.assistantText, liveTurn?.reasoningText, liveTurn?.events, liveTurn?.error]);
  return (
    <div className={`chat-view ${hasTranscriptContent ? "" : "is-empty"}`}>
      <div className="conversation-top">
          <div className="conversation-header">
            <div><strong>{session?.name || t("新对话")}</strong>{hasTranscriptContent && <span>{t("chat.recordCount", { count: visibleMessages.length })}</span>}</div>
            <div className="conversation-actions">
              <ConversationDisplay preferences={preferences} update={updatePreferences} />
              <IconButton label={t("重命名会话")} onClick={renameSession} disabled={!session || running || sessionBusy}><Pencil size={14} /></IconButton>
              <IconButton label={t("分叉会话")} onClick={forkSession} disabled={!session || running || sessionBusy || visibleMessages.length === 0}><Copy size={14} /></IconButton>
              <IconButton label={t("回退上一轮")} onClick={rewindSession} disabled={!session || running || sessionBusy || !canRewind}><RotateCcw size={14} /></IconButton>
              <IconButton label={t("删除会话")} onClick={deleteSession} disabled={!session || running || sessionBusy}><Trash2 size={14} /></IconButton>
            </div>
          </div>
        </div>
      <div className="transcript" ref={transcript} aria-busy={sessionBusy}>
        {sessionBusy && <div className="session-loading-anchor"><div className="session-loading" role="status"><RefreshCw className="spin" size={16} />{t("正在切换会话")}</div></div>}
        {visibleMessages.length === 0 && !liveTurn ? (
          <WelcomeHeader workspace={projectNameFromPath(inputOwner?.projectRoot || "")} />
        ) : (
          <div className="message-column" ref={transcriptContent}>
            <HistoryMessages key={`history:${readingKey}`} messages={visibleMessages} preferences={preferences} transcript={transcript} readingKey={readingKey} sessionId={session?.id ?? ""} />
            {liveTurn && <LiveMessage key={`live:${readingKey}`} turn={liveTurn} running={running} preferences={preferences} />}
          </div>
        )}
      </div>
      {hasNewContent && <button type="button" className="return-latest" onClick={() => { followLatest(); if (transcript.current) transcript.current.scrollTop = transcript.current.scrollHeight; }}>{t("回到最新")}</button>}
      <div className="chat-input-stack">
      {approval && <ApprovalPanel approval={approval} resolve={resolveApproval} />}
      <Composer
        value={prompt}
        setValue={setPrompt}
        send={() => { if (!running && !sessionBusy && !inputOwner?.streamSettingBusy && (prompt.trim() || attachments.length)) followLatest(); send(); }}
        running={running}
        cancel={cancel}
        mentionItems={mentionItems}
        mentionOpen={mentionOpen}
        mentionLoading={mentionLoading}
        requestMentions={requestMentions}
        chooseMention={chooseMention}
        attachments={attachments}
        selectAttachment={selectAttachment}
        importDroppedFiles={importDroppedFiles}
        removeAttachment={removeAttachment}
        pinnedSkills={pinnedSkills}
        unresolvedSkills={unresolvedSkills}
        unpinSkill={unpinSkill}
        modelName={modelName}
        contextUsage={contextUsage}
        tasks={tasks}
        resumable={resumable}
        resume={() => { followLatest(); resume(); }}
        disabled={sessionBusy}
      />
      </div>
      {!hasTranscriptContent && <StarterActions choose={chooseStarter} />}
    </div>
  );
}

function PageHeader({ icon, title, description, action }: { icon: ReactNode; title: string; description: string; action?: ReactNode }) {
  return (
    <div className="page-header">
      <div className="page-title-icon">{icon}</div>
      <div><h1>{title}</h1><p>{description}</p></div>
      {action && <div className="page-header-action">{action}</div>}
    </div>
  );
}

function ToolsView({ mode }: { mode: string }) {
  const { t } = useI18n();
  const [tools, setTools] = useState<ToolRecord[]>([]);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [layout, setLayout] = useState<"grid" | "list">("grid");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const response = await window.reverie.request("listTools", { mode });
      setTools((response.tools as ToolRecord[]) ?? []);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : String(loadError));
    } finally {
      setLoading(false);
    }
  }, [mode]);
  useEffect(() => { void load(); }, [load]);
  const categories = useMemo(
    () => [...new Set(tools.map((tool) => tool.category).filter(Boolean))].sort(),
    [tools],
  );
  const filtered = tools.filter((tool) => {
    const matchesCategory = category === "all" || tool.category === category;
    const haystack = `${tool.name} ${tool.description} ${tool.category} ${tool.kind} ${tool.aliases.join(" ")} ${tool.tags.join(" ")}`.toLowerCase();
    return matchesCategory && haystack.includes(query.toLowerCase());
  });
  const builtInCount = tools.filter((tool) => tool.kind === "built-in").length;
  const extensionCount = tools.length - builtInCount;
  return (
    <div className="page-scroll">
      <PageHeader icon={<Wrench size={20} />} title={t("工具")} description={t("tools.description", { mode })} action={<button type="button" className="secondary-button" onClick={() => void load()}><RefreshCw size={14} />{t("刷新")}</button>} />
      <div className="tool-overview">
        <div><Wrench size={17} /><span>{t("可用工具")}<strong>{tools.length}</strong></span></div>
        <div><ShieldCheck size={17} /><span>{t("内置工具")}<strong>{builtInCount}</strong></span></div>
        <div><Plug size={17} /><span>{t("MCP 与插件")}<strong>{extensionCount}</strong></span></div>
      </div>
      <div className="tool-controls">
        <div className="inline-search wide"><Search size={14} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t("搜索名称、用途、参数或分类")} /></div>
        <div className="layout-toggle">
          <button type="button" className={layout === "grid" ? "active" : ""} aria-label={t("网格视图")} onClick={() => setLayout("grid")}><LayoutGrid size={14} /></button>
          <button type="button" className={layout === "list" ? "active" : ""} aria-label={t("列表视图")} onClick={() => setLayout("list")}><List size={14} /></button>
        </div>
      </div>
      <div className="category-filter">
        <button type="button" className={category === "all" ? "active" : ""} onClick={() => setCategory("all")}>{t("全部")} <span>{tools.length}</span></button>
        {categories.map((item) => (
          <button type="button" key={item} className={category === item ? "active" : ""} onClick={() => setCategory(item)}>
            {item}<span>{tools.filter((tool) => tool.category === item).length}</span>
          </button>
        ))}
      </div>
      {loading ? <div className="page-loading"><RefreshCw className="spin" size={18} />{t("读取工具目录")}</div> : error ? <div className="page-loading error"><AlertCircle size={18} />{error}</div> : (
        <div className={`tool-catalog ${layout}`}>
          {filtered.map((tool) => (
            <details className="tool-catalog-card" key={tool.name}>
              <summary>
                <div className="tool-card-icon"><ToolGlyph name={tool.name} size={17} /></div>
                <div className="tool-card-main">
                  <div><strong>{tool.name}</strong><span>{t(tool.description || "该工具未提供说明。")}</span></div>
                  <div className="tag-row">
                    <span>{tool.category}</span>
                    <span>{t(tool.kind === "built-in" ? "内置" : tool.kind === "mcp" ? "MCP" : tool.kind === "rats" ? "RATS" : "插件")}</span>
                    {tool.traits.slice(0, 2).map((trait) => <span key={trait}>{trait}</span>)}
                  </div>
                </div>
                <ChevronDown size={14} />
              </summary>
              <div className="tool-card-details">
                <div><span>{t("用途")}</span><p>{t(tool.description || "暂无说明")}</p></div>
                <div><span>{t("参数")}</span><p>{tool.properties.length ? tool.properties.join(" · ") : t("无参数")}</p></div>
                {tool.required.length > 0 && <div><span>{t("必填")}</span><p>{tool.required.join(" · ")}</p></div>}
                {tool.aliases.length > 0 && <div><span>{t("别名")}</span><p>{tool.aliases.join(" · ")}</p></div>}
                {tool.supported_modes.length > 0 && <div><span>{t("模式")}</span><p>{tool.supported_modes.join(" · ")}</p></div>}
              </div>
            </details>
          ))}
          {filtered.length === 0 && <div className="empty-panel"><Search size={24} /><strong>{t("没有匹配的工具")}</strong><span>{t("尝试更换关键词或分类。")}</span></div>}
        </div>
      )}
    </div>
  );
}

function Toggle({ checked, onChange, disabled = false, label }: { checked: boolean; onChange: (checked: boolean) => void; disabled?: boolean; label?: string }) {
  return <button type="button" role="switch" aria-checked={checked} aria-label={label} className={`toggle ${checked ? "on" : ""}`} onClick={() => onChange(!checked)} disabled={disabled}><span /></button>;
}

function PluginsView({
  plugins,
  updatePlugin,
  refresh,
}: {
  plugins: PluginRecord[];
  updatePlugin: (action: "setPluginEnabled" | "setPluginTrust", plugin: PluginRecord, value: boolean) => void;
  refresh: () => void;
}) {
  const { t } = useI18n();
  return (
    <div className="page-scroll">
      <PageHeader icon={<Plug size={20} />} title={t("插件")} description={t("管理运行时插件的启用状态与可执行信任。插件能力由同一个 Reverie 内核加载。")} action={<button type="button" className="secondary-button" onClick={refresh}><RefreshCw size={14} />{t("重新扫描")}</button>} />
      <div className="plugin-list">
        {plugins.map((plugin) => (
          <div className="plugin-card" key={plugin.id}>
            <div className="plugin-icon"><Plug size={18} /></div>
            <div className="plugin-main">
              <div className="plugin-title"><strong>{plugin.name}</strong><span className={`status-pill ${plugin.status}`}>{t(plugin.status_label || plugin.status)}</span></div>
              <p>{plugin.family} · v{plugin.version || "—"}</p>
              <div className="plugin-stats"><span>{plugin.tool_count} {t("工具")}</span><span>{plugin.command_count} {t("命令")}</span><span>{plugin.skill_count} {t("技能")}</span></div>
            </div>
            <div className="plugin-toggles">
              <label><span>{t("信任执行")}</span><Toggle checked={plugin.trusted} onChange={(value) => updatePlugin("setPluginTrust", plugin, value)} /></label>
              <label><span>{t("启用")}</span><Toggle checked={plugin.enabled} onChange={(value) => updatePlugin("setPluginEnabled", plugin, value)} /></label>
            </div>
          </div>
        ))}
        {plugins.length === 0 && <div className="empty-panel"><Plug size={26} /><strong>{t("没有发现运行时插件")}</strong><span>{t("将插件放入 Reverie 插件目录后重新扫描。")}</span></div>}
      </div>
    </div>
  );
}

function SkillsView({
  skills,
  pinSkill,
  unpinSkill,
  clearPinned,
  refresh,
}: {
  skills: SkillsState;
  pinSkill: (name: string) => void;
  unpinSkill: (name: string) => void;
  clearPinned: () => void;
  refresh: () => void;
}) {
  const { t } = useI18n();
  const [query, setQuery] = useState("");
  const pinnedCount = skills.pinned.names.length + skills.pinned.unresolved.length;
  const full = pinnedCount >= skills.pinned.max;
  const visible = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return skills.records;
    return skills.records.filter((record) =>
      record.name.toLowerCase().includes(needle) || record.description.toLowerCase().includes(needle));
  }, [query, skills.records]);
  // A shadowed record only knows that it lost; the row carries who took the name.
  const shadowOwners = useMemo(() => {
    const owners = new Map<string, { scope: string; root: string }>();
    for (const row of skills.shadowed ?? []) {
      owners.set(String(row.path ?? ""), {
        scope: String(row.winner_scope ?? ""),
        root: String(row.winner_root ?? ""),
      });
    }
    return owners;
  }, [skills.shadowed]);
  const shadowHint = (record: SkillRecord) => t("skill.shadowed.hint", {
    name: record.name,
    scope: shadowOwners.get(record.path)?.scope ?? "",
    root: shadowOwners.get(record.path)?.root ?? "",
  });
  return (
    <div className="page-scroll skills-page">
      <PageHeader
        icon={<Sparkles size={20} />}
        title={t("技能")}
        description={t("固定技能后，每轮都会先读取并遵循它，直到取消固定。也可以在输入框输入 /skill 选择。")}
        action={<button type="button" className="secondary-button" onClick={refresh}><RefreshCw size={14} />{t("重新扫描")}</button>}
      />
      {(skills.mode === "writer" || skills.mode === "computer-controller") && (
        <p role="note" className="muted">{t(skills.mode === "writer" ? "skill.mode.writer" : "skill.mode.computer")}</p>
      )}
      <div className="skills-summary">
        <span>{t("已发现技能")} <strong>{skills.count}</strong></span>
        <span><Pin size={13} />{t("已固定")} <strong>{pinnedCount} / {skills.pinned.max}</strong></span>
        {skills.invalid_count > 0 && <span className="error"><AlertCircle size={13}/>{t("无效技能")} {skills.invalid_count}</span>}
        {skills.shadowed_count > 0 && <span title={t("同名技能优先级更高，这些文件不会被加载。")}>{t("被覆盖")} {skills.shadowed_count}</span>}
      </div>
      {pinnedCount > 0 && (
        <section className="page-section">
          <div className="section-heading">
            <div><h2>{t("固定的技能")}</h2><p>{t("这些技能对每一轮都是强制的，并会显示在输入框上方。")}</p></div>
            <button type="button" className="secondary-button danger-ghost" onClick={clearPinned}><X size={13} />{t("全部取消")}</button>
          </div>
          <div className="skill-strip skill-strip-page">
            {skills.pinned.names.map((name) => (
              <span className="skill-chip" key={name}>
                <Sparkles size={12} /><span>{name}</span>
                <button type="button" aria-label={t("skill.unpin", { name })} onClick={() => unpinSkill(name)}><X size={11} /></button>
              </span>
            ))}
            {skills.pinned.unresolved.map((name) => (
              <span className="skill-chip skill-chip-stale" key={`stale-${name}`} title={t("skill.pinned.stale", { name })}>
                <Sparkles size={12} /><span>{name}</span>
                <button type="button" aria-label={t("skill.unpin", { name })} onClick={() => unpinSkill(name)}><X size={11} /></button>
              </span>
            ))}
          </div>
        </section>
      )}
      <section className="page-section">
        <div className="section-heading">
          <div><h2>{t("全部技能")}</h2><p>{t("按名称或描述筛选，然后固定需要强制使用的技能。")}</p></div>
          <div className="inline-search"><Search size={14} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t("筛选技能")} aria-label={t("筛选技能")} /></div>
        </div>
        <div className="plugin-list">
          {visible.map((record) => (
            <div
              className={`plugin-card ${record.pinned ? "skill-card-pinned" : ""} ${record.shadowed ? "skill-card-shadowed" : ""}`}
              key={record.key || record.path}
            >
              <div className="plugin-icon"><Sparkles size={18} /></div>
              <div className="plugin-main">
                <div className="plugin-title">
                  <strong>{record.name}</strong>
                  <span className="status-pill">{record.scope}</span>
                  {record.pinned && <span className="status-pill pinned">{t("已固定")}</span>}
                  {record.shadowed && (
                    <span className="status-pill shadowed" title={shadowHint(record)}>{t("已被覆盖")}</span>
                  )}
                  {!record.allow_implicit_invocation && <span className="status-pill">{t("仅显式调用")}</span>}
                </div>
                <details className="skill-description"><summary><span>{record.description}</span><ChevronDown size={13}/></summary><code>{record.path}</code></details>
              </div>
              <div className="plugin-toggles">
                {record.pinned ? (
                  <button type="button" className="secondary-button danger-ghost" onClick={() => unpinSkill(record.name)}><X size={13} />{t("取消固定")}</button>
                ) : (
                  <button
                    type="button"
                    className="secondary-button"
                    disabled={full || record.shadowed}
                    title={record.shadowed ? shadowHint(record) : undefined}
                    onClick={() => pinSkill(record.name)}
                  >
                    <Pin size={13} />{t("固定")}
                  </button>
                )}
              </div>
            </div>
          ))}
          {visible.length === 0 && <div className="empty-panel"><Sparkles size={26} /><strong>{t("没有匹配的技能")}</strong><span>{t("把 SKILL.md 放进 .reverie/skills 或 .agents/skills 后重新扫描。")}</span></div>}
        </div>
      </section>
    </div>
  );
}

function RecoveryView({ recovery, rollback }: { recovery: RecoveryState; rollback: (checkpointId: string) => void }) {
  const { language, t } = useI18n();
  const total = Number(recovery.summary.total_operations ?? recovery.operations.length);
  const files = (recovery.summary.modified_files as string[] | undefined) ?? [];
  return (
    <div className="page-scroll">
      <PageHeader icon={<ArchiveRestore size={20} />} title={t("恢复与历史")} description={t("检查操作记录和自动检查点，并在明确确认后恢复会话与文件。")} />
      <div className="metric-grid">
        <div><Database size={16} /><span>{t("操作记录")}</span><strong>{total}</strong></div>
        <div><FileText size={16} /><span>{t("已修改文件")}</span><strong>{files.length}</strong></div>
        <div><RotateCcw size={16} /><span>{t("检查点")}</span><strong>{recovery.checkpoints.length}</strong></div>
      </div>
      <section className="page-section">
        <div className="section-heading"><div><h2>{t("检查点")}</h2><p>{t("恢复会同时回退检查点之后受跟踪的文件和会话消息。")}</p></div></div>
        <div className="recovery-list">
          {recovery.checkpoints.map((checkpoint) => (
            <div className="recovery-item" key={checkpoint.id}>
              <div className="timeline-dot"><Clock3 size={13} /></div>
              <div><strong>{t(checkpoint.description)}</strong><span>{formatTime(checkpoint.created_at, language)} · {t("recovery.checkpointMeta", { messages: checkpoint.message_count, files: checkpoint.file_checkpoints.length })}</span></div>
              <button type="button" className="secondary-button danger-ghost" onClick={() => rollback(checkpoint.id)}><RotateCcw size={13} />{t("恢复")}</button>
            </div>
          ))}
          {recovery.checkpoints.length === 0 && <div className="empty-row">{t("当前工作区还没有检查点")}</div>}
        </div>
      </section>
      <section className="page-section">
        <div className="section-heading"><div><h2>{t("最近操作")}</h2><p>{t("内核记录的提问、工具调用和文件操作。")}</p></div></div>
        <div className="operation-list">
          {recovery.operations.slice().reverse().slice(0, 100).map((operation) => (
            <div key={operation.id}><span className="operation-type">{operation.operation_type.replaceAll("_", " ")}</span><strong>{t(operation.description)}</strong><time>{formatTime(operation.timestamp, language)}</time></div>
          ))}
          {recovery.operations.length === 0 && <div className="empty-row">{t("还没有操作历史")}</div>}
        </div>
      </section>
    </div>
  );
}

function SettingControl({ item, update }: { item: SettingItem; update: (key: string, value: unknown) => void }) {
  const { t } = useI18n();
  if (item.kind === "bool" || item.kind === "workspace" || item.kind === "plugin-bool") {
    return <Toggle checked={Boolean(item.value)} onChange={(value) => update(item.key, value)} />;
  }
  if (item.kind === "choice") {
    const labels = item.labels ?? {};
    return (
      <select value={String(item.value ?? "")} onChange={(event) => update(item.key, event.target.value)}>
        {(item.choices ?? []).map((choice) => {
          const raw = String(choice);
          return <option key={raw} value={raw}>{t(labels[raw] ?? raw)}</option>;
        })}
      </select>
    );
  }
  if (item.kind === "int") {
    return <input type="number" value={Number(item.value ?? 0)} min={item.min} max={item.max} step={item.step ?? 1} onChange={(event) => update(item.key, Number(event.target.value))} />;
  }
  if (item.kind === "text" || item.kind === "url") {
    return <TextSettingControl item={item} update={update} />;
  }
  if (item.kind === "rules") {
    return <RulesEditor item={item} update={update} />;
  }
  return <span className="setting-readonly">{String(item.value ?? "—")}</span>;
}

function TextSettingControl({ item, update }: { item: SettingItem; update: (key: string, value: unknown) => void }) {
  const { t } = useI18n();
  const savedValue = String(item.value ?? "");
  const [value, setValue] = useState(savedValue);
  useEffect(() => setValue(savedValue), [savedValue]);
  const changed = value !== savedValue;
  return (
    <div className="setting-text-control">
      <input
        type={item.kind === "url" ? "url" : "text"}
        value={value}
        aria-label={t(item.name)}
        placeholder={item.key === "api_proxy" ? "http://127.0.0.1:7890" : ""}
        onChange={(event) => setValue(event.target.value)}
      />
      {changed && (
        <div>
          <span>{t("有未保存的更改")}</span>
          <button type="button" className="secondary-button" onClick={() => setValue(savedValue)}>{t("撤销")}</button>
          <button type="button" className="primary-button" onClick={() => update(item.key, value)}>{t("保存")}</button>
        </div>
      )}
    </div>
  );
}

function RulesEditor({ item, update }: { item: SettingItem; update: (key: string, value: unknown) => void }) {
  const { t } = useI18n();
  const savedValue = String(item.value ?? "");
  const [value, setValue] = useState(savedValue);
  useEffect(() => setValue(savedValue), [savedValue]);
  const changed = value !== savedValue;
  return (
    <div className="rules-editor">
      <textarea value={value} rows={6} onChange={(event) => setValue(event.target.value)} />
      <div>
        {changed && <span>{t("有未保存的更改")}</span>}
        <button type="button" className="secondary-button" onClick={() => setValue(savedValue)} disabled={!changed}>{t("撤销")}</button>
        <button type="button" className="primary-button" onClick={() => update(item.key, value)} disabled={!changed}>{t("保存规则")}</button>
      </div>
    </div>
  );
}

/** Fetch one raw stored secret from the core on explicit demand (viewing/editing). */
type RevealSecret = (params: { kind: "provider" | "standard" | "custom"; field?: string; source?: string; index?: number; providerId?: string }) => Promise<string>;

function ProviderFieldControl({ field, value, configured, update, reveal }: { field: ConfigField; value: unknown; configured: boolean; update: (key: string, value: unknown) => void; reveal?: () => Promise<string> }) {
  const { t } = useI18n();
  const [visible, setVisible] = useState(false);
  const [busy, setBusy] = useState(false);
  if (field.kind === "bool") return <Toggle checked={Boolean(value)} onChange={(checked) => update(field.key, checked)} />;
  if (field.kind === "choice") return <select value={String(value ?? "")} onChange={(event) => update(field.key, event.target.value)}>{(field.choices ?? []).map((choice) => <option key={choice} value={choice}>{choice}</option>)}</select>;
  const type = field.kind === "secret" && !visible ? "password" : field.kind === "int" || field.kind === "float" ? "number" : "text";
  const hasValue = String(value ?? "").length > 0;
  // Eye toggles visibility; for a configured secret with nothing yet loaded, it
  // first pulls the stored key into the field so it can be viewed and edited.
  const onEye = async () => {
    if (field.kind === "secret" && configured && !hasValue && reveal && !busy) {
      setBusy(true);
      try {
        const secret = await reveal();
        update(field.key, secret);
        setVisible(true);
      } catch { /* leave the field empty; the user can still type a new key */ }
      finally { setBusy(false); }
      return;
    }
    setVisible((shown) => !shown);
  };
  return (
    <div className="field-input-wrap">
      <input
        type={type}
        value={String(value ?? "")}
        min={field.min}
        max={field.max}
        step={field.kind === "float" ? "0.1" : undefined}
        placeholder={field.kind === "secret" && configured ? t("已配置；点击眼睛查看，清空并保存即可移除") : field.optional ? t("可选") : ""}
        onChange={(event) => update(field.key, type === "number" ? Number(event.target.value) : event.target.value)}
      />
      {field.kind === "secret" && <button type="button" aria-label={t("查看/隐藏密钥")} onClick={() => void onEye()} disabled={busy}>{visible ? <EyeOff size={14} /> : <Eye size={14} />}</button>}
    </div>
  );
}

const PROBE_STATUS_LABELS: Record<string, string> = {
  online: "在线",
  empty: "目录为空",
  unauthorized: "密钥无效",
  throttled: "速率受限",
  offline: "无法连接",
  error: "调用失败",
  unconfigured: "未配置",
  "not-probed": "未检测",
};

function probeTone(status: string): string {
  if (status === "online") return "ok";
  if (status === "empty" || status === "throttled" || status === "not-probed") return "warn";
  if (status === "unconfigured") return "idle";
  return "bad";
}

function ProbeBadge({ probe }: { probe?: ProviderProbe }) {
  const { t } = useI18n();
  if (!probe) return null;
  const label = t(PROBE_STATUS_LABELS[probe.status] ?? probe.status);
  return (
    <span className={`probe-badge ${probeTone(probe.status)}`}>
      <span className="probe-dot" />
      {label}
      {probe.status === "online" && probe.latency_ms != null && <small>{probe.latency_ms}ms</small>}
    </span>
  );
}

/** Everything the Custom Provider page needs, bundled so it can be passed through in one prop. */
type CustomProviderControls = {
  probes: Record<string, ProviderProbe>;
  probing: boolean;
  add: () => void;
  edit: (provider: CustomProviderRecord) => void;
  remove: (provider: CustomProviderRecord) => void;
  toggle: (provider: CustomProviderRecord, enabled: boolean) => void;
  setThinking: (provider: CustomProviderRecord, enabled: boolean) => void;
  refresh: (provider: CustomProviderRecord) => void;
  probe: (keys: string[]) => void;
  selectModel: (provider: CustomProviderRecord, model: CustomProviderModel) => void;
  editContextLimit: (provider: CustomProviderRecord, model: CustomProviderModel) => void;
};

function CustomProviderPanel({ source, controls }: { source: ModelSource; controls: CustomProviderControls }) {
  const { t } = useI18n();
  const providers = source.custom_providers ?? [];
  const probeKeys = providers.map((provider) => `custom:${provider.id}`);
  const [collapsedProviders, setCollapsedProviders] = useState<Record<string, boolean>>({});
  const toggleProvider = (provider: CustomProviderRecord) => {
    setCollapsedProviders((current) => {
      const collapsed = current[provider.id] ?? (providers.length > 1 && !provider.active);
      return { ...current, [provider.id]: !collapsed };
    });
  };
  return (
    <div className="provider-content">
      <div className="section-heading">
        <div>
          <h2>{source.display_name}</h2>
          <p>{t("自己的 OpenAI、Responses 或 Anthropic 兼容网关：填四个字段，模型列表由 Reverie 拉取。")}</p>
        </div>
        <div className="section-heading-actions">
          {providers.length > 0 && (
            <button type="button" className="secondary-button small" onClick={() => controls.probe(probeKeys)} disabled={controls.probing}>
              <Zap size={14} />{controls.probing ? t("检测中…") : t("测试全部")}
            </button>
          )}
          <button type="button" className="primary-button small" onClick={controls.add}><Plus size={14} />{t("添加 Provider")}</button>
        </div>
      </div>
      {providers.length === 0 && (
        <div className="empty-panel compact">
          <Database size={22} />
          <strong>{t("还没有自定义 Provider")}</strong>
          <span>{t("需要 Provider 名称、Base URL、API Key 和请求格式四项，随后即可在 TUI、命令行和 GUI 中使用。")}</span>
        </div>
      )}
      {providers.map((provider) => {
        const probe = controls.probes[`custom:${provider.id}`];
        const collapsed = collapsedProviders[provider.id] ?? (providers.length > 1 && !provider.active);
        const detailsId = `custom-provider-details-${provider.id}`;
        return (
          <article className={`custom-provider-card ${provider.active ? "active" : ""} ${provider.enabled ? "" : "disabled"} ${collapsed ? "collapsed" : ""}`} key={provider.id}>
            <header>
              <button
                type="button"
                className="custom-provider-summary"
                aria-expanded={!collapsed}
                aria-controls={detailsId}
                aria-label={`${t(collapsed ? "展开模型列表" : "收起模型列表")}: ${provider.name}`}
                title={`${t(collapsed ? "展开模型列表" : "收起模型列表")}: ${provider.name}`}
                onClick={() => toggleProvider(provider)}
              >
                {collapsed ? <ChevronRight size={15} /> : <ChevronDown size={15} />}
                <span className="custom-provider-title">
                  <strong>{provider.name}</strong>
                  <small className="custom-provider-model-count">{provider.models.length}</small>
                  {provider.active && <span className="provider-flag">{t("使用中")}</span>}
                  {!provider.enabled && <span className="provider-flag muted">{t("已停用")}</span>}
                  <ProbeBadge probe={probe} />
                </span>
              </button>
              <div className="custom-provider-actions">
                <IconButton label={t("测试")} onClick={() => controls.probe([`custom:${provider.id}`])} disabled={controls.probing}><Zap size={14} /></IconButton>
                <IconButton label={t("刷新目录")} onClick={() => controls.refresh(provider)}><RefreshCw size={14} /></IconButton>
                <IconButton label={t("编辑")} onClick={() => controls.edit(provider)}><Pencil size={14} /></IconButton>
                <Toggle label={t("启用")} checked={provider.enabled} onChange={(checked) => controls.toggle(provider, checked)} />
                <IconButton label={t("删除")} onClick={() => controls.remove(provider)}><Trash2 size={14} /></IconButton>
              </div>
            </header>
            {!collapsed && (
              <div id={detailsId} className="custom-provider-details">
                <dl className="custom-provider-meta">
                  <div><dt>{t("基础 URL")}</dt><dd>{provider.base_url}</dd></div>
                  <div><dt>{t("请求格式")}</dt><dd>{t(provider.format_label)}</dd></div>
                  <div>
                    <dt>{t("API 密钥")}</dt>
                    <dd>
                      {provider.api_key_configured
                        ? `${provider.api_key_masked}${provider.api_key_source === "env" ? ` · ${t("来自环境变量")}` : ""}`
                        : t("未配置")}
                    </dd>
                  </div>
                  <div className="custom-provider-thinking">
                    <dt>{t("思考模式")}</dt>
                    <dd>
                      <Toggle label={t("思考模式")} checked={provider.thinking} onChange={(checked) => controls.setThinking(provider, checked)} />
                      <span>{provider.thinking ? t("已开启（默认）") : t("已关闭")}</span>
                    </dd>
                  </div>
                </dl>
                {probe && probe.status !== "online" && probe.detail && <p className="custom-provider-note">{probe.detail}</p>}
                {provider.sync_error && <p className="custom-provider-note">{provider.sync_error}</p>}
                <div className="settings-model-grid">
                  {provider.models.map((model) => (
                    <div className={`settings-model-card ${provider.active && provider.selected_model_id === model.id ? "active" : ""}`} key={model.id}>
                      <button type="button" className="model-card-main" onClick={() => controls.selectModel(provider, model)}>
                        <div><strong>{model.display_name}</strong><span title={model.id}>{model.id}</span></div>
                        {provider.active && provider.selected_model_id === model.id ? <CheckCircle2 size={16} /> : <Circle size={14} />}
                      </button>
                      <div className="tag-row">
                        <button type="button" className="tag-button" onClick={() => controls.editContextLimit(provider, model)}>
                          {model.context_limit
                            ? `${formatTokens(model.context_limit)} ${t("上下文")}`
                            : t("设置上下文")}
                        </button>
                        {model.vision && <span>{t("视觉")}</span>}
                      </div>
                    </div>
                  ))}
                  {provider.models.length === 0 && (
                    <div className="empty-panel compact">
                      <Database size={22} />
                      <strong>{t("目录还是空的")}</strong>
                      <span>{t("点击刷新目录，从该 Provider 的 /models 接口重新获取。")}</span>
                    </div>
                  )}
                </div>
              </div>
            )}
          </article>
        );
      })}
    </div>
  );
}

function CustomProviderModal({
  provider,
  formats,
  close,
  save,
  reveal,
}: {
  provider: CustomProviderRecord | null;
  formats: CustomProviderFormat[];
  close: () => void;
  save: (values: { name: string; base_url: string; api_key: string; format: string }, clearApiKey: boolean) => void;
  reveal?: () => Promise<string>;
}) {
  const { t } = useI18n();
  const dialogRef = useRef<HTMLFormElement>(null);
  useDialogFocus(dialogRef, close);
  const editing = Boolean(provider);
  const configured = Boolean(provider?.api_key_configured);
  const [values, setValues] = useState({
    name: provider?.name ?? "",
    base_url: provider?.base_url ?? "",
    api_key: "",
    format: provider?.format ?? formats[0]?.id ?? "openai-chat",
  });
  const [visible, setVisible] = useState(false);
  const [revealed, setRevealed] = useState(false);
  const [busy, setBusy] = useState(false);
  const update = (key: keyof typeof values, value: string) => setValues((current) => ({ ...current, [key]: value }));
  // An existing provider already has a stored key, so only a new one must supply it.
  const valid = Boolean(values.name.trim() && values.base_url.trim() && (editing || values.api_key.trim()));
  // The stored key was pulled into the field and then emptied: an explicit clear.
  const clearApiKey = editing && configured && revealed && values.api_key.trim() === "";
  const activeFormat = formats.find((item) => item.id === values.format);
  const onEye = async () => {
    if (configured && !revealed && reveal && !busy) {
      setBusy(true);
      try {
        const secret = await reveal();
        update("api_key", secret);
        setRevealed(true);
        setVisible(true);
      } catch { /* leave blank; a new key can still be typed */ }
      finally { setBusy(false); }
      return;
    }
    setVisible((shown) => !shown);
  };
  return (
    <div className="modal-backdrop" onMouseDown={close}>
      <form
        ref={dialogRef}
        className="form-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="custom-provider-title"
        tabIndex={-1}
        onMouseDown={(event) => event.stopPropagation()}
        onSubmit={(event) => { event.preventDefault(); if (valid) save(values, clearApiKey); }}
      >
        <div className="form-modal-header">
          <div>
            <h2 id="custom-provider-title">{editing ? t("编辑 Provider") : t("添加 Provider")}</h2>
            <p>{t("只需四项，模型列表会自动从该 Provider 拉取。")}</p>
          </div>
          <IconButton label={t("关闭")} onClick={close}><X size={16} /></IconButton>
        </div>
        <div className="form-grid single">
        <label>
            <span>{t("Provider 名称")}</span>
            <input autoFocus value={values.name} onChange={(event) => update("name", event.target.value)} placeholder={t("例如 xkiro")} />
          </label>
          <label>
            <span>{t("基础 URL")}</span>
            <input value={values.base_url} onChange={(event) => update("base_url", event.target.value)} placeholder="https://api.xkiro.com/v1" />
          </label>
          <label>
            <span>{t("API 密钥")}</span>
            <div className="field-input-wrap">
              <input
                type={visible ? "text" : "password"}
                value={values.api_key}
                onChange={(event) => update("api_key", event.target.value)}
                placeholder={editing && configured ? t("已配置；点击眼睛查看，清空并保存即可移除") : ""}
              />
              {editing && configured && <button type="button" aria-label={t("查看/隐藏密钥")} onClick={() => void onEye()} disabled={busy}>{visible ? <EyeOff size={14} /> : <Eye size={14} />}</button>}
            </div>
          </label>
          <label>
            <span>{t("API 请求格式")}</span>
            <select value={values.format} onChange={(event) => update("format", event.target.value)}>
              {formats.map((item) => <option key={item.id} value={item.id}>{t(item.label)}</option>)}
            </select>
          </label>
        </div>
        {activeFormat && <p className="form-modal-hint">{t(activeFormat.description)}</p>}
        <div className="form-modal-footer">
          <button type="button" className="secondary-button" onClick={close}>{t("取消")}</button>
          <button type="submit" className="primary-button" disabled={!valid}>{editing ? t("保存") : t("添加 Provider")}</button>
        </div>
      </form>
    </div>
  );
}

const CONTEXT_LIMIT_MIN = 1_000;
const CONTEXT_LIMIT_MAX = 10_000_000;

/** Parse the same shorthand the CLI accepts: 128000, 128k, 1.2m. */
function parseContextLimit(value: string): number | null {
  const text = value.trim().toLowerCase().replace(/[,_\s]/g, "").replace(/tokens?$/, "");
  if (!text) return null;
  const multiplier = text.endsWith("k") ? 1_000 : text.endsWith("m") ? 1_000_000 : 1;
  const digits = multiplier === 1 ? text : text.slice(0, -1);
  if (!/^\d+(\.\d+)?$/.test(digits)) return null;
  const tokens = Math.floor(Number(digits) * multiplier);
  if (tokens < CONTEXT_LIMIT_MIN) return null;
  return Math.min(tokens, CONTEXT_LIMIT_MAX);
}

/**
 * Ask for one model's context limit.
 *
 * Gateways rarely publish a window worth trusting, so the answer is collected
 * the first time a model is picked and reused on every later selection.
 */
function ContextLimitModal({
  provider,
  model,
  close,
  save,
}: {
  provider: CustomProviderRecord;
  model: CustomProviderModel;
  close: () => void;
  save: (limit: number) => void;
}) {
  const { t } = useI18n();
  const dialogRef = useRef<HTMLFormElement>(null);
  useDialogFocus(dialogRef, close);
  const suggested = model.context_limit || model.suggested_context_limit || 128_000;
  const [value, setValue] = useState(String(suggested));
  const parsed = parseContextLimit(value);
  return (
    <div className="modal-backdrop" onMouseDown={close}>
      <form
        ref={dialogRef}
        className="form-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="context-limit-title"
        tabIndex={-1}
        onMouseDown={(event) => event.stopPropagation()}
        onSubmit={(event) => { event.preventDefault(); if (parsed) save(parsed); }}
      >
        <div className="form-modal-header">
          <div>
            <h2 id="context-limit-title">{t("模型上下文限额")}</h2>
            <p>{t("provider.contextPrompt", { name: `${provider.name} · ${model.display_name}` })}</p>
          </div>
          <IconButton label={t("关闭")} onClick={close}><X size={16} /></IconButton>
        </div>
        <div className="form-grid single">
          <label>
            <span>{t("上下文限额")}</span>
            <input
              autoFocus
              value={value}
              onChange={(event) => setValue(event.target.value)}
              placeholder="128000"
              aria-label={t("上下文限额")}
            />
          </label>
        </div>
        <p className="form-modal-hint">
          {t("provider.contextRange", { min: CONTEXT_LIMIT_MIN.toLocaleString(), max: CONTEXT_LIMIT_MAX.toLocaleString() })}
        </p>
        <div className="form-modal-footer">
          <button type="button" className="secondary-button" onClick={close}>{t("取消")}</button>
          <button type="submit" className="primary-button" disabled={!parsed}>{t("保存并使用")}</button>
        </div>
      </form>
    </div>
  );
}

function ProviderSettings({
  state,
  selectModel,
  saveProvider,
  revealSecret,
  addStandard,
  editStandard,
  deleteStandard,
  customProviders,
}: {
  state: DesktopState;
  selectModel: (source: ModelSource, model: ModelRecord) => void;
  saveProvider: (source: ModelSource, patch: Record<string, unknown>, clearFields?: string[]) => void;
  revealSecret: RevealSecret;
  addStandard: () => void;
  editStandard: (index: number, model: ModelRecord) => void;
  deleteStandard: (index: number) => void;
  customProviders: CustomProviderControls;
}) {
  const { t } = useI18n();
  const [sourceId, setSourceId] = useState(state.models.active_source);
  // The settings panel manages the aggregate `custom` source, so it must never
  // see the per-provider entries the picker synthesizes from it.
  const sources = settingsModelSources(state.models.sources);
  const source = sources.find((item) => item.id === sourceId) ?? sources[0];
  const [patch, setPatch] = useState<Record<string, unknown>>({});
  useEffect(() => setPatch({}), [source?.id]);
  if (!source) return null;
  const valueFor = (field: ConfigField) => field.key in patch ? patch[field.key] : source.config?.values[field.key];
  const sourceDescription = source.id === "standard"
    ? t("管理任意 OpenAI、Anthropic、Responses 或请求兼容模型。")
    : source.id === "agnes" && source.modalities
      ? t("provider.liveCatalog", { llm: source.modalities.llm, tti: source.modalities.tti, ttv: source.modalities.ttv, catalog: t(source.modalities.live ? "官方实时目录" : "内置回退目录") })
      : source.id === "opencode"
        ? t(source.catalog_live ? "provider.opencodeLive" : "provider.opencodeBuiltin", { count: source.models.length })
        : t("provider.modelCount", { count: source.models.length });
  return (
    <div className="provider-settings">
      <div className="provider-tabs">
        {sources.map((item) => <button type="button" key={item.id} className={item.id === source.id ? "active" : ""} onClick={() => setSourceId(item.id)}>{item.display_name}{item.active && <span />}</button>)}
      </div>
      {source.id === "custom" ? (
        <CustomProviderPanel source={source} controls={customProviders} />
      ) : (
      <div className="provider-content">
        <div className="section-heading">
          <div><h2>{source.display_name}</h2><p>{sourceDescription}</p></div>
          {source.id === "standard" && <button type="button" className="primary-button small" onClick={addStandard}><Plus size={14} />{t("添加模型")}</button>}
        </div>
        <div className="settings-model-grid">
          {source.models.map((model) => (
            <div className={`settings-model-card ${source.active && source.selected_model_id === model.id ? "active" : ""}`} key={model.id}>
              <button type="button" className="model-card-main" onClick={() => selectModel(source, model)}>
                <div><strong>{model.display_name}</strong><span title={model.id}>{model.id}</span></div>
                {source.active && source.selected_model_id === model.id ? <CheckCircle2 size={16} /> : <Circle size={14} />}
              </button>
              <p>{t(model.description)}</p>
              <div className="tag-row"><span>{formatTokens(model.context_length)} {t("上下文")}</span>{model.vision && <span>{t("视觉")}</span>}{model.tool_calling && <span>{t("工具")}</span>}{model.reasoning.control !== "none" && <span>{t(model.reasoning.control)}</span>}</div>
              {source.id === "standard" && (
                <div className="model-card-actions">
                  <button type="button" className="edit-model" onClick={() => editStandard(Number(model.id), model)} aria-label={t("编辑标准模型")} title={t("编辑标准模型")}><Pencil size={13} /></button>
                  <button type="button" className="delete-model" onClick={() => deleteStandard(Number(model.id))} aria-label={t("删除")} title={t("删除")}><Trash2 size={13} /></button>
                </div>
              )}
            </div>
          ))}
          {source.models.length === 0 && (
            <div className="empty-panel compact">
              <Database size={22} />
              {source.id === "standard"
                ? <><strong>{t("还没有标准模型")}</strong><span>{t("添加一个模型后即可用于 TUI、命令行和 GUI。")}</span></>
                : <><strong>{t("该来源暂无可用模型")}</strong><span>{t("先在下方填好连接配置，Reverie 会重新获取模型目录。")}</span></>}
            </div>
          )}
        </div>
        {source.config_fields.length > 0 && (
          <div className="provider-config">
            <div className="section-heading"><div><h2>{t("连接配置")}</h2><p>{t("点击眼睛可查看已保存的密钥；清空并保存即可移除。")}</p></div><button type="button" className="primary-button small" onClick={() => {
              // A configured secret explicitly emptied in the patch is a clear
              // request; the backend skips blank secrets otherwise, so translate
              // it into an explicit clearFields entry.
              const clearFields = source.config_fields
                .filter((field) => field.kind === "secret" && Boolean(source.config?.configured_secrets[field.key]) && field.key in patch && String(patch[field.key] ?? "") === "")
                .map((field) => field.key);
              saveProvider(source, patch, clearFields);
            }} disabled={!Object.keys(patch).length}>{t("保存")}</button></div>
            <div className="form-grid">
              {source.config_fields.map((field) => (
                <label key={field.key}><span>{t(field.label)}{field.optional && <small>{t("可选")}</small>}</span><ProviderFieldControl field={field} value={valueFor(field)} configured={Boolean(source.config?.configured_secrets[field.key])} update={(key, value) => setPatch((current) => ({ ...current, [key]: value }))} reveal={field.kind === "secret" ? () => revealSecret({ kind: "provider", source: source.id, field: field.key }) : undefined} /></label>
              ))}
            </div>
          </div>
        )}
      </div>
      )}
    </div>
  );
}

function ImageProviderSettings({
  imageModels,
  selectImageModel,
  refresh,
}: {
  imageModels: ImageModelSourcesState | null;
  selectImageModel: (source: string, model: ImageModelRecord) => void;
  refresh: () => void;
}) {
  const { t } = useI18n();
  const [sourceId, setSourceId] = useState("");
  // Fetch once when the tab first mounts and nothing is loaded yet.
  useEffect(() => { if (!imageModels) refresh(); }, [imageModels, refresh]);
  // Follow the active source once the catalog arrives, until the user picks a tab.
  useEffect(() => { if (!sourceId && imageModels) setSourceId(imageModels.active_source); }, [imageModels, sourceId]);
  if (!imageModels) {
    return <div className="empty-panel compact"><Image size={22} /><strong>{t("正在加载生图模型…")}</strong></div>;
  }
  const sources = imageModels.sources;
  const source = sources.find((item) => item.id === sourceId) ?? sources[0];
  if (!source) return null;
  const needsKey = source.requires_api_key && !source.api_key_available;
  return (
    <div className="provider-settings">
      <div className="provider-tabs">
        {sources.map((item) => <button type="button" key={item.id} className={item.id === source.id ? "active" : ""} onClick={() => setSourceId(item.id)}>{item.display_name}{item.active && <span />}</button>)}
      </div>
      <div className="provider-content">
        <div className="section-heading">
          <div>
            <h2>{source.display_name}</h2>
            <p>{t("image.modelCount", { count: source.models.length })}{source.requires_api_key ? ` · ${source.api_key_available ? t("密钥已配置") : t("未配置密钥")}` : ""}</p>
          </div>
          <button type="button" className="primary-button small" onClick={refresh}><RefreshCw size={13} />{t("刷新")}</button>
        </div>
        {needsKey && (
          <div className="empty-panel compact">
            <Image size={22} />
            <strong>{t("需要 API 密钥")}</strong>
            <span>{source.id === "pollinations"
              ? t("使用 /tti source pollinations 配置 API 密钥，然后刷新。")
              : t("请在“模型与提供商”页为该来源配置密钥后再生成图片。")}</span>
          </div>
        )}
        <div className="settings-model-grid">
          {source.models.map((model) => (
            <div className={`settings-model-card ${source.active && source.selected_model_id === model.id ? "active" : ""}`} key={model.id}>
              <button type="button" className="model-card-main" onClick={() => selectImageModel(source.id, model)}>
                <div><strong>{model.display_name}</strong><span title={model.id}>{model.id}</span></div>
                {source.active && source.selected_model_id === model.id ? <CheckCircle2 size={16} /> : <Circle size={14} />}
              </button>
              {model.description && <p>{t(model.description)}</p>}
              <div className="tag-row">
                <span>{model.supports_edit ? t("支持编辑") : t("仅生成")}</span>
                {model.default_size && <span>{model.default_size}</span>}
                {source.id === "local" && !model.exists && <span>{t("模型文件缺失")}</span>}
              </div>
            </div>
          ))}
          {source.models.length === 0 && (
            <div className="empty-panel compact">
              <Image size={22} />
              <strong>{t("该来源暂无可用生图模型")}</strong>
              <span>{t("先在下方或“模型与提供商”页填好连接配置，再刷新生图目录。")}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function SettingsView({
  state,
  updateSetting,
  selectModel,
  saveProvider,
  revealSecret,
  addStandard,
  editStandard,
  deleteStandard,
  customProviders,
  paths,
  selectCoreData,
  theme,
  setTheme,
  preferences,
  updatePreferences,
  selectBackground,
  clearBackground,
  imageModels,
  refreshImageModels,
  selectImageModel,
}: {
  state: DesktopState;
  updateSetting: (key: string, value: unknown) => void;
  selectModel: (source: ModelSource, model: ModelRecord) => void;
  saveProvider: (source: ModelSource, patch: Record<string, unknown>, clearFields?: string[]) => void;
  revealSecret: RevealSecret;
  addStandard: () => void;
  editStandard: (index: number, model: ModelRecord) => void;
  deleteStandard: (index: number) => void;
  customProviders: CustomProviderControls;
  paths: DesktopPaths | null;
  selectCoreData: () => void;
  theme: ThemePreference;
  setTheme: (theme: ThemePreference) => void;
  preferences: UiPreferences;
  updatePreferences: (patch: Partial<UiPreferences>) => void;
  selectBackground: () => void;
  clearBackground: () => void;
  imageModels: ImageModelSourcesState | null;
  refreshImageModels: () => void;
  selectImageModel: (source: string, model: ImageModelRecord) => void;
}) {
  const { t } = useI18n();
  const [tab, setTab] = useState<"general" | "appearance" | "conversation" | "models" | "images" | "about">("general");
  const [displayNameDraft, setDisplayNameDraft] = useState(preferences.userDisplayName);
  useEffect(() => setDisplayNameDraft(preferences.userDisplayName), [preferences.userDisplayName]);
  const items = state.settings.items.filter((item) => !item.key.startsWith("plugin_enabled:") && !["active_model_source", "active_model_index"].includes(item.key));
  const activeBackgroundUrl = effectiveBackgroundUrl(preferences);
  const activeBackgroundLabel = preferences.backgroundPreset === "custom"
    ? preferences.backgroundName || t("导入图片")
    : t(BACKGROUND_OPTIONS.find((option) => option.id === preferences.backgroundPreset)?.label || "纯净界面");
  return (
    <div className="settings-page">
      <div className="settings-nav">
        <div><h1>{t("设置")}</h1><p>{t("Reverie 桌面端")}</p></div>
        <button type="button" className={tab === "general" ? "active" : ""} onClick={() => setTab("general")}><SlidersHorizontal size={15} />{t("通用")}</button>
        <button type="button" className={tab === "appearance" ? "active" : ""} onClick={() => setTab("appearance")}><Palette size={15} />{t("外观")}</button>
        <button type="button" className={tab === "conversation" ? "active" : ""} onClick={() => setTab("conversation")}><MessageSquare size={15} />{t("对话显示")}</button>
        <button type="button" className={tab === "models" ? "active" : ""} onClick={() => setTab("models")}><Brain size={15} />{t("模型与提供商")}</button>
        <button type="button" className={tab === "images" ? "active" : ""} onClick={() => setTab("images")}><Image size={15} />{t("生图模型")}</button>
        <button type="button" className={tab === "about" ? "active" : ""} onClick={() => setTab("about")}><Info size={15} />{t("关于")}</button>
      </div>
      <div className="settings-content">
        {tab === "general" && (
          <>
            <PageHeader icon={<SlidersHorizontal size={20} />} title={t("通用设置")} description={t("这些设置由 CLI 内核持久化，TUI 和 GUI 会同步使用。")} />
            <section className="preference-section language-section">
              <div className="preference-heading"><div><h2>{t("界面语言")}</h2><p>{t("选择 Reverie GUI 使用的语言，切换后立即生效。")}</p></div></div>
              <div className="preference-row">
                <div><Globe size={17} /><span><strong>{t("语言")}</strong><small>{t("选择 Reverie GUI 使用的语言，切换后立即生效。")}</small></span></div>
                <div className="segmented-control language-control">
                  {UI_LANGUAGE_OPTIONS.map((option) => <button type="button" key={option.id} className={preferences.language === option.id ? "active" : ""} aria-pressed={preferences.language === option.id} onClick={() => updatePreferences({ language: option.id })}>{t(option.label)}</button>)}
                </div>
              </div>
            </section>
            <section className="preference-section">
              <div className="preference-heading"><div><h2>{t("默认启动方式")}</h2><p>{t("选择双击 Reverie 时打开图形界面或终端界面；命令行参数仍可临时覆盖。")}</p></div></div>
              <div className="preference-row">
                <div><SquareTerminal size={17} /><span><strong>{t("启动界面")}</strong><small>{t("设置将在下次启动时生效")}</small></span></div>
                <div className="segmented-control">
                  <button type="button" className={preferences.startupMode === "gui" ? "active" : ""} aria-pressed={preferences.startupMode === "gui"} onClick={() => updatePreferences({ startupMode: "gui" })}><Monitor size={14} />{t("图形界面")}</button>
                  <button type="button" className={preferences.startupMode === "tui" ? "active" : ""} aria-pressed={preferences.startupMode === "tui"} onClick={() => updatePreferences({ startupMode: "tui" })}><Terminal size={14} />{t("终端界面")}</button>
                </div>
              </div>
            </section>
            {paths && <div className="core-data-card"><div className="core-data-heading"><Database size={18} /><div><strong>{t("CLI 数据与历史")}</strong><p>{t("GUI 会直接读取此目录中的配置、会话、检查点和插件状态。")}</p></div></div><code>{paths.coreAppRoot}</code><div><button type="button" className="secondary-button" onClick={() => void window.reverie.reveal(paths.coreAppRoot)}><FolderOpen size={14} />{t("显示目录")}</button><button type="button" className="secondary-button" onClick={selectCoreData}><Folder size={14} />{t("切换数据目录")}</button></div></div>}
            <div className="setting-list">
              {items.map((item) => {
                const hint = item.descriptions?.[String(item.value ?? "")] ?? "";
                return (
                  <div className={`setting-row ${item.kind === "rules" ? "stacked" : ""}`} key={item.key}>
                    <div>
                      {/* Core setting metadata is translated in both directions. */}
                      <strong>{t(item.name)}{item.experimental && <span className="setting-badge">{t("实验性")}</span>}</strong>
                      <p>{t(item.description)}</p>
                      {hint && <p className="setting-hint">{t(hint)}</p>}
                    </div>
                    <SettingControl item={item} update={updateSetting} />
                  </div>
                );
              })}
            </div>
          </>
        )}
        {tab === "appearance" && (
          <>
            <PageHeader icon={<Palette size={20} />} title={t("外观")} description={t("调整主题、强调色、阅读尺度与工作区背景；所有设置会立即预览。")} />
            <section className="appearance-panel preference-section">
              <div className="appearance-copy">
                <div><h2>{t("界面主题")}</h2><p>{t("跟随系统会在 Windows 深色与浅色模式之间自动切换。")}</p></div>
                <span>{t("appearance.current", { value: t(THEME_OPTIONS.find((option) => option.id === theme)?.label || "") })}</span>
              </div>
              <div className="theme-grid">
                {THEME_OPTIONS.map(({ id, label, description, icon: Icon }) => (
                  <button type="button" key={id} className={`theme-card ${id === theme ? "active" : ""}`} aria-pressed={id === theme} onClick={() => setTheme(id)}>
                    <div className="theme-card-copy">
                      <span className="theme-card-icon"><Icon size={15} /></span>
                      <div><strong>{t(label)}</strong><small>{t(description)}</small></div>
                      {id === theme && <CheckCircle2 size={17} />}
                    </div>
                  </button>
                ))}
              </div>
            </section>
            <section className="preference-section">
              <div className="preference-heading"><div><h2>{t("强调色")}</h2><p>{t("用于焦点、选中状态、图标和技术活动。")}</p></div></div>
              <div className="accent-grid">
                {ACCENT_OPTIONS.map((option) => (
                  <button type="button" key={option.id} className={preferences.accent === option.id ? "active" : ""} aria-pressed={preferences.accent === option.id} onClick={() => updatePreferences({ accent: option.id })}>
                    <span style={{ backgroundColor: option.color }} /><strong>{t(option.label)}</strong>{preferences.accent === option.id && <Check size={14} />}
                  </button>
                ))}
              </div>
            </section>
            <section className="preference-section">
              <div className="preference-heading"><div><h2>{t("文字与阅读宽度")}</h2><p>{t("同时调整导航、正文和技术轨迹的字号与回答行长。")}</p></div></div>
              <div className="preference-row">
                <div><Type size={17} /><span><strong>{t("字体大小")}</strong><small>{t("选择整体界面阅读尺度")}</small></span></div>
                <div className="segmented-control">
                  {FONT_SIZE_OPTIONS.map((option) => <button type="button" key={option.id} className={preferences.fontSize === option.id ? "active" : ""} onClick={() => updatePreferences({ fontSize: option.id })}>{t(option.label)}</button>)}
                </div>
              </div>
              <div className="preference-row">
                <div><PanelRightOpen size={17} /><span><strong>{t("回答宽度")}</strong><small>{t("控制长回答和代码块占用的宽度")}</small></span></div>
                <div className="segmented-control">
                  {MESSAGE_WIDTH_OPTIONS.map((option) => <button type="button" key={option.id} className={preferences.messageWidth === option.id ? "active" : ""} onClick={() => updatePreferences({ messageWidth: option.id })}>{t(option.label)}</button>)}
                </div>
              </div>
            </section>
            <section className="preference-section">
              <div className="preference-heading">
                <div><h2>{t("工作区背景")}</h2><p>{t("选择 Reverie 原创背景，或导入自己的图片；自定义图片会复制到便携版数据目录。")}</p></div>
                <div className="preference-actions">
                  {preferences.backgroundPreset === "custom" && preferences.backgroundUrl && <button type="button" className="secondary-button" onClick={clearBackground}>{t("删除导入")}</button>}
                  <button type="button" className="primary-button" onClick={selectBackground}><ImagePlus size={14} />{t("导入图片")}</button>
                </div>
              </div>
              <div className="background-picker">
                {BACKGROUND_OPTIONS.map((option) => {
                  const OptionIcon = option.icon;
                  const url = backgroundPresetUrl(option.id);
                  return (
                    <button
                      type="button"
                      key={option.id}
                      className={preferences.backgroundPreset === option.id ? "active" : ""}
                      aria-pressed={preferences.backgroundPreset === option.id}
                      style={url ? { backgroundImage: `url("${url}")` } : undefined}
                      onClick={() => updatePreferences({
                        backgroundPreset: option.id,
                        ...(option.id !== "none" && preferences.backgroundOpacity < 0.72 ? { backgroundOpacity: 0.9 } : {}),
                      })}
                    >
                      <span className="background-card-overlay" />
                      <span className="background-card-copy"><OptionIcon size={15} /><strong>{t(option.label)}</strong><small>{t(option.description)}</small></span>
                      {preferences.backgroundPreset === option.id && <CheckCircle2 size={17} />}
                    </button>
                  );
                })}
                {preferences.backgroundUrl && (
                  <button
                    type="button"
                    className={preferences.backgroundPreset === "custom" ? "active" : ""}
                    aria-pressed={preferences.backgroundPreset === "custom"}
                    style={{ backgroundImage: `url("${preferences.backgroundUrl}")` }}
                    onClick={() => updatePreferences({ backgroundPreset: "custom" })}
                  >
                    <span className="background-card-overlay" />
                    <span className="background-card-copy"><ImagePlus size={15} /><strong>{t("我的图片")}</strong><small>{preferences.backgroundName}</small></span>
                    {preferences.backgroundPreset === "custom" && <CheckCircle2 size={17} />}
                  </button>
                )}
              </div>
              <div className={`background-preview ${activeBackgroundUrl ? "has-image" : ""}`} style={activeBackgroundUrl ? { backgroundImage: `url("${activeBackgroundUrl}")` } : undefined}>
                {activeBackgroundUrl ? <span>{activeBackgroundLabel}</span> : <div><Image size={22} /><strong>{t("纯净主题背景")}</strong><span>{t("选择上方背景即可立即预览")}</span></div>}
              </div>
              <div className="range-grid">
                <label><span>{t("照片强度")} <strong>{Math.round(preferences.backgroundOpacity * 100)}%</strong></span><input type="range" min="0" max="1" step="0.01" value={preferences.backgroundOpacity} onChange={(event) => updatePreferences({ backgroundOpacity: Number(event.target.value) })} /></label>
                <label><span>{t("模糊")} <strong>{preferences.backgroundBlur}px</strong></span><input type="range" min="0" max="24" step="1" value={preferences.backgroundBlur} onChange={(event) => updatePreferences({ backgroundBlur: Number(event.target.value) })} /></label>
                <label><span>{t("压暗")} <strong>{Math.round(preferences.backgroundDim * 100)}%</strong></span><input type="range" min="0" max="0.8" step="0.01" value={preferences.backgroundDim} onChange={(event) => updatePreferences({ backgroundDim: Number(event.target.value) })} /></label>
              </div>
            </section>
          </>
        )}
        {tab === "conversation" && (
          <>
            <PageHeader icon={<MessageSquare size={20} />} title={t("对话显示")} description={t("决定思考记录、模型调用、工具结果和实时活动在对话中如何呈现。")} />
            <section className="preference-section display-name-section">
              <div className="preference-heading"><div><h2>{t("用户显示名称")}</h2><p>{t("只改变对话中用户消息的显示名称；留空时显示默认名称。")}</p></div></div>
              <form onSubmit={(event) => { event.preventDefault(); updatePreferences({ userDisplayName: displayNameDraft }); }}>
                <label htmlFor="user-display-name">{t("显示名称")}</label>
                <input id="user-display-name" value={displayNameDraft} maxLength={32} onChange={(event) => setDisplayNameDraft(event.target.value)} placeholder={t("你")} />
                <button type="submit" className="secondary-button" disabled={displayNameDraft.trim() === preferences.userDisplayName}>{t("保存")}</button>
              </form>
              <AvatarEditor name={preferences.userDisplayName || t("你")} url={preferences.userAvatarUrl} save={userAvatarUrl => updatePreferences({ userAvatarUrl })} />
            </section>
            <section className="preference-section conversation-presets">
              <div className="preference-heading"><div><h2>{t("显示预设")}</h2><p>{t("选择预设后仍可单独调整每一项。")}</p></div></div>
              <DisplayPresets preferences={preferences} update={updatePreferences} />
            </section>
            <section className="preference-section">
              <div className="preference-row"><div><Brain size={17} /><span><strong>{t("推理记录")}</strong><small>{t("显示模型返回并保存在会话中的思考内容")}</small></span></div><Toggle checked={preferences.showReasoning} onChange={(value) => updatePreferences({ showReasoning: value, ...(value ? { expandReasoning: true } : {}) })} /></div>
              <div className="preference-row"><div><ChevronDown size={17} /><span><strong>{t("默认展开推理")}</strong><small>{t("开启后直接显示推理正文，而不是只显示摘要栏")}</small></span></div><Toggle checked={preferences.expandReasoning} disabled={!preferences.showReasoning} onChange={(value) => updatePreferences({ expandReasoning: value })} /></div>
              <div className="preference-row"><div><Wrench size={17} /><span><strong>{t("工具调用")}</strong><small>{t("显示工具名称与调用参数")}</small></span></div><Toggle checked={preferences.showToolCalls} onChange={(value) => updatePreferences({ showToolCalls: value })} /></div>
              <div className="preference-row"><div><CheckCircle2 size={17} /><span><strong>{t("工具结果")}</strong><small>{t("显示工具实际返回的内容")}</small></span></div><Toggle checked={preferences.showToolResults} onChange={(value) => updatePreferences({ showToolResults: value })} /></div>
              <div className="preference-row"><div><ChevronDown size={17} /><span><strong>{t("默认展开结果")}</strong><small>{t("打开会话时直接展开工具输出")}</small></span></div><Toggle checked={preferences.expandToolResults} disabled={!preferences.showToolResults} onChange={(value) => updatePreferences({ expandToolResults: value })} /></div>
              <div className="preference-row"><div><Clock3 size={17} /><span><strong>{t("实时活动")}</strong><small>{t("运行期间显示进度、工具事件和审批状态")}</small></span></div><Toggle checked={preferences.showLiveActivity} onChange={(value) => updatePreferences({ showLiveActivity: value })} /></div>
            </section>
            <section className="conversation-display-preview">
              <div className="preview-title"><Eye size={15} /><span>{t("当前呈现预览")}</span></div>
              {preferences.showReasoning && <div className="preview-trace reasoning"><Brain size={14} /><span>{t("推理记录")}</span><small>{t(preferences.expandReasoning ? "直接展开正文" : "显示摘要栏")}</small></div>}
              {preferences.showToolCalls && <div className="preview-trace"><Wrench size={14} /><span>read_file</span><small>{t("模型调用")}</small></div>}
              {preferences.showToolResults && <div className="preview-trace result"><CheckCircle2 size={14} /><span>read_file</span><small>{t("工具结果")}</small></div>}
              {!preferences.showReasoning && !preferences.showToolCalls && !preferences.showToolResults && <p>{t("技术轨迹已隐藏，对话中只显示正文。")}</p>}
            </section>
          </>
        )}
        {tab === "models" && (
          <>
            <PageHeader icon={<Brain size={20} />} title={t("模型与提供商")} description={t("选择模型、配置凭据，并检查模型级思考与多模态能力。")} />
            <ProviderSettings state={state} selectModel={selectModel} saveProvider={saveProvider} revealSecret={revealSecret} addStandard={addStandard} editStandard={editStandard} deleteStandard={deleteStandard} customProviders={customProviders} />
          </>
        )}
        {tab === "images" && (
          <>
            <PageHeader icon={<Image size={20} />} title={t("生图模型")} description={t("选择用于文生图和图片编辑的模型；所选模型会用于内置图片生成工具。")} />
            <ImageProviderSettings imageModels={imageModels} refresh={refreshImageModels} selectImageModel={selectImageModel} />
          </>
        )}
        {tab === "about" && (
          <>
            <PageHeader icon={<Info size={20} />} title={t("关于 Reverie")} description={t("Electron 仅承载界面；所有 AI、工具和会话逻辑都由嵌入的 Reverie CLI exe 执行。")} />
            <div className="about-card"><div className="about-mark"><img src={REVERIE_MARK_URL} alt="Reverie" /></div><div><h2>Reverie {state.core.version}</h2><p>{t("核心接口")} {state.core.interface_version} · {state.core.release_status}</p></div></div>
            <p><a className="about-repository" href="https://github.com/Lin-Silver/Reverie-Cli" onClick={event => { event.preventDefault(); void window.reverie.openExternal("https://github.com/Lin-Silver/Reverie-Cli"); }}>GitHub · Lin-Silver/Reverie-Cli</a></p>
            {paths?.desktopBuild && <p>{t("界面构建")}: <code>{paths.desktopBuild.version} · {paths.desktopBuild.id}</code> · {paths.desktopBuild.builtAt}</p>}
            {paths?.desktopExecutable && <div className="path-list"><button type="button" onClick={()=>void window.reverie.reveal(paths.desktopExecutable!)}><span>{t("正在运行的应用")}</span><code>{paths.desktopExecutable}</code><FolderOpen size={14}/></button></div>}
            <div className="path-list"><button type="button" onClick={() => void window.reverie.reveal(state.workspace.config_path)}><span>{t("配置文件")}</span><code>{state.workspace.config_path}</code><FolderOpen size={14} /></button><button type="button" onClick={() => void window.reverie.reveal(state.workspace.project_data_dir)}><span>{t("工作区数据")}</span><code>{state.workspace.project_data_dir}</code><FolderOpen size={14} /></button>{paths && <button type="button" onClick={() => void window.reverie.reveal(paths.kernelPath)}><span>{t("CLI 内核")}</span><code>{paths.kernelPath}</code><FolderOpen size={14} /></button>}</div>
          </>
        )}
      </div>
    </div>
  );
}

function InspectorContent({ state, liveTurn, indexWorkspace, compactContext, compactDisabled, tab }: {
  state: DesktopState; liveTurn: LiveTurn | null; indexWorkspace: () => void; compactContext: () => void; compactDisabled: boolean; tab: "context" | "activity";
}) {
  const { t } = useI18n();
  const permission = state.settings.items.find((item) => item.key === "permission_level")?.value;
  const events = liveTurn?.events ?? [];
  const contextEngine = state.workspace.context_engine;
  const contextLabel = contextEngine?.indexing ? t("context.indexing", { progress: Math.round(contextEngine.progress) }) : contextEngine?.ready ? t("自动检索已启用") : t("正在按需预热");
  return <>{tab === "context" ? (
        <div className="inspector-content">
          <section><div className="inspector-heading"><span>{t("工作区")}</span><div className="inspector-actions"><button type="button" onClick={compactContext} disabled={compactDisabled} aria-label={t("压缩上下文")} title={t("压缩上下文")}><Archive size={13} /></button><button type="button" onClick={indexWorkspace} title={t("重新索引")}><RefreshCw className={contextEngine?.indexing ? "spin" : ""} size={13} /></button></div></div><div className="context-card"><Folder size={15} /><div><strong>{state.workspace.project_name}</strong><span>{state.workspace.project_root}</span></div></div><div className="context-engine-card"><div><span className="context-engine-orbit"><Sparkles size={14} /></span><span><strong>{t("上下文引擎")}</strong><small>{contextLabel}</small></span></div><div className="context-engine-metrics"><span><strong>{contextEngine?.files ?? 0}</strong> {t("文件")}</span><span><strong>{contextEngine?.symbols ?? 0}</strong> {t("符号")}</span></div>{contextEngine?.indexing && <div className="context-progress"><span style={{ width: `${Math.max(3, contextEngine.progress)}%` }} /></div>}</div></section>
          <section><div className="inspector-heading"><span>{t("运行时")}</span></div><div className="context-line"><span>{t("模型")}</span><strong>{state.models.active_model?.display_name || t("未配置")}</strong></div><div className="context-line"><span>{t("来源")}</span><strong>{expandModelSources(state.models.sources).find((item) => item.active)?.display_name}</strong></div><div className="context-line"><span>{t("模式")}</span><strong>{state.workspace.mode}</strong></div><div className="context-line"><span>{t("权限")}</span><strong>{String(permission ?? "workspace_write")}</strong></div></section>
          <section><div className="inspector-heading"><span>{t("恢复")}</span></div><div className="context-line"><span>{t("检查点")}</span><strong>{state.recovery.checkpoints.length}</strong></div><div className="context-line"><span>{t("操作")}</span><strong>{String(state.recovery.summary.total_operations ?? state.recovery.operations.length)}</strong></div></section>
          <section><div className="inspector-heading"><span>{t("快捷提示")}</span></div><div className="hint-card"><AtSign size={14} /><span><kbd>@</kbd> {t("会用 Context Engine 推荐当前任务最相关的文件。")}</span></div><div className="hint-card"><Paperclip size={14} /><span>{t("回形针可选择任意文件，并安全复制到工作区附件区。")}</span></div><div className="hint-card"><Command size={14} /><span><kbd>Ctrl K</kbd> {t("打开完整命令目录。")}</span></div></section>
        </div>
      ) : (
        <div className="inspector-content activity-feed">{events.length ? events.map((event, index) => <ActivityItem key={index} event={event} />) : <div className="empty-panel compact"><Clock3 size={22} /><strong>{t("暂无实时活动")}</strong><span>{t("模型调用工具时会在这里显示。")}</span></div>}</div>
      )}
  </>;
}

function CommandPalette({ commands, close, choose }: { commands: CommandRecord[]; close: () => void; choose: (command: CommandRecord) => void }) {
  const { t } = useI18n();
  const dialogRef = useRef<HTMLDivElement>(null);
  useDialogFocus(dialogRef, close);
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(0);
  const filtered = commands.filter((item) => `${item.command} ${item.summary} ${item.section}`.toLowerCase().includes(query.toLowerCase())).slice(0, 30);
  useEffect(() => { dialogRef.current?.querySelector(`[data-command-index="${selected}"]`)?.scrollIntoView?.({block:"nearest"}); }, [selected]);
  return (
    <div className="modal-backdrop" onMouseDown={close}>
      <div ref={dialogRef} className="command-palette" role="dialog" aria-modal="true" aria-label={t("命令面板")} tabIndex={-1} onMouseDown={(event) => event.stopPropagation()}>
        <div className="command-search"><Search size={17} /><input autoFocus role="combobox" aria-expanded="true" aria-controls="desktop-command-list" aria-activedescendant={filtered[selected] ? `desktop-command-${selected}` : undefined} aria-label={t("搜索命令、工具和功能…")} value={query} onChange={(event) => {setQuery(event.target.value);setSelected(0);}} onKeyDown={event=>{if(event.nativeEvent.isComposing || event.nativeEvent.keyCode===229)return;if(event.key==="ArrowDown" || event.key==="ArrowUp"){event.preventDefault();setSelected(value=>filtered.length ? (value+(event.key==="ArrowDown"?1:-1)+filtered.length)%filtered.length : 0);}else if(event.key==="Enter" && filtered[selected]){event.preventDefault();choose(filtered[selected]);}}} placeholder={t("搜索命令、工具和功能…")} /><kbd>Esc</kbd></div>
        <div className="command-results" id="desktop-command-list" role="listbox" aria-label={t("命令面板")}>{filtered.map((item,index) => <button type="button" role="option" aria-selected={selected===index} tabIndex={-1} id={`desktop-command-${index}`} data-command-index={index} key={item.id} onPointerMove={()=>setSelected(index)} onClick={() => choose(item)}><div className="command-icon"><Command size={14} /></div><div><strong>{item.command}</strong><span>{t(item.summary)}</span></div><small>{desktopCommandAvailable(item.command) ? t(item.section) : t("终端参考")}</small></button>)}</div>
        <div className="command-footer"><span><kbd>↵</kbd> {t("插入命令参考")}</span><span>{t("完整功能可直接通过 GUI 页面或自然语言调用")}</span></div>
      </div>
    </div>
  );
}

function SessionSearch({ close, openSession }: { close: () => void; openSession: (id: string) => void }) {
  const { t } = useI18n();
  const dialogRef = useRef<HTMLDivElement>(null);
  useDialogFocus(dialogRef, close);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Array<Record<string, unknown>>>([]);
  const [searching, setSearching] = useState(false);
  const [error, setError] = useState("");
  const [completedQuery, setCompletedQuery] = useState("");
  useEffect(() => {
    const normalized = query.trim();
    if (!normalized) { setResults([]); setSearching(false); setError(""); setCompletedQuery(""); return; }
    let cancelled = false;
    setSearching(true);
    setError("");
    const timer = window.setTimeout(async () => {
      try {
        const response = await window.reverie.request("searchSessions", { query: normalized });
        if (!cancelled) {
          setResults(response.results);
          setCompletedQuery(normalized);
        }
      } catch (searchError) {
        if (!cancelled) setError(searchError instanceof Error ? searchError.message : String(searchError));
      } finally {
        if (!cancelled) setSearching(false);
      }
    }, 220);
    return () => { cancelled = true; window.clearTimeout(timer); };
  }, [query]);
  return (
    <div className="modal-backdrop" onMouseDown={close}>
      <div ref={dialogRef} className="command-palette session-search-modal" role="dialog" aria-modal="true" aria-label={t("搜索所有会话内容…")} tabIndex={-1} onMouseDown={(event) => event.stopPropagation()}>
        <div className="command-search"><Search size={17} /><input autoFocus aria-label={t("搜索所有会话内容…")} value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t("搜索所有会话内容…")} /><button type="button" aria-label={t("关闭")} onClick={close}><X size={15} /></button></div>
        <div className="session-search-results">
          {searching && <div className="empty-row"><RefreshCw className="spin" size={14} />{t("正在搜索")}</div>}
          {error && <div className="empty-row error"><AlertCircle size={14} />{error}</div>}
          {!searching && !error && results.map((result) => <button type="button" key={`${result.session_id}-${result.message_index}`} onClick={() => { openSession(String(result.session_id)); close(); }}><MessageSquare size={14} /><div><strong>{String(result.session_name)}</strong><span>{String(result.text)}</span></div><small>{Number(result.message_index) < 0 ? t("标题") : `#${Number(result.message_index) + 1}`}</small></button>)}
          {!searching && !error && completedQuery === query.trim() && results.length === 0 && <div className="empty-row">{t("没有匹配的会话内容")}</div>}
        </div>
      </div>
    </div>
  );
}

function RenameSessionModal({ session, close, save }: { session: { id: string; name: string }; close: () => void; save: (name: string) => void }) {
  const { t } = useI18n();
  const dialogRef = useRef<HTMLFormElement>(null);
  useDialogFocus(dialogRef, close);
  const [name, setName] = useState(session.name);
  const valid = Boolean(name.trim());
  return (
    <div className="modal-backdrop" onMouseDown={close}>
      <form ref={dialogRef} className="form-modal rename-session-modal" role="dialog" aria-modal="true" aria-labelledby="rename-session-title" tabIndex={-1} onMouseDown={(event) => event.stopPropagation()} onSubmit={(event) => { event.preventDefault(); if (valid) save(name.trim()); }}>
        <div className="form-modal-header"><div><h2 id="rename-session-title">{t("重命名会话")}</h2><p>{t("使用一个容易辨认的标题，历史记录会立即同步更新。")}</p></div><IconButton label={t("关闭")} onClick={close}><X size={16} /></IconButton></div>
        <div className="form-grid single"><label><span>{t("会话标题")}</span><input autoFocus value={name} maxLength={120} onChange={(event) => setName(event.target.value)} /></label></div>
        <div className="form-modal-footer"><button type="button" className="secondary-button" onClick={close}>{t("取消")}</button><button type="submit" className="primary-button" disabled={!valid}>{t("保存")}</button></div>
      </form>
    </div>
  );
}

/** The add/edit form's draft for one manual model, prefilled when editing. */
function standardModelDraft(model?: ModelRecord | null): Record<string, unknown> {
  if (!model) return { provider: "openai-chat", supports_vision: false, max_context_tokens: 128000 };
  return {
    model: model.model ?? model.id,
    model_display_name: model.display_name ?? "",
    provider: model.transport || "openai-chat",
    base_url: model.base_url ?? "",
    endpoint: model.endpoint ?? "",
    max_context_tokens: Number(model.context_length ?? 0) || 128000,
    supports_vision: Boolean(model.vision),
    // Carried through untouched: the form has no header editor, and dropping
    // the key here would silently erase headers on every edit.
    custom_headers: { ...(model.custom_headers ?? {}) },
  };
}

function StandardModelModal({
  target,
  close,
  save,
  reveal,
}: {
  target: { index: number; model: ModelRecord } | null;
  close: () => void;
  save: (model: Record<string, unknown>, clearApiKey: boolean) => void;
  reveal?: () => Promise<string>;
}) {
  const { t } = useI18n();
  const dialogRef = useRef<HTMLFormElement>(null);
  useDialogFocus(dialogRef, close);
  const editing = target !== null;
  const [model, setModel] = useState<Record<string, unknown>>(() => standardModelDraft(target?.model));
  const [visible, setVisible] = useState(false);
  const [revealed, setRevealed] = useState(false);
  const [busy, setBusy] = useState(false);
  const update = (key: string, value: unknown) => setModel((current) => ({ ...current, [key]: value }));
  const valid = Boolean(model.model && model.model_display_name && model.base_url);
  const keyStored = Boolean(target?.model.api_key_configured);
  // The stored key was pulled into the field and then emptied: an explicit clear.
  const clearApiKey = editing && keyStored && revealed && String(model.api_key ?? "").trim() === "";
  const onEye = async () => {
    if (keyStored && !revealed && reveal && !busy) {
      setBusy(true);
      try {
        const secret = await reveal();
        update("api_key", secret);
        setRevealed(true);
        setVisible(true);
      } catch { /* leave blank; a new key can still be typed */ }
      finally { setBusy(false); }
      return;
    }
    setVisible((shown) => !shown);
  };
  const headerCount = Object.keys((model.custom_headers ?? {}) as Record<string, string>).length;
  // A stored transport the picker never offered (codex, webgemini) must stay
  // selectable, otherwise editing anything else would silently rewrite it.
  const providerId = String(model.provider ?? "openai-chat");
  const providerOptions: Array<[string, string]> = [
     ["openai-chat", "OpenAI Chat Completions"],
     ["openai-responses", "OpenAI Responses"],
     ["anthropic", "Anthropic"],
     ["request", "Generic Request"],
     ["curl", "cURL"],
  ];
  if (!providerOptions.some(([id]) => id === providerId)) providerOptions.push([providerId, providerId]);
  return (
    <div className="modal-backdrop" onMouseDown={close}>
      <form ref={dialogRef} className="form-modal" role="dialog" aria-modal="true" aria-labelledby="standard-model-title" tabIndex={-1} onMouseDown={(event) => event.stopPropagation()} onSubmit={(event) => { event.preventDefault(); if (valid) save(model, clearApiKey); }}>
        <div className="form-modal-header"><div><h2 id="standard-model-title">{editing ? t("编辑标准模型") : t("添加标准模型")}</h2><p>{t("该模型会同时出现在 TUI、命令行和 GUI 中。")}</p></div><IconButton label={t("关闭")} onClick={close}><X size={16} /></IconButton></div>
         <div className="form-grid single"><label><span>{t("模型 ID")}</span><input autoFocus value={String(model.model ?? "")} onChange={(event) => update("model", event.target.value)} placeholder={t("例如 gpt-5.4")} /></label><label><span>{t("显示名称")}</span><input value={String(model.model_display_name ?? "")} onChange={(event) => update("model_display_name", event.target.value)} placeholder={t("例如 GPT-5.4")} /></label><label><span>{t("提供者")}</span><select value={providerId} onChange={(event) => update("provider", event.target.value)}>{providerOptions.map(([id, label]) => <option key={id} value={id}>{t(label)}</option>)}</select></label><label><span>{t("基础 URL")}</span><input value={String(model.base_url ?? "")} onChange={(event) => update("base_url", event.target.value)} placeholder="https://api.example.com/v1" /></label><label><span>{t("请求路径")}<small>{t("可选")}</small></span><input value={String(model.endpoint ?? "")} onChange={(event) => update("endpoint", event.target.value)} placeholder="/chat/completions" /></label><label><span>{t("API 密钥")}{keyStored && <small>{t("点击眼睛查看，清空并保存即可移除")}</small>}</span><div className="field-input-wrap"><input type={visible ? "text" : "password"} value={String(model.api_key ?? "")} onChange={(event) => update("api_key", event.target.value)} placeholder={keyStored ? "••••••••" : ""} />{keyStored && <button type="button" aria-label={t("查看/隐藏密钥")} onClick={() => void onEye()} disabled={busy}>{visible ? <EyeOff size={14} /> : <Eye size={14} />}</button>}</div></label><label><span>{t("上下文长度")}</span><input type="number" value={Number(model.max_context_tokens)} onChange={(event) => update("max_context_tokens", Number(event.target.value))} /></label><label className="inline-toggle"><span>{t("支持视觉")}</span><Toggle checked={Boolean(model.supports_vision)} onChange={(value) => update("supports_vision", value)} /></label></div>
        {editing && headerCount > 0 && <p className="form-modal-note">{t("standardModel.headersKept", { count: headerCount })}</p>}
        <div className="form-modal-footer"><button type="button" className="secondary-button" onClick={close}>{t("取消")}</button><button type="submit" className="primary-button" disabled={!valid}>{editing ? t("保存") : t("添加模型")}</button></div>
      </form>
    </div>
  );
}

function ConfirmModal({ title, message, confirmLabel, danger = false, close, confirm }: { title: string; message: string; confirmLabel: string; danger?: boolean; close: () => void; confirm: () => void }) {
  const { t } = useI18n();
  const dialogRef = useRef<HTMLDivElement>(null);
  useDialogFocus(dialogRef, close);
  return (
    <div className="modal-backdrop" onMouseDown={close}>
      <div ref={dialogRef} className="confirm-modal" role="alertdialog" aria-modal="true" aria-labelledby="confirmation-title" aria-describedby="confirmation-message" tabIndex={-1} onMouseDown={(event) => event.stopPropagation()}>
        <div className={`confirm-icon ${danger ? "danger" : ""}`}>{danger ? <AlertCircle size={20} /> : <Info size={20} />}</div>
        <h2 id="confirmation-title">{title}</h2>
        <p id="confirmation-message">{message}</p>
        <div><button type="button" className="secondary-button" onClick={close}>{t("取消")}</button><button type="button" className={danger ? "danger-button" : "primary-button"} onClick={confirm}>{confirmLabel}</button></div>
      </div>
    </div>
  );
}

const RATS_PERMISSION_OPTIONS: RatsPermission[] = ["read", "project", "edit", "asset", "run", "build", "ai"];

/** The provider this client implements and verifies; preferred when offering registration. */
const RATS_BUILTIN_PROVIDER_ID = "reverie.engine";

/** What the core assumes when a definition names no discovery root. */
const RATS_DEFAULT_DISCOVERY_ROOT = "ReverieLocal/RATS/Services";

/** One custom-provider definition being written. Text fields stay text so they stay editable. */
type RatsProviderDraft = {
  providerId: string;
  product: string;
  label: string;
  serviceKinds: string;
  permissionClasses: RatsPermission[];
  toolTags: string;
  discoveryRoot: string;
  executableIdentity: "path" | "product_name";
  executableProductNames: string;
  executableError: string;
};

const EMPTY_RATS_PROVIDER_DRAFT: RatsProviderDraft = {
  providerId: "",
  product: "",
  label: "",
  serviceKinds: "",
  // The core refuses an empty permission list, so the draft opens on the
  // narrowest grant that is actually accepted rather than on nothing.
  permissionClasses: ["read"],
  toolTags: "",
  discoveryRoot: "",
  executableIdentity: "path",
  executableProductNames: "",
  executableError: "",
};

/** Split a comma- or whitespace-separated field into the lowercase list the core validates. */
function splitRatsDraftList(value: string): string[] {
  return [...new Set(value.split(/[,\s]+/).map((item) => item.trim().toLowerCase()).filter(Boolean))];
}

/**
 * The definition to send for one draft.
 *
 * `discoveryRoot` goes out as typed rather than pre-split into segments: the core
 * refuses an absolute path outright, and splitting it here would quietly
 * reinterpret it as relative and then discover nothing under it.
 */
function ratsProviderDefinition(draft: RatsProviderDraft): Record<string, unknown> {
  const definition: Record<string, unknown> = {
    providerId: draft.providerId.trim().toLowerCase(),
    product: draft.product.trim(),
    serviceKinds: splitRatsDraftList(draft.serviceKinds),
    permissionClasses: draft.permissionClasses,
    toolTags: splitRatsDraftList(draft.toolTags),
    executableIdentity: draft.executableIdentity,
  };
  if (draft.label.trim()) definition.label = draft.label.trim();
  if (draft.discoveryRoot.trim()) definition.discoveryRoot = draft.discoveryRoot.trim();
  if (draft.executableIdentity === "product_name") {
    // Only meaningful in this mode, and the core refuses the mode without them.
    definition.executableProductNames = draft.executableProductNames
      .split(/[,\n]+/)
      .map((item) => item.trim())
      .filter(Boolean);
  }
  if (draft.executableError.trim()) definition.executableError = draft.executableError.trim();
  return definition;
}

/** The fields the core cannot accept a draft without. Everything else has a default. */
function ratsDraftIsSendable(draft: RatsProviderDraft): boolean {
  return Boolean(
    draft.providerId.trim()
    && draft.product.trim()
    && splitRatsDraftList(draft.serviceKinds).length
    && draft.permissionClasses.length
    && (draft.executableIdentity === "path" || draft.executableProductNames.trim()),
  );
}

/**
 * The six checks `/rats confirm` reports, computed from one state record.
 *
 * Same order and same names as the terminal command, so a user who reads one
 * surface recognises the other. Nothing here talks to the service: a check that
 * asked its own question could disagree with the row shown right above it.
 */
function ratsConfirmationChecks(
  service: RatsServiceRecord,
  protocol: string,
): Array<{ label: string; passed: boolean; detail: string }> {
  return [
    { label: "descriptor verified", passed: true, detail: service.descriptorPath },
    {
      label: "protocol agreed",
      passed: Boolean(service.protocol) && service.protocol === protocol,
      detail: service.protocol === protocol ? service.protocol : `${service.protocol || "—"} ≠ ${protocol}`,
    },
    {
      label: "endpoint reachable",
      passed: service.connection === "connected" || service.connection === "available",
      detail: service.endpoint,
    },
    {
      label: "enabled by you",
      passed: service.enabled,
      detail: service.enabled ? service.permissions.join(" · ") : "",
    },
    { label: "session open", passed: service.sessionActive, detail: service.error },
    {
      label: "catalog readable",
      passed: service.tools.length > 0,
      detail: `${service.tools.length}/${service.nativeToolCount}`,
    },
  ];
}

function normalizeRatsState(next: RatsState): RatsState {
  if (Array.isArray(next.enabledProviders)) return next;
  const legacy = Array.isArray(next.enabledEngines) ? next.enabledEngines : [];
  return {
    ...next,
    enabledProviders: legacy.map((selection) => ({
      providerId: "reverie.engine",
      executable: selection.executable,
      permissions: selection.permissions,
    })),
  };
}

function RatsView() {
  const { t } = useI18n();
  const [state, setState] = useState<RatsState | null>(null);
  const [permissionDrafts, setPermissionDrafts] = useState<Record<string, RatsPermission[]>>({});
  const [definitions, setDefinitions] = useState<Record<string, Record<string, unknown>>>({});
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [logsOpen, setLogsOpen] = useState(false);
  const [registerTarget, setRegisterTarget] = useState("");
  const [confirmed, setConfirmed] = useState<Record<string, boolean>>({});
  const [draftOpen, setDraftOpen] = useState(false);
  const [draft, setDraft] = useState<RatsProviderDraft>(EMPTY_RATS_PROVIDER_DRAFT);
  /** True while the banner is showing a failure the background poll itself caused. */
  const pollFailed = useRef(false);

  const acceptState = useCallback((next: RatsState) => {
    const normalized = normalizeRatsState(next);
    setState(normalized);
    setPermissionDrafts((current) => {
      const updated = { ...current };
      for (const service of normalized.services) {
        if (!updated[service.executable]) updated[service.executable] = service.permissions;
      }
      for (const selection of normalized.enabledProviders ?? []) updated[selection.executable] = selection.permissions;
      return updated;
    });
    setRegisterTarget((current) => {
      if (current && normalized.supportedProviders.some((provider) => provider.providerId === current)) return current;
      // Never index blindly into supportedProviders: it is sorted by id, so a
      // custom provider named earlier in the alphabet would otherwise become the
      // default target and the register button would quietly register the wrong
      // application.
      const preferred = normalized.supportedProviders.find((provider) => provider.providerId === RATS_BUILTIN_PROVIDER_ID)
        ?? normalized.supportedProviders.find((provider) => !provider.custom)
        ?? normalized.supportedProviders[0];
      return preferred?.providerId ?? "";
    });
  }, []);

  const load = useCallback(async (foreground = false) => {
    if (foreground) setLoading(true);
    try {
      const response = await window.reverie.request("ratsState", {});
      acceptState(response.rats);
      // A successful poll says nothing about the action that failed, so it only
      // clears a message it put there itself. Otherwise the core's field-specific
      // refusal would vanish 2.5 seconds later, while it is still being read.
      if (foreground || pollFailed.current) {
        pollFailed.current = false;
        setError("");
      }
    } catch (loadError) {
      pollFailed.current = !foreground;
      setError(loadError instanceof Error ? loadError.message : String(loadError));
    } finally {
      setLoading(false);
    }
  }, [acceptState]);

  useEffect(() => {
    // Paint from the scan this session already did, then scan for real. Opening
    // the page is instant, and the poll below always scans: whether the disk
    // changed is the only question a poll is asking.
    void (async () => {
      try {
        const response = await window.reverie.request("ratsStateCached", {});
        acceptState(response.rats);
        setLoading(false);
      } catch {
        // An older core has no cached view. The scan is the answer either way.
      }
      await load(true);
    })();
    const timer = window.setInterval(() => void load(false), 2500);
    return () => window.clearInterval(timer);
  }, [acceptState, load]);

  const registerProvider = useCallback(async (providerId: string) => {
    const target = providerId.trim();
    if (!target) {
      setError("No supported RATS provider is registered.");
      return;
    }
    setBusy(`add:${target}`);
    try {
      const executable = await window.reverie.selectRatsProvider(target);
      if (executable) {
        const response = await window.reverie.request("ratsRegisterProvider", { providerId: target, executable });
        acceptState(response.rats);
      }
      setError("");
    } catch (actionError) {
      setError(actionError instanceof Error ? actionError.message : String(actionError));
    } finally {
      setBusy("");
    }
  }, [acceptState]);

  const setEnabled = useCallback(async (service: RatsServiceRecord, enabled: boolean, permissions?: RatsPermission[]) => {
    setBusy(service.serviceId);
    try {
      const selected = permissions ?? permissionDrafts[service.executable] ?? ["read"];
      const response = await window.reverie.request("ratsSetProviderEnabled", {
        providerId: service.providerId,
        executable: service.executable,
        enabled,
        permissions: selected,
      });
      acceptState(response.rats);
      setError("");
    } catch (actionError) {
      setError(actionError instanceof Error ? actionError.message : String(actionError));
    } finally {
      setBusy("");
    }
  }, [acceptState, permissionDrafts]);

  const togglePermission = useCallback((service: RatsServiceRecord, permission: RatsPermission) => {
    const current = permissionDrafts[service.executable] ?? service.permissions;
    let next = current.includes(permission)
      ? current.filter((item) => item !== permission)
      : [...current, permission];
    if (!next.length) next = ["read"];
    next = [...new Set(next)].sort() as RatsPermission[];
    setPermissionDrafts((drafts) => ({ ...drafts, [service.executable]: next }));
    if (service.enabled) void setEnabled(service, true, next);
  }, [permissionDrafts, setEnabled]);

  const inspectTool = useCallback(async (service: RatsServiceRecord, name: string) => {
    const key = `${service.serviceId}:${name}`;
    setBusy(key);
    try {
      const response = await window.reverie.request("ratsDescribe", { serviceId: service.serviceId, names: [name] });
      setDefinitions((current) => ({ ...current, [key]: response.definitions[0] ?? { name, schema_available: false } }));
      setError("");
    } catch (actionError) {
      setError(actionError instanceof Error ? actionError.message : String(actionError));
    } finally {
      setBusy("");
    }
  }, []);

  const removeRoot = useCallback(async (root: string) => {
    setBusy(root);
    try {
      const response = await window.reverie.request("ratsRemoveRoot", { root });
      acceptState(response.rats);
    } catch (actionError) {
      setError(actionError instanceof Error ? actionError.message : String(actionError));
    } finally {
      setBusy("");
    }
  }, [acceptState]);

  const confirmService = useCallback(async (service: RatsServiceRecord) => {
    if (confirmed[service.serviceId]) {
      setConfirmed((current) => ({ ...current, [service.serviceId]: false }));
      return;
    }
    // Detection is a fresh scan, not a read of what is already on screen:
    // confirming a service against a state view from 2 seconds ago would report
    // on a descriptor that may no longer exist.
    setBusy(`confirm:${service.serviceId}`);
    try {
      const response = await window.reverie.request("ratsState", {});
      acceptState(response.rats);
      setConfirmed((current) => ({ ...current, [service.serviceId]: true }));
      setError("");
    } catch (actionError) {
      setError(actionError instanceof Error ? actionError.message : String(actionError));
    } finally {
      setBusy("");
    }
  }, [acceptState, confirmed]);

  const defineCustomProvider = useCallback(async () => {
    setBusy("define");
    try {
      const response = await window.reverie.request("ratsDefineCustomProvider", {
        definition: ratsProviderDefinition(draft),
      });
      acceptState(response.rats);
      setDraft(EMPTY_RATS_PROVIDER_DRAFT);
      setDraftOpen(false);
      setError("");
    } catch (actionError) {
      // The draft is deliberately kept: the core names exactly which field it
      // refused, and clearing the form would make that message unusable.
      setError(actionError instanceof Error ? actionError.message : String(actionError));
    } finally {
      setBusy("");
    }
  }, [acceptState, draft]);

  const removeCustomProvider = useCallback(async (providerId: string) => {
    setBusy(`remove:${providerId}`);
    try {
      const response = await window.reverie.request("ratsRemoveCustomProvider", { providerId });
      acceptState(response.rats);
      setError("");
    } catch (actionError) {
      setError(actionError instanceof Error ? actionError.message : String(actionError));
    } finally {
      setBusy("");
    }
  }, [acceptState]);

  const toggleDraftPermission = useCallback((permission: RatsPermission) => {
    setDraft((current) => {
      const next = current.permissionClasses.includes(permission)
        ? current.permissionClasses.filter((item) => item !== permission)
        : [...current.permissionClasses, permission];
      return { ...current, permissionClasses: (next.length ? next : ["read"]) as RatsPermission[] };
    });
  }, []);

  const connected = state?.services.filter((service) => service.connection === "connected").length ?? 0;
  const available = state?.services.filter((service) => service.connection !== "unreachable").length ?? 0;
  const toolCount = state?.services.reduce((total, service) => total + service.tools.length, 0) ?? 0;
  const diagnostics = state ? [...state.diagnostics].reverse() : [];
  const offlineSelections = state?.enabledProviders?.filter((selection) =>
    !state.services.some((service) =>
      service.providerId.toLowerCase() === selection.providerId.toLowerCase()
      && service.executable.toLowerCase() === selection.executable.toLowerCase()
    )) ?? [];
  const supportedProviders = state?.supportedProviders ?? [];
  const customProviders = state?.customProviders ?? [];
  // A core that never published the schema does not have the declarative layer,
  // so the define surface is hidden rather than offered and then refused.
  const customProvidersSupported = Boolean(state?.customProviderSchema);
  const customProviderLimit = state?.customProviderLimit ?? 0;
  const permissionOptionsFor = (providerId: string): RatsPermission[] => {
    const declared = supportedProviders.find((provider) => provider.providerId === providerId)?.permissions ?? [];
    // Narrowed to the classes this build can render, then widened back to the
    // full list if that leaves nothing: an empty permission row would make an
    // enabled service look ungrantable.
    const known = declared.filter((permission) => RATS_PERMISSION_OPTIONS.includes(permission));
    return known.length ? known : RATS_PERMISSION_OPTIONS;
  };

  return (
    <div className="page-scroll rats-page">
      <PageHeader
        icon={<Database size={20} />}
        title="RATS"
        description={t("RATS 支持多个经过批准的 Reverie/Rilance 提供者；当前主动选择列表中只有 Reverie Engine 已实现并验证。")}
        action={<div className="header-action-row">{supportedProviders.length > 1 && <select aria-label={t("选择要登记的提供者")} value={registerTarget} onChange={(event) => setRegisterTarget(event.target.value)}>{supportedProviders.map((provider) => <option key={provider.providerId} value={provider.providerId}>{provider.providerId}</option>)}</select>}<button type="button" className="secondary-button" aria-expanded={logsOpen} aria-controls="rats-diagnostic-panel" onClick={() => setLogsOpen((open) => !open)}><FileText size={14} />{t("RTP 日志")}</button><button type="button" className="secondary-button" onClick={() => void load(true)} disabled={loading}><RefreshCw className={loading ? "spin" : ""} size={14} />{t("刷新")}</button><button type="button" className="primary-button" onClick={() => void registerProvider(registerTarget)} disabled={busy === `add:${registerTarget}`}><Plus size={14} />{t("登记提供者应用")}</button></div>}
      />
      <div className="tool-overview rats-overview">
        <div><Globe size={17} /><span>{t("发现服务")}<strong>{state?.services.length ?? 0}</strong></span></div>
        <div><ShieldCheck size={17} /><span>{t("已连接会话")}<strong>{connected}</strong></span></div>
        <div><Wrench size={17} /><span>{t("已公开工具")}<strong>{toolCount}</strong></span></div>
      </div>
      <div className="rats-security-note">
        <ShieldCheck size={18} />
        <div><strong>{t("受支持提供者，工具默认关闭")}</strong><span>{t("只显示已登记、正在运行并通过身份握手的 Reverie 提供者；未知或离线条目仅写入本地诊断日志。控制令牌和 RTP 会话令牌不会发送到页面或写入设置。")}</span></div>
      </div>
      {logsOpen && <section id="rats-diagnostic-panel" className="rats-log-panel" aria-labelledby="rats-log-title">
        <div className="rats-log-header"><div><h2 id="rats-log-title">{t("RTP 检索日志")}</h2><p>{t("记录发现、拒绝、握手、超时与目录请求；不记录令牌或工具参数。")}</p></div><button type="button" aria-label={t("关闭 RTP 日志")} onClick={() => setLogsOpen(false)}><X size={15} /></button></div>
        <div className="rats-log-summary">
          <div><span>{t("最近扫描")}</span><strong>{state?.scanDurationMs ?? 0} ms</strong></div>
          <div><span>{t("已拒绝条目")}</span><strong>{state?.rejectedDescriptorCount ?? 0}</strong></div>
          <code title={state?.diagnosticsPath}>{state?.diagnosticsPath || t("等待日志路径")}</code>
        </div>
        <div className="rats-log-list">
          {diagnostics.map((entry, index) => {
            const context = [entry.providerId, entry.serviceId, entry.operation, entry.reason, entry.path].filter(Boolean).join(" · ");
            return <div className={`rats-log-row ${entry.level}`} key={`${entry.timestampUtc}:${entry.event}:${index}`}>
              <time>{entry.timestampUtc.replace("T", " ").replace("Z", " UTC")}</time>
              <div><strong>{entry.event}</strong>{context && <span title={context}>{context}</span>}</div>
              <code>{entry.durationMs === undefined ? "—" : `${entry.durationMs} ms`}</code>
            </div>;
          })}
          {diagnostics.length === 0 && <div className="rats-log-empty">{t("刷新后将在这里显示 RATS 检索与 RTP 请求记录。")}</div>}
        </div>
      </section>}
      {error && <div className="page-loading error"><AlertCircle size={18} />{error}</div>}
      {loading && !state ? <div className="page-loading"><RefreshCw className="spin" size={18} />{t("扫描本地 RATS 服务")}</div> : (
        <>
          <div className="rats-section-heading"><div><h2>{t("受支持提供者")}</h2><p>{t("从每个提供者可执行文件旁的本地 RATS 发现目录实时读取。")}</p></div><span>{available}/{state?.services.length ?? 0}</span></div>
          <div className="rats-service-grid">
            {state?.services.map((service) => {
              const selectedPermissions = permissionDrafts[service.executable] ?? service.permissions;
              const statusLabel = service.connection === "connected" ? t("已连接") : service.connection === "available" ? t("可用") : t("不可达");
              return (
                <section className={`rats-service-card ${service.connection}`} key={service.serviceId}>
                  <div className="rats-service-header">
                    <div className="rats-service-emblem"><Sparkles size={20} /></div>
                    <div><h3>{service.product}</h3><p>{service.productVersion || service.protocol}</p></div>
                    <span className={`rats-status ${service.connection}`}><Circle size={8} fill="currentColor" />{statusLabel}</span>
                    <Toggle checked={service.enabled} disabled={busy === service.serviceId} onChange={(enabled) => void setEnabled(service, enabled)} />
                  </div>
                  <div className="rats-service-meta">
                    <div><span>{t("提供者")}</span><code>{service.providerId}</code></div>
                    <div><span>{t("端点")}</span><code>{service.endpoint}</code></div>
                    <div><span>{t("进程")}</span><code>PID {service.pid}</code></div>
                    <div><span>{t("服务 ID")}</span><code>{service.serviceId}</code></div>
                    <div><span>{t("身份握手")}</span><code>{service.probeLatencyMs} ms</code></div>
                    <div className="wide"><span>{t("提供者可执行文件")}</span><code title={service.executable}>{service.executable}</code></div>
                  </div>
                  <div className="rats-permissions">
                    <div><strong>{t("会话权限")}</strong><span>{t("修改已启用服务的权限会立即轮换会话令牌。")}</span></div>
                    <div className="permission-chips">
                      {permissionOptionsFor(service.providerId).map((permission) => (
                        <button type="button" key={permission} className={selectedPermissions.includes(permission) ? "active" : ""} onClick={() => togglePermission(service, permission)} disabled={busy === service.serviceId}>{permission}</button>
                      ))}
                    </div>
                  </div>
                  {service.error && <div className="rats-inline-error"><AlertCircle size={14} />{service.error}</div>}
                  <div className="rats-catalog-heading">
                    <div><strong>{t("检测与确认")}</strong><span>{t("重新扫描发现目录，再逐项核对这个服务是否真的可用。")}</span></div>
                    <button type="button" className="secondary-button" aria-expanded={Boolean(confirmed[service.serviceId])} onClick={() => void confirmService(service)} disabled={busy === `confirm:${service.serviceId}`}>{busy === `confirm:${service.serviceId}` ? <RefreshCw className="spin" size={13} /> : <ShieldCheck size={13} />}{t("确认服务")}</button>
                  </div>
                  {confirmed[service.serviceId] && <div className="rats-confirm-list">
                    {ratsConfirmationChecks(service, state?.protocol ?? "").map((check) => (
                      <div className={`rats-confirm-row ${check.passed ? "passed" : "failed"}`} key={check.label}>
                        {check.passed ? <CheckCircle2 size={14} /> : <AlertCircle size={14} />}
                        <strong>{check.label}</strong>
                        <code title={check.detail}>{check.detail || "—"}</code>
                      </div>
                    ))}
                  </div>}
                  <div className="rats-catalog-heading"><div><strong>{t("RTP 紧凑目录")}</strong><span>{service.tools.length ? t("按需展开定义，不把全部 schema 注入提示词。") : t(service.enabled ? "正在等待工具目录" : "启用服务后读取工具目录")}</span></div><span>{service.tools.length}/{service.nativeToolCount}</span></div>
                  {service.tools.length > 0 && <div className="rats-tool-list">
                    {service.tools.map((tool) => {
                      const definitionKey = `${service.serviceId}:${tool.name}`;
                      return <details key={tool.name} className="rats-tool-row">
                        <summary><div><strong>{tool.name}</strong><span>{tool.summary || t("暂无说明")}</span></div><span>{tool.permission}</span><ChevronDown size={14} /></summary>
                        <div className="rats-tool-detail">
                          <div className="tag-row"><span>{tool.category}</span>{tool.flags.map((flag) => <span key={flag}>{flag}</span>)}</div>
                          <button type="button" className="secondary-button" onClick={() => void inspectTool(service, tool.name)} disabled={busy === definitionKey}>{busy === definitionKey ? <RefreshCw className="spin" size={13} /> : <FileSearch size={13} />}{t("检查完整定义")}</button>
                          {definitions[definitionKey] && <pre>{JSON.stringify(definitions[definitionKey], null, 2)}</pre>}
                        </div>
                      </details>;
                    })}
                  </div>}
                </section>
              );
            })}
            {state?.services.length === 0 && <div className="empty-panel rats-empty"><Database size={28} /><strong>{t("尚未发现正在运行的 RATS 服务")}</strong><span>{t("启动已支持的提供者应用，或登记其可执行文件以检查固定的本地服务目录；拒绝原因可在 RTP 日志中审查。")}</span><button type="button" className="primary-button" onClick={() => void registerProvider(registerTarget)}><Plus size={14} />{t("登记提供者应用")}</button></div>}
          </div>
          {supportedProviders.length > 0 && <section className="rats-provider-panel">
            <div className="rats-section-heading"><div><h2>{t("可识别的提供者")}</h2><p>{t("内置提供者由本客户端编译时固定；自定义提供者读自设置文件，二者都不能互相覆盖。")}</p></div><span>{supportedProviders.length}</span></div>
            {supportedProviders.map((provider) => <div className="rats-provider-row" key={provider.providerId}>
              <Plug size={15} />
              <div>
                <strong>{provider.providerId}</strong>
                <span>{[provider.label || provider.product, ...(provider.serviceKinds ?? [provider.serviceKind])].filter(Boolean).join(" · ")}</span>
              </div>
              <span className="rats-provider-origin">{provider.custom ? t("自定义") : t("内置")}</span>
              <button type="button" aria-label={t("rats.registerProvider", { provider: provider.providerId })} onClick={() => void registerProvider(provider.providerId)} disabled={busy === `add:${provider.providerId}`}><Plus size={14} /></button>
            </div>)}
          </section>}
          {customProvidersSupported && <section className="rats-custom-panel">
            <div className="rats-section-heading"><div><h2>{t("自定义提供者")}</h2><p>{t("声明一个新的 RATS 提供者：定义只是数据，校验规则由核心据此构建。发现目录是相对于该提供者可执行文件所在目录的路径。")}</p></div><span>{customProviders.length}/{customProviderLimit}</span></div>
            {customProviders.map((definition) => <div className="rats-custom-row" key={definition.providerId}>
              <Plug size={15} />
              <div>
                <strong>{definition.providerId}</strong>
                <span>{[definition.label, definition.serviceKinds.join("/"), definition.discoveryRoot.join("/"), definition.executableIdentity].filter(Boolean).join(" · ")}</span>
              </div>
              <code>{definition.permissionClasses.join(" · ")}</code>
              <button type="button" aria-label={t("rats.removeCustomProvider", { provider: definition.providerId })} onClick={() => void removeCustomProvider(definition.providerId)} disabled={busy === `remove:${definition.providerId}`}><Trash2 size={14} /></button>
            </div>)}
            {customProviders.length === 0 && <div className="rats-custom-empty">{t("还没有自定义提供者。内置提供者的 ID 是保留的，不能被定义覆盖。")}</div>}
            <div className="rats-custom-actions">
              <button type="button" className="secondary-button" aria-expanded={draftOpen} aria-controls="rats-provider-draft" onClick={() => setDraftOpen((open) => !open)} disabled={customProviders.length >= customProviderLimit && !draftOpen}><Plus size={14} />{draftOpen ? t("收起定义表单") : t("定义新提供者")}</button>
              {customProviders.length >= customProviderLimit && <span>{t("已达到自定义提供者数量上限。")}</span>}
            </div>
            {draftOpen && <form id="rats-provider-draft" className="rats-custom-form" onSubmit={(event) => { event.preventDefault(); void defineCustomProvider(); }}>
              <div className="form-grid">
                <label><span>{t("提供者 ID")}</span><input value={draft.providerId} onChange={(event) => setDraft((current) => ({ ...current, providerId: event.target.value }))} placeholder="acme.toolhost" /></label>
                <label><span>{t("产品名称")}</span><input value={draft.product} onChange={(event) => setDraft((current) => ({ ...current, product: event.target.value }))} placeholder="Acme Tool Host" /></label>
                <label><span>{t("显示名称")}</span><input value={draft.label} onChange={(event) => setDraft((current) => ({ ...current, label: event.target.value }))} placeholder={t("留空则沿用产品名称")} /></label>
                <label><span>{t("服务种类")}</span><input value={draft.serviceKinds} onChange={(event) => setDraft((current) => ({ ...current, serviceKinds: event.target.value }))} placeholder="editor, headless" /></label>
                <label><span>{t("工具标签")}</span><input value={draft.toolTags} onChange={(event) => setDraft((current) => ({ ...current, toolTags: event.target.value }))} placeholder={t("可留空")} /></label>
                <label><span>{t("发现目录（相对）")}</span><input value={draft.discoveryRoot} onChange={(event) => setDraft((current) => ({ ...current, discoveryRoot: event.target.value }))} placeholder={RATS_DEFAULT_DISCOVERY_ROOT} /></label>
                <label><span>{t("可执行文件校验方式")}</span><select value={draft.executableIdentity} onChange={(event) => setDraft((current) => ({ ...current, executableIdentity: event.target.value === "product_name" ? "product_name" : "path" }))}><option value="path">{t("path：只校验路径存在")}</option><option value="product_name">{t("product_name：校验文件的产品名资源")}</option></select></label>
                {draft.executableIdentity === "product_name" && <label><span>{t("允许的产品名")}</span><input value={draft.executableProductNames} onChange={(event) => setDraft((current) => ({ ...current, executableProductNames: event.target.value }))} placeholder="Acme Tool Host" /></label>}
                <label className="wide"><span>{t("选择失败时的提示")}</span><input value={draft.executableError} onChange={(event) => setDraft((current) => ({ ...current, executableError: event.target.value }))} placeholder={t("留空则由核心生成")} /></label>
              </div>
              <div className="rats-draft-permissions">
                <div><strong>{t("可授予的权限类别")}</strong><span>{t("这里声明的是这个提供者最多能被授予什么，而不是现在授予了什么。")}</span></div>
                <div className="permission-chips">
                  {RATS_PERMISSION_OPTIONS.map((permission) => (
                    <button type="button" key={permission} className={draft.permissionClasses.includes(permission) ? "active" : ""} onClick={() => toggleDraftPermission(permission)}>{permission}</button>
                  ))}
                </div>
              </div>
              <details className="rats-draft-preview"><summary>{t("查看将要提交的定义")}</summary><pre>{JSON.stringify(ratsProviderDefinition(draft), null, 2)}</pre></details>
              <div className="rats-custom-actions">
                <button type="button" className="secondary-button" onClick={() => { setDraft(EMPTY_RATS_PROVIDER_DRAFT); setDraftOpen(false); }}>{t("取消")}</button>
                <button type="submit" className="primary-button" disabled={busy === "define" || !ratsDraftIsSendable(draft)}>{busy === "define" ? <RefreshCw className="spin" size={13} /> : <Check size={13} />}{t("保存定义")}</button>
              </div>
            </form>}
          </section>}
          {offlineSelections.length > 0 && <section className="rats-offline-panel"><div className="rats-section-heading"><div><h2>{t("已保存但离线")}</h2><p>{t("这些提供者下次启动时会自动建立已授权会话。")}</p></div></div>{offlineSelections.map((selection) => <div className="rats-offline-row" key={`${selection.providerId}:${selection.executable}`}><Database size={15} /><div><strong>{selection.providerId}</strong><code>{selection.executable}</code></div><span>{selection.permissions.join(" · ")}</span></div>)}</section>}
          {state && state.configuredDiscoveryRoots.length > 0 && <section className="rats-roots-panel"><div className="rats-section-heading"><div><h2>{t("已登记发现目录")}</h2><p>{t("设置实时保存在 Reverie CLI 可执行文件旁的 .reverie/rats 目录中。")}</p></div><code title={state.statePath}>{state.statePath}</code></div>{state.configuredDiscoveryRoots.map((root) => <div className="rats-root-row" key={root}><Folder size={15} /><code>{root}</code><button type="button" aria-label={t("移除发现目录")} onClick={() => void removeRoot(root)} disabled={busy === root}><X size={14} /></button></div>)}</section>}
        </>
      )}
    </div>
  );
}

const ACTIVE_SUBAGENT_STATUSES = new Set(["queued", "running", "cancelling"]);

function subagentStatusLabel(status: string, t: (key: string) => string): string {
  const normalized = status.trim().toLowerCase();
  if (normalized === "queued") return t("排队中");
  if (normalized === "running") return t("运行中");
  if (normalized === "cancelling") return t("正在取消");
  if (normalized === "cancelled") return t("已取消");
  if (normalized === "failed") return t("失败");
  if (normalized === "completed") return t("已完成");
  return status || t("未知");
}

function subagentModelName(agent: SubagentSpecRecord): string {
  return String(agent.model_ref.display_name ?? agent.model_ref.model ?? agent.model_ref.source ?? "—");
}

function SubagentsView() {
  const { language, t } = useI18n();
  const [snapshot, setSnapshot] = useState<SubagentsState | null>(null);
  const [selectedAgentId, setSelectedAgentId] = useState("all");
  const [selectedRunId, setSelectedRunId] = useState("");
  const [runLog, setRunLog] = useState<SubagentRunLog | null>(null);
  const [runFilter, setRunFilter] = useState("");
  const [detailTab, setDetailTab] = useState<"timeline" | "output">("timeline");
  const [loading, setLoading] = useState(true);
  const [logLoading, setLogLoading] = useState(false);
  const [error, setError] = useState("");
  const loadInFlight = useRef(false);
  const logSequence = useRef(0);

  const load = useCallback(async (foreground = false) => {
    if (loadInFlight.current) return;
    loadInFlight.current = true;
    if (foreground) setLoading(true);
    try {
      const response = await window.reverie.request("getSubagents", {});
      setSnapshot(response.subagents);
      setError("");
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : String(loadError));
    } finally {
      setLoading(false);
      loadInFlight.current = false;
    }
  }, []);

  useEffect(() => { void load(true); }, [load]);

  const hasActiveRuns = snapshot?.runs.some((run) => ACTIVE_SUBAGENT_STATUSES.has(run.status.toLowerCase())) ?? false;
  useEffect(() => {
    const timer = window.setInterval(() => void load(false), hasActiveRuns ? 1_500 : 6_000);
    return () => window.clearInterval(timer);
  }, [hasActiveRuns, load]);

  const filteredRuns = useMemo(() => {
    const needle = runFilter.trim().toLowerCase();
    return (snapshot?.runs ?? []).filter((run) => {
      if (selectedAgentId !== "all" && run.subagent_id !== selectedAgentId) return false;
      if (!needle) return true;
      return [run.run_id, run.task_id, run.subagent_id, run.status, run.summary, run.error]
        .some((value) => value.toLowerCase().includes(needle));
    });
  }, [runFilter, selectedAgentId, snapshot?.runs]);

  useEffect(() => {
    if (selectedRunId && filteredRuns.some((run) => run.run_id === selectedRunId)) return;
    setSelectedRunId(filteredRuns[0]?.run_id ?? "");
  }, [filteredRuns, selectedRunId]);

  const selectedRun = filteredRuns.find((run) => run.run_id === selectedRunId) ?? null;
  useEffect(() => {
    const sequence = ++logSequence.current;
    if (!selectedRunId) {
      setRunLog(null);
      return;
    }
    setLogLoading(true);
    void window.reverie.request("getSubagentRunLog", { runId: selectedRunId }).then((response) => {
      if (sequence === logSequence.current) setRunLog(response.log);
    }).catch((logError) => {
      if (sequence === logSequence.current) {
        setRunLog(null);
        setError(logError instanceof Error ? logError.message : String(logError));
      }
    }).finally(() => {
      if (sequence === logSequence.current) setLogLoading(false);
    });
  }, [selectedRunId, selectedRun?.ended_at, selectedRun?.status]);

  const agents = snapshot?.agents ?? [];
  const runs = snapshot?.runs ?? [];
  const activeCount = runs.filter((run) => ACTIVE_SUBAGENT_STATUSES.has(run.status.toLowerCase())).length;
  const completedCount = runs.filter((run) => run.status.toLowerCase() === "completed").length;
  const failedCount = runs.filter((run) => run.status.toLowerCase() === "failed").length;
  const selectedAgent = agents.find((agent) => agent.id === selectedRun?.subagent_id);
  const runStatus = selectedRun?.status.toLowerCase() ?? "";
  const runOutput = selectedRun?.error || selectedRun?.summary || runLog?.run.error || runLog?.run.summary || "";

  return (
    <div className="page-scroll subagents-page">
      <PageHeader
        icon={<Bot size={20} />}
        title={t("SubAgents")}
        description={t("集中查看委派代理、运行状态、执行时间线与脱敏日志。")}
        action={<button type="button" className="secondary-button" onClick={() => void load(true)} disabled={loading}><RefreshCw className={loading ? "spin" : ""} size={14} />{t("刷新")}</button>}
      />
      <div className="tool-overview subagent-overview">
        <div><Bot size={17} /><span>{t("已配置代理")}<strong>{agents.length}</strong></span></div>
        <div><Activity size={17} /><span>{t("正在执行")}<strong>{activeCount}</strong></span></div>
        <div><CheckCircle2 size={17} /><span>{t("已完成运行")}<strong>{completedCount}</strong></span></div>
        <div><AlertCircle size={17} /><span>{t("失败运行")}<strong>{failedCount}</strong></span></div>
      </div>
      {error && <div className="page-loading error"><AlertCircle size={18} />{error}</div>}
      {snapshot && !snapshot.available ? (
        <div className="empty-panel subagent-empty"><Bot size={30} /><strong>{t("当前模式不支持 SubAgents")}</strong><span>{t("请切换到 Reverie 或 Computer 模式后再查看。")}</span></div>
      ) : (
        <div className="subagent-dashboard">
          <section className="subagent-agent-panel" aria-labelledby="subagent-agents-title">
            <div className="subagent-panel-heading"><div><h2 id="subagent-agents-title">{t("代理")}</h2><p>{t("按代理筛选运行记录")}</p></div><span>{agents.length}</span></div>
            <div className="subagent-agent-list">
              <button type="button" className={selectedAgentId === "all" ? "active" : ""} onClick={() => setSelectedAgentId("all")}>
                <span className="subagent-avatar all"><Bot size={16} /></span>
                <span><strong>{t("全部代理")}</strong><small>{t("subagent.runCount", { count: runs.length })}</small></span>
              </button>
              {agents.map((agent) => {
                const agentRuns = runs.filter((run) => run.subagent_id === agent.id);
                const agentActive = agentRuns.some((run) => ACTIVE_SUBAGENT_STATUSES.has(run.status.toLowerCase()));
                return (
                  <button type="button" className={selectedAgentId === agent.id ? "active" : ""} key={agent.id} onClick={() => setSelectedAgentId(agent.id)}>
                    <span className={`subagent-avatar ${agentActive ? "working" : ""}`} style={{ color: agent.color, borderColor: agent.color }}><Bot size={16} /></span>
                    <span><strong>{agent.name || agent.id}</strong><small>{subagentModelName(agent)}</small></span>
                    <code>{agentRuns.length}</code>
                  </button>
                );
              })}
              {!agents.length && !loading && <div className="subagent-list-empty"><Bot size={22} /><span>{t("尚未配置 SubAgent")}</span><small>{t("可在对话中让 Reverie 创建并委派代理。")}</small></div>}
            </div>
          </section>

          <section className="subagent-runs-panel" aria-labelledby="subagent-runs-title">
            <div className="subagent-panel-heading runs"><div><h2 id="subagent-runs-title">{t("运行记录")}</h2><p>{t(hasActiveRuns ? "活动运行每 1.5 秒自动刷新" : "显示当前工作区的历史运行")}</p></div><span>{filteredRuns.length}</span></div>
            <label className="subagent-run-search"><Search size={14} /><input value={runFilter} onChange={(event) => setRunFilter(event.target.value)} placeholder={t("筛选运行、状态或摘要")} /></label>
            <div className="subagent-run-list">
              {filteredRuns.map((run) => {
                const status = run.status.toLowerCase();
                const running = ACTIVE_SUBAGENT_STATUSES.has(status);
                const agent = agents.find((item) => item.id === run.subagent_id);
                return (
                  <button type="button" className={`subagent-run-row ${selectedRunId === run.run_id ? "active" : ""}`} key={run.run_id} onClick={() => setSelectedRunId(run.run_id)}>
                    <span className={`subagent-run-state ${status}`}>{running ? <RefreshCw className="spin" size={13} /> : status === "completed" ? <Check size={13} /> : <AlertCircle size={13} />}</span>
                    <span className="subagent-run-copy"><strong>{agent?.name || run.subagent_id}</strong><small>{run.summary || run.error || run.task_id}</small></span>
                    <span className={`subagent-status ${status}`}>{subagentStatusLabel(run.status, t)}</span>
                    <time>{formatTime(run.started_at, language)}</time>
                  </button>
                );
              })}
              {!filteredRuns.length && <div className="subagent-list-empty"><Clock3 size={22} /><span>{t("暂无运行记录")}</span><small>{t("SubAgent 开始工作后会在这里显示。")}</small></div>}
            </div>
          </section>

          <section className="subagent-detail-panel" aria-labelledby="subagent-detail-title">
            {!selectedRun ? (
              <div className="subagent-detail-empty"><Bot size={28} /><strong>{t("选择一条运行查看日志")}</strong><span>{t("时间线会把模型等待、工具调用和完成状态分开呈现。")}</span></div>
            ) : (
              <>
                <div className="subagent-detail-header">
                  <div><p>{selectedAgent?.name || selectedRun.subagent_id}</p><h2 id="subagent-detail-title">{selectedRun.task_id || selectedRun.run_id}</h2></div>
                  <span className={`subagent-status ${runStatus}`}>{subagentStatusLabel(selectedRun.status, t)}</span>
                </div>
                <div className="subagent-detail-meta">
                  <div><span>{t("模型")}</span><strong>{runLog?.model.display_name || runLog?.model.model || (selectedAgent ? subagentModelName(selectedAgent) : "—")}</strong></div>
                  <div><span>{t("开始时间")}</span><strong>{new Date(selectedRun.started_at).toLocaleString(language)}</strong></div>
                  <div><span>{t("运行 ID")}</span><code>{selectedRun.run_id}</code></div>
                </div>
                {runLog?.assignment && <div className="subagent-assignment"><span>{t("委派任务")}</span><p>{runLog.assignment}</p></div>}
                <div className="subagent-detail-tabs" role="tablist" aria-label={t("SubAgent 日志视图")}>
                  <button type="button" role="tab" aria-selected={detailTab === "timeline"} className={detailTab === "timeline" ? "active" : ""} onClick={() => setDetailTab("timeline")}><Activity size={14} />{t("时间线")}<span>{runLog?.events.length ?? 0}</span></button>
                  <button type="button" role="tab" aria-selected={detailTab === "output"} className={detailTab === "output" ? "active" : ""} onClick={() => setDetailTab("output")}><FileText size={14} />{t("输出")}</button>
                </div>
                <div className="subagent-detail-body">
                  {logLoading ? <div className="subagent-log-loading"><RefreshCw className="spin" size={15} />{t("正在读取日志")}</div> : detailTab === "timeline" ? (
                    <div className="subagent-timeline">
                      {runLog?.events.length ? runLog.events.map((event, index) => <ActivityItem key={`${String(event.event ?? event.message ?? "event")}-${index}`} event={event} />) : <div className="subagent-log-empty"><Activity size={22} /><span>{t("该运行没有保存结构化事件")}</span></div>}
                    </div>
                  ) : (
                    <div className={`subagent-output ${selectedRun.error ? "error" : ""}`}>
                      {runOutput ? <Markdown>{runOutput}</Markdown> : <div className="subagent-log-empty"><FileText size={22} /><span>{t("正在等待代理输出")}</span></div>}
                    </div>
                  )}
                </div>
                {runLog && <details className="subagent-raw-log"><summary><Code2 size={13} />{t("查看脱敏原始日志")}<ChevronDown size={13} /></summary><pre>{JSON.stringify(runLog, null, 2)}</pre></details>}
              </>
            )}
          </section>
        </div>
      )}
    </div>
  );
}

function taskKey(task: RatsTaskRecord): string {
  return `${task.provider_id}:${task.service_id}:${task.task_id}`;
}

const RTP_TASK_LOG_HISTORY_LIMIT = 64 * 1024;

function appendTaskLogHistory(previous: string, incoming: string): string {
  const combined = `${previous}${incoming}`;
  return combined.length > RTP_TASK_LOG_HISTORY_LIMIT
    ? combined.slice(-RTP_TASK_LOG_HISTORY_LIMIT)
    : combined;
}

function recordValue(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : {};
}

function taskRunning(task: RatsTaskRecord, status: Record<string, unknown>): boolean {
  const output = recordValue(status.output);
  if (typeof status.running === "boolean") return status.running;
  if (typeof output.running === "boolean") return output.running;
  return Boolean(recordValue(task.status).running);
}

function taskStatusLabel(task: RatsTaskRecord, status: Record<string, unknown>, t: (key: string) => string): string {
  if (taskRunning(task, status)) return t("运行中");
  if (Boolean(status.cancelled ?? task.cancelled)) return t("已取消");
  if (status.error || task.error) return t("失败");
  return t("已完成");
}

/** One provider's live standing, with the worst-case reason it is not usable. */
type RtpProviderStatus = {
  providerId: string;
  label: string;
  kinds: string;
  origin: "builtin" | "custom" | "unlisted";
  authorized: boolean;
  services: RatsServiceRecord[];
  connected: number;
  tools: number;
  tasks: number;
  connection: "connected" | "available" | "unreachable" | "absent";
  error: string;
  /** Permission classes the *definition* grants, which a live session may narrow. */
  permissionClasses: string[];
  toolTags: string[];
  /** Present only for a user-declared provider, and only if the core reports them. */
  definition: RatsCustomProviderDefinition | null;
};

/**
 * Every provider this page should report on, whether or not it is running.
 *
 * Built from the three lists the core publishes rather than from a hard-coded
 * id: `supportedProviders` covers compiled-in and user-declared definitions,
 * the enabled selections cover ones authorized in an earlier run that have not
 * come back up, and `services` covers anything live that the other two somehow
 * do not name — an older core, or a definition deleted while its service ran.
 */
function rtpProviderStatuses(state: RatsState | null, tasks: RatsTaskRecord[]): RtpProviderStatus[] {
  if (!state) return [];
  const services = state.services;
  const definitions = new Map((state.customProviders ?? []).map((entry) => [entry.providerId, entry]));
  const authorized = new Set([
    ...(state.enabledProviders ?? []).map((selection) => selection.providerId),
    ...(state.enabledProviders === undefined && state.enabledEngines?.length ? [RATS_BUILTIN_PROVIDER_ID] : []),
  ]);
  const build = (
    providerId: string,
    label: string,
    kinds: string[],
    origin: RtpProviderStatus["origin"],
    provider?: RatsProviderRecord,
  ): RtpProviderStatus => {
    const owned = services.filter((service) => service.providerId === providerId);
    const connection = owned.some((service) => service.connection === "connected")
      ? "connected" as const
      : owned.some((service) => service.connection === "available")
        ? "available" as const
        : owned.length ? "unreachable" as const : "absent" as const;
    const definition = definitions.get(providerId) ?? null;
    return {
      providerId,
      label: label || providerId,
      kinds: kinds.filter(Boolean).join(" · "),
      origin,
      authorized: authorized.has(providerId),
      services: owned,
      connected: owned.filter((service) => service.connection === "connected" && service.sessionActive).length,
      tools: owned.reduce((total, service) => total + service.tools.length, 0),
      tasks: tasks.filter((task) => task.provider_id === providerId).length,
      connection,
      error: owned.map((service) => service.error).find(Boolean) ?? "",
      // The definition is the more authoritative of the two: a compiled-in
      // record carries only what this build knows, while a user-declared one
      // may name a class this build was never compiled with.
      permissionClasses: definition?.permissionClasses ?? provider?.permissions ?? [],
      toolTags: definition?.toolTags ?? provider?.toolTags ?? [],
      definition,
    };
  };
  const rows = state.supportedProviders.map((provider) => build(
    provider.providerId,
    provider.label || provider.product,
    provider.serviceKinds ?? [provider.serviceKind],
    provider.custom ? "custom" : "builtin",
    provider,
  ));
  const listed = new Set(rows.map((row) => row.providerId));
  for (const providerId of [...authorized, ...services.map((service) => service.providerId)]) {
    if (listed.has(providerId)) continue;
    listed.add(providerId);
    const service = services.find((item) => item.providerId === providerId);
    rows.push(build(providerId, service?.product ?? providerId, service ? [service.serviceKind] : [], "unlisted"));
  }
  // Live first, then anything the user authorized, then the rest by id, so the
  // panel opens on whatever is actually answering RTP right now.
  const rank = { connected: 0, available: 1, unreachable: 2, absent: 3 };
  return rows.sort((left, right) =>
    rank[left.connection] - rank[right.connection]
    || Number(right.authorized) - Number(left.authorized)
    || left.providerId.localeCompare(right.providerId));
}

function rtpProviderStatusLabel(row: RtpProviderStatus, t: (key: string) => string): string {
  if (row.connection === "connected") return row.connected ? t("已连接") : t("已握手");
  if (row.connection === "available") return t("可用");
  if (row.connection === "unreachable") return t("不可达");
  return row.authorized ? t("已授权待启动") : t("未发现服务");
}

/** One labelled fact in an expanded provider. `wide` spans the whole fact grid. */
type RtpFact = { label: string; value: string; wide?: boolean };

/**
 * Everything the core reports about one live service.
 *
 * Facts with no value are dropped rather than rendered as an em dash: an older
 * core answers without the capability-contract fields at all, and a grid full
 * of blanks reads as breakage instead of as "this service predates the field".
 */
function rtpServiceFacts(service: RatsServiceRecord, t: (key: string) => string): RtpFact[] {
  return ([
    { label: t("能力契约"), value: service.contract ?? "" },
    { label: t("传输协议"), value: service.protocol },
    { label: t("产品版本"), value: service.productVersion },
    { label: t("服务种类"), value: service.serviceKind },
    { label: t("端点"), value: service.endpoint },
    { label: t("进程"), value: service.pid ? `PID ${service.pid}` : "" },
    { label: t("身份握手"), value: service.probeLatencyMs ? `${service.probeLatencyMs} ms` : "" },
    { label: t("启动时间"), value: service.startedUtc },
    { label: t("目录版本"), value: service.catalogRevision },
    // Loaded / compact / native: the three counts diverge when the service
    // publishes more tools than the session was granted permission to load.
    { label: t("工具计数"), value: `${service.loadedToolNames.length} / ${service.tools.length} / ${service.nativeToolCount}` },
    { label: t("描述符"), value: service.descriptorPath, wide: true },
    { label: t("可执行文件"), value: service.executable, wide: true },
  ] satisfies RtpFact[]).filter((fact) => Boolean(fact.value));
}

function RtpFactGrid({ facts }: { facts: RtpFact[] }) {
  if (!facts.length) return null;
  return <div className="rtp-fact-grid">
    {facts.map((fact) => (
      <div className={fact.wide ? "wide" : ""} key={fact.label}>
        <span>{fact.label}</span>
        <code title={fact.value}>{fact.value}</code>
      </div>
    ))}
  </div>;
}

function RtpChipRow({ label, items }: { label: string; items: string[] }) {
  if (!items.length) return null;
  return <div className="rtp-chip-row">
    <span>{label}</span>
    <div className="tag-row">{items.map((item) => <span key={item}>{item}</span>)}</div>
  </div>;
}

/** `{ read: 12 }` rendered as `read 12`, so a zero count still reads as a class. */
function rtpCountChips(counts: Record<string, number> | undefined): string[] {
  return Object.entries(counts ?? {}).map(([key, value]) => `${key} ${value}`);
}

function RtpProviderDetail({ row, t }: { row: RtpProviderStatus; t: (key: string, values?: Record<string, string | number>) => string }) {
  const definition = row.definition;
  return (
    <div className="rtp-provider-detail">
      <div className="rtp-detail-block">
        <div className="rtp-detail-heading">
          <strong>{t("登记信息")}</strong>
          <span>{row.origin === "custom" ? t("读自设置文件的自定义定义") : row.origin === "builtin" ? t("本客户端编译时固定的内置定义") : t("核心未登记，仅从运行中的服务推断")}</span>
        </div>
        <RtpFactGrid facts={([
          { label: t("提供者 ID"), value: row.providerId },
          { label: t("名称"), value: row.label },
          { label: t("服务种类"), value: row.kinds },
          { label: t("授权状态"), value: row.authorized ? t("已授权") : t("未授权") },
          { label: t("发现目录"), value: definition ? definition.discoveryRoot.join("/") : "", wide: true },
          { label: t("可执行匹配"), value: definition ? definition.executableIdentity : "" },
          { label: t("可执行产品名"), value: definition ? definition.executableProductNames.join(" · ") : "", wide: true },
        ] satisfies RtpFact[]).filter((fact) => Boolean(fact.value))} />
        <RtpChipRow label={t("权限类别")} items={row.permissionClasses} />
        <RtpChipRow label={t("工具标签")} items={row.toolTags} />
        {definition?.executableError && <div className="rats-inline-error"><AlertCircle size={14} />{definition.executableError}</div>}
      </div>
      {row.services.map((service) => (
        <div className="rtp-detail-block" key={service.serviceId}>
          <div className="rtp-detail-heading">
            <strong>{service.product || service.serviceId}</strong>
            <span>{service.serviceId}</span>
            <span className={`rats-status ${service.connection}`}>
              {service.connection === "connected"
                ? (service.sessionActive ? t("已连接") : t("已握手"))
                : service.connection === "available" ? t("可用") : t("不可达")}
            </span>
          </div>
          <RtpFactGrid facts={rtpServiceFacts(service, t)} />
          <RtpChipRow label={t("声明权限")} items={service.declaredPermissions ?? service.permissions} />
          <RtpChipRow label={t("会话权限")} items={service.permissions} />
          <RtpChipRow label={t("每类工具数")} items={rtpCountChips(service.permissionToolCounts)} />
          <RtpChipRow label={t("协商特性")} items={service.features ?? []} />
          <RtpChipRow label={t("服务约束")} items={service.constraints ?? []} />
          <RtpChipRow label={t("服务限额")} items={rtpCountChips(service.limits)} />
          {service.error && <div className="rats-inline-error"><AlertCircle size={14} />{service.error}</div>}
        </div>
      ))}
      {!row.services.length && <div className="rats-task-empty-inline">
        {row.authorized ? t("已授权但当前没有服务在运行，启动提供者应用后会自动出现。") : t("尚未在这台机器上发现该提供者的服务。")}
      </div>}
    </div>
  );
}

function RtpTasksView({ preferences, updatePreferences }: {
  preferences: UiPreferences;
  updatePreferences: (patch: Partial<UiPreferences>) => void;
}) {
  const { t } = useI18n();
  const [state, setState] = useState<RatsState | null>(null);
  const [tasks, setTasks] = useState<RatsTaskRecord[]>([]);
  const [selectedKey, setSelectedKey] = useState("");
  const [detail, setDetail] = useState<{ status: Record<string, unknown>; events: Array<Record<string, unknown>>; logs: string; logCursor: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const requestSequence = useRef(0);
  const loadInFlight = useRef(false);
  const selectedKeyRef = useRef("");
  const eventHistory = useRef<Record<string, Array<Record<string, unknown>>>>({});
  const logHistory = useRef<Record<string, string>>({});
  const logCursors = useRef<Record<string, number>>({});
  const cancelledTasks = useRef(new Set<string>());
  /**
   * Provider the task list is narrowed to, or `"all"`.
   *
   * Kept in a ref as well because `load` reads it while choosing which task to
   * select, and `load` is rebuilt only when its own callbacks change.
   */
  const [providerFilter, setProviderFilter] = useState("all");
  const providerFilterRef = useRef("all");
  const selectTask = useCallback((key: string) => {
    selectedKeyRef.current = key;
    setSelectedKey(key);
  }, []);
  const retainTaskCacheKeys = useCallback((validKeys: Set<string>) => {
    for (const key of Object.keys(eventHistory.current)) {
      if (!validKeys.has(key)) delete eventHistory.current[key];
    }
    for (const key of Object.keys(logHistory.current)) {
      if (!validKeys.has(key)) delete logHistory.current[key];
    }
    for (const key of Object.keys(logCursors.current)) {
      if (!validKeys.has(key)) delete logCursors.current[key];
    }
    for (const key of cancelledTasks.current) {
      if (!validKeys.has(key)) cancelledTasks.current.delete(key);
    }
  }, []);

  const load = useCallback(async (foreground = false) => {
    if (loadInFlight.current) return;
    loadInFlight.current = true;
    const sequence = ++requestSequence.current;
    if (foreground) setLoading(true);
    try {
      const stateResponse = await window.reverie.request("ratsState", {});
      const nextState = stateResponse.rats;
      if (sequence !== requestSequence.current) return;
      setState(nextState);
      const connectedServices = nextState.services.filter((item) => item.connection === "connected" && item.sessionActive);
      if (!connectedServices.length) {
        retainTaskCacheKeys(new Set<string>());
        setTasks([]);
        selectTask("");
        setDetail(null);
        setError("");
        return;
      }
      const tasksResponse = await window.reverie.request("ratsTasks", {});
      const taskRecords = (Array.isArray(tasksResponse.tasks) ? tasksResponse.tasks : []) as RatsTaskRecord[];
      if (sequence !== requestSequence.current) return;
      retainTaskCacheKeys(new Set(taskRecords.map(taskKey)));
      const nextTasks = taskRecords.map((task) =>
        cancelledTasks.current.has(taskKey(task)) ? { ...task, cancelled: true } : task,
      );
      setTasks(nextTasks);
      const currentKey = selectedKeyRef.current;
      // Selection follows the visible list: a task hidden by the provider filter
      // must not stay selected, or the detail pane would describe a row the user
      // cannot see.
      const filter = providerFilterRef.current;
      const candidates = filter === "all"
        ? nextTasks
        : nextTasks.filter((task) => task.provider_id === filter);
      const nextKey = currentKey && candidates.some((task) => taskKey(task) === currentKey)
        ? currentKey
        : candidates[0] ? taskKey(candidates[0]) : "";
      selectTask(nextKey);
      if (!nextKey || !nextTasks.some((task) => taskKey(task) === nextKey)) {
        setDetail(null);
        setError("");
        return;
      }
      const task = nextTasks.find((item) => taskKey(item) === nextKey) as RatsTaskRecord;
      const eventCursor = Number(recordValue(task.status).next_cursor ?? task.cursor ?? 0) || 0;
      const logCursor = logCursors.current[nextKey] ?? 0;
      const [statusResult, eventsResult, logsResult] = await Promise.allSettled([
        window.reverie.request("ratsTaskStatus", { providerId: task.provider_id, serviceId: task.service_id, taskId: task.task_id, deadlineMs: 5_000 }),
        window.reverie.request("ratsTaskEvents", { providerId: task.provider_id, serviceId: task.service_id, taskId: task.task_id, cursor: eventCursor, limit: 32, deadlineMs: 5_000 }),
        window.reverie.request("ratsTaskLogs", { providerId: task.provider_id, serviceId: task.service_id, taskId: task.task_id, cursor: logCursor, limit: 8_192, deadlineMs: 5_000 }),
      ]);
      if (sequence !== requestSequence.current || selectedKeyRef.current !== nextKey) return;
      const failedResult = [statusResult, eventsResult, logsResult].find((result) => result.status === "rejected");
      if (failedResult?.status === "rejected") {
        setDetail(null);
        const reason = failedResult.reason;
        setError(reason instanceof Error ? reason.message : String(reason));
        return;
      }
      if (statusResult.status !== "fulfilled" || eventsResult.status !== "fulfilled" || logsResult.status !== "fulfilled") return;
      const statusResponse = statusResult.value;
      const eventsResponse = eventsResult.value;
      const logsResponse = logsResult.value;
      const status = statusResponse?.result ?? recordValue(task.status);
      const eventResult = eventsResponse?.result ?? {};
      const incomingEvents = Array.isArray(eventResult.events) ? eventResult.events as Array<Record<string, unknown>> : [];
      const previousEvents = [
        ...(eventHistory.current[nextKey] ?? []),
        ...(Array.isArray(task.events) ? task.events : []),
      ];
      const mergedEvents = [...previousEvents, ...incomingEvents].filter((event, index, all) => {
        const identity = `${String(event.sequence ?? "")}:${String(event.type ?? "")}:${String(event.timestamp_utc ?? "")}`;
        return all.findIndex((candidate) => `${String(candidate.sequence ?? "")}:${String(candidate.type ?? "")}:${String(candidate.timestamp_utc ?? "")}` === identity) === index;
      }).slice(-128);
      eventHistory.current[nextKey] = mergedEvents;
      const logResult = logsResponse?.result ?? {};
      const logText = String(logResult.text ?? "");
      if (logText) logHistory.current[nextKey] = appendTaskLogHistory(logHistory.current[nextKey] ?? "", logText);
      const nextLogCursor = Number(logResult.next_cursor ?? logCursor) || logCursor;
      logCursors.current[nextKey] = nextLogCursor;
      setDetail({ status: recordValue(status), events: mergedEvents, logs: logHistory.current[nextKey] ?? "", logCursor: nextLogCursor });
      setError("");
    } catch (loadError) {
      if (sequence === requestSequence.current) setError(loadError instanceof Error ? loadError.message : String(loadError));
    } finally {
      if (sequence === requestSequence.current) setLoading(false);
      loadInFlight.current = false;
    }
  }, [retainTaskCacheKeys, selectTask]);

  useEffect(() => {
    let stopped = false;
    let timer: number | null = null;
    const poll = async (foreground: boolean) => {
      await load(foreground);
      if (!stopped) timer = window.setTimeout(() => void poll(false), 1500);
    };
    void poll(true);
    return () => {
      stopped = true;
      if (timer !== null) window.clearTimeout(timer);
    };
  }, [load]);

  const providerRows = useMemo(() => rtpProviderStatuses(state, tasks), [state, tasks]);
  const visibleTasks = useMemo(
    () => providerFilter === "all" ? tasks : tasks.filter((task) => task.provider_id === providerFilter),
    [providerFilter, tasks],
  );
  const chooseProviderFilter = useCallback((providerId: string) => {
    providerFilterRef.current = providerId;
    setProviderFilter(providerId);
    selectTask("");
    setDetail(null);
    void load(true);
  }, [load, selectTask]);

  const selectedTask = visibleTasks.find((task) => taskKey(task) === selectedKey) ?? null;
  const status = detail?.status ?? recordValue(selectedTask?.status);
  const output = recordValue(status.output);
  const progressValue = typeof status.progress === "number" ? status.progress : typeof output.progress === "number" ? output.progress : null;
  const progress = progressValue !== null && Number.isFinite(progressValue)
    ? Math.max(0, Math.min(1, progressValue)) * 100
    : null;
  const connected = state?.services.filter((service) => service.connection === "connected" && service.sessionActive).length ?? 0;
  const liveProviders = providerRows.filter((row) => row.connected > 0).length;
  const activeTasks = visibleTasks.filter((task) => taskRunning(task, recordValue(task.status))).length;

  const cancel = useCallback(async () => {
    if (!selectedTask) return;
    const key = taskKey(selectedTask);
    setBusy(key);
    try {
      await window.reverie.request("ratsTaskCancel", {
        providerId: selectedTask.provider_id,
        serviceId: selectedTask.service_id,
        taskId: selectedTask.task_id,
        deadlineMs: 5_000,
      });
      cancelledTasks.current.add(key);
      await load(true);
    } catch (cancelError) {
      setError(cancelError instanceof Error ? cancelError.message : String(cancelError));
    } finally {
      setBusy("");
    }
  }, [load, selectedTask]);

  return (
    <div className="page-scroll rats-tasks-page">
      <PageHeader
        icon={<Clock3 size={20} />}
        title={t("RTP 任务")}
        description={t("实时查看每个已登记 RATS 提供者的连接状态，以及它们的任务、事件游标、日志和取消结果。")}
        action={<div className="header-action-row">
          {providerRows.length > 1 && <select aria-label={t("按提供者筛选任务")} value={providerFilter} onChange={(event) => chooseProviderFilter(event.target.value)}>
            <option value="all">{t("全部提供者")}</option>
            {providerRows.map((row) => <option key={row.providerId} value={row.providerId}>{row.providerId}</option>)}
          </select>}
          <button type="button" className="secondary-button" onClick={() => void load(true)} disabled={loading}><RefreshCw className={loading ? "spin" : ""} size={14} />{t("刷新")}</button>
        </div>}
      />
      <div className="tool-overview rats-task-overview">
        <div><Plug size={17} /><span>{t("在线提供者")}<strong>{liveProviders}/{providerRows.length}</strong></span></div>
        <div><Activity size={17} /><span>{t("已连接服务")}<strong>{connected}</strong></span></div>
        <div><Clock3 size={17} /><span>{t("活动任务")}<strong>{activeTasks}</strong></span></div>
        <div><FileText size={17} /><span>{t("事件记录")}<strong>{detail?.events.length ?? 0}</strong></span></div>
      </div>
      {error && <div className="page-loading error"><AlertCircle size={18} />{error}</div>}
      {/* Always rendered, connected or not: seeing that an authorized provider is
          offline is the whole point of a per-provider status board. */}
      <section className={`rtp-provider-panel ${preferences.rtpProviderDetails ? "expanded" : ""}`} aria-labelledby="rtp-provider-title">
        <div className="rats-task-panel-heading">
          <div><h2 id="rtp-provider-title">{t("提供者实时状态")}</h2><p>{t("列出全部已登记提供者（内置与自定义），每 1.5 秒刷新一次连接、会话与任务数。")}</p></div>
          {/* Opt-in, and remembered: the detail is several screens per provider,
              but a user who wants contract fields wants them every session. */}
          <label className="rtp-detail-toggle">
            <input
              type="checkbox"
              checked={preferences.rtpProviderDetails}
              onChange={(event) => updatePreferences({ rtpProviderDetails: event.target.checked })}
            />
            {t("显示详细信息")}
          </label>
          <span>{liveProviders}/{providerRows.length}</span>
        </div>
        <div className="rtp-provider-list">
          {providerRows.map((row) => (
            <div className="rtp-provider-entry" key={row.providerId}>
              <button
                type="button"
                className={`rtp-provider-row ${row.connection} ${providerFilter === row.providerId ? "active" : ""}`}
                aria-pressed={providerFilter === row.providerId}
                onClick={() => chooseProviderFilter(providerFilter === row.providerId ? "all" : row.providerId)}
              >
                <span className={`rats-task-dot ${row.connected ? "running" : row.connection === "absent" ? "" : "done"}`} />
                <span className="rtp-provider-identity">
                  <strong>{row.providerId}</strong>
                  <small>{[row.label, row.kinds].filter(Boolean).join(" · ") || t("暂无说明")}</small>
                </span>
                <span className="rtp-provider-origin">{row.origin === "builtin" ? t("内置") : row.origin === "custom" ? t("自定义") : t("未登记")}</span>
                <span className="rtp-provider-metrics">
                  <code>{t("rtp.providerServices", { connected: row.connected, total: row.services.length })}</code>
                  <code>{t("rtp.providerTools", { count: row.tools })}</code>
                  <code>{t("rtp.providerTasks", { count: row.tasks })}</code>
                </span>
                <span className={`rats-status ${row.connection === "absent" ? "" : row.connection}`}>{rtpProviderStatusLabel(row, t)}</span>
              </button>
              {preferences.rtpProviderDetails && <RtpProviderDetail row={row} t={t} />}
            </div>
          ))}
          {providerRows.length === 0 && <div className="rats-task-empty-inline">{t("核心还没有报告任何 RATS 提供者。")}</div>}
        </div>
        {providerRows.some((row) => row.error) && <div className="rtp-provider-errors">
          {providerRows.filter((row) => row.error).map((row) => (
            <div className="rats-inline-error" key={row.providerId}><AlertCircle size={14} />{row.providerId}: {row.error}</div>
          ))}
        </div>}
      </section>
      {connected === 0 && !loading ? (
        <div className="empty-panel rats-task-empty"><ShieldCheck size={28} /><strong>{t("尚未启用 RTP 服务")}</strong><span>{t("在 RATS 页面启用上面任意一个提供者的服务，它启动的长任务就会自动出现在这里。")}</span></div>
      ) : (
        <div className="rats-task-layout">
          <section className="rats-task-list-panel" aria-labelledby="rats-task-list-title">
            <div className="rats-task-panel-heading"><div><h2 id="rats-task-list-title">{t("任务列表")}</h2><p>{providerFilter === "all" ? t("每 1.5 秒从全部已连接服务同步状态") : t("rtp.taskListFiltered", { provider: providerFilter })}</p></div><span>{visibleTasks.length}</span></div>
            <div className="rats-task-list">
              {visibleTasks.map((task) => {
                const itemStatus = recordValue(task.status);
                const itemKey = taskKey(task);
                return <button type="button" className={`rats-task-row ${itemKey === selectedKey ? "active" : ""}`} key={itemKey} onClick={() => { selectTask(itemKey); setDetail(null); void load(true); }}>
                  <span className={`rats-task-dot ${taskRunning(task, itemStatus) ? "running" : "done"}`} />
                  <span className="rats-task-row-main"><strong>{task.tool || t("原生任务")}</strong><code><span className="rats-task-row-provider">{task.provider_id}</span>{task.task_id}</code></span>
                  <span className={`rats-status ${taskRunning(task, itemStatus) ? "connected" : "available"}`}>{taskStatusLabel(task, itemStatus, t)}</span>
                </button>;
              })}
              {!visibleTasks.length && <div className="rats-task-list-empty"><Clock3 size={20} /><span>{providerFilter === "all" ? t("暂无活动任务") : t("该提供者暂无任务")}</span><small>{t("由 AI 或工具调用启动的长任务会自动同步到这里。")}</small></div>}
            </div>
          </section>
          <section className="rats-task-detail" aria-labelledby="rats-task-detail-title">
            {!selectedTask ? <div className="rats-task-detail-empty"><Clock3 size={24} /><strong>{t("选择一个任务查看详情")}</strong></div> : <>
              <div className="rats-task-detail-header"><div><p>{t("RTP 任务详情")}</p><h2 id="rats-task-detail-title">{selectedTask.tool || t("原生任务")}</h2></div><div className="rats-task-detail-actions"><span className={`rats-status ${taskRunning(selectedTask, status) ? "connected" : "available"}`}>{taskStatusLabel(selectedTask, status, t)}</span>{taskRunning(selectedTask, status) && <button type="button" className="danger-button" onClick={() => void cancel()} disabled={busy === taskKey(selectedTask)}><Square size={13} />{t("取消任务")}</button>}</div></div>
              <div className="rats-task-meta"><div><span>{t("任务 ID")}</span><code>{selectedTask.task_id}</code></div><div><span>{t("提供者")}</span><code>{selectedTask.provider_id}</code></div><div><span>{t("事件游标")}</span><code>{String(status.next_cursor ?? selectedTask.cursor ?? 0)}</code></div><div><span>{t("截止时间")}</span><code>{String(selectedTask.deadline_msec ?? 0)} ms</code></div></div>
              {progress !== null && <div className="rats-task-progress"><div><span>{t("进度")}</span><strong>{Math.round(progress)}%</strong></div><div className="rats-task-progress-track"><span style={{ width: `${progress}%` }} /></div></div>}
              <div className="rats-task-detail-grid">
                <section className="rats-task-stream" aria-labelledby="rats-task-events-title"><div className="rats-task-subheading"><div><h3 id="rats-task-events-title">{t("版本化事件")}</h3><span>reverie.rtp.task/1</span></div><span>{detail?.events.length ?? 0}</span></div><div className="rats-task-events">{detail?.events.map((event, index) => <div className="rats-task-event" key={`${String(event.sequence ?? "")}:${String(event.type ?? "")}:${index}`}><div><strong>{String(event.type ?? t("事件"))}</strong><span>{String(event.timestamp_utc ?? event.timestamp ?? "")}</span></div><code>{event.sequence === undefined ? "—" : `#${String(event.sequence)}`}</code><pre>{JSON.stringify(event.payload ?? event.output ?? {}, null, 2)}</pre></div>)}{!detail?.events.length && <div className="rats-task-empty-inline">{t("等待事件")}</div>}</div></section>
                <section className="rats-task-stream" aria-labelledby="rats-task-logs-title"><div className="rats-task-subheading"><div><h3 id="rats-task-logs-title">{t("任务日志")}</h3><span>{t("实时增量读取")}</span></div><code>{detail?.logCursor ?? 0}</code></div><pre className="rats-task-log-output">{detail?.logs || t("等待日志")}</pre></section>
              </div>
            </>}
          </section>
        </div>
      )}
    </div>
  );
}

// Sits directly above the composer (not a centred modal) so the pending call and
// the input the user might answer it with share one field of view. Three
// actions: 拒绝 (deny), 我想额外说点 (message = deny this call + send text to the
// model), 同意 (allow). 同意 is two-tier: the primary button allows just this
// call (once) and a small adjacent entry allows the tool for the whole session.
function ApprovalPanel({ approval, resolve }: { approval: Record<string, unknown>; resolve: (decision: ApprovalDecision, message?: string) => void }) {
  const { t } = useI18n();
  const dialogRef = useRef<HTMLDivElement>(null);
  const [message, setMessage] = useState("");
  const [showReply, setShowReply] = useState(false);
  const [submitting,setSubmitting]=useState(false);
  const submit=(decision:ApprovalDecision,reply?:string)=>{if(submitting)return;setSubmitting(true);resolve(decision,reply);};
  useEffect(()=>{setSubmitting(false);setMessage("");setShowReply(false);},[approval.approval_id]);
  useDialogFocus(dialogRef);
  const risk = String(approval.risk ?? "").trim();
  const concerns = Array.isArray(approval.concerns) ? approval.concerns.map(String) : [];
  const reviewer = String(approval.review_source ?? "").trim();
  const riskLabel = risk ? risk : "";
  const riskClass = riskLabel ? `risk-badge risk-${riskLabel}` : "risk-badge";
  const panelClass = riskLabel ? `approval-panel risk-edge-${riskLabel}` : "approval-panel";
  return (
    <div ref={dialogRef} className={panelClass} role="alertdialog" aria-labelledby="approval-title" aria-describedby="approval-message" tabIndex={-1}>
      <div className="approval-header">
        <div className="confirm-icon"><ShieldCheck size={18} /></div>
        <div>
          <h2 id="approval-title">{t("工具请求更高权限")}</h2>
          <p>{t(String(approval.permission_mode === "strict" ? "Strict 模式：每次工具调用都需要你的批准。" : "Reverie 内核暂停执行，等待你的决定。"))}</p>
        </div>
      </div>
      <div className="approval-tool"><Wrench size={15} /><strong>{String(approval.tool ?? "tool")}</strong>{riskLabel && <span className={riskClass}>{riskLabel}</span>}</div>
      <p id="approval-message" className="approval-message">{t(String(approval.message ?? "此工具超出当前权限级别。"))}</p>
      <dl className="approval-scope">
        {approval.view_id != null && <><dt>{t("来源视图")}</dt><dd>{String(approval.view_title || approval.view_id)} · {String(approval.view_id)}</dd></>}
        <dt>{t("所属会话与运行")}</dt><dd>{String(approval.session_id || "—")} · {String(approval.run_id || "—")}</dd>
        <dt>{t("实际命令与目录")}</dt><dd><code>{String(approval.command || "—")}</code><br />{String(approval.cwd || approval.project_root || "未知")}</dd>
        <dt>{t("已知目标路径")}</dt><dd>{Array.isArray(approval.paths) && approval.paths.length ? approval.paths.map(String).join("\n") : t("未知或工具声明")}</dd>
        <dt>{t("网络范围")}</dt><dd>{t("未知或工具声明")}</dd>
      </dl>
      <details><summary>{t("参数与权限边界")}</summary><pre>{JSON.stringify(approval.arguments ?? {}, null, 2)}</pre><p>{t("软件工具权限不是操作系统沙箱；子进程仍使用当前用户权限。")}</p></details>
      {concerns.length > 0 && <div className="approval-concerns">{concerns.map((tag) => <span key={tag} className="concern-tag">{tag}</span>)}</div>}
      {reviewer && reviewer !== "policy" && <div className="approval-reviewer"><Sparkles size={12} />{t("审查")}: {reviewer}</div>}
      {showReply ? (
        <div className="approval-reply">
          <textarea autoFocus rows={2} value={message} onChange={(e) => setMessage(e.target.value)} placeholder={t("写给 Reverie，例如：先解释清楚再执行……（将拒绝本次调用）")} />
          <div className="approval-actions">
            <button type="button" className="secondary-button" onClick={() => setShowReply(false)}>{t("返回")}</button>
            <button type="button" className="primary-button" disabled={submitting || !message.trim()} onClick={() => submit("message", message.trim())}>{t("发送并拒绝本次")}</button>
          </div>
        </div>
      ) : (
        <div className="approval-actions">
          <button type="button" className="danger-button" disabled={submitting} onClick={() => submit("deny")}>{t("拒绝")}</button>
          <button type="button" className="secondary-button" onClick={() => setShowReply(true)}>{t("我想额外说点")}</button>
          <div className="approval-allow">
            <button type="button" className="primary-button" disabled={submitting} onClick={() => submit("once")}>{t("同意")}</button>
            {(!Array.isArray(approval.scopes) || approval.scopes.includes("session")) && <button type="button" className="approval-allow-session" disabled={submitting} onClick={() => submit("session")}>{t("本会话允许")}</button>}
          </div>
        </div>
      )}
    </div>
  );
}

function Toasts({ items, onDismiss }: { items: Toast[]; onDismiss: (id: number) => void }) {
  const { t } = useI18n();
  return <div className="toast-stack">{items.map((toast) => <div className={`toast ${toast.kind}`} role={toast.kind === "error" ? "alert" : "status"} key={toast.id}>{toast.kind === "success" ? <CheckCircle2 size={15} /> : toast.kind === "error" ? <AlertCircle size={20} /> : <Info size={15} />}<span>{toast.message}</span>{toast.kind === "error" && <button className="icon-button toast-dismiss" aria-label={t("关闭")} onClick={() => onDismiss(toast.id)}><X size={16} /></button>}</div>)}</div>;
}

export default function App() {
  const [state, setState] = useState<DesktopState | null>(null);
  const [desktopPaths, setDesktopPaths] = useState<DesktopPaths | null>(null);
  const [bootError, setBootError] = useState("");
  const [view, setView] = useState<ViewId>("chat");
  const [session, setSession] = useState<SessionState | null>(null);
  const [sessionBusy, setSessionBusy] = useState(false);
  const [workspaceReady, setWorkspaceReady] = useState(false);
  const [prompt, setPrompt] = useState("");
  const [running, setRunning] = useState(false);
  const [liveTurn, setLiveTurn] = useState<LiveTurn | null>(null);
  const runtimeViews = useRef(new Map<string, { live: LiveTurn | null; running: boolean; approval: Record<string, unknown> | null }>());
  const pendingLiveBatch = useRef<LiveTurnBatch>(emptyLiveTurnBatch());
  const liveBatchTimer = useRef<number | null>(null);
  const acceptLiveEvents = useRef(false);
  const [sidebarPreferenceCollapsed, setSidebarPreferenceCollapsed] = useState(() =>
    normalizeSidebarCollapsed(localStorage.getItem(SIDEBAR_COLLAPSED_STORAGE_KEY)),
  );
  const [compactViewport, setCompactViewport] = useState(() =>
    window.matchMedia(SIDEBAR_AUTO_COLLAPSE_QUERY).matches,
  );
  const [sidebarViewportOverride, setSidebarViewportOverride] = useState<boolean | null>(null);
  const sidebarCollapsed = resolveSidebarCollapsed(
    sidebarPreferenceCollapsed,
    compactViewport,
    sidebarViewportOverride,
  );
  const shellRef = useRef<HTMLDivElement>(null);
  const [layoutWidth, setLayoutWidth] = useState(0);
  const layoutReady = Boolean(state);
  useLayoutEffect(() => {
    const shell = shellRef.current;
    if (!shell) return;
    const measure = () => setLayoutWidth(shell.getBoundingClientRect().width);
    const observer = new ResizeObserver(measure); observer.observe(shell); measure();
    return () => observer.disconnect();
  }, [layoutReady]);
  /**
   * Width being dragged right now, which deliberately bypasses the preference
   * round-trip: persisting every pointer frame would queue an IPC call per
   * frame, and the reply would arrive behind the cursor and fight it.
   */
  const [paneWidthDraft, setPaneWidthDraft] = useState<{ sidebar?: number; inspector?: number }>({});
  const paneResizing = paneWidthDraft.sidebar !== undefined || paneWidthDraft.inspector !== undefined;
  const [modelPickerOpen, setModelPickerOpen] = useState(false);
  const [commandOpen, setCommandOpen] = useState(false);
  useEffect(() => {
    const open = () => setCommandOpen(true);
    window.addEventListener("reverie:commands", open);
    return () => window.removeEventListener("reverie:commands", open);
  }, []);
  const [sessionSearchOpen, setSessionSearchOpen] = useState(false);
  /** `null` while closed; `{ target: null }` to add; `{ target }` to edit in place. */
  const [standardModelForm, setStandardModelForm] = useState<{ target: { index: number; model: ModelRecord } | null } | null>(null);
  const [providerModal, setProviderModal] = useState<{ provider: CustomProviderRecord | null } | null>(null);
  const [contextLimitModal, setContextLimitModal] = useState<{ provider: CustomProviderRecord; model: CustomProviderModel } | null>(null);
  const [providerProbes, setProviderProbes] = useState<Record<string, ProviderProbe>>({});
  const [providerProbing, setProviderProbing] = useState(false);
  // Image-generation catalog is fetched lazily (its own bridge action), so it is
  // not part of DesktopState and lives here until the settings tab asks for it.
  const [imageModels, setImageModels] = useState<ImageModelSourcesState | null>(null);
  const [renameSessionTarget, setRenameSessionTarget] = useState<{ id: string; name: string } | null>(null);
  const [approval, setApproval] = useState<Record<string, unknown> | null>(null);
  const [contextUsage, setContextUsage] = useState<ContextUsage | null>(null);
  const contextBaselines = useRef(new Map<string, NonNullable<ContextUsage["api_baseline"]>>());
  const contextDirty = useRef(true);
  const contextRevision = useRef(0);
  const [mentionItems, setMentionItems] = useState<Array<Record<string, unknown>>>([]);
  const [mentionOpen, setMentionOpen] = useState(false);
  const [mentionLoading, setMentionLoading] = useState(false);
  const [mentionError, setMentionError] = useState("");
  const [attachments, setAttachments] = useState<ComposerAttachment[]>([]);
  const [draftError, setDraftError] = useState("");
  const [composerError, setComposerError] = useState("");
  const [controlStatus, setControlStatus] = useState("");
  const [streamSettingBusy, setStreamSettingBusy] = useState(false);
  const streamSettingPending = useRef(false);
  useEffect(() => () => readingPositions.clear(), []);
  const [sessionStates, setSessionStates] = useState<Record<string, string>>({});
  const [sendBehavior, setSendBehavior] = useState<"queue" | "steer">("queue");
  const [queue, setQueue] = useState<QueuedMessage[]>([]);
  const [queuePaused, setQueuePaused] = useState(true);
  const queueStarting = useRef(new Set<string>());
  const authorizedQueues = useRef(new Map<string, {projectRoot:string;sessionId:string}>());
  const draftOwner = useRef({ root: "", id: NEW_SESSION_DRAFT_ID });
  const [gitStatus, setGitStatus] = useState<GitWorkspaceStatus | null>(null);
  const [gitBusy, setGitBusy] = useState(false);
  const [confirmation, setConfirmation] = useState<{ title: string; message: string; label: string; danger?: boolean; action: () => void } | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [theme, setTheme] = useState<ThemePreference>(() => normalizeTheme(localStorage.getItem(THEME_STORAGE_KEY)));
  const [systemDark, setSystemDark] = useState(() => window.matchMedia("(prefers-color-scheme: dark)").matches);
  const [uiPreferences, setUiPreferences] = useState<UiPreferences>(DEFAULT_UI_PREFERENCES);
  const t = useMemo(
    () => (key: string, values?: Record<string, string | number>) => translate(uiPreferences.language, key, values),
    [uiPreferences.language],
  );
  const toastId = useRef(0);
  const sessionRequestSequence = useRef(0);
  const pendingSessionId = useRef("");
  const mentionRequestSequence = useRef(0);
  const initializeSequence = useRef(0);
  const gitStatusSequence = useRef(0);
  const themeRequestSequence = useRef(0);
  const uiPreferenceRequestSequence = useRef(0);
  const drafts = useRef<Record<string, string>>({});
  const sessionCache = useRef(new SessionCache());

  // Feeding the cache from the rendered session covers every path that can
  // produce one -- open, create, prompt, compact, fork, rewind -- so no call
  // site can forget to update it.
  useEffect(() => {
    if (session) sessionCache.current.set(session);
  }, [session]);

  // Auto-save the composer for the active conversation on every keystroke. The
  // in-memory `drafts` map is the fast path for same-session switches; the
  // localStorage mirror is what survives a crash or restart. Writing on each
  // change (no debounce) is deliberate: a debounced tail could be lost to a
  // hard kill, which is exactly the case this must not drop. Text typed before
  // a conversation exists parks under a placeholder id until the first send
  // mints the real session.
  const projectRoot = state?.workspace.project_root ?? "";
  draftOwner.current = { root: projectRoot, id: session?.id ?? NEW_SESSION_DRAFT_ID };
  useEffect(() => {
    setQueue(loadQueue(projectRoot, session?.id ?? NEW_SESSION_DRAFT_ID));
    setQueuePaused(!authorizedQueues.current.has(ownerKey(projectRoot, session?.id ?? NEW_SESSION_DRAFT_ID)));
    setComposerError("");
    setControlStatus("");
  }, [projectRoot, session?.id]);
  const updateQueue = useCallback((items: QueuedMessage[]) => {
    const owner = draftOwner.current;
    const error = saveQueue(owner.root, owner.id, items);
    if (error) { setComposerError(`${t("队列未保存")}: ${error}`); return false; }
    setQueue(items);
    return true;
  }, [t]);
  const refreshGitStatus = useCallback(async () => {
    const sequence = ++gitStatusSequence.current;
    try {
      const status = await window.reverie.gitStatus();
      if (sequence === gitStatusSequence.current) setGitStatus(status);
    } catch {
      if (sequence === gitStatusSequence.current) setGitStatus(null);
    }
  }, []);
  useEffect(() => {
    setGitStatus(null);
    if (projectRoot) void refreshGitStatus();
    window.addEventListener("focus", refreshGitStatus);
    const timer = window.setInterval(refreshGitStatus, 2500);
    return () => {
      gitStatusSequence.current += 1;
      window.removeEventListener("focus", refreshGitStatus);
      window.clearInterval(timer);
    };
  }, [projectRoot, refreshGitStatus]);
  useEffect(() => {
    const draftId = session?.id ?? NEW_SESSION_DRAFT_ID;
    drafts.current[draftId] = prompt;
    if (projectRoot && workspaceReady && !sessionBusy) {
      saveDraft(projectRoot, draftId, prompt);
      const error = saveStructuredDraft(projectRoot, draftId, { text: prompt, attachments });
      setDraftError(error ? `${t("草稿未保存")}: ${error}` : "");
    }
  }, [prompt, attachments, session?.id, projectRoot, workspaceReady, sessionBusy, t]);

  const toggleSidebar = useCallback(() => {
    if (compactViewport) {
      setSidebarViewportOverride((current) => !resolveSidebarCollapsed(
        sidebarPreferenceCollapsed,
        true,
        current,
      ));
      return;
    }
    setSidebarViewportOverride(null);
    setSidebarPreferenceCollapsed((current) => !current);
  }, [compactViewport, sidebarPreferenceCollapsed]);

  useEffect(() => {
    applyTheme(theme, systemDark);
    localStorage.setItem(THEME_STORAGE_KEY, theme);
  }, [systemDark, theme]);

  useEffect(() => {
    applyUiPreferences(uiPreferences);
  }, [uiPreferences]);

  useEffect(() => {
    localStorage.setItem(SIDEBAR_COLLAPSED_STORAGE_KEY, String(sidebarPreferenceCollapsed));
  }, [sidebarPreferenceCollapsed]);

  useEffect(() => {
    const media = window.matchMedia(SIDEBAR_AUTO_COLLAPSE_QUERY);
    const updateCompactViewport = (event: MediaQueryListEvent) => {
      setCompactViewport(event.matches);
      setSidebarViewportOverride(null);
    };
    media.addEventListener("change", updateCompactViewport);
    return () => media.removeEventListener("change", updateCompactViewport);
  }, []);

  useEffect(() => {
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const updateSystemTheme = (event: MediaQueryListEvent) => setSystemDark(event.matches);
    media.addEventListener("change", updateSystemTheme);
    const stopAppearanceEvents = window.reverie.onAppearance((appearance) => {
      setTheme(normalizeTheme(appearance.theme));
      setSystemDark(appearance.resolved === "dark");
    });
    const requestSequence = themeRequestSequence.current;
    void window.reverie.appearance().then((appearance) => {
      if (requestSequence !== themeRequestSequence.current) return;
      setTheme(normalizeTheme(appearance.theme));
      setSystemDark(appearance.resolved === "dark");
    });
    const preferenceSequence = uiPreferenceRequestSequence.current;
    void window.reverie.uiPreferences().then((preferences) => {
      if (preferenceSequence !== uiPreferenceRequestSequence.current) return;
      setUiPreferences(normalizeUiPreferences(preferences));
    });
    return () => {
      media.removeEventListener("change", updateSystemTheme);
      stopAppearanceEvents();
    };
  }, []);

  const toast = useCallback((message: string, kind: Toast["kind"] = "info") => {
    const id = ++toastId.current;
    setToasts((items) => [...items, { id, kind, message }]);
    window.setTimeout(() => setToasts((items) => items.filter((item) => item.id !== id)), kind === "error" ? 12000 : 3600);
  }, []);

  const changeTheme = useCallback((nextTheme: ThemePreference) => {
    const previousTheme = theme;
    const requestSequence = ++themeRequestSequence.current;
    setTheme(nextTheme);
    void window.reverie.setAppearance(nextTheme).then((appearance) => {
      if (requestSequence !== themeRequestSequence.current) return;
      setTheme(normalizeTheme(appearance.theme));
      setSystemDark(appearance.resolved === "dark");
    }).catch((error) => {
      if (requestSequence !== themeRequestSequence.current) return;
      setTheme(previousTheme);
      toast(error instanceof Error ? error.message : String(error), "error");
    });
  }, [theme, toast]);

  const updateUiPreferences = useCallback((patch: Partial<UiPreferences>) => {
    const requestSequence = ++uiPreferenceRequestSequence.current;
    setUiPreferences((current) => normalizeUiPreferences({ ...current, ...patch }));
    void window.reverie.setUiPreferences(patch).then((preferences) => {
      if (requestSequence !== uiPreferenceRequestSequence.current) return;
      setUiPreferences(normalizeUiPreferences(preferences));
    }).catch((error) => {
      if (requestSequence !== uiPreferenceRequestSequence.current) return;
      void window.reverie.uiPreferences().then((preferences) => setUiPreferences(normalizeUiPreferences(preferences)));
      toast(error instanceof Error ? error.message : String(error), "error");
    });
  }, [toast]);

  const setWorkbenchOpen = useCallback((inspectorOpen: boolean) => updateUiPreferences({ inspectorOpen }), [updateUiPreferences]);
  const desiredSidebarWidth = paneWidthDraft.sidebar ?? uiPreferences.sidebarWidth;
  const desiredInspectorWidth = paneWidthDraft.inspector ?? uiPreferences.inspectorWidth;
  const sidebarWidth = layoutWidth && !compactViewport
    ? Math.min(desiredSidebarWidth, Math.max(SIDEBAR_MIN_WIDTH, paneDragLimit(layoutWidth, uiPreferences.inspectorOpen ? INSPECTOR_MIN_WIDTH : 0, SIDEBAR_MAX_WIDTH))) : desiredSidebarWidth;
  const inspectorWidth = layoutWidth
    ? Math.min(desiredInspectorWidth, compactViewport ? Math.max(INSPECTOR_MIN_WIDTH, layoutWidth - 48) : Math.max(INSPECTOR_MIN_WIDTH, paneDragLimit(layoutWidth, sidebarCollapsed ? 0 : sidebarWidth, INSPECTOR_MAX_WIDTH))) : desiredInspectorWidth;
  const commitSidebarWidth = useCallback((width: number) => {
    setPaneWidthDraft((current) => ({ ...current, sidebar: undefined }));
    updateUiPreferences({ sidebarWidth: width });
  }, [updateUiPreferences]);
  const commitInspectorWidth = useCallback((width: number) => {
    setPaneWidthDraft((current) => ({ ...current, inspector: undefined }));
    updateUiPreferences({ inspectorWidth: width });
  }, [updateUiPreferences]);
  const previewSidebarWidth = useCallback((width: number) => {
    setPaneWidthDraft((current) => (current.sidebar === width ? current : { ...current, sidebar: width }));
  }, []);
  const previewInspectorWidth = useCallback((width: number) => {
    setPaneWidthDraft((current) => (current.inspector === width ? current : { ...current, inspector: width }));
  }, []);

  const selectBackground = useCallback(async () => {
    try {
      const preferences = await window.reverie.selectBackground();
      if (preferences) {
        setUiPreferences(normalizeUiPreferences(preferences));
        toast(t("工作区背景已更新"), "success");
      }
    } catch (error) {
      toast(error instanceof Error ? error.message : String(error), "error");
    }
  }, [t, toast]);

  const clearBackground = useCallback(async () => {
    try {
      const preferences = await window.reverie.clearBackground();
      setUiPreferences(normalizeUiPreferences(preferences));
      toast(t("工作区背景已清除"), "success");
    } catch (error) {
      toast(error instanceof Error ? error.message : String(error), "error");
    }
  }, [t, toast]);

  const initialize = useCallback(async (projectRoot?: string) => {
    const requestSequence = ++initializeSequence.current;
    const sessionSequence = ++sessionRequestSequence.current;
    pendingSessionId.current = "";
    setSessionBusy(false);
    setWorkspaceReady(false);
    setBootError("");
    // Transcripts are per project, and switching projects re-enters this path.
    sessionCache.current.clear();
    try {
      const [paths, preferences] = await Promise.all([
        window.reverie.paths(),
        window.reverie.uiPreferences(),
      ]);
      if (requestSequence !== initializeSequence.current) return;
      setDesktopPaths(paths);
      setUiPreferences(normalizeUiPreferences(preferences));
      const response = await window.reverie.request("initialize", {
        projectRoot: projectRoot ?? paths.projectRoot,
        deferPayloads: true,
      });
      if (requestSequence !== initializeSequence.current) return;
      let nextState = response.state;
      let nextSession: SessionState | null = null;
      // Restore this project's saved composer drafts before painting a session,
      // so the persistence effect and the prompt restore below both read the
      // text that survived the last quit. Drafts are keyed per project, so a
      // fresh hydrate replaces whatever the previous workspace left in memory.
      const resolvedRoot = nextState.workspace.project_root;
      drafts.current = loadProjectDrafts(resolvedRoot);
      // Paint the workspace shell from the compact bootstrap response before
      // loading a transcript or the large provider/tool catalogs.
      setState(nextState);
      setSession(null);
      const currentId = nextState.sessions.current_session_id || nextState.sessions.items[0]?.id;
      if (currentId) {
        const sessionResponse = await window.reverie.request("getSession", { sessionId: currentId });
        if (requestSequence !== initializeSequence.current) return;
        nextSession = sessionResponse.session;
        nextState = { ...nextState, sessions: sessionResponse.sessions };
        setState(nextState);
        setSession(nextSession);
      }
      // Re-open the composer exactly where it was left for the restored session
      // (or the pre-session placeholder when the workspace has none yet).
      const restoredDraft = loadStructuredDraft(resolvedRoot, nextSession?.id ?? NEW_SESSION_DRAFT_ID);
      setPrompt(restoredDraft.text);
      setAttachments(restoredDraft.attachments);
      if (response.deferred === true) {
        try {
          const hydrated = await window.reverie.request("getState", {});
          if (requestSequence !== initializeSequence.current) return;
          nextState = hydrated.state;
        } catch (error) {
          if (requestSequence !== initializeSequence.current) return;
          toast(error instanceof Error ? error.message : String(error), "error");
        }
      }
      setState((current) => current && sessionSequence !== sessionRequestSequence.current
        ? { ...nextState, sessions: current.sessions }
        : nextState);
      if (sessionSequence === sessionRequestSequence.current) setSession(nextSession);
      setWorkspaceReady(true);
    } catch (error) {
      if (requestSequence === initializeSequence.current) setBootError(error instanceof Error ? error.message : String(error));
    }
  }, [toast]);

  useEffect(() => { void initialize(); }, [initialize]);

  const retryInitialization = useCallback(async () => {
    // A timed-out initialize can still be running inside the serialized core
    // bridge. Restart it before retrying so the next request is not queued
    // behind the stale one.
    if (/timed out: initialize\b/.test(bootError)) {
      await window.reverie.cancel().catch(() => undefined);
    }
    await initialize();
  }, [bootError, initialize]);

  useEffect(() => {
    const contextEngine = state?.workspace.context_engine;
    if (!state || (contextEngine?.ready && !contextEngine.indexing)) return;
    let cancelled = false;
    const timer = window.setTimeout(async () => {
      try {
        const response = await window.reverie.request("getContextStatus", {});
        if (cancelled) return;
        const nextContext = response.context_engine;
        setState((current) => current ? {
          ...current,
          workspace: { ...current.workspace, index_ready: Boolean(nextContext?.ready), context_engine: nextContext },
        } : current);
      } catch {
        // Context status is advisory; initialization and prompts remain usable.
      }
    }, 900);
    return () => { cancelled = true; window.clearTimeout(timer); };
  }, [state]);

  const flushLiveBatch = useCallback(() => {
    liveBatchTimer.current = null;
    const batch = pendingLiveBatch.current;
    pendingLiveBatch.current = emptyLiveTurnBatch();
    if (!batch.assistantText && !batch.reasoningText && batch.events.length === 0) return;
    setLiveTurn((current) => current ? mergeLiveTurnBatch(current, batch) : current);
  }, []);

  const resetLiveBatch = useCallback(() => {
    if (liveBatchTimer.current !== null) {
      window.clearTimeout(liveBatchTimer.current);
      liveBatchTimer.current = null;
    }
    pendingLiveBatch.current = emptyLiveTurnBatch();
  }, []);

  useEffect(() => {
    const unsubscribe = window.reverie.onEvent((message) => {
      if (message.type === "desktop.preferences") {
        setUiPreferences(current => normalizeUiPreferences({ ...current, ...asRecord(message.preferences) }));
        return;
      }
      const event = asRecord(message.event);
      const type = String(event.type ?? "");
      if (message.type === "executors.changed") {
        const entries = (message.entries || []) as Array<{ projectRoot: string; sessionId: string; state: string; reason: string }>;
        setSessionStates(current => { const next = { ...current }; for (const entry of entries) next[ownerKey(entry.projectRoot, entry.sessionId)] = entry.state === "queued" ? `queued: ${entry.reason}` : "running"; return next; });
        return;
      }
      const eventOwner = ownerKey(String(event.project_root || draftOwner.current.root), String(event.session_id || draftOwner.current.id));
      const currentOwner = ownerKey(draftOwner.current.root, draftOwner.current.id);
      const runtime = runtimeViews.current.get(eventOwner);
      if (type === "view.run") {
        const active = event.state === "running";
        if (active) runtimeViews.current.set(eventOwner, { running: true, live: null, approval: null });
        else if (runtime) { runtime.running = false; runtime.approval = null; }
        setSessionStates(current => ({ ...current, [eventOwner]: active ? "running" : "" }));
        if (eventOwner === currentOwner) { setRunning(active); setApproval(null); acceptLiveEvents.current = active; }
        return;
      }
      if (type === "approval.request" && event.view_id && runtime) runtime.approval = event;
      if (type === "run.started" && typeof event.history_message_count === "number") {
        if (runtime?.live) runtime.live = { ...runtime.live, historyMessageCount: event.history_message_count };
        if (eventOwner === currentOwner) setLiveTurn(current => current ? { ...current, historyMessageCount: event.history_message_count as number } : current);
        return;
      }
      if (type === "context.usage") {
        const usage = event.usage as ContextUsage;
        if (usage.api_baseline) contextBaselines.current.set(eventOwner, usage.api_baseline);
        if (eventOwner === currentOwner) {
          contextRevision.current += 1;
          contextDirty.current = true;
          setContextUsage(usage);
        }
        return;
      }
      if (runtime?.live) {
        const saved = emptyLiveTurnBatch();
        if (type === "assistant.delta") saved.assistantText = String(event.text || "");
        else if (type === "reasoning.delta") saved.reasoningText = String(event.text || "");
        else if (type === "ui.event") saved.events.push(asRecord(event.event));
        else if (type === "approval.request" || type === "run.auto_followup") saved.events.push(event);
        runtime.live = mergeLiveTurnBatch(runtime.live, saved);
        if (type === "approval.request") { runtime.approval = event; setSessionStates(current => ({ ...current, [eventOwner]: "approval" })); }
      }
      if (eventOwner !== currentOwner) return;
      if (runtime?.running) acceptLiveEvents.current = true;
      if (!acceptLiveEvents.current) return;
      if (type === "run.steer") {
        setControlStatus(event.status === "received" ? t("当前运行已接收补充") : t("等待安全点接收补充"));
        return;
      }
      if (type === "run.control") {
        setControlStatus(t(String(event.state === "stopping" ? "正在停止，等待当前操作结束" : event.state === "paused" ? "已在工具边界暂停" : event.state === "waiting_pause" ? "等待工具边界暂停" : "运行中")));
        return;
      }
      if (type === "approval.request") {
        setApproval(event);
        setSessionStates(current => ({ ...current, [ownerKey(draftOwner.current.root, draftOwner.current.id)]: "approval" }));
        // Raise a background-only OS toast in Reverie's name so a user who has
        // tabbed away still learns the kernel is paused waiting on them. When the
        // window is focused, main.ts drops it -- the in-app panel is enough.
        // The owning main-process executor persists and deduplicates notifications.
      }

      const batch = pendingLiveBatch.current;
      if (type === "assistant.delta") {
        const text = String(event.text ?? "");
        batch.assistantText += text;
        batch.ordered?.push({ kind: "assistant", text });
      }
      else if (type === "reasoning.delta") {
        const text = String(event.text ?? "");
        batch.reasoningText += text;
        batch.ordered?.push({ kind: "reasoning", text });
      }
      else if (type === "ui.event") {
        const inner = asRecord(event.event);
        // The Thinking Tool's deliberation arrives as a tool call's arguments, not
        // as reasoning deltas. Show it as reasoning -- which is what it is -- so it
        // does not sit unread in the activity feed. The terminal likewise keeps
        // think calls out of its running-tools footer.
        //
        // `encode_stream_event` stores the kind under `event`; the activity feed's
        // own events use `type`, so accept either.
        const innerType = String(inner.event ?? inner.type ?? "").trim().toLowerCase();
        const thinking = innerType === "tool_start" && isThinkTool(inner.tool_name)
          ? thinkToolText(inner.arguments)
          : "";
        if (thinking) {
          batch.reasoningText += `${batch.reasoningText ? "\n\n" : ""}${thinking}`;
          batch.ordered?.push({ kind: "reasoning", text: thinking });
        }
        else if (isViewEventRecord(inner)) {
          // A kernel-minted view announcement becomes its own timeline segment,
          // never an activity row. The event carries only an opaque handle; the
          // bytes are fetched later through getView, so a well-formed forgery in
          // model text resolves to nothing. A malformed shape (parse -> null)
          // falls back to an ordinary activity row so nothing is dropped.
          const parsed = parseViewEvent(inner);
          if (parsed) batch.ordered?.push({ kind: "view", view: toViewSegment(parsed) });
          else {
            batch.events.push(inner);
            batch.ordered?.push({ kind: "activity", event: inner });
          }
        }
        else {
          batch.events.push(inner);
          batch.ordered?.push({ kind: "activity", event: inner });
        }
      }
      else if (type === "run.auto_followup" || type === "approval.request") {
        batch.events.push(event);
        batch.ordered?.push({ kind: "activity", event });
      }
      else return;

      if (liveBatchTimer.current === null) {
        liveBatchTimer.current = window.setTimeout(flushLiveBatch, LIVE_STREAM_RENDER_INTERVAL_MS);
      }
    });
    return () => {
      unsubscribe();
      resetLiveBatch();
    };
  }, [flushLiveBatch, resetLiveBatch, t]);

  useEffect(() => {
    const shortcuts = (event: globalThis.KeyboardEvent) => {
      const modifier = event.ctrlKey || event.metaKey;
      if (modifier && event.key.toLowerCase() === "k") { event.preventDefault(); setCommandOpen(true); }
      if (modifier && event.key.toLowerCase() === "n") { event.preventDefault(); void createSession(); }
      if (modifier && event.key.toLowerCase() === "f") { event.preventDefault(); setSessionSearchOpen(true); }
      if (modifier && event.key.toLowerCase() === "b") {
        event.preventDefault();
        if (event.shiftKey) updateUiPreferences({ inspectorOpen: !uiPreferences.inspectorOpen });
        else toggleSidebar();
      }
      if (event.key === "Escape") {
        setModelPickerOpen(false);
        setCommandOpen(false);
        setSessionSearchOpen(false);
        setStandardModelForm(null);
        setRenameSessionTarget(null);
        setConfirmation(null);
        mentionRequestSequence.current += 1;
        setMentionLoading(false);
        setMentionOpen(false);
      }
    };
    window.addEventListener("keydown", shortcuts);
    return () => window.removeEventListener("keydown", shortcuts);
  });

  const contextSnapshot = useRef<Record<string, unknown>>({});
  const contextOwner = ownerKey(projectRoot, session?.id || NEW_SESSION_DRAFT_ID);
  const contextModel = JSON.stringify([state?.models.active_source, state?.models.active_model, state?.models.sources.find(source => source.id === "custom")?.custom_providers?.find(provider => provider.active)?.id]);
  useEffect(() => {
    contextBaselines.current.clear();
    contextRevision.current += 1;
    contextDirty.current = true;
  }, [contextModel]);
  contextSnapshot.current = {
    ...(session?.id ? { sessionId: session.id } : {}),
    draftText: prompt,
    attachments: attachments.filter(item => !item.status || item.status === "ready"),
    liveAssistantText: running ? liveTurn?.assistantText || "" : "",
    apiBaseline: contextBaselines.current.get(contextOwner),
  };
  useEffect(() => {
    setContextUsage(null);
    contextRevision.current += 1;
    contextDirty.current = true;
  }, [projectRoot, session?.id, state?.workspace.active_model]);
  useEffect(() => {
    contextDirty.current = true;
  }, [session?.messages, prompt, attachments, liveTurn?.assistantText, liveTurn?.events, running]);
  useEffect(() => {
    if (!workspaceReady || sessionBusy || !state?.workspace.active_model) return;
    let cancelled = false;
    let inFlight = false;
    // Throttle rather than debounce: continuous typing/streaming must keep updating.
    const timer = window.setInterval(async () => {
      if (!contextDirty.current || inFlight) return;
      contextDirty.current = false;
      inFlight = true;
      const revision = contextRevision.current;
      try {
        const response = await window.reverie.request("getContextUsage", contextSnapshot.current);
        if (!cancelled && revision === contextRevision.current) setContextUsage(response.usage ?? null);
      } catch {
        if (!cancelled && revision === contextRevision.current) setContextUsage(null);
      } finally {
        inFlight = false;
      }
    }, 250);
    return () => { cancelled = true; window.clearInterval(timer); };
  }, [workspaceReady, projectRoot, session?.id, sessionBusy, state?.workspace.active_model]);

  const openSession = useCallback(async (id: string) => {
    // Re-selecting the conversation already in view is just a jump back to its
    // chat content, so honour it even mid-run: without this, clicking (or
    // double-clicking) the active conversation while parked on Settings or any
    // other view did nothing. Switching to a different session still waits for
    // the current turn, whose live output belongs to the session on screen.
    if ((id === session?.id && !pendingSessionId.current) || id === pendingSessionId.current) {
      setView("chat");
      return;
    }
    pendingSessionId.current = id;
    resetLiveBatch();
    if (session) drafts.current[session.id] = prompt;
    const requestSequence = ++sessionRequestSequence.current;
    // A transcript already read in this window cannot have changed unless this
    // window changed it, so paint it now and let the core reconcile behind us.
    // Without this the chat area shows a spinner on every switch, including the
    // trip back to a session the user just left.
    const cached = sessionCache.current.get(id);
    if (cached) {
      // `activeSessionId` prefers the rendered session, so this alone moves the
      // sidebar highlight -- patching `state.sessions` too would re-render every
      // consumer of `state` for a value the arriving response overwrites anyway.
      setSession(cached);
      setView("chat");
      setLiveTurn(runtimeViews.current.get(ownerKey(projectRoot, id))?.live ?? null);
      setPrompt(drafts.current[id] ?? "");
      const restoredDraft = loadStructuredDraft(projectRoot, id);
      setPrompt(restoredDraft.text);
      setAttachments(restoredDraft.attachments);
      setMentionOpen(false);
      setSessionBusy(false);
    } else {
      setSessionBusy(true);
    }
    try {
      const response = await window.reverie.request("getSession", { sessionId: id });
      if (requestSequence !== sessionRequestSequence.current) return;
      const nextSession = cached?.revision && cached.revision === response.session.revision
        ? cached
        : response.session;
      setSession(nextSession);
      setState((current) => current ? { ...current, sessions: response.sessions, skills: response.skills ?? current.skills } : current);
      setView("chat");
      setLiveTurn(runtimeViews.current.get(ownerKey(projectRoot, id))?.live ?? null);
      // The draft was already restored for the optimistic paint; re-applying it
      // here would discard anything typed while the request was in flight.
      if (!cached) {
        setPrompt(drafts.current[nextSession.id] ?? "");
        const restoredDraft = loadStructuredDraft(projectRoot, nextSession.id);
        setPrompt(restoredDraft.text);
        setAttachments(restoredDraft.attachments);
        setMentionOpen(false);
      }
    } catch (error) {
      if (requestSequence === sessionRequestSequence.current) toast(error instanceof Error ? error.message : String(error), "error");
    } finally {
      if (requestSequence === sessionRequestSequence.current) {
        pendingSessionId.current = "";
        setSessionBusy(false);
      }
    }
  }, [prompt, running, session, projectRoot, toast, resetLiveBatch]);

  const createSession = useCallback(async (force = false) => {
    if (sessionBusy) return;
    if (!force && !running && session && sessionIsEmpty(session) && !prompt.trim() && !attachments.length) {
      setView("chat");
      return;
    }
    if (session) drafts.current[session.id] = prompt;
    const requestSequence = ++sessionRequestSequence.current;
    setSessionBusy(true);
    try {
      const response = await window.reverie.request("createSession", {});
      if (requestSequence !== sessionRequestSequence.current) return;
      const nextSession = response.session;
      setSession(nextSession);
      setState((current) => current ? { ...current, sessions: response.sessions, skills: response.skills ?? current.skills } : current);
      setView("chat");
      setLiveTurn(null);
      setPrompt(drafts.current[nextSession.id] ?? "");
      const restoredDraft = loadStructuredDraft(projectRoot, nextSession.id);
      setPrompt(restoredDraft.text);
      setAttachments(restoredDraft.attachments);
      setMentionOpen(false);
    } catch (error) {
      if (requestSequence === sessionRequestSequence.current) toast(error instanceof Error ? error.message : String(error), "error");
    } finally {
      if (requestSequence === sessionRequestSequence.current) setSessionBusy(false);
    }
  }, [prompt, attachments.length, running, session, sessionBusy, projectRoot, toast]);

  useEffect(() => {
    const runtime = runtimeViews.current.get(ownerKey(projectRoot, session?.id ?? NEW_SESSION_DRAFT_ID));
    setRunning(runtime?.running ?? false);
    setLiveTurn(runtime?.live ?? null);
    setApproval(runtime?.approval ?? null);
    acceptLiveEvents.current = runtime?.running ?? false;
    setControlStatus("");
    setComposerError("");
    if (session) setSessionStates(current => ({ ...current, [ownerKey(projectRoot, session.id)]: runtime?.running ? current[ownerKey(projectRoot,session.id)] || "running" : "" }));
  }, [projectRoot, session?.id]);

  const compactContext = useCallback(async (focus = "") => {
    if (running || sessionBusy || !state) return;
    const requestSequence = ++sessionRequestSequence.current;
    setSessionBusy(true);
    try {
      let activeSession = session;
      if (!activeSession) {
        const created = await window.reverie.request("createSession", {});
        if (requestSequence !== sessionRequestSequence.current) return;
        activeSession = created.session;
        setSession(activeSession);
        setState((current) => current ? { ...current, sessions: created.sessions, skills: created.skills ?? current.skills } : current);
      }
      const response = await window.reverie.request("compactContext", {
        sessionId: activeSession.id,
        focus: focus || undefined,
        projectRoot: state.workspace.project_root,
      });
      if (requestSequence !== sessionRequestSequence.current) return;
      setSession(response.session);
      setState((current) => current ? {
        ...current,
        sessions: response.sessions,
        recovery: response.recovery,
        workspace: { ...current.workspace, context_engine: response.context_engine },
      } : current);
      setMentionItems([]);
      setMentionOpen(false);
      toast(response.message, "success");
    } catch (error) {
      if (requestSequence === sessionRequestSequence.current) toast(error instanceof Error ? error.message : String(error), "error");
    } finally {
      if (requestSequence === sessionRequestSequence.current) setSessionBusy(false);
    }
  }, [running, session, sessionBusy, state, toast]);

  const skillsState = state?.skills;
  const pinnedSkills = useMemo(() => skillsState?.pinned.names ?? [], [skillsState]);
  const unresolvedSkills = useMemo(() => skillsState?.pinned.unresolved ?? [], [skillsState]);

  const refreshSkills = useCallback(async () => {
    try {
      const response = await window.reverie.request("refreshSkills", {});
      setState((current) => current ? { ...current, skills: response.skills } : current);
      toast(t("技能目录已刷新"), "success");
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [t, toast]);

  // Pinning is session state on the core side, so every mutation answers with the
  // whole pin set: the composer chip and the Skills page can never drift apart.
  const pinSkill = useCallback(async (name: string) => {
    const owner = { ...draftOwner.current };
    try {
      const response = await window.reverie.request("pinSkill", { skill: name });
      if (owner.root !== draftOwner.current.root || owner.id !== draftOwner.current.id) return false;
      setState((current) => current ? { ...current, skills: response.skills } : current);
      if (response.status === "full") {
        toast(t("skill.pin.full", { max: String(response.skills.pinned.max) }), "error");
      } else if (response.status === "missing") {
        toast(t("skill.pin.missing", { name }), "error");
      } else if (response.status === "already") {
        toast(t("skill.pin.already", { name: response.name }), "info");
      } else {
        toast(t("skill.pin.done", { name: response.name }), "success");
      }
      return response.status === "pinned" || response.status === "already";
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); return false; }
  }, [t, toast]);

  const unpinSkill = useCallback(async (name: string) => {
    try {
      const response = await window.reverie.request("unpinSkill", { skill: name });
      setState((current) => current ? { ...current, skills: response.skills } : current);
      if (response.status === "missing") toast(t("skill.pin.missing", { name }), "error");
      else toast(t("skill.unpin.done", { name: response.name }), "success");
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [t, toast]);

  const clearPinnedSkills = useCallback(async () => {
    try {
      const response = await window.reverie.request("clearPinnedSkills", {});
      setState((current) => current ? { ...current, skills: response.skills } : current);
      toast(t("skill.pin.cleared"), "success");
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [t, toast]);

  const updateSetting = useCallback(async (key: string, value: unknown) => {
    const outputMode = key === "stream_responses";
    if (outputMode && streamSettingPending.current) return false;
    const previous = state?.settings.items.find(item => item.key === key)?.value;
    if (outputMode) {
      streamSettingPending.current = true; setStreamSettingBusy(true);
      setState(current => current ? { ...current, settings: { ...current.settings, items: current.settings.items.map(item => item.key === key ? { ...item, value } : item) } } : current);
    }
    try {
      const response = await window.reverie.request("setSetting", { key, value });
      if (response.success === false) throw new Error(String(response.message ?? t("设置未保存")));
      setState((current) => current ? { ...current, settings: response.settings, models: response.models ?? current.models, workspace: response.workspace ?? current.workspace } : current);
      if (!outputMode) toast(t("设置已保存"), "success");
      return true;
    } catch (error) {
      if (outputMode) setState(current => current ? { ...current, settings: { ...current.settings, items: current.settings.items.map(item => item.key === key ? { ...item, value: previous } : item) } } : current);
      toast(error instanceof Error ? error.message : String(error), "error"); return false;
    }
    finally { if (outputMode) { streamSettingPending.current = false; setStreamSettingBusy(false); } }
  }, [state?.settings, t, toast]);

  // Runs one turn end to end. Split out of sendPrompt so a mid-stream interrupt
  // can reuse the exact same path after cancelling the in-flight turn. Assumes
  // the composer control commands (/skill, /compact) have already been handled
  // and the prompt slot cleared by the caller.
  const runPromptText = useCallback(async (text: string, resume = false, inputAttachments: ComposerAttachment[] = [], runType = "prompt", queuedOwner?: {projectRoot:string;sessionId:string}, onResult?: (output:string)=>void) => {
    const activeState = state;
    const runRoot = queuedOwner?.projectRoot || projectRoot;
    const runSessionId = queuedOwner?.sessionId || session?.id || NEW_SESSION_DRAFT_ID;
    const startsInView = ownerKey(draftOwner.current.root,draftOwner.current.id)===ownerKey(runRoot,runSessionId);
    if (!activeState || streamSettingPending.current || (resume && !session)) return false;
    // A cached transcript is usable while its read reconciles. Once a turn
    // starts, an older read must not clear that turn's live output.
    if (startsInView) sessionRequestSequence.current += 1;
    if (startsInView) pendingSessionId.current = "";
    if (startsInView) setRunning(true);
    setSessionStates(current => ({ ...current, [ownerKey(runRoot, runSessionId)]: "running" }));
    if (startsInView) { setComposerError(""); setControlStatus(""); resetLiveBatch(); acceptLiveEvents.current = true; }
    const runtime = { live: { userText: resume ? "" : text, historyMessageCount: startsInView ? session?.messages.length ?? 0 : undefined, attachments: resume ? [] : inputAttachments.map(item => ({ ...item })), resumed: resume, assistantText: "", reasoningText: "", events: [], segments: [], error: "", startedAt: Date.now() } as LiveTurn | null, running: true, approval: null as Record<string, unknown> | null };
    let runtimeKey = ownerKey(runRoot, runSessionId);
    runtimeViews.current.set(runtimeKey, runtime);
    if (startsInView) setLiveTurn(runtime.live);
    const ownsView = () => ownerKey(draftOwner.current.root, draftOwner.current.id) === runtimeKey && runtimeViews.current.get(runtimeKey) === runtime;
    try {
      let activeSession = queuedOwner ? {id:queuedOwner.sessionId} as SessionState : session;
      if (!activeSession && !resume) {
        const created = await window.reverie.request("createSession", {});
        activeSession = created.session;
        runtimeViews.current.delete(runtimeKey);
        runtimeKey = ownerKey(runRoot, activeSession.id);
        runtimeViews.current.set(runtimeKey, runtime);
        setSession(activeSession);
        setState((current) => current ? { ...current, sessions: created.sessions, skills: created.skills ?? current.skills } : current);
      }
      // The prompt has been sent, so this conversation's draft is spent. Clear
      // both the saved slot and the pre-session placeholder that a brand-new
      // conversation was drafted under, so neither lingers to be restored.
      if (!activeSession) return;
      const response = await window.reverie.request(resume ? "resumePrompt" : "runPrompt", {
        ...(!resume ? { prompt: text } : {}),
        sessionId: activeSession.id,
        mode: activeState.workspace.mode,
        source: activeState.models.active_source,
        model: activeState.models.active_model?.id,
        ...(!resume ? { attachments: inputAttachments, projectRoot: runRoot } : {}),
        ...(runType === "review" ? { runType } : {}),
      });
      const result = response.result;
      const stopped = isStoppedPrompt(result.error);
      const outputText = result.output_text === result.error ? "" : result.output_text;
      const assistantText = (streamed: string) => outputText || (result.error && streamed.endsWith(result.error) ? streamed.slice(0, -result.error.length).trimEnd() : streamed);
      onResult?.(result.output_text || "");
      runtime.running = false;
      runtime.approval = null;
      runtime.live = result.success ? null : { ...runtime.live!, assistantText: assistantText(runtime.live?.assistantText || ""), reasoningText: result.thinking_text || runtime.live?.reasoningText || "", error: stopped ? "" : result.error, stopped };
      if (!result.success) authorizedQueues.current.delete(runtimeKey);
      if (!ownsView()) { setSessionStates(current => ({ ...current, [runtimeKey]: result.success ? "unread" : stopped ? "" : "failed" })); return result.success; }
      acceptLiveEvents.current = false;
      if (liveBatchTimer.current !== null) window.clearTimeout(liveBatchTimer.current);
      flushLiveBatch();
      resetLiveBatch();
      setLiveTurn((current) => current ? {
        ...current,
        assistantText: assistantText(current.assistantText),
        reasoningText: result.thinking_text || current.reasoningText,
        error: stopped ? "" : result.error,
        stopped,
      } : current);
      setState((current) => current ? {
        ...current,
        sessions: response.sessions,
        recovery: response.recovery,
      } : current);
      const refreshed = await window.reverie.request("getSession", { sessionId: result.session_id || activeSession.id });
      if (!ownsView()) return result.success;
      setSession(refreshed.session);
      setState((current) => current ? { ...current, sessions: refreshed.sessions } : current);
      if (!result.success) {
        setSessionStates(current => ({ ...current, [ownerKey(runRoot, activeSession.id)]: stopped ? "" : "failed" }));
        setQueuePaused(true);
        // The in-body error block carries the full humanized detail (e.g. the
        // 403 guidance) under the model output, and main.ts raises a native OS
        // toast when the window is in the background. That covers both the
        // focused and unfocused cases, so no in-app toast is needed here.
      } else {
        setSessionStates(current => ({ ...current, [ownerKey(runRoot, activeSession.id)]: document.hasFocus() ? "" : "unread" }));
        setLiveTurn(null);
      }
      return result.success;
    } catch (error) {
      authorizedQueues.current.delete(runtimeKey);
      runtime.running = false;
      runtime.approval = null;
      const message = error instanceof Error ? error.message : String(error);
      const stopped = isStoppedPrompt(message);
      runtime.live = runtime.live ? { ...runtime.live, error: stopped ? "" : message, stopped } : null;
      if (!ownsView()) { setSessionStates(current => ({ ...current, [runtimeKey]: stopped ? "" : "failed" })); return false; }
      acceptLiveEvents.current = false;
      setQueuePaused(true);
      setSessionStates(current => ({ ...current, [runtimeKey]: stopped ? "" : "failed" }));
      // A cancel is an intentional interrupt, not a failure -- interruptAndSend
      // clears the turn itself, so don't paint it as an error or notify.
      if (stopped) {
        setLiveTurn((current) => current ? { ...current, error: "", stopped: true } : current);
      } else {
        setLiveTurn((current) => current ? { ...current, error: message } : current);
        if (!runtime.live) setComposerError(message);
      }
      return false;
    } finally {
      if (ownsView()) { setRunning(false); setControlStatus(""); }
    }
  }, [flushLiveBatch, projectRoot, resetLiveBatch, session, state, t]);

  useEffect(() => {
    const followup = (event: Event) => {
      const detail = (event as CustomEvent<{ sessionId: string; text: string }>).detail;
      if (!detail || detail.sessionId !== session?.id || running || sessionBusy) {
        event.preventDefault();
        toast(t("会话正忙，请稍后发送追问。"), "info");
        return;
      }
      void runPromptText(detail.text);
    };
    window.addEventListener("reverie:view-followup", followup);
    return () => window.removeEventListener("reverie:view-followup", followup);
  }, [runPromptText, session?.id, running, sessionBusy, t, toast]);

  const sendPrompt = useCallback(async (behaviorOverride?: "queue" | "steer") => {
    const text = prompt.trim();
    if ((!text && !attachments.length) || sessionBusy || streamSettingPending.current || !state) return;
    const targetView = COMMAND_VIEWS[text.toLowerCase()];
    if (targetView && !/^\/skills?$/i.test(text)) { setView(targetView); setPrompt(""); return; }
    const command = desktopCommand(text);
    if (command?.kind === "setting") {
      if (running) { setComposerError(t("请先停止当前任务再修改运行设置")); return; }
      if (await updateSetting(command.key, command.value)) setPrompt("");
      return;
    }
    if (command?.kind === "review") { setPrompt(""); window.dispatchEvent(new CustomEvent("reverie:workbench", { detail: { tab: "review", reviewFile: command.file, scope: command.scope, base: command.base } })); return; }
    if (command?.kind === "provider") { setView("settings"); setPrompt(""); return; }
    if (attachments.some(item => item.status && item.status !== "ready")) { setComposerError(t("请处理未就绪附件")); return; }
    if (attachments.length > 20 || attachments.reduce((sum, item) => sum + item.size, 0) > 200 * 1024 * 1024) { setComposerError(t("附件超过数量或总量限制")); return; }
    // `/skill …` is a composer control, not a turn: Enter converts the typed text
    // into a pinned-skill chip instead of sending anything to the model.
    const skillMatch = /^\/skill(?:s)?(?:\s+([\s\S]*))?$/i.exec(text);
    if (skillMatch) {
      const argument = (skillMatch[1] || "").trim();
      const lowered = argument.toLowerCase();
      setPrompt("");
      setMentionItems([]);
      setMentionOpen(false);
      if (!argument || lowered === "status" || lowered === "show" || lowered === "list" || lowered === "available") {
        setView("skills");
        return;
      }
      if (lowered === "clear" || lowered === "off" || lowered === "none" || lowered === "reset") {
        await clearPinnedSkills();
        return;
      }
      const unpinMatch = /^(?:unpin|remove)\s+([\s\S]+)$/i.exec(argument);
      if (unpinMatch) {
        await unpinSkill(unpinMatch[1].trim().replace(/^\$/, ""));
        return;
      }
      await pinSkill(argument.replace(/^(?:pin|add|use)\s+/i, "").trim().replace(/^\$/, ""));
      return;
    }
    const compactMatch = /^\/compact(?:\s+([\s\S]*))?$/i.exec(text);
    if (compactMatch) {
      // /compact talks to the core; running it mid-turn would collide with the
      // in-flight request, so ignore it while a turn is streaming.
      if (running) return;
      setPrompt("");
      setMentionItems([]);
      setMentionOpen(false);
      await compactContext((compactMatch[1] || "").trim());
      return;
    }
    if (/^\/[a-z][\w-]*(?:\s|$)/i.test(text)) { setComposerError(t("此终端指令不能在桌面输入框执行，请使用对应页面或 Reverie TUI。")); return; }
    if (running) {
      if (!session) return;
      if ((behaviorOverride ?? sendBehavior) === "steer") {
        try {
          await window.reverie.request("steerPrompt", { projectRoot, sessionId: session.id, prompt: text, attachments });
          setControlStatus(t("等待安全点接收补充"));
        } catch (error) { setComposerError(error instanceof Error ? error.message : String(error)); return; }
      } else {
        const next = [...queue, { id: crypto.randomUUID(), projectRoot, sessionId: session.id, text, attachments: [...attachments], createdAt: Date.now() }];
        if (!updateQueue(next)) return;
        authorizedQueues.current.set(ownerKey(projectRoot,session.id),{projectRoot,sessionId:session.id});
        setQueuePaused(false);
      }
    }
    clearDraft(projectRoot, session?.id ?? NEW_SESSION_DRAFT_ID);
    setPrompt("");
    // The sent turn owns the current chips. Files added while it streams belong
    // to the next draft and must survive this turn's completion.
    setAttachments([]);
    setMentionItems([]);
    setMentionOpen(false);
    if (running) return;
    const success = await runPromptText(text, false, attachments);
    if (!success && draftOwner.current.root === projectRoot && (!session || draftOwner.current.id === session.id)) {
      setPrompt(current => current || text);
      setAttachments(current => current.length ? current : attachments);
    }
  }, [clearPinnedSkills, compactContext, pinSkill, prompt, attachments, queue, sendBehavior, running, runPromptText, sessionBusy, session, projectRoot, state, unpinSkill, updateQueue, updateSetting, t]);

  useEffect(() => {
    const pump = () => {
      if (sessionBusy || streamSettingBusy) return;
      for (const [key, owner] of authorizedQueues.current) {
        if (runtimeViews.current.get(key)?.running || queueStarting.current.has(key)) continue;
        const item = loadQueue(owner.projectRoot, owner.sessionId)[0];
        if (!item) { authorizedQueues.current.delete(key); continue; }
        queueStarting.current.add(key);
        void runPromptText(item.text, false, item.attachments, "prompt", owner).then(success => {
          if (success) {
            const next = loadQueue(owner.projectRoot,owner.sessionId).filter(message=>message.id!==item.id);
            const error = saveQueue(owner.projectRoot,owner.sessionId,next);
            if (ownerKey(draftOwner.current.root,draftOwner.current.id)===key) { setQueue(next); if(error)setComposerError(error); }
            if(error)authorizedQueues.current.delete(key);
          } else { authorizedQueues.current.delete(key); if(ownerKey(draftOwner.current.root,draftOwner.current.id)===key)setQueuePaused(true); }
        }).finally(()=>queueStarting.current.delete(key));
      }
    };
    pump();const timer=window.setInterval(pump,500);return()=>window.clearInterval(timer);
  }, [queue, queuePaused, running, sessionBusy, streamSettingBusy, runPromptText]);

  const cancelPrompt = useCallback(async () => {
    if (!session || !running) return;
    authorizedQueues.current.delete(ownerKey(projectRoot,session.id));
    setQueuePaused(true);
    setControlStatus(t("正在停止，等待当前操作结束"));
    setApproval(null);
    try {
      await window.reverie.request("stopPrompt", { projectRoot, sessionId: session.id });
    } catch (error) {
      setComposerError(error instanceof Error ? error.message : String(error));
    }
  }, [projectRoot, running, session, t]);

  const renameSession = useCallback(async (name: string) => {
    if (!renameSessionTarget || running || sessionBusy) return;
    try {
      const response = await window.reverie.request("renameSession", { sessionId: renameSessionTarget.id, name });
      const activeSession = response.session ?? null;
      if (activeSession) setSession(activeSession);
      setState((current) => current ? { ...current, sessions: response.sessions } : current);
      setRenameSessionTarget(null);
      toast(t("会话标题已更新"), "success");
    } catch (error) {
      toast(error instanceof Error ? error.message : String(error), "error");
    }
  }, [renameSessionTarget, running, sessionBusy, t, toast]);

  const toggleSessionArchive = useCallback((target: SessionInfo, archived: boolean) => {
    if (!state) return;
    const projectRoot = state.workspace.project_root;
    const currentIds = uiPreferences.archivedSessions[projectRoot] ?? [];
    const nextIds = archived
      ? currentIds.filter((id) => id !== target.id)
      : [...new Set([...currentIds, target.id])];
    updateUiPreferences({
      archivedSessions: {
        ...uiPreferences.archivedSessions,
        [projectRoot]: nextIds,
      },
    });
    toast(t(archived ? "会话已移出归档" : "会话已归档"), "success");
  }, [state, t, toast, uiPreferences.archivedSessions, updateUiPreferences]);

  const forkActiveSession = useCallback(async () => {
    if (!session || running || sessionBusy) return;
    drafts.current[session.id] = prompt;
    const requestSequence = ++sessionRequestSequence.current;
    setSessionBusy(true);
    try {
      const response = await window.reverie.request("forkSession", { sessionId: session.id, messageCount: session.messages.length });
      if (requestSequence !== sessionRequestSequence.current) return;
      const forked = response.session;
      setSession(forked);
      setState((current) => current ? { ...current, sessions: response.sessions } : current);
      setPrompt("");
      setLiveTurn(null);
      setView("chat");
      toast(t("已创建独立会话分支"), "success");
    } catch (error) {
      if (requestSequence === sessionRequestSequence.current) toast(error instanceof Error ? error.message : String(error), "error");
    } finally {
      if (requestSequence === sessionRequestSequence.current) setSessionBusy(false);
    }
  }, [prompt, running, session, sessionBusy, t, toast]);

  const rewindActiveSession = useCallback(() => {
    if (!session || running || sessionBusy) return;
    const messageCount = previousTurnBoundary(session.messages);
    if (messageCount === null) return;
    setConfirmation({
      title: t("回退上一轮对话？"),
      message: t("上一轮用户消息、回答及工具活动会从当前会话移除；完整记录仍由内核归档，可通过恢复功能找回。"),
      label: t("确认回退"),
      danger: true,
      action: () => { void (async () => {
        setSessionBusy(true);
        try {
          const response = await window.reverie.request("rewindSession", { sessionId: session.id, messageCount, confirmed: true });
          setSession(response.session);
          setState((current) => current ? { ...current, sessions: response.sessions } : current);
          setLiveTurn(null);
          toast(t("已回退上一轮对话"), "success");
        } catch (error) {
          toast(error instanceof Error ? error.message : String(error), "error");
        } finally {
          setSessionBusy(false);
        }
      })(); },
    });
  }, [running, session, sessionBusy, t, toast]);

  const deleteSession = useCallback((target: { id: string; name: string }) => {
    if (running || sessionBusy) return;
    setConfirmation({
      title: t("删除这个会话？"),
      message: t("delete.sessionMessage", { name: target.name }),
      label: t("删除会话"),
      danger: true,
      action: () => { void (async () => {
        setSessionBusy(true);
        try {
          const response = await window.reverie.request("deleteSession", { sessionId: target.id, confirmed: true });
          delete drafts.current[target.id];
          if (projectRoot) clearDraft(projectRoot, target.id);
          sessionCache.current.delete(target.id);
          const nextSession = response.session ?? null;
          setSession(nextSession);
          setState((current) => current ? { ...current, sessions: response.sessions } : current);
          setPrompt(nextSession ? drafts.current[nextSession.id] ?? "" : "");
          setLiveTurn(null);
          if (state) {
            const projectRoot = state.workspace.project_root;
            const archived = uiPreferences.archivedSessions[projectRoot] ?? [];
            if (archived.includes(target.id)) {
              updateUiPreferences({
                archivedSessions: {
                  ...uiPreferences.archivedSessions,
                  [projectRoot]: archived.filter((id) => id !== target.id),
                },
              });
            }
          }
          toast(t("会话已删除"), "success");
        } catch (error) {
          toast(error instanceof Error ? error.message : String(error), "error");
        } finally {
          setSessionBusy(false);
        }
      })(); },
    });
  }, [running, sessionBusy, state, t, toast, uiPreferences.archivedSessions, updateUiPreferences]);

  const deleteArchivedSessions = useCallback((targets: SessionInfo[]) => {
    if (running || sessionBusy || !state || targets.length === 0) return;
    const projectRoot = state.workspace.project_root;
    const targetIds = [...new Set(targets.map((target) => target.id).filter(Boolean))];
    if (targetIds.length === 0) return;
    setConfirmation({
      title: t("清空全部归档会话？"),
      message: t("delete.archiveMessage", { count: targetIds.length }),
      label: t("清空归档"),
      danger: true,
      action: () => { void (async () => {
        setSessionBusy(true);
        try {
          const response = await window.reverie.request("deleteSessions", { sessionIds: targetIds, confirmed: true });
          const deletedIds = Array.isArray(response.deleted_session_ids)
            ? response.deleted_session_ids.map((value) => String(value))
            : targetIds;
          deletedIds.forEach((sessionId) => {
            delete drafts.current[sessionId];
            clearDraft(projectRoot, sessionId);
            sessionCache.current.delete(sessionId);
          });
          const nextSession = response.session ?? null;
          setSession(nextSession);
          setState((current) => current ? { ...current, sessions: response.sessions } : current);
          setPrompt(nextSession ? drafts.current[nextSession.id] ?? "" : "");
          setLiveTurn(null);
          updateUiPreferences({
            archivedSessions: {
              ...uiPreferences.archivedSessions,
              [projectRoot]: [],
            },
          });
          toast(t("archive.deleted", { count: deletedIds.length }), "success");
        } catch (error) {
          toast(error instanceof Error ? error.message : String(error), "error");
        } finally {
          setSessionBusy(false);
        }
      })(); },
    });
  }, [running, sessionBusy, state, t, toast, uiPreferences.archivedSessions, updateUiPreferences]);

  const resolveApproval = useCallback(async (decision: ApprovalDecision, message?: string) => {
    if (!approval) return;
    try {
      await window.reverie.request("resolveApproval", {
        approvalId: approval.approval_id,
        projectRoot: String(approval.project_root || projectRoot), sessionId: String(approval.session_id || session?.id || ""),
        decision,
        ...(decision === "message" && message ? { message } : {}),
      });
      setApproval(null);
      toast(
        t(decision === "deny" ? "已拒绝工具执行" : decision === "message" ? "已发送个性化回复给模型" : "权限已授予"),
        decision === "deny" ? "info" : "success"
      );
    } catch (error) {
      setApproval(null);
      toast(error instanceof Error ? error.message : String(error), "error");
    }
  }, [approval, projectRoot, session?.id, t, toast]);

  const openModelPicker = useCallback(() => {
    if (state?.workspace.mode === "computer-controller") return;
    setModelPickerOpen(true);
    void window.reverie.request("refreshModelSources", {}).then((response) => {
      if (!response.models) return;
      setState((current) => current ? { ...current, models: response.models } : current);
    }).catch(() => {
      // Keep the initialized fallback catalog available when live discovery fails.
    });
  }, [state?.workspace.mode]);

  useEffect(() => {
    if (state?.workspace.mode === "computer-controller") setModelPickerOpen(false);
  }, [state?.workspace.mode]);

  const selectReasoning = useCallback(async (reasoning: string) => {
    if (!state) return;
    // Act on the entry the trigger actually shows, then map it back: a custom
    // provider's reasoning is stored against the aggregate `custom` source.
    const source = expandModelSources(state.models.sources).find((item) => item.active);
    if (!source) return;
    try {
      const response = await window.reverie.request("selectModel", { source: coreSourceId(source), modelId: source.selected_model_id, reasoning });
      setState((current) => current ? { ...current, models: response.models, workspace: response.workspace } : current);
      toast(t("思考设置已更新"), "success");
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [state, t, toast]);

  const revealSecret = useCallback<RevealSecret>(async (params) => {
    const response = await window.reverie.request("revealProviderSecret", {
      kind: params.kind,
      ...(params.field ? { field: params.field } : {}),
      ...(params.source ? { source: params.source } : {}),
      ...(typeof params.index === "number" ? { index: params.index } : {}),
      ...(params.providerId ? { providerId: params.providerId } : {}),
    });
    return String(response.value ?? "");
  }, []);

  const saveProvider = useCallback(async (source: ModelSource, patch: Record<string, unknown>, clearFields: string[] = []) => {
    try {
      const response = await window.reverie.request("setProviderConfig", {
        source: source.id,
        patch,
        ...(clearFields.length ? { clearFields } : {}),
      });
      setState((current) => current ? { ...current, models: response.models, workspace: response.workspace } : current);
      toast(t("provider.saved", { name: source.display_name }), "success");
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [t, toast]);

  const saveStandard = useCallback(async (model: Record<string, unknown>, clearApiKey = false) => {
    // One handler for both directions: the modal only knows the draft, and the
    // core preserves an omitted API key on update, so a blank key stays intact
    // unless the user explicitly cleared a revealed key (clearFields).
    const target = standardModelForm?.target ?? null;
    try {
      const response = target
        ? await window.reverie.request("updateStandardModel", {
            index: target.index,
            model,
            ...(clearApiKey ? { clearFields: ["api_key"] } : {}),
          })
        : await window.reverie.request("addStandardModel", { model });
      setState((current) => current ? { ...current, models: response.models, workspace: response.workspace } : current);
      setStandardModelForm(null);
      toast(target ? t("标准模型已更新") : t("标准模型已添加"), "success");
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [standardModelForm, t, toast]);

  const deleteStandard = useCallback((index: number) => {
    setConfirmation({ title: t("删除标准模型？"), message: t("这会从 Reverie 内核配置中移除该模型，但不会删除任何远端数据。"), label: t("删除模型"), danger: true, action: () => { void (async () => { try { const response = await window.reverie.request("deleteStandardModel", { index }); setState((current) => current ? { ...current, models: response.models, workspace: response.workspace } : current); toast(t("模型已删除"), "success"); } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); } })(); } });
  }, [t, toast]);

  const saveCustomProvider = useCallback(async (values: { name: string; base_url: string; api_key: string; format: string }, clearApiKey = false) => {
    const editing = providerModal?.provider ?? null;
    try {
      const response = editing
        ? await window.reverie.request("updateCustomProvider", {
            providerId: editing.id,
            patch: values,
            ...(clearApiKey ? { clearFields: ["api_key"] } : {}),
          })
        : await window.reverie.request("addCustomProvider", { provider: values });
      setState((current) => current ? { ...current, models: response.models, workspace: response.workspace } : current);
      setProviderModal(null);
      const syncError = response.provider?.sync_error;
      if (syncError) toast(syncError, "error");
      else toast(editing ? t("provider.saved", { name: values.name }) : t("provider.added", { name: values.name }), "success");
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [providerModal, t, toast]);

  const patchCustomProvider = useCallback(async (provider: CustomProviderRecord, patch: Record<string, unknown>) => {
    try {
      const response = await window.reverie.request("updateCustomProvider", { providerId: provider.id, patch });
      setState((current) => current ? { ...current, models: response.models, workspace: response.workspace } : current);
      toast(t("provider.saved", { name: provider.name }), "success");
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [t, toast]);

  const refreshCustomProvider = useCallback(async (provider: CustomProviderRecord) => {
    try {
      const response = await window.reverie.request("refreshCustomProviderModels", { providerId: provider.id });
      setState((current) => current ? { ...current, models: response.models, workspace: response.workspace } : current);
      toast(t("provider.catalogRefreshed", { name: provider.name, count: response.provider?.models.length ?? 0 }), "success");
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [t, toast]);

  const deleteCustomProvider = useCallback((provider: CustomProviderRecord) => {
    setConfirmation({
      title: t("删除这个 Provider？"),
      message: t("这会从 Reverie 内核配置中移除该 Provider 及其模型选择，远端服务不受影响。"),
      label: t("删除 Provider"),
      danger: true,
      action: () => { void (async () => {
        try {
          const response = await window.reverie.request("deleteCustomProvider", { providerId: provider.id });
          setState((current) => current ? { ...current, models: response.models, workspace: response.workspace } : current);
          setProviderProbes((current) => { const next = { ...current }; delete next[`custom:${provider.id}`]; return next; });
          toast(t("Provider 已删除"), "success");
        } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
      })(); },
    });
  }, [t, toast]);

  const selectCustomProviderModel = useCallback(async (
    provider: CustomProviderRecord,
    model: CustomProviderModel,
    contextLimit?: number,
  ) => {
    // The limit is asked exactly once per model; afterwards the stored value is
    // reused so switching models stays a single click.
    if (model.needs_context_limit && contextLimit === undefined) {
      setContextLimitModal({ provider, model });
      return;
    }
    try {
      const response = await window.reverie.request("selectCustomProviderModel", {
        providerId: provider.id,
        modelId: model.id,
        ...(contextLimit === undefined ? {} : { contextLimit }),
      });
      setState((current) => current ? { ...current, models: response.models, workspace: response.workspace } : current);
      setContextLimitModal(null);
      toast(t("model.switched", { name: model.display_name }), "success");
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [t, toast]);

  /** The stored record behind a synthetic `custom:<id>` picker entry. */
  const customProviderById = useCallback((providerId: string): CustomProviderRecord | null => {
    const aggregate = (state?.models.sources ?? []).find((item) => item.id === CUSTOM_SOURCE_ID);
    return (aggregate?.custom_providers ?? []).find((record) => record.id === providerId) ?? null;
  }, [state?.models.sources]);

  const selectModel = useCallback(async (source: ModelSource, model: ModelRecord, selectedReasoning?: string) => {
    // A per-provider picker entry is not a source the core knows: activating it
    // means activating that provider, which has its own call because it may still
    // need the user to confirm the model's context limit.
    const providerId = customProviderIdOf(source);
    if (providerId) {
      const provider = customProviderById(providerId);
      if (!provider) {
        toast(t("Provider 已不存在，请刷新后重试"), "error");
        return;
      }
      setModelPickerOpen(false);
      await selectCustomProviderModel(provider, model as CustomProviderModel);
      return;
    }
    try {
      const reasoning = selectedReasoning ?? (
        model.reasoning.options.some((option) => option.id === model.reasoning.value)
          ? model.reasoning.value
          : model.reasoning.options[0]?.id
      );
      const response = await window.reverie.request("selectModel", { source: source.id, modelId: model.id, ...(reasoning ? { reasoning } : {}) });
      setState((current) => current ? { ...current, models: response.models, workspace: response.workspace } : current);
      setModelPickerOpen(false);
      toast(t("model.switched", { name: model.display_name }), "success");
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [customProviderById, selectCustomProviderModel, t, toast]);

  const refreshImageModels = useCallback(async () => {
    try {
      const response = await window.reverie.request("refreshImageModelSources", {});
      setImageModels(response.imageModels);
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [toast]);

  const selectImageModel = useCallback(async (source: string, model: ImageModelRecord) => {
    try {
      const response = await window.reverie.request("selectImageModel", { source, modelId: model.id });
      setImageModels(response.imageModels);
      toast(t("image.switched", { name: model.display_name }), "success");
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [t, toast]);

  const saveCustomProviderContextLimit = useCallback(async (
    provider: CustomProviderRecord,
    model: CustomProviderModel,
    limit: number,
  ) => {
    // Reuse the selection call: it both stores the limit and pins the model, so
    // confirming a limit can never leave the two out of step.
    try {
      const response = await window.reverie.request("selectCustomProviderModel", {
        providerId: provider.id,
        modelId: model.id,
        contextLimit: limit,
      });
      setState((current) => current ? { ...current, models: response.models, workspace: response.workspace } : current);
      setContextLimitModal(null);
      toast(t("provider.contextSaved", { name: model.display_name, tokens: limit.toLocaleString() }), "success");
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [t, toast]);

  const setCustomProviderThinking = useCallback(async (provider: CustomProviderRecord, enabled: boolean) => {
    try {
      const response = await window.reverie.request("updateCustomProvider", { providerId: provider.id, patch: { thinking: enabled } });
      setState((current) => current ? { ...current, models: response.models, workspace: response.workspace } : current);
      toast(t(enabled ? "provider.thinkingOn" : "provider.thinkingOff", { name: provider.name }), "success");
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [t, toast]);

  const probeProviders = useCallback(async (keys: string[]) => {
    if (!keys.length) return;
    setProviderProbing(true);
    try {
      const response = await window.reverie.request("probeProviders", { keys });
      setProviderProbes((current) => {
        const next = { ...current };
        for (const probe of response.probes) next[probe.key] = probe;
        return next;
      });
      const offline = response.probes.filter((probe) => probe.probeable && probe.status !== "online").length;
      if (offline) toast(t("provider.probeIssues", { count: offline }), "error");
      else toast(t("provider.probeOk", { count: response.probes.length }), "success");
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
    finally { setProviderProbing(false); }
  }, [t, toast]);

  const customProviderControls = useMemo<CustomProviderControls>(() => ({
    probes: providerProbes,
    probing: providerProbing,
    add: () => setProviderModal({ provider: null }),
    edit: (provider) => setProviderModal({ provider }),
    remove: deleteCustomProvider,
    toggle: (provider, enabled) => void patchCustomProvider(provider, { enabled }),
    setThinking: (provider, enabled) => void setCustomProviderThinking(provider, enabled),
    refresh: (provider) => void refreshCustomProvider(provider),
    probe: (keys) => void probeProviders(keys),
    selectModel: (provider, model) => void selectCustomProviderModel(provider, model),
    editContextLimit: (provider, model) => setContextLimitModal({ provider, model }),
  }), [providerProbes, providerProbing, deleteCustomProvider, patchCustomProvider, setCustomProviderThinking, refreshCustomProvider, probeProviders, selectCustomProviderModel]);

  const updatePlugin = useCallback(async (action: "setPluginEnabled" | "setPluginTrust", plugin: PluginRecord, value: boolean) => {
    try {
      const response = action === "setPluginEnabled"
        ? await window.reverie.request("setPluginEnabled", { pluginId: plugin.id, enabled: value })
        : await window.reverie.request("setPluginTrust", { pluginId: plugin.id, trusted: value });
      const plugins = response.plugins;
      setState((current) => current ? { ...current, plugins, settings: response.settings } : current);
      toast(t("plugin.updated", { name: plugin.name }), "success");
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [t, toast]);

  const refreshPlugins = useCallback(async () => {
    try {
      const response = await window.reverie.request("refreshPlugins", {});
      setState((current) => current ? { ...current, plugins: response.plugins } : current);
      toast(t("插件目录已刷新"), "success");
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [t, toast]);

  const indexWorkspace = useCallback(async () => {
    toast(t("工作区索引已开始"), "info");
    try {
      const response = await window.reverie.request("indexWorkspace", {});
      setState((current) => current ? { ...current, workspace: response.workspace } : current);
      toast(t("工作区索引完成"), "success");
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [t, toast]);

  const rollback = useCallback((checkpointId: string) => {
    setConfirmation({ title: t("恢复到这个检查点？"), message: t("Reverie 将恢复会话消息，并回退该检查点之后被操作历史跟踪的文件。建议先提交当前改动。"), label: t("确认恢复"), danger: true, action: () => { void (async () => { try { const response = await window.reverie.request("rollbackCheckpoint", { checkpointId, confirmed: true }); setState((current) => current ? { ...current, recovery: response.recovery } : current); if (session) await openSession(session.id); toast(t("检查点恢复完成"), "success"); } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); } })(); } });
  }, [openSession, session, t, toast]);

  const attachmentValidationKey = attachments.map(item=>`${item.id}:${item.relativePath}:${item.status || "ready"}`).join("|");
  useEffect(()=>{
    if(!attachments.length || !window.reverie.workbench)return;
    const owner={...draftOwner.current};let active=true;
    void window.reverie.workbench("validate-input",{projectRoot:owner.root,sessionId:owner.id,attachments}).then(value=>{
      if(active && draftOwner.current.root===owner.root && draftOwner.current.id===owner.id)setAttachments(current => current === attachments ? (value as {attachments:ComposerAttachment[]}).attachments : current);
    }).catch(error=>{if(active)setComposerError(String(error));});
    return()=>{active=false;};
  },[projectRoot,session?.id,attachmentValidationKey]);

  const requestMentions = useCallback(async (query?: string) => {
    if (query === undefined && mentionOpen) {
      mentionRequestSequence.current += 1;
      setMentionOpen(false);
      setMentionLoading(false);
      return;
    }
    const requestSequence = ++mentionRequestSequence.current;
    const expectedRoot = projectRoot;
    setMentionOpen(true);
    setMentionLoading(true);
    setMentionError("");
    try {
      const response = await window.reverie.request("workspaceMentions", { query: query ?? prompt.trim(), limit: 24 });
      if (requestSequence !== mentionRequestSequence.current || draftOwner.current.root !== expectedRoot) return;
      let recent:Array<Record<string,unknown>>=[];try{recent=JSON.parse(localStorage.getItem(`reverie.recentRefs:${ownerKey(projectRoot,"")}`) || "[]");}catch{setComposerError(t("最近引用记录无法读取"));}
      const recentItems:Array<Record<string,unknown>>=(query ?? prompt.trim()) ? [] : recent.map(item=>({...item,reason:t("最近引用")}));
      setMentionItems([...recentItems,...response.items.filter(item=>!recentItems.some(recent=>recent.path===item.path && recent.line===item.line))].slice(0,24));
      const nextContext = response.context_engine;
      setState((current) => current ? {
        ...current,
        workspace: { ...current.workspace, index_ready: Boolean(nextContext?.ready), context_engine: nextContext },
      } : current);
    } catch (error) {
      if (requestSequence !== mentionRequestSequence.current) return;
      setMentionItems([]);
      setMentionError(error instanceof Error ? error.message : String(error));
    } finally {
      if (requestSequence === mentionRequestSequence.current) setMentionLoading(false);
    }
  }, [mentionOpen, projectRoot, prompt, t, toast]);


  const updateOwnedAttachments = useCallback((owner: { root: string; id: string }, change: (items: ComposerAttachment[]) => ComposerAttachment[]) => {
    if (owner.root === draftOwner.current.root && owner.id === draftOwner.current.id) setAttachments(change);
    else {
      const draft = loadStructuredDraft(owner.root, owner.id);
      saveStructuredDraft(owner.root, owner.id, { ...draft, attachments: change(draft.attachments) });
    }
  }, []);
  const addAttachments = useCallback((added: ComposerAttachment[], owner = { ...draftOwner.current }) => {
    updateOwnedAttachments(owner, current => [...current, ...added.filter(item => !item.relativePath || !current.some(existing => existing.relativePath === item.relativePath && existing.line === item.line))]);
    setMentionOpen(false);
  }, [updateOwnedAttachments]);

  const selectAttachment = useCallback(async () => {
    const owner = { ...draftOwner.current };
    try {
      const attachment = await window.reverie.selectAttachment(owner.root);
      if (!attachment) return;
      addAttachments([attachment], owner);
      toast(t("attachment.added", { name: attachment.name }), "success");
    } catch (error) {
      setComposerError(error instanceof Error ? error.message : String(error));
    }
  }, [addAttachments, t, toast]);

  const importDroppedFiles = useCallback(async (files: File[]) => {
    const owner = { ...draftOwner.current };
    if (files.length + attachments.length > 20) { setComposerError(t("附件超过数量或总量限制")); return; }
    const pending = files.map(file => ({ id: crypto.randomUUID(), name: file.name, relativePath: "", size: file.size, status: "pending" as const }));
    addAttachments(pending, owner);
    try {
      const added = await window.reverie.importDroppedFiles(files, owner.root);
      if (!added.length) throw new Error(t("没有可用的本地文件"));
      updateOwnedAttachments(owner, current => current.map(item => {
        const index = pending.findIndex(entry => entry.id === item.id);
        return index < 0 ? item : { ...added[index], id: item.id, status: added[index].status ?? "ready" };
      }));
      toast(t("attachment.filesAdded", { count: added.length }), "success");
    } catch (error) {
      const detail = error instanceof Error ? error.message : String(error);
      updateOwnedAttachments(owner, current => current.map(item => pending.some(entry => entry.id === item.id) ? { ...item, status: "failed", error: detail } : item));
    }
  }, [addAttachments, attachments.length, updateOwnedAttachments, t, toast]);

  const removeAttachment = useCallback((attachment: ComposerAttachment) => {
    setAttachments((current) => current.filter((item) => attachment.id ? item.id !== attachment.id : item.relativePath !== attachment.relativePath));
  }, []);

  const pasteImage = useCallback(async () => {
    const owner = { ...draftOwner.current };
    if (attachments.length >= 20) { setComposerError(t("附件超过数量或总量限制")); return; }
    try { addAttachments([await window.reverie.pasteImage(owner.root)], owner); }
    catch (error) { if (owner.root === draftOwner.current.root && owner.id === draftOwner.current.id) setComposerError(error instanceof Error ? error.message : String(error)); }
  }, [attachments.length, addAttachments, t]);
  const retryAttachment = useCallback(async (item: ComposerAttachment, copy = false) => {
    const owner = { ...draftOwner.current };
    updateOwnedAttachments(owner, current => current.map(entry => entry === item ? { ...entry, status: "pending", error: "" } : entry));
    try {
      const next = await window.reverie.retryAttachment(owner.root, item, copy);
      updateOwnedAttachments(owner, current => current.map(entry => (item.id ? entry.id === item.id : entry.relativePath === item.relativePath) ? { ...next, id: item.id } : entry));
    } catch (error) { updateOwnedAttachments(owner, current => current.map(entry => (item.id ? entry.id === item.id : entry.relativePath === item.relativePath) ? { ...entry, status: "failed", error: error instanceof Error ? error.message : String(error) } : entry)); }
  }, [updateOwnedAttachments]);

  const chooseStructuredMention = useCallback((value: string, range?: { start: number; end: number }) => {
    const match = /^@(?:"([^"]+)"|'([^']+)'|(.+?))(?:#L(\d+))?$/.exec(value);
    if (!match) return;
    const file = match[1] || match[2] || match[3];
    addAttachments([{ id: crypto.randomUUID(), relativePath: file, sourcePath: `${projectRoot}/${file}`, name: file.split(/[\\/]/).pop() || file, size: 0, status: "ready", kind: "reference", line: match[4] ? Number(match[4]) : undefined }]);
    try{const key=`reverie.recentRefs:${ownerKey(projectRoot,"")}`;const recent=JSON.parse(localStorage.getItem(key) || "[]") as Array<Record<string,unknown>>;const line=match[4]?Number(match[4]):undefined;localStorage.setItem(key,JSON.stringify([{path:file,name:file.split(/[\\/]/).pop(),kind:line?"symbol":"file",line},...recent.filter(item=>item.path!==file || item.line!==line)].slice(0,16)));}catch(error){setComposerError(String(error));}
    setPrompt(current => range ? current.slice(0, range.start) + current.slice(range.end) : current.replace(/(?:^|\s)@[^\s]*$/, " "));
    setMentionOpen(false);
  }, [addAttachments, projectRoot]);

  const selectWorkspace = useCallback(async () => {
    if (sessionBusy) return;
    setSessionBusy(true);
    try {
      if (session) drafts.current[session.id] = prompt;
      const projectRoot = await window.reverie.selectWorkspace();
      if (projectRoot) {
        sessionRequestSequence.current += 1;
        drafts.current = {};
        setPrompt("");
        setAttachments([]);
        setMentionOpen(false);
        await initialize(projectRoot);
      }
    } catch (error) {
      toast(error instanceof Error ? error.message : String(error), "error");
    } finally {
      setSessionBusy(false);
    }
  }, [initialize, prompt, running, session, sessionBusy, toast]);

  const switchWorkspace = useCallback(async (projectRoot: string): Promise<boolean> => {
    if (sessionBusy || projectRoot.toLowerCase() === state?.workspace.project_root.toLowerCase()) return false;
    try {
      if (session) drafts.current[session.id] = prompt;
      setSessionBusy(true);
      const selectedRoot = await window.reverie.switchWorkspace(projectRoot);
      if (!selectedRoot) return false;
      sessionRequestSequence.current += 1;
      drafts.current = {};
      setPrompt("");
      setAttachments([]);
      setMentionOpen(false);
      await initialize(selectedRoot);
      return true;
    } catch (error) {
      toast(error instanceof Error ? error.message : String(error), "error");
      return false;
    } finally {
      setSessionBusy(false);
    }
  }, [initialize, prompt, running, session, sessionBusy, state?.workspace.project_root, toast]);

  const createSessionForProject = useCallback(async (projectRoot: string) => {
    if (sessionBusy) return;
    const activeRoot = state?.workspace.project_root ?? "";
    if (activeRoot && activeRoot.toLowerCase() === projectRoot.toLowerCase()) {
      await createSession(true);
      return;
    }
    if (await switchWorkspace(projectRoot)) { const response=await window.reverie.request("createSession",{}); setSession(response.session); setState(current=>current?{...current,sessions:response.sessions,skills:response.skills??current.skills}:current); const draft=loadStructuredDraft(projectRoot,response.session.id);setPrompt(draft.text);setAttachments(draft.attachments);setView("chat"); }
  }, [createSession, running, sessionBusy, state?.workspace.project_root, switchWorkspace]);

  const navigateToSession = useCallback(async (root: string, id: string) => {
    if (root.toLowerCase() === projectRoot.toLowerCase()) { if (id) await openSession(id); else await createSession(true); return; }
    if (!await switchWorkspace(root)) return;
    const response = id ? await window.reverie.request("getSession", { sessionId: id }) : await window.reverie.request("createSession", {});
    setSession(response.session);
    setState(current => current ? { ...current, sessions: response.sessions, skills: response.skills ?? current.skills } : current);
    const draft = loadStructuredDraft(root, response.session.id);
    setPrompt(draft.text); setAttachments(draft.attachments); setView("chat");
  }, [projectRoot, openSession, createSession, switchWorkspace]);

  useEffect(()=>{const open=(event:Event)=>void navigateToSession(String((event as CustomEvent).detail.root),"").catch(error=>toast(String(error),"error"));window.addEventListener("reverie:workspace-open",open);return()=>window.removeEventListener("reverie:workspace-open",open);},[navigateToSession,toast]);

  useEffect(() => window.reverie.onEvent(message => {
    if (message.type === "notification.open") { const item = asRecord(message.notification); void navigateToSession(String(item.projectRoot), String(item.sessionId)).catch(error => toast(String(error), "error")); }
  }), [navigateToSession, toast]);

  const deleteProject = useCallback((target: { root: string; name: string; active: boolean }) => {
    if (running || sessionBusy) return;
    setConfirmation({
      title: t("project.deleteTitle", { name: target.name }),
      message: t("该项目的全部会话、完整转录、记忆、检查点、Context Engine 缓存和已导入附件将永久删除。源码与普通项目文件不会被删除。"),
      label: t("删除项目与记录"),
      danger: true,
      action: () => { void (async () => {
        setSessionBusy(true);
        try {
          const result = await window.reverie.deleteWorkspace(target.root);
          if (!result) return;
          // The project's records are gone, so drop its saved composer drafts
          // too instead of leaving orphaned keys behind in localStorage.
          clearProjectDrafts(target.root);
          setUiPreferences(normalizeUiPreferences(result.preferences));
          if (target.active) {
            sessionRequestSequence.current += 1;
            drafts.current = {};
            setPrompt("");
            setAttachments([]);
            setMentionOpen(false);
            await initialize(result.projectRoot);
          }
          toast(t("project.deleted", { count: result.deletedSessions }), "success");
        } catch (error) {
          toast(error instanceof Error ? error.message : String(error), "error");
        } finally {
          setSessionBusy(false);
        }
      })(); },
    });
  }, [initialize, running, sessionBusy, t, toast]);

  const selectCoreData = useCallback(async () => {
    if (running || sessionBusy) return;
    try {
      const coreAppRoot = await window.reverie.selectCoreData();
      if (!coreAppRoot) return;
      sessionRequestSequence.current += 1;
      drafts.current = {};
      setState(null);
      setSession(null);
      setPrompt("");
      await initialize(desktopPaths?.projectRoot);
    } catch (error) { toast(error instanceof Error ? error.message : String(error), "error"); }
  }, [desktopPaths?.projectRoot, initialize, running, sessionBusy, toast]);

  const chooseCommand = useCallback((command: CommandRecord) => {
    setCommandOpen(false);

    const target = COMMAND_VIEWS[command.command];
    if (target) { setView(target); return; }
    setView("chat");
    setPrompt(command.examples?.[0] || command.command);
    toast(t("command.inserted", { command: command.command }), "info");
  }, [t, toast]);

  const switchBranch = useCallback(async (name: string, remote: boolean) => {
    if (running || sessionBusy || gitBusy || !state) return;
    setGitBusy(true);
    try {
      const status = await window.reverie.switchGitBranch(name, remote);
      setGitStatus(status);
      await initialize(state.workspace.project_root);
      toast(t("git.switched", { name: status.currentBranch }), "success");
    } catch (error) {
      toast(error instanceof Error ? error.message : String(error), "error");
      void refreshGitStatus();
    } finally {
      setGitBusy(false);
    }
  }, [gitBusy, initialize, refreshGitStatus, running, sessionBusy, state, t, toast]);

  const createBranch = useCallback(async (name: string) => {
    if (running || sessionBusy || gitBusy || !state) return;
    setGitBusy(true);
    try {
      const status = await window.reverie.createGitBranch(name);
      setGitStatus(status);
      await initialize(state.workspace.project_root);
      toast(t("git.created", { name: status.currentBranch }), "success");
    } catch (error) {
      toast(error instanceof Error ? error.message : String(error), "error");
      void refreshGitStatus();
    } finally {
      setGitBusy(false);
    }
  }, [gitBusy, initialize, refreshGitStatus, running, sessionBusy, state, t, toast]);

  const activeSessionId = session?.id ?? state?.sessions.current_session_id ?? "";
  const page = useMemo(() => {
    if (!state) return null;
    if (view === "tools") return <ToolsView mode={state.workspace.mode} />;
    if (view === "rats") return <RatsView />;
    if (view === "tasks") return <RtpTasksView preferences={uiPreferences} updatePreferences={updateUiPreferences} />;
    if (view === "subagents") return <SubagentsView />;
    if (view === "skills") return <SkillsView skills={state.skills} pinSkill={(name) => void pinSkill(name)} unpinSkill={(name) => void unpinSkill(name)} clearPinned={() => void clearPinnedSkills()} refresh={() => void refreshSkills()} />;
    if (view === "plugins") return <PluginsView plugins={state.plugins.records} updatePlugin={updatePlugin} refresh={refreshPlugins} />;
    if (view === "recovery") return <RecoveryView recovery={state.recovery} rollback={rollback} />;
    if (view === "settings") return <SettingsView state={state} updateSetting={updateSetting} selectModel={selectModel} saveProvider={saveProvider} revealSecret={revealSecret} addStandard={() => setStandardModelForm({ target: null })} editStandard={(index, model) => setStandardModelForm({ target: { index, model } })} deleteStandard={deleteStandard} customProviders={customProviderControls} paths={desktopPaths} selectCoreData={() => void selectCoreData()} theme={theme} setTheme={changeTheme} preferences={uiPreferences} updatePreferences={updateUiPreferences} selectBackground={() => void selectBackground()} clearBackground={() => void clearBackground()} imageModels={imageModels} refreshImageModels={() => void refreshImageModels()} selectImageModel={(source, model) => void selectImageModel(source, model)} />;
    return <ChatView session={session} liveTurn={liveTurn} running={running} prompt={prompt} setPrompt={setPrompt} send={() => void sendPrompt()} cancel={() => void cancelPrompt()} resume={() => void runPromptText("", true)} mentionItems={mentionItems} mentionOpen={mentionOpen} mentionLoading={mentionLoading} requestMentions={(query) => void requestMentions(query)} chooseMention={chooseStructuredMention} attachments={attachments} selectAttachment={() => void selectAttachment()} importDroppedFiles={(files) => void importDroppedFiles(files)} removeAttachment={removeAttachment} pinnedSkills={pinnedSkills} unresolvedSkills={unresolvedSkills} unpinSkill={(name) => void unpinSkill(name)} modelName={state.models.active_model?.display_name ?? "Reverie"} sessionBusy={sessionBusy} renameSession={() => { if (session) setRenameSessionTarget({ id: session.id, name: session.name }); }} forkSession={() => void forkActiveSession()} rewindSession={rewindActiveSession} deleteSession={() => { if (session) deleteSession(session); }} preferences={uiPreferences}
        updatePreferences={updateUiPreferences} approval={approval} resolveApproval={resolveApproval} contextUsage={contextUsage} />;
  }, [state, view, updatePlugin, refreshPlugins, rollback, updateSetting, selectModel, saveProvider, revealSecret, deleteStandard, customProviderControls, desktopPaths, selectCoreData, theme, changeTheme, uiPreferences, updateUiPreferences, selectBackground, clearBackground, imageModels, refreshImageModels, selectImageModel, session, liveTurn, running, prompt, mentionItems, mentionOpen, mentionLoading, attachments, selectAttachment, importDroppedFiles, removeAttachment, pinnedSkills, unresolvedSkills, pinSkill, unpinSkill, clearPinnedSkills, refreshSkills, sendPrompt, cancelPrompt, runPromptText, requestMentions, chooseStructuredMention, sessionBusy, forkActiveSession, rewindActiveSession, deleteSession, approval, resolveApproval, contextUsage]);

  if (bootError) return <I18nProvider language={uiPreferences.language}><ErrorScreen error={bootError} retry={() => void retryInitialization()} /></I18nProvider>;
  if (!state) return <I18nProvider language={uiPreferences.language}><LoadingScreen /></I18nProvider>;
  const selectedModelSource = state.models.sources.find(source => source.id === state.workspace.active_source);
  const streamRequired = state.workspace.mode === "writer" && state.workspace.active_source === "sensenova";
  const streamSetting = state.settings.items.find(item => item.key === "stream_responses");
  const streaming = streamRequired || streamSetting?.value !== false;

  return (
    <I18nProvider language={uiPreferences.language}>
    <ViewPresentationProvider scope={projectRoot} persisted={uiPreferences.viewPresentations}>
    <InputContext.Provider value={{
      projectRoot, sessionId: session?.id ?? "", behavior: sendBehavior, setBehavior: setSendBehavior,
      streaming, streamReady: Boolean(streamSetting), streamSettingBusy, streamRequired, toggleStreaming: () => void updateSetting("stream_responses", !streaming),
      paste: () => void pasteImage(), retryAttachment: (item, copy) => void retryAttachment(item, copy),
      commands: state.commands.items, skills: state.skills, pinSkill, mentionError,
      mode: state.workspace.mode, setMode: mode => void updateSetting("mode", mode),
      closeMentions: () => { mentionRequestSequence.current += 1; setMentionOpen(false); setMentionLoading(false); }, error: [draftError, composerError].filter(Boolean).join(" · "), status: controlStatus,
      moveAttachment: (index, direction) => setAttachments(current => { const next = [...current]; const target = Math.max(0, Math.min(next.length - 1, index + direction)); const [item] = next.splice(index, 1); next.splice(target, 0, item); return next; }),
      queue, queuePaused, resumeQueue: () => { if(session)authorizedQueues.current.set(ownerKey(projectRoot,session.id),{projectRoot,sessionId:session.id}); setQueuePaused(false); },
      editQueue: (index, text, items) => { updateQueue(queue.map((item, i) => i === index ? { ...item, text, attachments: items } : item)); },
      moveQueue: (index, direction) => { const next = [...queue]; const [item] = next.splice(index, 1); next.splice(index + direction, 0, item); updateQueue(next); },
      deleteQueue: index => { updateQueue(queue.filter((_, i) => i !== index)); },
      forceStop: () => { setConfirmation({ title: t("强制停止核心？"), message: t("当前操作可能尚未完成；只保存最后持久化记录，队列保持暂停。"), label: t("强制停止"), danger: true, action: () => { setQueuePaused(true); void window.reverie.cancel({projectRoot:state.workspace.project_root,sessionId:session?.id || ""}); } }); },
      vision: selectedModelSource?.models.find(model => model.id === selectedModelSource.selected_model_id)?.vision,
      running, approval: Boolean(approval), sessionStates, steer: () => void sendPrompt("steer"),
    }}>
    <div
      ref={shellRef}
      className={`app-shell ${sidebarCollapsed ? "sidebar-collapsed" : ""} ${uiPreferences.inspectorOpen ? "with-inspector" : ""} ${paneResizing ? "pane-resizing" : ""}`}
      style={{ "--sidebar-width": `${sidebarWidth}px`, "--inspector-width": `${inspectorWidth}px` } as CSSProperties}
    >
      <Sidebar state={state} view={view} setView={setView} activeSessionId={activeSessionId} openSession={(id) => void openSession(id)} newSession={() => void createSession()} newProjectSession={(projectRoot) => void createSessionForProject(projectRoot)} sessionBusy={sessionBusy} selectWorkspace={() => void selectWorkspace()} switchWorkspace={(projectRoot) => void switchWorkspace(projectRoot)} openSearch={() => setSessionSearchOpen(true)} preferences={uiPreferences} toggleSidebar={toggleSidebar} renameSession={(target) => setRenameSessionTarget({ id: target.id, name: target.name })} toggleArchive={toggleSessionArchive} deleteSession={deleteSession} deleteArchivedSessions={deleteArchivedSessions} deleteProject={deleteProject} />
      <main className={`main-area ${gitStatus ? "with-git-status" : ""}`}>
        <Topbar state={state} view={view} sidebarCollapsed={sidebarCollapsed} toggleSidebar={toggleSidebar} openModelPicker={openModelPicker} selectReasoning={(value) => void selectReasoning(value)} inspectorOpen={uiPreferences.inspectorOpen} toggleInspector={() => updateUiPreferences({ inspectorOpen: !uiPreferences.inspectorOpen })} openCommands={() => setCommandOpen(true)} theme={theme} setTheme={changeTheme} />
        <div className="content-area">{page}</div>
        {gitStatus && <GitBranchPicker status={gitStatus} busy={running || sessionBusy || gitBusy} refresh={() => void refreshGitStatus()} switchBranch={(name, remote) => void switchBranch(name, remote)} createBranch={(name) => void createBranch(name)} />}
      </main>
      <Workbench root={projectRoot} sessionId={activeSessionId} running={running} open={uiPreferences.inspectorOpen} onOpenChange={setWorkbenchOpen}
        onDraft={value => { setPrompt(current => current ? `${current}\n\n${value}` : value); setView("chat"); }}
        onReview={async text => { let output = ""; const success = await runPromptText(text, false, [], "review", undefined, value => { output = value; }); if (!success) throw new Error(t("审查未完成，请检查运行记录")); return output; }}
        changesPanel={<FileChanges sessionId={activeSessionId} running={running} revision={state.recovery} />}
        contextPanel={<InspectorContent state={state} liveTurn={liveTurn} indexWorkspace={() => void indexWorkspace()} compactContext={() => void compactContext()} compactDisabled={running || sessionBusy} tab="context" />}
        activityPanel={<InspectorContent state={state} liveTurn={liveTurn} indexWorkspace={() => void indexWorkspace()} compactContext={() => void compactContext()} compactDisabled={running || sessionBusy} tab="activity" />}>
        <SessionWorkbench root={projectRoot} sessionId={activeSessionId} running={running} state={state} onDraft={value => setPrompt(current => current ? `${current}\n\n${value}` : value)} onNavigate={(root, id) => void navigateToSession(root, id).catch(error => toast(String(error), "error"))} />
      </Workbench>
      {/* Handles live on the shell, not inside the panes: both panes clip their
          overflow, so a child handle could not straddle the seam it drags. */}
      <PaneResizer
        edge="left"
        label={t("调整会话侧栏宽度")}
        width={sidebarWidth}
        minimum={SIDEBAR_MIN_WIDTH}
        maximum={SIDEBAR_MAX_WIDTH}
        fallback={SIDEBAR_DEFAULT_WIDTH}
        shell={shellRef}
        opposite={uiPreferences.inspectorOpen ? inspectorWidth : 0}
        preview={previewSidebarWidth}
        commit={commitSidebarWidth}
      />
      <PaneResizer
        edge="right"
        label={t("调整工作面板宽度")}
        overlay={compactViewport}
        width={inspectorWidth}
        minimum={INSPECTOR_MIN_WIDTH}
        maximum={INSPECTOR_MAX_WIDTH}
        fallback={INSPECTOR_DEFAULT_WIDTH}
        shell={shellRef}
        opposite={sidebarCollapsed ? 0 : sidebarWidth}
        preview={previewInspectorWidth}
        commit={commitInspectorWidth}
      />
      {modelPickerOpen && state.workspace.mode !== "computer-controller" && <ModelPicker state={state} onSelect={(source, model, reasoning) => void selectModel(source, model, reasoning)} close={() => setModelPickerOpen(false)} />}
      {commandOpen && <CommandPalette commands={state.commands.items} close={() => setCommandOpen(false)} choose={chooseCommand} />}
      {sessionSearchOpen && <SessionSearch close={() => setSessionSearchOpen(false)} openSession={(id) => void openSession(id)} />}
      {renameSessionTarget && <RenameSessionModal session={renameSessionTarget} close={() => setRenameSessionTarget(null)} save={(name) => void renameSession(name)} />}
      {standardModelForm && <StandardModelModal target={standardModelForm.target} close={() => setStandardModelForm(null)} save={(model, clearApiKey) => void saveStandard(model, clearApiKey)} reveal={standardModelForm.target ? () => revealSecret({ kind: "standard", index: standardModelForm.target!.index }) : undefined} />}
      {providerModal && (
        <CustomProviderModal
          provider={providerModal.provider}
          formats={state.models.sources.find((item) => item.id === "custom")?.custom_provider_formats ?? []}
          close={() => setProviderModal(null)}
          save={(values, clearApiKey) => void saveCustomProvider(values, clearApiKey)}
          reveal={providerModal.provider ? () => revealSecret({ kind: "custom", providerId: providerModal.provider!.id }) : undefined}
        />
      )}
      {contextLimitModal && (
        <ContextLimitModal
          provider={contextLimitModal.provider}
          model={contextLimitModal.model}
          close={() => setContextLimitModal(null)}
          save={(limit) => void saveCustomProviderContextLimit(contextLimitModal.provider, contextLimitModal.model, limit)}
        />
      )}
      {confirmation && <ConfirmModal title={confirmation.title} message={confirmation.message} confirmLabel={confirmation.label} danger={confirmation.danger} close={() => setConfirmation(null)} confirm={() => { const action = confirmation.action; setConfirmation(null); action(); }} />}
      <Toasts items={toasts} onDismiss={(id) => setToasts((items) => items.filter((item) => item.id !== id))} />
    </div>
    </InputContext.Provider>
    </ViewPresentationProvider>
    </I18nProvider>
  );
}

const DIALOG_FOCUSABLE = [
  "button:not([disabled])",
  "input:not([disabled])",
  "select:not([disabled])",
  "textarea:not([disabled])",
  "[href]",
  "[tabindex]:not([tabindex='-1'])",
].join(",");

function useDialogFocus(
  dialogRef: { current: HTMLElement | null },
  close?: () => void,
): void {
  const closeRef = useRef(close);
  closeRef.current = close;
  const restoreFocus = useRef<HTMLElement | null>(
    typeof document !== "undefined" && document.activeElement instanceof HTMLElement
      ? document.activeElement
      : null,
  );

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    const focusable = () => Array.from(dialog.querySelectorAll<HTMLElement>(DIALOG_FOCUSABLE))
      .filter((element) => !element.hidden && element.getAttribute("aria-hidden") !== "true");
    const initial = dialog.querySelector<HTMLElement>("[autofocus]") ?? focusable()[0] ?? dialog;
    initial.focus();

    const keyDown = (event: globalThis.KeyboardEvent) => {
      if (event.key === "Escape" && closeRef.current) {
        event.preventDefault();
        event.stopPropagation();
        closeRef.current();
        return;
      }
      if (event.key !== "Tab") return;
      const elements = focusable();
      if (!elements.length) {
        event.preventDefault();
        dialog.focus();
        return;
      }
      const first = elements[0];
      const last = elements[elements.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    dialog.addEventListener("keydown", keyDown);
    return () => {
      dialog.removeEventListener("keydown", keyDown);
      restoreFocus.current?.focus();
    };
  }, [dialogRef]);
}
