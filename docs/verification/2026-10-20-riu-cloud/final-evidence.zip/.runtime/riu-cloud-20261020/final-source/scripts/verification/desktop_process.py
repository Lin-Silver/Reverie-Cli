"""Own only the isolated Desktop process tree launched by a verifier."""
import os
import signal
import subprocess


def launch_options(*, visible=False):
    if os.name != 'nt':
        return {'start_new_session': True}
    startup = subprocess.STARTUPINFO()
    startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow = int(visible)
    return {'startupinfo': startup}


def stop_process(process):
    if process is None or process.poll() is not None:
        return
    if os.name == 'nt':
        subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'],
                       capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
    elif os.getpgid(process.pid) == process.pid:
        os.killpg(process.pid, signal.SIGTERM)
    else:
        process.terminate()
    process.wait(timeout=30)
