from pathlib import Path
from collections import Counter,defaultdict
import json,hashlib
R=Path('/workspace/Reverie-Cli');B=R/'.runtime/riu-cloud-20261020'
import sys
phase=sys.argv[1] if len(sys.argv)>1 else 'anonymous-matrix-protocol-resumed'
M=B/phase/'matrix.json'
d=json.loads(M.read_text())
items=[];requests=[];duplicates=defaultdict(list)
for sample in d['samples']:
 for case in sample.get('cases',[]):
  origin=Path(sample['report']).parent
  item={'task':sample['task'],'attempt':sample['attempt'],'outcome':case.get('outcome'),'report':str(Path(sample['report']).relative_to(R)),'checks':len(case.get('checks',[])),'checks_passed':sum(c.get('passed',False)for c in case.get('checks',[])),'failed_checks':[c['name']for c in case.get('checks',[])if not c.get('passed')],'repairs':case.get('repair_count',0),'turns':case.get('turns',[]),'artifacts':case.get('artifacts',[]),'violations':case.get('violations',[]),'error':case.get('error')}
  items.append(item)
  for request in case.get('requests',[]):
   requests.append(request)
   if request.get('response_sha256'):duplicates[(request.get('request_sha256'),request.get('response_sha256'))].append({'task':sample['task'],'attempt':sample['attempt'],'request':request['request']})
generation=[c for c in items if c['task']!='text'];text=[c for c in items if c['task']=='text']
first=[]
for sample in d['samples']:
 p=Path(sample['report']).parent/'request-0000.json'
 if p.exists():
  request=json.loads(p.read_text());first.append({'task':sample['task'],'attempt':sample['attempt'],'request_options':{k:v for k,v in request.items()if k not in ['messages','tools']},'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
summary={'matrix':str(M.relative_to(R)),'planned_generation':15,'complete_generation':len(generation),'planned_text_controls':3,'complete_text_controls':len(text),'generation_outcomes':dict(Counter(c['outcome']for c in generation)),'text_outcomes':dict(Counter(c['outcome']for c in text)),'model_id_requested':d['model'],'raw_response_models':sorted({r.get('response_model')for r in requests if r.get('response_model')}),'fixture_version':d['task_version'],'fixture_sha256':d['task_sha256'],'verifier_sha256':d.get('verifier_sha256'),'request_count':len(requests),'http_status_counts':dict(Counter(str(r.get('status'))for r in requests)),'usage':{k:sum((r.get('usage')or{}).get(k,0)for r in requests)for k in ['prompt_tokens','completion_tokens','total_tokens']},'completion_1500_count':sum((r.get('usage')or{}).get('completion_tokens')==1500 for r in requests),'byte_identical_request_and_response_groups':[{'request_sha256':key[0],'response_sha256':key[1],'members':members}for key,members in duplicates.items()if len(members)>1],'independence_limit':'Each complete case has a fresh process/profile/workspace/memory. Equal request and SSE hashes show repeated upstream output; do not infer independent stochastic trials.','sampling_and_output_options':first,'cases':items}
(B/('quality-summary-contract-final.json' if phase=='anonymous-matrix-contract-final' else 'quality-summary-protocol.json')).write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps({k:summary[k]for k in ['complete_generation','complete_text_controls','generation_outcomes','text_outcomes','request_count','http_status_counts','completion_1500_count']},ensure_ascii=False))
