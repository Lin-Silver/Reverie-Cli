from pathlib import Path
import hashlib,json,os,zipfile
ROOT=Path('/workspace/Reverie-Cli');BASE=ROOT/'.runtime/riu-cloud-20261020';OUT=ROOT/'docs/verification/2026-10-20-riu-cloud'
OUT.mkdir(exist_ok=True)
archive=OUT/'final-evidence.zip';manifest=[]
skip={'app-root','desktop-home','workspace','temp','sdk','xvfb','__pycache__','node_modules'}
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for parent,dirs,names in os.walk(BASE):
  dirs[:]=sorted(d for d in dirs if (d not in skip and not d.endswith('-home')) or 'model-artifacts' in Path(parent).parts)
  for name in sorted(names):
   p=Path(parent)/name
   if p.is_symlink()or p.suffix in {'.zip','.deb','.exe'}or 'config' in p.name.lower():continue
   if p.suffix.lower()not in {'.json','.txt','.log','.md','.html','.sse','.headers','.xml','.png','.py','.css','.js','.patch','.body','.ini'}:continue
   data=p.read_bytes();relative=str(p.relative_to(ROOT));z.writestr(relative,data);manifest.append({'path':relative,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 package_lock=BASE/'sdk/package-lock.json'
 if package_lock.exists():
  data=package_lock.read_bytes();relative=str(package_lock.relative_to(ROOT));z.writestr(relative,data);manifest.append({'path':relative,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
record={'scope':'All retained current-run evidence; model HTML only from model-artifacts snapshots; excludes profiles/configs/caches/binaries/SDK distribution','archive':'final-evidence.zip','archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(manifest),'entries':manifest}
(OUT/'final-manifest.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:record[k]for k in ['archive_bytes','archive_sha256','files']}))
