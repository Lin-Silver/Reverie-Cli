"""Write the reviewable final record from retained actual evidence."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import shutil
import subprocess

ROOT = Path('/workspace/Reverie-Cli')
BASE = ROOT / '.runtime/riu-cloud-20261020'
OUT = ROOT / 'docs/verification/2026-10-20-riu-cloud'

def read(name):
    return json.loads((BASE / name).read_text())

python_log = (BASE / 'python-full-12.txt').read_text()
match = re.search(r'(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s', python_log)
assert match and match.group(1) == '2103', 'Final root-invocation full suite must finish successfully first.'
python_result = {'passed': int(match[1]), 'skipped': int(match[2]),
                 'warnings': int(match[3]), 'seconds': float(match[4]),
                 'log': '.runtime/riu-cloud-20261020/python-full-12.txt',
                 'junit': '.runtime/riu-cloud-20261020/python-full-12.xml',
                 'cwd': str(ROOT), 'display': ':93',
                 'command': 'DISPLAY=:93 .venv/bin/python -m pytest -q -c ReverieCli-py/pytest.ini ReverieCli-py/tests -o junit_family=xunit1 --junitxml=.runtime/riu-cloud-20261020/python-full-12.xml'}
artifacts = read('artifacts-catalog-final.json')
standalone = read('standalone-catalog-final.json')
assert artifacts['passed']
for module in artifacts['frozen_modules']:
    source = ROOT / 'ReverieCli-py' / (module['module'].replace('.', '/') + '.py')
    assert hashlib.sha256(source.read_bytes()).hexdigest() == module['source_sha256'], source

consumers = {}
for name in ('p2', 'p3', 'p4'):
    d = read(name + '-catalog-final/report.json')
    assert d['passed'] and all(c['passed'] for c in d['checks'])
    consumers[name] = {'passed': len(d['checks']), 'total': len(d['checks']),
                       'report': '.runtime/riu-cloud-20261020/' + name + '-catalog-final/report.json'}
isolation = read('isolation-catalog-final.json')
assert isolation['evaluation']['passed']
consumers['isolation'] = {'passed': len(isolation['checks']), 'total': len(isolation['checks']),
                          'metrics': isolation['metrics'],
                          'report': '.runtime/riu-cloud-20261020/isolation-catalog-final.json'}
p4 = read('p4-catalog-final/report.json')
performance = {key: p4['measurements'][key] for key in
               ('registration_to_interactive_upper_bound', 'local_input_to_two_animation_frames_1000_rows')}

quality = read('quality-summary-final.json')
previous = read('quality-summary-protocol.json')
hf = read('hf-free-api-search-20261021/summary.json')
opencode = read('opencode-production-20261021/report.json')
raw_source = BASE / 'final-source'
raw_source.mkdir(exist_ok=True)
changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines()
changed += ['ReverieCli-py/tests/test_provider_retry_after.py', 'scripts/verification/desktop_process.py']
source_manifest = []
for relative in sorted(set(changed)):
    source = ROOT / relative
    if not source.is_file() or source.suffix not in ('.py', '.ini'):
        continue
    target = raw_source / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    source_manifest.append({'path': relative, 'sha256': hashlib.sha256(source.read_bytes()).hexdigest()})
(BASE / 'source-final.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=ROOT))
(BASE / 'final-source-manifest.json').write_text(json.dumps(source_manifest, indent=2) + '\n')

report = {
    'status': 'Verification completed; real-model generation quality gate not met; additional compatible free model and native Windows/macOS validation remain blocked by current service/platform availability.',
    'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
    'baseline': '350c5baaed1b41f399ca09e01b912a4f81eaa80e',
    'source_state': 'Uncommitted reviewable changes; no version bump, release, commit or push.',
    'platform': 'Linux x86_64 / Xvfb / Electron 41.2.1 / Python 3.12.14 / Node 24.19.0',
    'checks': {
        'python_latest': python_result,
        'python_before_final_recorder_test': 'python-full-9:2102/24/14 warnings;147.01s',
        'python_core_cwd_final': 'python-full-11:2103/24/14 warnings;121.48s',
        'python_root_collection_failure_retained': 'python-full-10:2 collection errors; core scripts namespace missing from sys.path. pytest.ini now explicitly includes its directory; exact documented root invocation rerun in python-full-12.',
        'desktop_latest': {'passed': 383, 'skipped': 1, 'seconds': 73.04,
                           'log': '.runtime/riu-cloud-20261020/desktop-full-5.txt'},
        'typecheck': {'passed': True, 'translations': 1041, 'templates': 82,
                      'log': '.runtime/riu-cloud-20261020/typecheck-5.txt'},
        'focused_source_and_recorder': {'passed': 53, 'seconds': 5.00,
                                        'log': '.runtime/riu-cloud-20261020/catalog-recorder-final-green.txt'},
        'desktop_build_id': 'f83a5d6f50971c66',
        'standalone_final': standalone,
        'frozen_verification': {'passed': True, 'modules': len(artifacts['frozen_modules']),
                                'ui_files': 71, 'manifest_matches': True,
                                'standalone_hash_in_trust_manifest': True,
                                'report': '.runtime/riu-cloud-20261020/artifacts-catalog-final.json'},
        **consumers,
        'local_performance': performance,
        'measurement_boundary': 'Native Linux deterministic consumer fixtures; no concurrent build/compression/model batch. Not model generation speed or quality. Older build measurements retained separately.',
        'legacy_report_scope_label': 'Retained P3/P4 raw scope strings say Windows; actual binaries/build/hardware/runtime are Linux. Future verifier labels made platform-neutral; no Windows claim.',
    },
    'fixes': [
        'Honor Retry-After seconds/HTTP date across main SDK/direct HTTP retry paths with cancellation; ordinary 402 stays terminal.',
        'Anonymous OpenAI Chat uses existing direct HTTP path without fake credentials.',
        'Reject incomplete tool JSON through original executor before discovery/effects, including after normalization; complete imperfect-escape recovery retained.',
        'Drop nameless sparse stream placeholders; assign valid missing tool IDs once before history and execution.',
        'Exclude old empty-ID orphan tool results only from outbound copy; preserve original history/native thinking.',
        'Remove automatic plain-chat retries that hid declared tools/history on HTTP errors.',
        'Resolve official OpenCode inference catalog separately from OpenAI chat path; custom hosts/query/legacy routes retained.',
        'Clarify interactive-answer selection and sandbox-compatible local buttons/inline validation; no iframe permission expansion.',
        'Record native Linux independent-profile quality cases; preserve raw requests/SSE and actual identity; reject zero-assertion or no-view false positives.',
        'Classify missing required accessible controls and unchanged modification reference explicitly; settle parent/child animation frames before real pointer checks.',
        'Isolate live Windows modifiers in synthetic input tests; distinguish imported tokenizer from available encoding data.',
        'Set pytest core import path explicitly so documented repository-root full-suite invocation resolves core scripts.',
    ],
    'quality_final': quality,
    'quality_before_form_contract': previous,
    'providers': {
        'opencode_production': {
            'catalog_http_status': 200, 'catalog_url': 'https://opencode.ai/inference/v1/models',
            'chat_url': 'https://opencode.ai/inference/openai/v1/chat/completions',
            'model': 'deepseek-v4.1-flash-free', 'generation_requests': len(opencode['cases'][0]['requests']),
            'generation_status': 403, 'error': 'FreeTierError: free tier only usable within OpenCode',
            'actual_identity': opencode['cases'][0]['requests'][0].get('client_identity'),
            'anonymous': True, 'identity_spoofing': False,
            'report': '.runtime/riu-cloud-20261020/opencode-production-20261021/report.json'},
        'pollinations_classic': {'alias': 'openai-fast', 'actual_response_model': 'gpt-oss-20b',
                                 'anonymous': True, 'aliases_count_as_multiple_models': False},
        'hugging_face_search': hf,
    },
    'agent_operated_model_html_review': {
        'form': {'report': '.runtime/riu-cloud-20261020/agent-inspection-form/report.json',
                 'findings': 'Quantity3 total240, Tab order and PiP fit; actual submit click failed, dark theme/state reload failed. Synthetic submit diagnostic never counted as user interaction pass.'},
        'chart': {'report': '.runtime/riu-cloud-20261020/agent-inspection-chart/report.json',
                  'restart_report': '.runtime/riu-cloud-20261020/agent-inspection-chart-restart/report.json',
                  'findings': 'Apply2=>720, zero/negative feedback; no live-input recalculation, missing rows, theme/state failure; actual process restart changed2=>1.'},
        'table': {'report': '.runtime/riu-cloud-20261020/agent-inspection-table-second/report.json',
                  'findings': 'Keyword/clear/PiP work; missing empty feedback and dark text failure. Immediate OOPIF pointer4/5 lost; parent+component two frames then5/5 real clicks.'},
        'all_original_html_unchanged': True, 'manual_review_model_requests': 0,
        'scope': 'Actual native packaged GUI at each recorded host build displaying preserved earlier real-model outputs; not counted as final matrix successes.'},
    'historical_failures_retained': [
        'Original Windows2098/2/1 and isolated1pass retained; Linux synthetic modifiers do not prove physical IME behavior.',
        'Linux initial61failures, missing package startup, P3 single-instance overlap and exploratory loaded performance retained.',
        'Original interrupted/cancelled/contaminated matrices and raw classification errors retained.',
        'One genuine verifier pointer race excluded and rerun; semantic failures retained; environment-interrupted cases not complete samples.',
        'JUnit xunit2 format warnings retained; final compatible xunit1 export avoids those45 reporting warnings.',
    ],
    'boundaries_preserved': ['Original executor approvals/ownership/session locks', 'Private _meta',
                             'Opaque allow-scripts iframe/CSP', 'Complete native thinking',
                             '27 native tool schemas', 'No product-added output/thinking cap',
                             'No new model key/payment/signup/client spoofing'],
    'unverified_or_not_passed': [
        'Real-model cross-template generation/modification/theme/restart quality gate:0/15 final generation passes.',
        'Second real model with exposed native tools and complete standard Chat/SSE loop: not available under current no-new-key/free constraints. MiniCPM5 Space text/SSE works but no tools parameters.',
        'New Windows CLI/Desktop/portable/NSIS installer lifecycle; macOS; physical Windows IME and screen reader.',
        'Remote authenticated UI/OAuth, full window.openai and Plugin Extensions; no broader protocol parity claim.',
    ],
    'evidence': {
        'directory': '2026-10-20-riu-cloud/',
        'archives': ['pre-matrix-evidence.zip', 'protocol-failure-evidence.zip', 'final-evidence.zip'],
        'manifests': ['pre-matrix-manifest.json', 'protocol-failure-manifest.json', 'final-manifest.json'],
        'free_api_readme': '2026-10-20-riu-cloud/free-api-search.md',
        'registered_model_artifacts': '.runtime/riu-cloud-20261020/registered-artifacts-manifest.json',
        'final_source_snapshot': '.runtime/riu-cloud-20261020/final-source-manifest.json',
    },
}
for kind, folder in [('form', 'agent-inspection-form'), ('chart', 'agent-inspection-chart'),
                     ('table', 'agent-inspection-table-second')]:
    inspection = read(folder + '/report.json')
    assert inspection['finished'] and inspection['original_model_html_unchanged']
    assert not inspection['requests']
    report['agent_operated_model_html_review'][kind]['host_build'] = inspection['current_host_build']['desktopBuild']
    report['agent_operated_model_html_review'][kind]['original_generation_build'] = inspection['original_generation_build']
(ROOT / 'docs/verification/2026-10-20-riu-cloud.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'python': python_result, 'build': report['checks']['desktop_build_id'],
                  'generation_quality_passes': quality['generation_quality_passes'],
                  'source_snapshot_files': len(source_manifest)}, ensure_ascii=False))
