"""Read the same real model answer in a copied native profile; no model rerun."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, socket, subprocess, sys
ROOT = Path('/workspace/Reverie-Cli')
BASE = ROOT/'.runtime/riu-completion-20261021'
SOURCE = BASE/'rich-answer-native'
OUT = BASE/'rich-answer-actual-themes'
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT/'scripts/verification'))
import riu_quality_benchmark as q
from playwright.sync_api import sync_playwright
digest = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
bound = {str(path): digest(path) for path in [SOURCE/'report.json', SOURCE/'actual-model-session.json']}
app_root, home = OUT/'app-root', OUT/'desktop-home'
shutil.copytree(SOURCE/'app-root', app_root, ignore=shutil.ignore_patterns('browser', 'git-checkpoints'))
settings = home/'.reverie/desktop/desktop-settings.json'
settings.parent.mkdir(parents=True)
settings.write_text(json.dumps({'coreAppRoot': str(app_root), 'projectRoot': str(SOURCE/'workspace'),
 'ui': {'language':'zh-CN', 'showReasoning': False, 'showToolCalls': False, 'showToolResults': False}}))
report = {'scope':'Same actual saved model answer, copied profile, real theme controls and viewport changes. Zero model reruns; original raw verdict preserved.', 'captures':[], 'contrasts':[], 'checks':[]}
color_probe = '''root => {
  const canvas=document.createElement('canvas');canvas.width=canvas.height=1;const ctx=canvas.getContext('2d');
  const rgba=color=>{ctx.clearRect(0,0,1,1);ctx.fillStyle=color;ctx.fillRect(0,0,1,1);return [...ctx.getImageData(0,0,1,1).data];};
  const background=el=>{const chain=[];for(let p=el;p;p=p.parentElement)chain.unshift(p);let rgb=[255,255,255];for(const p of chain){const c=rgba(getComputedStyle(p).backgroundColor),a=c[3]/255;rgb=rgb.map((v,i)=>c[i]*a+v*(1-a));}return rgb;};
  const luminance=rgb=>rgb.map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;}).reduce((v,c,i)=>v+c*[.2126,.7152,.0722][i],0);
  return [...root.querySelectorAll('.answer-metric dt,.answer-metric dd,.answer-card p,.answer-card h3,.answer-badge,.answer-source,.answer-table th,.answer-table td')].filter(el=>el.getBoundingClientRect().width>0 && el.innerText.trim() && !el.querySelector('.answer-badge')).map(el=>{const style=getComputedStyle(el),fg=rgba(style.color),bg=background(el),a=fg[3]/255,visible=fg.slice(0,3).map((v,i)=>v*a+bg[i]*(1-a)),l=[luminance(visible),luminance(bg)],ratio=(Math.max(...l)+.05)/(Math.min(...l)+.05),minimum=parseFloat(style.fontSize)>=24||(parseFloat(style.fontSize)>=18.66&&Number(style.fontWeight)>=700)?3:4.5;return {text:el.innerText,foreground:visible,background:bg,ratio,minimum,passed:ratio>=minimum};});
}'''
process = None
log = (OUT/'electron.log').open('x')
try:
 with sync_playwright() as playwright:
  with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  env={**os.environ,'DISPLAY':':94','PORTABLE_EXECUTABLE_DIR':str(home),'REVERIE_APP_ROOT':str(app_root)};env.pop('ELECTRON_RUN_AS_NODE',None)
  process=subprocess.Popen([str(ROOT/'ReverieCli-ui/release/linux-unpacked/ReverieUI'),'--gui','--project',str(SOURCE/'workspace'),f'--remote-debugging-port={port}'],env=env,stdout=log,stderr=subprocess.STDOUT,**q.launch_options())
  browser,page=q.wait_for_packaged_page(playwright,process,port)
  page.set_viewport_size({'width':1280,'height':1800});page.wait_for_selector('textarea[aria-autocomplete=list]',timeout=120000)
  page.locator('.session-item').filter(has_text='富格式检查：真实模型回答').click(timeout=30000)
  target=page.locator('.message.assistant .answer-markdown').last;target.locator('.answer-card').first.wait_for(timeout=30000)
  for theme,label in [('dark','深色'),('light','浅色')]:
   page.get_by_role('button',name='切换主题',exact=True).click();page.locator('.theme-menu').get_by_role('button',name=label,exact=False).click();page.wait_for_function('t=>document.documentElement.dataset.theme===t',arg=theme)
   contrast=target.evaluate(color_probe);report['contrasts'].append({'theme':theme,'samples':contrast});report['checks'].append({'name':'actual-answer-text-contrast-'+theme,'passed':bool(contrast) and all(x['passed'] for x in contrast)})
   for width in [1280,460]:
    page.set_viewport_size({'width':width,'height':1800});page.wait_for_timeout(300)
    path=OUT/f'actual-answer-{theme}-{width}.png';target.screenshot(path=str(path));report['captures'].append({'path':str(path),'sha256':digest(path),'theme':theme,'viewport':page.viewport_size,'answer_css_box':target.bounding_box()})
   page.set_viewport_size({'width':1280,'height':1800})
  browser.close()
except Exception as error:report['error']=type(error).__name__+': '+str(error)
finally:
 q.stop_process(process);log.close();report['original_native_report_and_saved_actual_answer_unchanged']=all(digest(path)==sha for path,sha in bound.items());report['checks'].append({'name':'original-model-evidence-unchanged','passed':report['original_native_report_and_saved_actual_answer_unchanged']});report['passed']=not report.get('error') and all(x['passed'] for x in report['checks']);report['finished_at_utc']=datetime.now(timezone.utc).isoformat();(OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'passed':report['passed'],'error':report.get('error'),'captures':len(report['captures']),'contrast_failures':[x for theme in report['contrasts'] for x in theme['samples'] if not x['passed']]},ensure_ascii=False))
raise SystemExit(0 if report['passed'] else 2)
